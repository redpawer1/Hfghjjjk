#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Health Check — Browser, memory, proxy monitoring
"""

import asyncio
import logging
import psutil
from datetime import datetime
from typing import Optional, Callable

logger = logging.getLogger("HealthCheck")


class HealthCheck:
    def __init__(self, bot_instance=None, alert_func: Callable = None):
        self.bot = bot_instance
        self.alert = alert_func
        self.running = False
        self.check_interval = 300  # 5 دقائق
        self.last_check = None
        self.issues = []
        
        # العتبات
        self.memory_threshold = 85
        self.cpu_threshold = 90
        self.browser_timeout = 60
    
    async def start(self):
        """بدء المراقبة."""
        self.running = True
        logger.info("Health check started")
        
        while self.running:
            await self._check()
            await asyncio.sleep(self.check_interval)
    
    def stop(self):
        self.running = False
    
    async def _check(self):
        """فحص شامل."""
        self.last_check = datetime.now()
        self.issues = []
        
        # فحص الذاكرة
        mem = psutil.virtual_memory()
        if mem.percent > self.memory_threshold:
            self.issues.append(f"ذاكرة عالية: {mem.percent}%")
            await self._handle_high_memory()
        
        # فحص CPU
        cpu = psutil.cpu_percent(interval=1)
        if cpu > self.cpu_threshold:
            self.issues.append(f"CPU عالي: {cpu}%")
        
        # فحص المتصفح
        if self.bot:
            browser_ok = await self._check_browser()
            if not browser_ok:
                self.issues.append("المتصفح علق")
                await self._restart_browser()
        
        # فحص القرص
        disk = psutil.disk_usage('/')
        if disk.percent > 90:
            self.issues.append(f"القرص ممتلئ: {disk.percent}%")
        
        if self.issues:
            logger.warning("Health issues: %s", self.issues)
            if self.alert:
                await self.alert(f"⚠️ مشاكل:\n" + "\n".join(self.issues))
        else:
            logger.debug("Health check OK")
    
    async def _check_browser(self) -> bool:
        """فحص المتصفح."""
        if not self.bot or not hasattr(self.bot, "page"):
            return True
        
        page = self.bot.page
        if not page:
            return False
        
        try:
            # محاولة تنفيذ JavaScript بسيط
            result = await asyncio.wait_for(
                page.evaluate("1 + 1"),
                timeout=self.browser_timeout
            )
            return result == 2
        except asyncio.TimeoutError:
            logger.warning("Browser timeout")
            return False
        except Exception as e:
            logger.warning("Browser check failed: %s", e)
            return False
    
    async def _handle_high_memory(self):
        """معالجة الذاكرة العالية."""
        if self.bot and hasattr(self.bot, "history"):
            old_len = len(self.bot.history)
            self.bot.history = set(list(self.bot.history)[-1000:])
            logger.info("Cleaned history: %d -> %d", old_len, len(self.bot.history))
        
        if self.bot and hasattr(self.bot, "invalid"):
            self.bot.invalid = set(list(self.bot.invalid)[-500:])
    
    async def _restart_browser(self):
        """إعادة تشغيل المتصفح."""
        if not self.bot:
            return
        
        logger.info("Restarting browser...")
        
        try:
            restart = getattr(self.bot, "restart_browser", None)
            if callable(restart):
                recovered = await restart("health_check")
            else:
                if hasattr(self.bot, "_close_browser"):
                    await self.bot._close_browser()
                await asyncio.sleep(5)
                if hasattr(self.bot, "_launch_browser"):
                    await self.bot._launch_browser()
                recovered = True

            if not recovered:
                raise RuntimeError(
                    getattr(self.bot, "_last_collection_error", "resume_failed")
                )
            logger.info("Browser restarted and collection resumed")
            
            if self.alert:
                await self.alert("🔄 تم إعادة تشغيل المتصفح")
        except Exception as e:
            logger.error("Browser restart failed: %s", e)
            if self.alert:
                await self.alert(f"❌ فشل إعادة تشغيل المتصفح: {e}")
    
    def get_status(self) -> dict:
        """حالة النظام."""
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        return {
            "last_check": self.last_check.isoformat() if self.last_check else None,
            "memory_percent": mem.percent,
            "cpu_percent": psutil.cpu_percent(),
            "disk_percent": disk.percent,
            "issues": self.issues,
            "healthy": len(self.issues) == 0,
        }

health_check = HealthCheck()
