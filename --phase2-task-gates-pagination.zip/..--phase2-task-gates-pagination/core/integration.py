#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Integration Layer
يربط الأنظمة الجديدة بـ main.py بدون تعديل الملف الأصلي
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional, Any

from .database import db
from .risk_manager import risk_manager
from .monitor import monitor
from .human_behavior import human
from .pending_queue import pending_queue
from .retry import retry_system
from .proof_collector import proof_collector

logger = logging.getLogger("Integration")

class BotIntegration:
    """طبقة التكامل بين الأنظمة الجديدة والبوت الأصلي."""
    
    def __init__(self, bot_instance):
        self.bot = bot_instance
        self._initialized = False
    
    async def initialize(self, telegram_send_func=None):
        """تهيئة الأنظمة."""
        if self._initialized:
            return
        
        # ربط إرسال تيليجرام
        if telegram_send_func:
            monitor.send = telegram_send_func
            pending_queue.send = telegram_send_func
        
        # بدء المراقبة في الخلفية
        asyncio.create_task(monitor.start())
        
        self._initialized = True
        logger.info("Integration layer initialized")
    
    async def before_task(self, url: str, platform: str, price: float = 0) -> tuple:
        """فحوصات قبل تنفيذ المهمة."""
        
        # 1. فحص الحدود اليومية
        can_exec, reason = risk_manager.can_execute(platform)
        if not can_exec:
            logger.info("Skipping task: %s", reason)
            return False, reason
        
        # 2. فحص صحة المنصة
        if risk_manager.should_skip_platform(platform):
            return False, f"platform_unhealthy:{platform}"
        
        # 3. فحص المحاولات السابقة
        attempts = db.get_task_attempts(url)
        if attempts >= retry_system.max_attempts:
            return False, "max_attempts_reached"
        
        # 4. فحص إذا المهمة اتنفذت قبل كده
        if db.is_task_done(url):
            return False, "already_done"
        
        # 5. تسجيل المهمة
        db.add_task(url, "", platform, [], price)
        
        return True, ""
    
    async def after_task(self, url: str, platform: str, success: bool, 
                         price: float = 0, reason: str = "", proofs: dict = None):
        """تسجيل بعد تنفيذ المهمة."""
        
        # تحديث الإحصائيات
        risk_manager.record_execution(platform, success, price)
        
        # تحديث حالة المهمة
        status = "done" if success else "failed"
        db.update_task_status(url, status, reason, proofs)
        
        # تغذية راجعة
        if not success and reason:
            db.add_feedback(url, True, reason)
            risk_manager.check_auto_block(reason)
        
        # تنبيه
        await monitor.task_completed(platform, price, success)
        
        # استراحة عشوائية
        if human.should_take_break():
            await human.take_break()
    
    async def human_click(self, page, selector: str):
        """ضغط بشري."""
        await human.before_click(page, selector)
        await page.click(selector)
        await human.after_action()
    
    async def human_fill(self, page, selector: str, text: str):
        """كتابة بشرية."""
        await human.before_click(page, selector)
        await human.typing_delay(text)
        await page.fill(selector, text)
        await human.after_action()
    
    async def collect_proofs(self, page, platform: str, proof_types: list) -> dict:
        """جمع الإثباتات."""
        return await proof_collector.collect_proofs(page, platform, proof_types)
    
    async def add_to_pending(self, url: str, data: dict, reason: str):
        """إضافة مهمة معلقة."""
        await pending_queue.add(url, data, reason)
    
    async def handle_telegram_command(self, command: str, args: str = "") -> str:
        """معالجة أوامر تيليجرام."""
        
        if command == "/status":
            status = risk_manager.get_status()
            sys_stats = monitor.get_system_stats()
            return (
                f"📊 الحالة\n"
                f"✅ منفذ: {status['tasks_done']}\n"
                f"❌ فشل: {status['tasks_failed']}\n"
                f"💰 أرباح: {status['earnings']:.2f}₽\n"
                f"📦 متبقي: {status['daily_remaining']}\n"
                f"🖥 CPU: {sys_stats['cpu']}%\n"
                f"💾 RAM: {sys_stats['memory']}%"
            )
        
        elif command == "/stats":
            summary = db.get_stats_summary()
            return (
                f"📈 الإحصائيات\n"
                f"إجمالي: {summary['total']}\n"
                f"ناجح: {summary['done']}\n"
                f"فاشل: {summary['failed']}\n"
                f"أرباح: {summary['earnings']:.2f}₽"
            )
        
        elif command == "/pending":
            return await pending_queue.process_telegram_command("/pending", "")
        
        elif command == "/resume":
            return await pending_queue.process_telegram_command("/resume", args)
        
        elif command == "/skip":
            return await pending_queue.process_telegram_command("/skip", args)
        
        elif command == "/pause":
            self.bot.running = False
            return "⏸ تم إيقاف البوت"
        
        elif command == "/start":
            self.bot.running = True
            return "▶️ تم تشغيل البوت"
        
        return ""
    
    def cleanup_memory(self, history: set, invalid: set, validated: set, max_size: int = 2000):
        """تنظيف الذاكرة."""
        if len(history) > max_size:
            history = set(list(history)[-max_size:])
        if len(invalid) > max_size:
            invalid = set(list(invalid)[-max_size:])
        if len(validated) > max_size:
            validated = set(list(validated)[-max_size:])
        return history, invalid, validated
    
    async def shutdown(self):
        """إغلاق نظيف."""
        monitor.stop()
        db.cleanup_old_tasks()
        proof_collector.cleanup_old_proofs()
        logger.info("Integration shutdown complete")

# دالة مساعدة للربط
def create_integration(bot_instance) -> BotIntegration:
    return BotIntegration(bot_instance)
