#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Daily Report — تقارير يومية
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Callable

logger = logging.getLogger("DailyReport")


class DailyReport:
    """نظام التقارير اليومية"""
    
    def __init__(self):
        self.last_report_date: Optional[str] = None
        self.report_hour = 23  # الساعة 11 مساءً
        self._send_func: Optional[Callable] = None
    
    def set_sender(self, func: Callable):
        """تعيين دالة الإرسال"""
        self._send_func = func
    
    def should_send_report(self) -> bool:
        """هل يجب إرسال التقرير؟"""
        now = datetime.now()
        today = now.strftime("%Y-%m-%d")
        
        if self.last_report_date == today:
            return False
        
        if now.hour >= self.report_hour:
            return True
        
        return False
    
    def generate_report(self, stats: dict) -> str:
        """توليد نص التقرير"""
        today = datetime.now().strftime("%Y-%m-%d")
        
        # حساب نسبة النجاح
        done = stats.get('tasks_done', 0)
        failed = stats.get('failed', 0)
        total = done + failed
        rate = (done / total * 100) if total > 0 else 0
        
        # تفصيل المنصات
        platforms = stats.get('platforms', {})
        platform_lines = ""
        if platforms:
            for p, count in sorted(platforms.items(), key=lambda x: -x[1])[:5]:
                platform_lines += f"\n  • {p}: {count}"
        
        return f"""📊 **تقرير يومي — {today}**

✅ مهام منجزة: {done}
💰 أرباح: {stats.get('earnings', 0):.2f} ₽
❌ فشل: {failed}
⏭️ تخطي: {stats.get('skipped', 0)}

📈 نسبة النجاح: {rate:.1f}%

🏆 المنصات:{platform_lines if platform_lines else ' N/A'}
💵 أعلى سعر: {stats.get('highest_price', 0):.2f} ₽
📦 إجمالي الفحص: {stats.get('checked', 0)}
"""
    
    async def send_if_needed(self, stats: dict) -> bool:
        """إرسال التقرير لو لازم"""
        if not self.should_send_report():
            return False
        
        if not self._send_func:
            logger.warning("No sender configured for daily report")
            return False
        
        try:
            report = self.generate_report(stats)
            await self._send_func(report)
            self.last_report_date = datetime.now().strftime("%Y-%m-%d")
            logger.info("Daily report sent")
            return True
        except Exception as e:
            logger.error("Failed to send daily report: %s", e)
            return False


# Singleton
daily_report = DailyReport()
