#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Session Manager — Session validation, auto-refresh, backup
"""

import asyncio
import json
import logging
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict

logger = logging.getLogger("SessionManager")

SESSIONS_DIR = Path("/root/sessions")
BACKUP_DIR = Path("/root/unu-bot/data/session_backups")


class SessionManager:
    def __init__(self):
        self.sessions: Dict[str, Dict] = {}
        self.current_session: Optional[str] = None
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    
    def load_session(self, name: str, path: Path = None) -> Optional[Dict]:
        """تحميل جلسة."""
        if path is None:
            path = SESSIONS_DIR / f"{name}.json"
        
        if not path.exists():
            logger.warning("Session not found: %s", path)
            return None
        
        try:
            data = json.loads(path.read_text())
            self.sessions[name] = {
                "path": path,
                "data": data,
                "loaded_at": datetime.now(),
                "valid": True,
            }
            logger.info("Loaded session: %s", name)
            return data
        except Exception as e:
            logger.error("Failed to load session %s: %s", name, e)
            return None
    
    def save_session(self, name: str, data: Dict) -> bool:
        """حفظ جلسة."""
        path = SESSIONS_DIR / f"{name}.json"
        try:
            path.write_text(json.dumps(data, ensure_ascii=False, indent=2))
            if name in self.sessions:
                self.sessions[name]["data"] = data
                self.sessions[name]["loaded_at"] = datetime.now()
            logger.info("Saved session: %s", name)
            return True
        except Exception as e:
            logger.error("Failed to save session %s: %s", name, e)
            return False
    
    def backup_session(self, name: str) -> Optional[Path]:
        """نسخ احتياطي للجلسة."""
        if name not in self.sessions:
            return None
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = BACKUP_DIR / f"{name}_{timestamp}.json"
        
        try:
            shutil.copy(self.sessions[name]["path"], backup_path)
            logger.info("Backed up session: %s -> %s", name, backup_path.name)
            return backup_path
        except Exception as e:
            logger.error("Failed to backup session %s: %s", name, e)
            return None
    
    def backup_all(self):
        """نسخ احتياطي لكل الجلسات."""
        for name in self.sessions:
            self.backup_session(name)
        
        # تنظيف النسخ القديمة (الاحتفاظ بآخر 10)
        for name in self.sessions:
            backups = sorted(BACKUP_DIR.glob(f"{name}_*.json"))
            for old in backups[:-10]:
                old.unlink()
                logger.debug("Removed old backup: %s", old.name)
    
    async def validate_session(self, page, name: str) -> bool:
        """التحقق من صلاحية الجلسة."""
        try:
            await page.goto("https://unu.im/account", timeout=30000)
            await asyncio.sleep(2)
            
            # فحص إذا فيه زر تسجيل دخول
            login_btn = await page.query_selector('a[href*="login"]')
            if login_btn:
                logger.warning("Session invalid: %s", name)
                if name in self.sessions:
                    self.sessions[name]["valid"] = False
                return False
            
            logger.info("Session valid: %s", name)
            return True
        except Exception as e:
            logger.error("Session validation failed: %s", e)
            return False
    
    def get_storage_state(self, name: str) -> Optional[Dict]:
        """الحصول على storage state للجلسة."""
        if name not in self.sessions:
            self.load_session(name)
        
        if name in self.sessions:
            return self.sessions[name]["data"]
        return None
    
    def list_sessions(self) -> list:
        """قائمة الجلسات المتاحة."""
        sessions = []
        for path in SESSIONS_DIR.glob("*.json"):
            name = path.stem
            sessions.append({
                "name": name,
                "path": str(path),
                "size": path.stat().st_size,
                "modified": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
                "loaded": name in self.sessions,
                "valid": self.sessions.get(name, {}).get("valid", None),
            })
        return sessions
    
    def get_status(self) -> Dict:
        """حالة الجلسات."""
        return {
            "loaded": len(self.sessions),
            "available": len(list(SESSIONS_DIR.glob("*.json"))),
            "current": self.current_session,
            "backups": len(list(BACKUP_DIR.glob("*.json"))),
        }

session_manager = SessionManager()
