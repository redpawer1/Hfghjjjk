"""UNU Bot Core Modules"""

from .database import db, Database
from .risk_manager import risk_manager, RiskManager
from .monitor import monitor, Monitor
from .human_behavior import human, HumanBehavior
from .pending_queue import pending_queue, PendingQueue
from .retry import retry_system, RetrySystem
from .proof_collector import proof_collector, ProofCollector
from .integration import BotIntegration, create_integration
from .proxy_manager import proxy_manager, ProxyManager
from .session_manager import session_manager, SessionManager
from .backup import backup_system, BackupSystem
from .health_check import health_check, HealthCheck
from .anti_detect import anti_detect, AntiDetect

__all__ = [
    'db', 'Database',
    'risk_manager', 'RiskManager',
    'monitor', 'Monitor',
    'human', 'HumanBehavior',
    'pending_queue', 'PendingQueue',
    'retry_system', 'RetrySystem',
    'proof_collector', 'ProofCollector',
    'BotIntegration', 'create_integration',
    'proxy_manager', 'ProxyManager',
    'session_manager', 'SessionManager',
    'backup_system', 'BackupSystem',
    'health_check', 'HealthCheck',
    'anti_detect', 'AntiDetect',
]

from .local_ai import local_classifier, smart_classifier, classify_local, learn_from_task, get_ai_stats
__all__.extend(['local_classifier', 'smart_classifier', 'classify_local', 'learn_from_task', 'get_ai_stats'])
