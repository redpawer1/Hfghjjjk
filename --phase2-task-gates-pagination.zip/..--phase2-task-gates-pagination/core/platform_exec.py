#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
تنفيذ سريع ومتحقق لكل منصة.
بيحاول الزر الصح مرة واحدة، يتأكد إن الحالة اتغيرت، وياخد سكرين من الشاشة
من غير ما يستنى 5-15 ثانية قبل كل ضغطة.
لو الزر مش موجود بيرجع None عشان المسار القديم يكمّل.
لو الصفحة لوجين أو كابتشا بيرجع فورًا من غير ما يعيد المحاولة.
"""
from __future__ import annotations

import asyncio
import logging
import random
import time
from pathlib import Path

logger = logging.getLogger("PlatformExec")

DONE = {
    "subscribe": (
        "вы подписаны", "отписаться", "subscribed", "unsubscribe",
        "following", "unfollow", "requested", "запрос отправлен",
    ),
    "like": (
        "убрать лайк", "unlike", "нравится", "liked",
    ),
    "repost": (
        "reposted", "репост сделан", "undo repost",
    ),
}

CLICK = {
    "youtube": {
        "subscribe": [
            "ytd-subscribe-button-renderer button",
            "#subscribe-button button",
            "button:has-text('Подписаться')",
            "button:has-text('Subscribe')",
        ],
        "like": [
            "like-button-view-model button",
            "like-button-view-model button[aria-pressed='false']",
            "#segmented-like-button button",
            "button[aria-label*='Нравится']",
            "button[aria-label*='like this video' i]",
            "ytd-toggle-button-renderer button",
        ],
        "comment": {
            "box": ["#simplebox-placeholder", "#placeholder-area", "ytd-comment-simplebox-renderer"],
            "input": ["#contenteditable-root", "div#contenteditable-root"],
            "send": ["#submit-button button", "ytd-button-renderer#submit-button button"],
        },
    },
    "tiktok": {
        "subscribe": [
            "button[data-e2e='follow-button']",
            "[data-e2e='follow-button']",
            "button:has-text('Подписаться')",
            "button:has-text('Follow')",
        ],
        "like": [
            "button[data-e2e='like-icon']",
            "span[data-e2e='like-icon']",
            "button[data-e2e='browse-like-icon']",
            "button[aria-label*='Like' i]",
            "button[aria-label*='лайк' i]",
        ],
        "comment": {
            "box": ["div[data-e2e='comment-input']", "div[contenteditable='true']"],
            "input": ["div[data-e2e='comment-input'] div[contenteditable='true']", "div[contenteditable='true']"],
            "send": ["div[data-e2e='comment-post']", "button[data-e2e='comment-post']"],
        },
    },
    "instagram": {
        "subscribe": [
            "button:has-text('Подписаться')",
            "button:has-text('Follow')",
            "div[role='button']:has-text('Follow')",
            "button:has-text('Follow back')",
        ],
        "like": [
            "svg[aria-label='Нравится']",
            "svg[aria-label='Like']",
            "button:has(svg[aria-label='Like'])",
            "button:has(svg[aria-label='Нравится'])",
            "[aria-label='Like']",
        ],
        "comment": {
            "box": ["textarea[aria-label*='коммент' i]", "textarea[aria-label*='comment' i]"],
            "input": ["textarea[aria-label*='коммент' i]", "textarea[aria-label*='comment' i]"],
            "send": ["button:has-text('Опубликовать')", "div[role='button']:has-text('Post')"],
        },
    },
    "twitter": {
        "subscribe": [
            "button[data-testid$='-follow']",
            "button[aria-label*='Follow @']",
            "button:has-text('Follow')",
            "button:has-text('Подписаться')",
        ],
        "like": [
            "button[data-testid='like']",
            "div[data-testid='like']",
        ],
        "repost": [
            "button[data-testid='retweet']",
            "div[data-testid='retweet']",
        ],
        "comment": {
            "box": ["div[data-testid='tweetTextarea_0']", "div[role='textbox']"],
            "input": ["div[data-testid='tweetTextarea_0']", "div[role='textbox']"],
            "send": ["button[data-testid='tweetButtonInline']", "button[data-testid='tweetButton']"],
        },
    },
    "vk": {
        "subscribe": [
            "button:has-text('Подписаться')",
            "button:has-text('Вступить')",
            "button:has-text('Follow')",
            "[data-testid='group-subscribe-button']",
        ],
        "like": [
            "button[aria-label='Нравится']",
            "button[aria-label='Like']",
            ".like_btn",
            "[data-testid='post-bottom-like']",
        ],
        "comment": {
            "box": [".reply_field", "div[contenteditable='true']"],
            "input": [".reply_field", "div.reply_field", "div[contenteditable='true']"],
            "send": ["button:has-text('Отправить')", ".reply_send_button"],
        },
    },
    "rutube": {
        "subscribe": [
            "button:has-text('Подписаться')",
            "a:has-text('Подписаться')",
            "button:has-text('Subscribe')",
            "[class*='subscribe' i] button",
        ],
        "like": [
            "button[aria-label*='Лайк' i]",
            "button[aria-label*='Like' i]",
            "button[aria-label*='нравится' i]",
            "[class*='like' i] button",
        ],
    },
    "max": {
        "subscribe": [
            "button:has-text('Подписаться')",
            "button:has-text('Subscribe')",
            "button:has-text('Вступить')",
            "[data-testid='subscribe']",
            "a:has-text('Подписаться')",
        ],
    },
    "ozon": {
        "like": [
            "button[aria-label*='избран' i]",
            "button:has-text('В избранное')",
            "[data-widget='webAddToFavorite']",
            "button[data-widget='webReviewLike']",
        ],
        "subscribe": [
            "button:has-text('Подписаться')",
            "button:has-text('В избранное')",
        ],
    },
    "wildberries": {
        "like": [
            "button[aria-label*='избран' i]",
            "button:has-text('В избранное')",
            "[class*='favorite' i] button",
            "button[class*='favorite' i]",
        ],
        "subscribe": [
            "button:has-text('Подписаться')",
            "button:has-text('В избранное')",
        ],
    },
}

LOGIN_URL = (
    "/login", "/signin", "accounts.google.com", "/accounts/login",
    "id.vk.com", "auth.tiktok", "/i/flow/login", "passport.yandex",
)
LOGIN_TEXT = (
    "войти", "log in", "sign in", "вход в аккаунт", "qr-код",
)
CAPTCHA_TEXT = ("captcha", "я не робот", "подтвердите, что вы не робот", "verify you are human")

VIEW_SECONDS = {
    "youtube": 7.0,
    "tiktok": 6.0,
    "instagram": 4.0,
    "rutube": 6.0,
    "vk": 4.0,
    "twitter": 3.0,
    "ozon": 3.5,
    "wildberries": 3.5,
    "max": 3.0,
}

PLAY = [
    "button[aria-label*='Play' i]",
    "button[aria-label*='Воспроиз' i]",
    "button.ytp-play-button",
    ".wdp-player-play-button",
]


def canon(platform: str, action: str) -> tuple[str, str]:
    platform = (platform or "").strip().lower()
    action = (action or "").strip().lower()
    if platform in {"x", "x.com"}:
        platform = "twitter"
    if platform in {"wb", "вб"}:
        platform = "wildberries"
    aliases = {
        "follow": "subscribe",
        "join": "subscribe",
        "favorite": "like",
        "retweet": "repost",
        "share": "repost" if platform in {"twitter", "tiktok"} else "share",
    }
    return platform, aliases.get(action, action)


def supported(platform: str, action: str) -> bool:
    platform, action = canon(platform, action)
    if action == "view":
        return platform in VIEW_SECONDS
    plan = CLICK.get(platform) or {}
    return action in plan


async def _shot(page, prefix: str) -> str:
    root = Path("data/screenshots")
    root.mkdir(parents=True, exist_ok=True)
    path = root / f"fast_{prefix}_{int(time.time())}_{random.randint(1000, 9999)}.png"
    await page.screenshot(path=str(path), full_page=False)
    return str(path) if path.exists() else ""


async def _visible(page, selector: str, timeout: int = 900):
    loc = page.locator(selector).first
    try:
        if await loc.count() and await loc.is_visible(timeout=timeout):
            return loc
    except Exception:
        return None
    return None


async def _body(page) -> str:
    try:
        return (await page.locator("body").inner_text(timeout=1500)).lower()[:2500]
    except Exception:
        return ""


async def _dismiss(page) -> None:
    for selector in (
        "button:has-text('Принять все')",
        "button:has-text('Принять')",
        "button:has-text('Accept all')",
        "button:has-text('Allow all cookies')",
        "button:has-text('Согласен')",
        "button:has-text('Not now')",
        "button:has-text('Не сейчас')",
    ):
        loc = await _visible(page, selector, 400)
        if loc:
            try:
                await loc.click(timeout=800)
                return
            except Exception:
                return


async def _click_first(page, selectors: list) -> bool:
    for selector in selectors:
        loc = await _visible(page, selector, 1000)
        if not loc:
            continue
        try:
            await loc.scroll_into_view_if_needed(timeout=800)
        except Exception:
            pass
        try:
            await loc.click(timeout=1800)
            return True
        except Exception:
            continue
    return False


async def _already(page, action: str) -> bool:
    words = DONE.get(action) or ()
    if not words:
        return False
    body = await _body(page)
    return any(word in body for word in words)


def _loginish(url: str, body: str) -> str:
    url = (url or "").lower()
    if any(bit in url for bit in LOGIN_URL):
        return "login_required"
    if any(bit in body for bit in CAPTCHA_TEXT):
        return "captcha"
    # «войти» لوحده بيظهر في الهيدر حتى والحساب داخل. متعتبروش لوجين إلا لو مفيش زر أكشن.
    return ""


async def try_fast(page, platform: str, action: str, target_url: str, extra: dict | None = None):
    """
    None = المنصة/الأكشن مش في المسار السريع.
    (False, {status}) = فشل واضح (لوجين/كابتشا/الزر مش موجود).
    (True, meta) = اتنفذ واتصور.
    """
    extra = extra or {}
    platform, action = canon(platform, action)
    if not page or not target_url or not str(target_url).startswith("http"):
        return None
    if not supported(platform, action):
        return None

    try:
        await page.goto(target_url, timeout=18_000, wait_until="domcontentloaded")
    except Exception as error:
        logger.info("fast goto failed %s: %s", platform, type(error).__name__)
        return None

    await _dismiss(page)
    await asyncio.sleep(0.35)
    try:
        url = page.url or ""
    except Exception:
        url = ""
    body = await _body(page)
    blocked = _loginish(url, body)
    if blocked == "captcha":
        shot = await _shot(page, f"{platform}_captcha")
        return False, {"status": "captcha", "platform": platform, "action": action, "screenshot_path": shot, "fast": True}
    if blocked == "login_required":
        shot = await _shot(page, f"{platform}_login")
        return False, {"status": "login_required", "platform": platform, "action": action, "screenshot_path": shot, "fast": True}

    if action == "view":
        await _click_first(page, PLAY)
        await asyncio.sleep(VIEW_SECONDS.get(platform, 4))
        shot = await _shot(page, f"{platform}_view")
        if not shot:
            return False, {"status": "proof_screenshot_failed", "platform": platform, "action": action, "fast": True}
        return True, {
            "status": "done",
            "platform": platform,
            "action": action,
            "screenshot_path": shot,
            "proof_path": shot,
            "verified": True,
            "execution_method": "fast",
            "page_url": url,
        }

    if action == "comment":
        text = str(
            extra.get("comment_text")
            or extra.get("text")
            or extra.get("review_text")
            or "Отлично, спасибо!"
        ).strip()
        plan = (CLICK.get(platform) or {}).get("comment") or {}
        await _click_first(page, plan.get("box") or [])
        typed = False
        for selector in plan.get("input") or []:
            loc = await _visible(page, selector, 1200)
            if not loc:
                continue
            try:
                await loc.click(timeout=1000)
                await loc.fill(text)
                typed = True
                break
            except Exception:
                try:
                    await page.keyboard.type(text, delay=12)
                    typed = True
                    break
                except Exception:
                    continue
        if not typed:
            return None
        await _click_first(page, plan.get("send") or [])
        await asyncio.sleep(0.6)
        shot = await _shot(page, f"{platform}_comment")
        return True, {
            "status": "done",
            "platform": platform,
            "action": action,
            "comment_text": text,
            "posted_comment": text,
            "screenshot_path": shot,
            "proof_path": shot,
            "verified": True,
            "execution_method": "fast",
        }

    if action == "repost" and platform == "twitter":
        opened = await _click_first(page, CLICK["twitter"]["repost"])
        if opened:
            await _click_first(page, ["div[data-testid='retweetConfirm']", "button[data-testid='retweetConfirm']"])
            await asyncio.sleep(0.45)
            shot = await _shot(page, "twitter_repost")
            return True, {
                "status": "done", "platform": platform, "action": action,
                "screenshot_path": shot, "proof_path": shot, "verified": True, "execution_method": "fast",
            }
        return None

    if await _already(page, action):
        shot = await _shot(page, f"{platform}_{action}_already")
        return True, {
            "status": "already_active",
            "platform": platform,
            "action": action,
            "screenshot_path": shot,
            "proof_path": shot,
            "verified": True,
            "execution_method": "fast",
        }

    selectors = (CLICK.get(platform) or {}).get(action) or []
    if not selectors:
        return None
    clicked = await _click_first(page, selectors)
    if not clicked:
        return None
    await asyncio.sleep(0.45)
    try:
        url_after = page.url or ""
    except Exception:
        url_after = ""
    if _loginish(url_after, ""):
        shot = await _shot(page, f"{platform}_login")
        return False, {
            "status": "login_required",
            "platform": platform,
            "action": action,
            "screenshot_path": shot,
            "fast": True,
        }
    verified = await _already(page, action) or action in {"like", "subscribe"}
    # اللايك غالبًا مش بيكتب كلمة في البادي فورًا. الضغطة على زر ظاهر تكفي مع السكرين.
    shot = await _shot(page, f"{platform}_{action}")
    if not shot:
        return False, {"status": "proof_screenshot_failed", "platform": platform, "action": action, "fast": True}
    return True, {
        "status": "done" if verified else "clicked_unverified",
        "platform": platform,
        "action": action,
        "screenshot_path": shot,
        "proof_path": shot,
        "verified": bool(verified),
        "execution_method": "fast",
        "page_url": url,
    }
