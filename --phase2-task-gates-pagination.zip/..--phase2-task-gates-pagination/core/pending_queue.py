#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Pending Queue — Handle captcha, manual assist, deferred tasks
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import Optional, Dict, Any, Callable
from .database import db

logger = logging.getLogger("PendingQueue")

class PendingQueue:
    def __init__(self, telegram_send: Callable = None):
        self.send = telegram_send
        self._waiting_response: Dict[str, asyncio.Future] = {}
    
    async def add(self, url: str, data: dict, reason: str) -> bool:
        """Add task to pending queue."""
        db.add_pending_task(url, data, reason)
        logger.info("Added to pending: %s | reason: %s", url[:50], reason)
        
        if self.send and reason == "manual_assist":
            await self.send(
                f"⏳ مهمة معلقة تحتاج مساعدة:\n"
                f"الرابط: {url}\n"
                f"السبب: {reason}\n"
                f"رد بـ /resume {url[:20]} للإكمال"
            )
        
        return True
    
    async def get_all(self) -> list:
        """Get all pending tasks."""
        return db.get_pending_tasks()
    
    async def remove(self, url: str):
        """Remove task from pending."""
        db.remove_pending_task(url)
        if url in self._waiting_response:
            del self._waiting_response[url]
        logger.info("Removed from pending: %s", url[:50])
    
    async def resume(self, url: str, response_data: dict = None) -> Optional[dict]:
        """Resume a pending task."""
        tasks = await self.get_all()
        for task in tasks:
            if url in task['url']:
                data = json.loads(task['data'])
                data['response'] = response_data
                await self.remove(task['url'])
                logger.info("Resuming task: %s", task['url'][:50])
                return data
        return None
    
    async def wait_for_response(self, url: str, timeout: float = 1800) -> Optional[dict]:
        """Wait for user response on Telegram."""
        future = asyncio.get_event_loop().create_future()
        self._waiting_response[url] = future
        
        try:
            result = await asyncio.wait_for(future, timeout=timeout)
            return result
        except asyncio.TimeoutError:
            logger.warning("Timeout waiting for response: %s", url[:50])
            return None
        finally:
            if url in self._waiting_response:
                del self._waiting_response[url]
    
    def provide_response(self, url: str, response: dict):
        """Provide response from Telegram."""
        if url in self._waiting_response:
            self._waiting_response[url].set_result(response)
            return True
        return False
    
    async def process_telegram_command(self, command: str, args: str) -> str:
        """Process Telegram commands for pending tasks."""
        if command == "/pending":
            tasks = await self.get_all()
            if not tasks:
                return "لا توجد مهام معلقة"
            msg = "📋 المهام المعلقة:\n"
            for t in tasks[:10]:
                msg += f"• {t['url'][:40]}... ({t['reason']})\n"
            return msg
        
        elif command == "/resume":
            if not args:
                return "استخدم: /resume <url>"
            data = await self.resume(args)
            if data:
                return f"✅ تم استئناف المهمة"
            return "❌ المهمة غير موجودة"
        
        elif command == "/skip":
            if not args:
                return "استخدم: /skip <url>"
            await self.remove(args)
            return "✅ تم تخطي المهمة"
        
        return ""

pending_queue = PendingQueue()
