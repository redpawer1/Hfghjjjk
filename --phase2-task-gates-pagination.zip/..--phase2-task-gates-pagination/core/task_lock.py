#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Task Lock — منع تضارب المهام المتزامنة
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional, Set

logger = logging.getLogger("TaskLock")


class TaskLock:
    """قفل لمنع تنفيذ نفس المهمة مرتين."""
    
    def __init__(self):
        self._lock = asyncio.Lock()
        self._running: Set[str] = set()
        self._completed: Set[str] = set()
        self._max_completed = 10000
    
    async def acquire(self, task_id: str) -> bool:
        """
        محاولة الحصول على قفل المهمة.
        يرجع True لو نجح، False لو المهمة شغالة أو خلصت.
        """
        async with self._lock:
            if task_id in self._running:
                logger.debug("Task %s already running", task_id)
                return False
            if task_id in self._completed:
                logger.debug("Task %s already completed", task_id)
                return False
            self._running.add(task_id)
            return True
    
    async def release(self, task_id: str, completed: bool = True):
        """تحرير القفل بعد الانتهاء."""
        async with self._lock:
            self._running.discard(task_id)
            if completed:
                self._completed.add(task_id)
                # تنظيف الذاكرة
                if len(self._completed) > self._max_completed:
                    to_remove = list(self._completed)[:1000]
                    for t in to_remove:
                        self._completed.discard(t)
    
    def is_running(self, task_id: str) -> bool:
        return task_id in self._running
    
    def is_completed(self, task_id: str) -> bool:
        return task_id in self._completed
    
    def get_stats(self) -> dict:
        return {
            "running": len(self._running),
            "completed": len(self._completed),
        }


# Singleton
task_lock = TaskLock()
