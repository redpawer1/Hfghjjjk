#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Safety Config — ربط إعدادات الأمان
"""

import os
import logging
from typing import Optional

logger = logging.getLogger("SafetyConfig")


class SafetyConfig:
    """إعدادات الأمان المتصلة بـ .env"""
    
    def __init__(self):
        self._load()
    
    def _load(self):
        """تحميل الإعدادات من البيئة"""
        self.max_tasks_per_day = int(os.getenv("MAX_TASKS_PER_DAY", "500"))
        self.max_tasks_per_platform = int(os.getenv("MAX_TASKS_PER_PLATFORM", "100"))
        self.require_human_approval = os.getenv("REQUIRE_HUMAN_APPROVAL", "true").lower() in ("true", "1", "yes")
        self.min_price = float(os.getenv("MIN_PRICE", "0.0"))
        self.max_price = float(os.getenv("MAX_PRICE", "999999.0"))
        
        logger.info("Safety config loaded: max_daily=%d, human_approval=%s", 
                   self.max_tasks_per_day, self.require_human_approval)
    
    def check_daily_limit(self, tasks_done: int) -> bool:
        """فحص الحد اليومي"""
        if tasks_done >= self.max_tasks_per_day:
            logger.warning("Daily limit reached: %d/%d", tasks_done, self.max_tasks_per_day)
            return False
        return True
    
    def check_price(self, price: float) -> bool:
        """فحص السعر"""
        return self.min_price <= price <= self.max_price
    
    def needs_approval(self, task_type: str = None) -> bool:
        """هل المهمة محتاجة موافقة؟"""
        if not self.require_human_approval:
            return False
        # مهام حساسة دايمًا محتاجة موافقة
        sensitive = {"withdraw", "payment", "kyc", "verification"}
        if task_type and task_type.lower() in sensitive:
            return True
        return self.require_human_approval
    
    def reload(self):
        """إعادة تحميل الإعدادات"""
        self._load()


# Singleton
safety_config = SafetyConfig()
