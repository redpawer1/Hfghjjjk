#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Smart Filter — فلاتر ذكية للمهام
"""

import logging
from typing import List, Dict, Any, Optional

logger = logging.getLogger("SmartFilter")


class SmartFilter:
    """فلاتر ذكية لاختيار أفضل المهام"""
    
    def __init__(self):
        self.min_price = 0.0
        self.max_price = 999999.0
        self.preferred_platforms = []
        self.blocked_platforms = []
        self.preferred_actions = ["subscribe", "like", "view"]
        self.sort_by = "price"  # price, speed, confidence
    
    def set_price_range(self, min_price: float, max_price: float):
        """تحديد نطاق السعر"""
        self.min_price = min_price
        self.max_price = max_price
    
    def set_platforms(self, preferred: List[str] = None, blocked: List[str] = None):
        """تحديد المنصات"""
        if preferred:
            self.preferred_platforms = preferred
        if blocked:
            self.blocked_platforms = blocked
    
    def filter_tasks(self, tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """فلترة المهام"""
        filtered = []
        
        for task in tasks:
            price = float(task.get("price", 0))
            platform = task.get("platform", "").lower()
            
            # فحص السعر
            if not (self.min_price <= price <= self.max_price):
                continue
            
            # فحص المنصة المحظورة
            if platform in self.blocked_platforms:
                continue
            
            filtered.append(task)
        
        # ترتيب حسب الأولوية
        return self._sort_tasks(filtered)
    
    def _sort_tasks(self, tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """ترتيب المهام"""
        if self.sort_by == "price":
            return sorted(tasks, key=lambda t: float(t.get("price", 0)), reverse=True)
        elif self.sort_by == "confidence":
            return sorted(tasks, key=lambda t: float(t.get("confidence", 0)), reverse=True)
        return tasks
    
    def calculate_priority(self, task: Dict[str, Any]) -> float:
        """حساب أولوية المهمة"""
        price = float(task.get("price", 0))
        confidence = float(task.get("confidence", 0.5))
        platform = task.get("platform", "")
        
        # صيغة الأولوية
        priority = (price * 10) + (confidence * 20)
        
        # مكافأة للمنصات المفضلة
        if platform in self.preferred_platforms:
            priority += 15
        
        return priority
    
    def get_best_tasks(self, tasks: List[Dict[str, Any]], limit: int = 10) -> List[Dict[str, Any]]:
        """الحصول على أفضل المهام"""
        filtered = self.filter_tasks(tasks)
        
        # حساب الأولوية لكل مهمة
        for task in filtered:
            task["_priority"] = self.calculate_priority(task)
        
        # ترتيب حسب الأولوية
        sorted_tasks = sorted(filtered, key=lambda t: t.get("_priority", 0), reverse=True)
        
        return sorted_tasks[:limit]


# Singleton
smart_filter = SmartFilter()
