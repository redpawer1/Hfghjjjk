#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Risk Manager — Daily limits, platform health, auto-blocking
"""

import logging
from datetime import datetime
from typing import Optional
from .database import db

logger = logging.getLogger("RiskManager")

class RiskManager:
    def __init__(self):
        self.daily_limit = 500
        self.platform_daily_limit = 50
        self.max_reject_rate = 0.30
        self.max_attempts = 3
        self._platform_daily: dict = {}
        self._today = datetime.now().strftime("%Y-%m-%d")
    
    def _reset_if_new_day(self):
        today = datetime.now().strftime("%Y-%m-%d")
        if today != self._today:
            self._platform_daily = {}
            self._today = today
            logger.info("Daily counters reset")
    
    def can_execute(self, platform: str = None) -> tuple:
        """Check if we can execute more tasks."""
        self._reset_if_new_day()
        
        stats = db.get_daily_stats()
        total_today = stats.get("tasks_done", 0) + stats.get("tasks_failed", 0)
        
        if total_today >= self.daily_limit:
            return False, "daily_limit_reached"
        
        if platform:
            platform_count = self._platform_daily.get(platform, 0)
            if platform_count >= self.platform_daily_limit:
                return False, f"platform_limit:{platform}"
        
        return True, ""
    
    def record_execution(self, platform: str, success: bool, price: float = 0):
        """Record task execution."""
        self._reset_if_new_day()
        
        self._platform_daily[platform] = self._platform_daily.get(platform, 0) + 1
        
        if success:
            db.update_daily_stats(tasks_done=1, earnings=price)
            db.update_platform_stats(platform, success=True)
        else:
            db.update_daily_stats(tasks_failed=1)
            db.update_platform_stats(platform, success=False)
    
    def should_skip_platform(self, platform: str) -> bool:
        """Check if platform has high reject rate."""
        stats = db.get_platform_stats(platform)
        total = stats.get("total", 0)
        failed = stats.get("failed", 0)
        
        if total < 10:
            return False
        
        reject_rate = failed / total
        if reject_rate > self.max_reject_rate:
            logger.warning("Platform %s reject rate %.1f%% > 30%%", platform, reject_rate * 100)
            return True
        
        return False
    
    def check_auto_block(self, reason: str) -> bool:
        """Check if we should auto-add block rule."""
        count = db.get_rejection_count(reason)
        if count >= 3:
            logger.warning("Reason '%s' rejected %d times, adding block rule", reason, count)
            db.add_block_rule(reason, reason, auto=True)
            return True
        return False
    
    def get_priority_score(self, price: float, confidence: float, 
                           is_risky: bool, is_compound: bool, platform: str) -> int:
        """Calculate priority score."""
        score = 50
        
        score += int(price * 10)
        score += int(confidence * 20)
        
        if is_risky:
            score -= 30
        
        if not is_compound:
            score += 15
        
        easy = {"telegram", "vk", "tiktok", "instagram"}
        if platform in easy:
            score += 10
        
        if self.should_skip_platform(platform):
            score -= 50
        
        return max(0, min(100, score))
    
    def get_status(self) -> dict:
        """Get current risk status."""
        stats = db.get_daily_stats()
        return {
            "today": self._today,
            "tasks_done": stats.get("tasks_done", 0),
            "tasks_failed": stats.get("tasks_failed", 0),
            "earnings": stats.get("earnings", 0),
            "daily_remaining": self.daily_limit - stats.get("tasks_done", 0) - stats.get("tasks_failed", 0),
            "platform_counts": self._platform_daily,
        }

risk_manager = RiskManager()
