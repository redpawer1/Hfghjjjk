#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Error Logger — تسجيل شامل لكل الأخطاء
"""

import logging
import traceback
import json
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional, Any

# مجلد اللوجات — بيتلف لوحده عشان سنة تشغيل ما تملاش القرص
LOGS_DIR = Path(os_logs if (os_logs := __import__("os").getenv("LOGS_DIR")) else "/root/unu-bot/data/logs")
try:
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    LOGS_DIR = Path("data/logs")
    LOGS_DIR.mkdir(parents=True, exist_ok=True)

ERROR_LOG = LOGS_DIR / "errors.log"
DEBUG_LOG = LOGS_DIR / "debug.log"
TASK_LOG = LOGS_DIR / "tasks.log"


def _rotating(path: Path, level: int) -> logging.Logger:
    name = f"ErrorLog.{path.stem}"
    log = logging.getLogger(name)
    log.setLevel(level)
    if not log.handlers:
        handler = RotatingFileHandler(path, maxBytes=5_000_000, backupCount=5, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        log.addHandler(handler)
        log.propagate = False
    return log


class ErrorLogger:
    def __init__(self):
        self.error_count = 0
        self.warning_count = 0
        
        # إعداد اللوج
        self._setup_loggers()
    
    def _setup_loggers(self):
        """إعداد ملفات اللوج بتدوير."""
        self.error_logger = _rotating(ERROR_LOG, logging.ERROR)
        self.debug_logger = _rotating(DEBUG_LOG, logging.DEBUG)
        self.task_logger = _rotating(TASK_LOG, logging.INFO)
    
    def error(self, message: str, exc: Optional[Exception] = None, context: dict = None):
        """تسجيل خطأ."""
        self.error_count += 1
        
        error_data = {
            "time": datetime.now().isoformat(),
            "message": message,
            "context": context or {},
        }
        
        if exc:
            error_data["exception"] = str(exc)
            error_data["traceback"] = traceback.format_exc()
        
        self.error_logger.error(json.dumps(error_data, ensure_ascii=False))
    
    def warning(self, message: str, context: dict = None):
        """تسجيل تحذير."""
        self.warning_count += 1
        self.debug_logger.warning(f"{message} | {context or {}}")
    
    def debug(self, message: str, data: Any = None):
        """تسجيل debug."""
        if data:
            self.debug_logger.debug(f"{message} | {data}")
        else:
            self.debug_logger.debug(message)
    
    def task(self, action: str, url: str, status: str, details: dict = None):
        """تسجيل مهمة."""
        task_data = {
            "action": action,
            "url": url,
            "status": status,
            "details": details or {},
        }
        self.task_logger.info(json.dumps(task_data, ensure_ascii=False))
    
    def get_stats(self) -> dict:
        """إحصائيات الأخطاء."""
        return {
            "errors": self.error_count,
            "warnings": self.warning_count,
        }


# Singleton
error_logger = ErrorLogger()
