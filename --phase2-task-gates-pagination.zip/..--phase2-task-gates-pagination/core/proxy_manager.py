#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Proxy Manager — Health checks, rotation, sticky sessions
"""

import asyncio
import logging
import random
from datetime import datetime, timedelta
from typing import Optional, List, Dict
import httpx

logger = logging.getLogger("ProxyManager")


class ProxyManager:
    def __init__(self):
        self.proxies: List[Dict] = []
        self.current_proxy: Optional[Dict] = None
        self.sticky_until: Optional[datetime] = None
        self.sticky_duration = timedelta(minutes=30)
        self.health_check_url = "https://unu.im"
        self.timeout = 15
    
    def add_proxy(self, server: str, username: str = "", password: str = "", protocol: str = "http"):
        """إضافة بروكسي."""
        proxy = {
            "server": server,
            "username": username,
            "password": password,
            "protocol": protocol,
            "url": f"{protocol}://{username}:{password}@{server}" if username else f"{protocol}://{server}",
            "healthy": True,
            "last_check": None,
            "failures": 0,
        }
        self.proxies.append(proxy)
        logger.info("Added proxy: %s", server)
    
    def add_proxy_url(self, url: str):
        """إضافة بروكسي من URL."""
        # http://user:pass@host:port
        if "@" in url:
            protocol = url.split("://")[0]
            rest = url.split("://")[1]
            auth, server = rest.split("@")
            username, password = auth.split(":")
            self.add_proxy(server, username, password, protocol)
        else:
            protocol = url.split("://")[0]
            server = url.split("://")[1]
            self.add_proxy(server, "", "", protocol)
    
    async def check_health(self, proxy: Dict) -> bool:
        """فحص صحة البروكسي."""
        try:
            async with httpx.AsyncClient(
                proxy=proxy["url"],
                timeout=self.timeout,
            ) as client:
                response = await client.head(self.health_check_url)
                healthy = response.status_code < 500
                proxy["healthy"] = healthy
                proxy["last_check"] = datetime.now()
                if healthy:
                    proxy["failures"] = 0
                else:
                    proxy["failures"] += 1
                return healthy
        except Exception as e:
            logger.warning("Proxy health check failed: %s - %s", proxy["server"], e)
            proxy["healthy"] = False
            proxy["failures"] += 1
            proxy["last_check"] = datetime.now()
            return False
    
    async def check_all(self):
        """فحص كل البروكسيات."""
        for proxy in self.proxies:
            await self.check_health(proxy)
            await asyncio.sleep(1)
        
        healthy_count = sum(1 for p in self.proxies if p["healthy"])
        logger.info("Proxy health: %d/%d healthy", healthy_count, len(self.proxies))
    
    def get_healthy_proxies(self) -> List[Dict]:
        """الحصول على البروكسيات السليمة."""
        return [p for p in self.proxies if p["healthy"] and p["failures"] < 5]
    
    async def get_proxy(self) -> Optional[Dict]:
        """الحصول على بروكسي (sticky session)."""
        # لو فيه sticky session صالحة
        if self.current_proxy and self.sticky_until and datetime.now() < self.sticky_until:
            if self.current_proxy["healthy"]:
                return self.current_proxy
        
        # اختيار بروكسي جديد
        healthy = self.get_healthy_proxies()
        if not healthy:
            logger.warning("No healthy proxies available")
            return None
        
        self.current_proxy = random.choice(healthy)
        self.sticky_until = datetime.now() + self.sticky_duration
        logger.info("Selected proxy: %s (sticky until %s)", 
                   self.current_proxy["server"], 
                   self.sticky_until.strftime("%H:%M"))
        
        return self.current_proxy
    
    def mark_failed(self, proxy: Dict):
        """تسجيل فشل البروكسي."""
        proxy["failures"] += 1
        if proxy["failures"] >= 3:
            proxy["healthy"] = False
            logger.warning("Proxy marked unhealthy: %s", proxy["server"])
        
        # إلغاء sticky session
        if self.current_proxy == proxy:
            self.current_proxy = None
            self.sticky_until = None
    
    def get_playwright_proxy(self) -> Optional[Dict]:
        """الحصول على إعدادات البروكسي لـ Playwright."""
        if not self.current_proxy:
            return None
        
        return {
            "server": f"{self.current_proxy['protocol']}://{self.current_proxy['server']}",
            "username": self.current_proxy["username"],
            "password": self.current_proxy["password"],
        }
    
    def get_status(self) -> Dict:
        """حالة البروكسيات."""
        return {
            "total": len(self.proxies),
            "healthy": len(self.get_healthy_proxies()),
            "current": self.current_proxy["server"] if self.current_proxy else None,
            "sticky_until": self.sticky_until.isoformat() if self.sticky_until else None,
        }

proxy_manager = ProxyManager()
