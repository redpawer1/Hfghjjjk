#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Retry System — Smart retry with backoff
"""

import asyncio
import logging
from typing import Callable, Any, Optional
from .database import db

logger = logging.getLogger("Retry")

class RetrySystem:
    def __init__(self):
        self.max_attempts = 3
        self.base_delay = 30
        self.permanent_failures = {
            "blocked", "invalid", "rejected", "not_found",
            "session_expired", "captcha_failed", "account_banned"
        }
    
    def is_permanent_failure(self, reason: str) -> bool:
        """Check if failure is permanent."""
        reason_lower = (reason or "").lower()
        return any(pf in reason_lower for pf in self.permanent_failures)
    
    async def should_retry(self, url: str, reason: str) -> tuple:
        """Check if we should retry."""
        if self.is_permanent_failure(reason):
            return False, "permanent_failure"
        
        attempts = db.get_task_attempts(url)
        if attempts >= self.max_attempts:
            return False, "max_attempts_reached"
        
        return True, ""
    
    async def get_delay(self, attempt: int) -> float:
        """Get delay for retry (exponential backoff)."""
        delay = self.base_delay * (2 ** attempt)
        return min(delay, 300)
    
    async def execute_with_retry(self, url: str, func: Callable, *args, **kwargs) -> tuple:
        """Execute function with retry logic."""
        last_error = None
        
        for attempt in range(self.max_attempts):
            try:
                result = await func(*args, **kwargs)
                
                if isinstance(result, dict):
                    if result.get("success"):
                        return True, result
                    
                    reason = result.get("reason", "")
                    if self.is_permanent_failure(reason):
                        logger.info("Permanent failure: %s", reason)
                        return False, result
                
                last_error = result
                
            except Exception as e:
                last_error = str(e)
                logger.warning("Attempt %d failed: %s", attempt + 1, e)
            
            if attempt < self.max_attempts - 1:
                delay = await self.get_delay(attempt)
                logger.info("Retrying in %.0f seconds...", delay)
                await asyncio.sleep(delay)
        
        logger.error("All attempts failed for: %s", url[:50])
        return False, last_error

retry_system = RetrySystem()
