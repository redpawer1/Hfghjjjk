#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI Fallback — تحويل ذكي بين مزودي AI
"""

import asyncio
import logging
import os
from typing import Optional, Any, Callable

logger = logging.getLogger("AIFallback")


class AIFallback:
    """نظام fallback بين مزودي AI"""
    
    def __init__(self):
        self.providers = []
        self.current_index = 0
        self.failure_counts = {}
        self._setup_providers()
    
    def _setup_providers(self):
        """إعداد المزودين المتاحين"""
        if os.getenv("GROQ_API_KEY"):
            self.providers.append("groq1")
        if os.getenv("GROQ_API_KEY_2"):
            self.providers.append("groq2")
        if os.getenv("GEMINI_API_KEY"):
            self.providers.append("gemini")
        if os.getenv("CEREBRAS_API_KEY"):
            self.providers.append("cerebras")
        if os.getenv("MISTRAL_API_KEY"):
            self.providers.append("mistral")
        if os.getenv("DEEPSEEK_API_KEY"):
            self.providers.append("deepseek")
        if os.getenv("OPENROUTER_API_KEY"):
            self.providers.append("openrouter")
        
        for p in self.providers:
            self.failure_counts[p] = 0
        
        logger.info("AI providers available: %s", self.providers)
    
    def get_current_provider(self) -> Optional[str]:
        """الحصول على المزود الحالي"""
        if not self.providers:
            return None
        return self.providers[self.current_index % len(self.providers)]
    
    def mark_failure(self, provider: str):
        """تسجيل فشل مزود"""
        self.failure_counts[provider] = self.failure_counts.get(provider, 0) + 1
        logger.warning("Provider %s failed (count=%d)", provider, self.failure_counts[provider])
        
        # لو فشل 3 مرات، انتقل للتالي
        if self.failure_counts[provider] >= 3:
            self.current_index += 1
            next_provider = self.get_current_provider()
            logger.info("Switching to provider: %s", next_provider)
    
    def mark_success(self, provider: str):
        """تسجيل نجاح مزود"""
        self.failure_counts[provider] = 0
    
    async def execute_with_fallback(self, func: Callable, *args, **kwargs) -> tuple[bool, Any]:
        """
        تنفيذ دالة مع fallback.
        يرجع (success, result)
        """
        if not self.providers:
            logger.error("No AI providers available")
            return False, None
        
        for attempt in range(len(self.providers)):
            provider = self.get_current_provider()
            try:
                result = await func(provider, *args, **kwargs)
                self.mark_success(provider)
                return True, result
            except Exception as e:
                logger.warning("Provider %s error: %s", provider, e)
                self.mark_failure(provider)
        
        return False, None
    
    def get_stats(self) -> dict:
        """إحصائيات المزودين"""
        return {
            "providers": self.providers,
            "current": self.get_current_provider(),
            "failures": dict(self.failure_counts),
        }


# Singleton
ai_fallback = AIFallback()
