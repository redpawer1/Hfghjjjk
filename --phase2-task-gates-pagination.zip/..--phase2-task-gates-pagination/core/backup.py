#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Backup System — Database, sessions, configs
"""

import asyncio
import json
import logging
import shutil
import tarfile
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict

logger = logging.getLogger("Backup")

BACKUP_DIR = Path("/root/unu-bot/data/backups")
DATA_DIR = Path("/root/unu-bot/data")
SESSIONS_DIR = Path("/root/sessions")


class BackupSystem:
    def __init__(self):
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        self.max_backups = 7
    
    def backup_database(self) -> Optional[Path]:
        """نسخ احتياطي لقاعدة البيانات."""
        db_path = DATA_DIR / "unu_bot.db"
        if not db_path.exists():
            logger.warning("Database not found")
            return None
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = BACKUP_DIR / f"db_{timestamp}.db"
        
        try:
            shutil.copy(db_path, backup_path)
            logger.info("Database backed up: %s", backup_path.name)
            return backup_path
        except Exception as e:
            logger.error("Database backup failed: %s", e)
            return None
    
    def backup_sessions(self) -> Optional[Path]:
        """نسخ احتياطي للجلسات."""
        if not SESSIONS_DIR.exists():
            return None
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = BACKUP_DIR / f"sessions_{timestamp}.tar.gz"
        
        try:
            with tarfile.open(backup_path, "w:gz") as tar:
                tar.add(SESSIONS_DIR, arcname="sessions")
            logger.info("Sessions backed up: %s", backup_path.name)
            return backup_path
        except Exception as e:
            logger.error("Sessions backup failed: %s", e)
            return None
    
    def backup_all(self) -> Dict:
        """نسخ احتياطي كامل."""
        results = {
            "timestamp": datetime.now().isoformat(),
            "database": None,
            "sessions": None,
        }
        
        db_backup = self.backup_database()
        if db_backup:
            results["database"] = str(db_backup)
        
        sessions_backup = self.backup_sessions()
        if sessions_backup:
            results["sessions"] = str(sessions_backup)
        
        self._cleanup_old()
        
        return results
    
    def _cleanup_old(self):
        """حذف النسخ القديمة."""
        for pattern in ["db_*.db", "sessions_*.tar.gz"]:
            backups = sorted(BACKUP_DIR.glob(pattern))
            for old in backups[:-self.max_backups]:
                old.unlink()
                logger.debug("Removed old backup: %s", old.name)
    
    def restore_database(self, backup_path: Path) -> bool:
        """استعادة قاعدة البيانات."""
        db_path = DATA_DIR / "unu_bot.db"
        
        try:
            # نسخ احتياطي للحالي أولاً
            if db_path.exists():
                shutil.copy(db_path, db_path.with_suffix(".db.bak"))
            
            shutil.copy(backup_path, db_path)
            logger.info("Database restored from: %s", backup_path.name)
            return True
        except Exception as e:
            logger.error("Database restore failed: %s", e)
            return False
    
    def list_backups(self) -> list:
        """قائمة النسخ الاحتياطية."""
        backups = []
        for path in sorted(BACKUP_DIR.glob("*"), reverse=True):
            backups.append({
                "name": path.name,
                "size": path.stat().st_size,
                "created": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
            })
        return backups
    
    def get_status(self) -> Dict:
        """حالة النسخ الاحتياطي."""
        backups = list(BACKUP_DIR.glob("*"))
        total_size = sum(b.stat().st_size for b in backups)
        
        return {
            "count": len(backups),
            "total_size_mb": round(total_size / 1024 / 1024, 2),
            "latest": backups[-1].name if backups else None,
        }

backup_system = BackupSystem()
