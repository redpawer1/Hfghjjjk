#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Anti-Detection — Advanced Fingerprint & Stealth
"""

import random
import logging
from typing import Dict, List

logger = logging.getLogger("AntiDetect")


class AntiDetect:
    def __init__(self):
        # User agents حديثة
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0",
        ]
        
        # Viewports شائعة
        self.viewports = [
            {"width": 1920, "height": 1080},
            {"width": 1366, "height": 768},
            {"width": 1536, "height": 864},
            {"width": 1440, "height": 900},
            {"width": 1680, "height": 1050},
        ]
        
        # إعدادات روسية ثابتة
        self.locale = "ru-RU"
        self.timezone = "Europe/Moscow"
        
        # بصمة ثابتة للجلسة
        self._session_fingerprint = None
    
    def get_fingerprint(self, new: bool = False) -> Dict:
        """الحصول على بصمة ثابتة للجلسة."""
        if self._session_fingerprint and not new:
            return self._session_fingerprint
        
        self._session_fingerprint = {
            "user_agent": random.choice(self.user_agents),
            "viewport": random.choice(self.viewports),
            "locale": self.locale,
            "timezone": self.timezone,
            "color_scheme": "light",
            "device_scale_factor": 1,
            "has_touch": False,
            "is_mobile": False,
        }
        
        logger.info("Fingerprint: UA=%s, VP=%s", 
                   self._session_fingerprint["user_agent"][:50],
                   self._session_fingerprint["viewport"])
        
        return self._session_fingerprint
    
    def get_browser_args(self) -> List[str]:
        """إعدادات المتصفح للتخفي."""
        return [
            "--disable-blink-features=AutomationControlled",
            "--disable-dev-shm-usage",
            "--no-sandbox",
            "--disable-setuid-sandbox",
            "--disable-infobars",
            "--disable-extensions",
            "--disable-gpu",
            "--disable-web-security",
            "--disable-features=IsolateOrigins,site-per-process",
            "--lang=ru-RU",
        ]
    
    def get_stealth_scripts(self) -> str:
        """سكريبتات التخفي."""
        return """
        // إخفاء webdriver
        Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
        
        // إخفاء automation
        window.chrome = {runtime: {}};
        
        // إخفاء plugins
        Object.defineProperty(navigator, 'plugins', {
            get: () => [1, 2, 3, 4, 5]
        });
        
        // إخفاء languages
        Object.defineProperty(navigator, 'languages', {
            get: () => ['ru-RU', 'ru', 'en-US', 'en']
        });
        
        // إخفاء permissions
        const originalQuery = window.navigator.permissions.query;
        window.navigator.permissions.query = (parameters) => (
            parameters.name === 'notifications' ?
            Promise.resolve({state: Notification.permission}) :
            originalQuery(parameters)
        );
        """


anti_detect = AntiDetect()
