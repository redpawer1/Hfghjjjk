#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Human Behavior — Fast but Natural
"""

import asyncio
import random
import logging

logger = logging.getLogger("HumanBehavior")

class HumanBehavior:
    def __init__(self):
        self.tasks_since_break = 0
        self.break_interval = random.randint(20, 30)
    
    async def delay(self, min_sec: float = 0.5, max_sec: float = 1.5):
        """تأخير قصير بين الإجراءات."""
        delay = random.uniform(min_sec, max_sec)
        await asyncio.sleep(delay)
    
    async def short_delay(self):
        """تأخير قصير جداً (0.2-0.5 ثانية)."""
        await asyncio.sleep(random.uniform(0.2, 0.5))
    
    async def typing_delay(self, text: str):
        """تأخير الكتابة."""
        delay = len(text) * random.uniform(0.02, 0.05)
        await asyncio.sleep(min(delay, 1.0))
    
    async def scroll(self, page, amount: int = 300):
        """تمرير طبيعي."""
        await page.mouse.wheel(0, amount)
        await self.short_delay()
    
    async def random_mouse_move(self, page):
        """حركة ماوس عشوائية."""
        x = random.randint(100, 800)
        y = random.randint(100, 600)
        await page.mouse.move(x, y)
    
    async def should_take_break(self) -> bool:
        """هل يحتاج استراحة؟"""
        self.tasks_since_break += 1
        if self.tasks_since_break >= self.break_interval:
            self.tasks_since_break = 0
            self.break_interval = random.randint(20, 30)
            return True
        return False
    
    async def take_break(self):
        """استراحة قصيرة."""
        delay = random.uniform(5, 15)
        logger.info("Taking break: %.1f sec", delay)
        await asyncio.sleep(delay)


human_behavior = HumanBehavior()

human = human_behavior
