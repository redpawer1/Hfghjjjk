#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Browser Restart — إعادة تشغيل المتصفح تلقائيًا
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import Optional, Callable

logger = logging.getLogger("BrowserRestart")


class BrowserRestart:
    """نظام إعادة تشغيل المتصفح"""
    
    def __init__(self):
        self.error_count = 0
        self.max_errors = 5
        self.last_restart: Optional[datetime] = None
        self.min_restart_interval = timedelta(minutes=5)
        self._restart_func: Optional[Callable] = None
        self.restart_count = 0
    
    def set_restart_func(self, func: Callable):
        """تعيين دالة إعادة التشغيل"""
        self._restart_func = func
    
    def record_error(self):
        """تسجيل خطأ متصفح"""
        self.error_count += 1
        logger.warning("Browser error recorded (count=%d)", self.error_count)
        
        if self.should_restart():
            asyncio.create_task(self.restart())
    
    def record_success(self):
        """تسجيل نجاح"""
        self.error_count = 0
    
    def should_restart(self) -> bool:
        """هل يجب إعادة التشغيل؟"""
        if self.error_count < self.max_errors:
            return False
        
        if self.last_restart:
            elapsed = datetime.now() - self.last_restart
            if elapsed < self.min_restart_interval:
                logger.info("Restart cooldown active")
                return False
        
        return True
    
    async def restart(self) -> bool:
        """إعادة تشغيل المتصفح"""
        if not self._restart_func:
            logger.error("No restart function configured")
            return False
        
        try:
            logger.info("Restarting browser...")
            await self._restart_func()
            self.last_restart = datetime.now()
            self.error_count = 0
            self.restart_count += 1
            logger.info("Browser restarted (total=%d)", self.restart_count)
            return True
        except Exception as e:
            logger.error("Browser restart failed: %s", e)
            return False
    
    def get_stats(self) -> dict:
        """إحصائيات"""
        return {
            "error_count": self.error_count,
            "restart_count": self.restart_count,
            "last_restart": self.last_restart.isoformat() if self.last_restart else None,
        }


# Singleton
browser_restart = BrowserRestart()
