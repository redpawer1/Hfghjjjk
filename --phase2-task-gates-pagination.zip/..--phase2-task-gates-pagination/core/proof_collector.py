#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Proof Collector — Screenshots, usernames, account URLs
"""

import asyncio
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict
from PIL import Image
try:
    from proof_manifest import build_proof_manifest
except ImportError:
    build_proof_manifest = None

logger = logging.getLogger("ProofCollector")

PROOFS_DIR = Path("/root/unu-bot/data/proofs")

class ProofCollector:
    def __init__(self):
        PROOFS_DIR.mkdir(parents=True, exist_ok=True)
    
    async def screenshot(self, page, name: str = "proof") -> Optional[str]:
        """Take screenshot and compress."""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = PROOFS_DIR / f"{name}_{timestamp}.png"
            
            await page.screenshot(path=str(path), full_page=False)
            
            # Compress
            compressed = await self._compress(path)
            final_path = compressed if compressed else path
            return str(final_path)
        except Exception as e:
            logger.error("Screenshot failed: %s", e)
            return None
    
    async def _compress(self, path: Path, max_size: int = 500) -> Optional[Path]:
        """Compress image to max size (KB)."""
        try:
            img = Image.open(path)
            
            if img.mode == 'RGBA':
                img = img.convert('RGB')
            
            quality = 85
            while quality > 20:
                compressed_path = path.with_suffix('.jpg')
                img.save(compressed_path, 'JPEG', quality=quality, optimize=True)
                
                if compressed_path.stat().st_size <= max_size * 1024:
                    path.unlink()
                    return compressed_path
                
                quality -= 10
            
            return path
        except Exception as e:
            logger.warning("Compression failed: %s", e)
            return None
    
    async def extract_username(self, page, platform: str) -> Optional[str]:
        """Extract username from page."""
        selectors = {
            "telegram": ['.tgme_page_title', '.tgme_channel_info_header_title'],
            "vk": ['.page_name', '.owner_panel_name'],
            "instagram": ['h2', '.username'],
            "tiktok": ['h1[data-e2e="user-title"]', '.username'],
            "twitter": ['[data-testid="UserName"]'],
            "youtube": ['#channel-handle', 'yt-formatted-string.ytd-channel-name'],
            "rutube": ['.channel-header__title', '[class*="channel"] h1'],
            "max": ['[data-testid="profile-name"]', '[class*="profile"] [class*="name"]'],
        }
        
        for selector in selectors.get(platform, []):
            try:
                element = await page.query_selector(selector)
                if element:
                    text = await element.inner_text()
                    if text:
                        return text.strip()
            except:
                pass
        
        return None
    
    async def get_account_url(self, page, platform: str) -> Optional[str]:
        """Get current account URL."""
        try:
            url = page.url
            
            patterns = {
                "telegram": "t.me/",
                "vk": "vk.com/",
                "instagram": "instagram.com/",
                "tiktok": "tiktok.com/@",
                "twitter": "x.com/",
                "youtube": ("youtube.com/@", "youtube.com/channel/"),
                "rutube": "rutube.ru/channel/",
                "max": ("max.ru/u/", "max.ru/@"),
            }
            
            pattern = patterns.get(platform, "")
            if isinstance(pattern, tuple):
                if any(item in url for item in pattern):
                    return url
            elif pattern and pattern in url:
                return url
            
            return None
        except:
            return None
    
    async def collect_proofs(self, page, platform: str, proof_types: List[str]) -> Dict:
        """Collect all required proofs."""
        proofs = {}
        
        for proof_type in proof_types:
            if proof_type == "screenshot":
                proofs["screenshot"] = await self.screenshot(page, f"{platform}_proof")
            
            elif proof_type == "screenshot_start":
                proofs["screenshot_start"] = await self.screenshot(page, f"{platform}_start")
            
            elif proof_type == "screenshot_end":
                proofs["screenshot_end"] = await self.screenshot(page, f"{platform}_end")
            
            elif proof_type == "username":
                proofs["username"] = await self.extract_username(page, platform)
            
            elif proof_type == "account_url":
                proofs["account_url"] = await self.get_account_url(page, platform)

        screenshot = proofs.get("screenshot") or proofs.get("screenshot_end")
        if screenshot and build_proof_manifest:
            proofs["manifest"] = build_proof_manifest(
                screenshot,
                platform=platform,
                page_url=getattr(page, "url", ""),
                stage="end" if "screenshot_end" in proofs else "single",
            )
        
        return proofs
    
    def cleanup_old_proofs(self, days: int = 7):
        """Remove old proof files."""
        import time
        cutoff = time.time() - (days * 86400)
        
        for f in PROOFS_DIR.glob("*"):
            if f.stat().st_mtime < cutoff:
                f.unlink()
                logger.debug("Removed old proof: %s", f.name)

proof_collector = ProofCollector()
