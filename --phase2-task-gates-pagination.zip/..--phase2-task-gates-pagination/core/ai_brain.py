#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot AI Brain — نظام ذكاء هجين
محلي سريع + API للمهام المعقدة + تعلم مستمر
"""

import asyncio
import json
import logging
import re
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Tuple, Any
from collections import Counter
import httpx

logger = logging.getLogger("AIBrain")

DATA_DIR = Path("/root/unu-bot/data")
BRAIN_FILE = DATA_DIR / "ai_brain.json"


class AIBrain:
    """
    الدماغ الذكي للبوت:
    1. تصنيف محلي سريع (كلمات مفتاحية)
    2. ذاكرة للمهام السابقة
    3. API خارجي للمهام المعقدة
    4. تعلم من النتائج
    """
    
    def __init__(self):
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        
        # الذاكرة
        self.memory: Dict[str, Dict] = {}
        
        # الكلمات المفتاحية
        self.platform_words: Dict[str, Counter] = {}
        self.action_words: Dict[str, Counter] = {}
        
        # الأنماط المحظورة
        self.blocked_patterns: List[str] = [
            r"kyc", r"верификац", r"паспорт", r"документ",
            r"крипт", r"crypto", r"usdt", r"btc", r"eth",
            r"кошел[её]к", r"wallet", r"обмен",
            r"регистрац.*сайт", r"создать.*аккаунт",
            r"clck\.ru", r"myapelsin", r"clickkk",
        ]
        
        # إعدادات API
        self.api_config = {
            "enabled": False,
            "provider": "groq",
            "api_key": "",
            "model": "llama-3.1-8b-instant",
            "timeout": 30,
        }
        
        # إحصائيات
        self.stats = {
            "local_hits": 0,
            "memory_hits": 0,
            "api_calls": 0,
            "blocked": 0,
            "learned": 0,
        }
        
        self._load()
    
    def _load(self):
        """تحميل البيانات المحفوظة."""
        if BRAIN_FILE.exists():
            try:
                data = json.loads(BRAIN_FILE.read_text())
                self.memory = data.get("memory", {})
                self.stats = data.get("stats", self.stats)
                self.api_config.update(data.get("api_config", {}))
                
                # إعادة بناء الكلمات
                for key, item in self.memory.items():
                    self._update_keywords(item.get("text", ""), 
                                         item.get("platform", ""),
                                         item.get("actions", []))
                
                logger.info("AI Brain loaded: %d memories", len(self.memory))
            except Exception as e:
                logger.warning("Failed to load AI brain: %s", e)
    
    def _save(self):
        """حفظ البيانات."""
        data = {
            "memory": dict(list(self.memory.items())[-2000:]),
            "stats": self.stats,
            "api_config": {k: v for k, v in self.api_config.items() if k != "api_key"},
            "updated": datetime.now().isoformat(),
        }
        BRAIN_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2))
    
    def _hash(self, text: str) -> str:
        """هاش للنص."""
        return hashlib.md5(text.lower().strip().encode()).hexdigest()[:16]
    
    def _tokenize(self, text: str) -> List[str]:
        """تقسيم النص."""
        text = text.lower()
        text = re.sub(r'https?://\S+', ' ', text)
        words = re.findall(r'[а-яёa-z]{3,}', text)
        return words
    
    def _update_keywords(self, text: str, platform: str, actions: List[str]):
        """تحديث الكلمات المفتاحية."""
        words = self._tokenize(text)
        
        if platform and platform != "unknown":
            if platform not in self.platform_words:
                self.platform_words[platform] = Counter()
            self.platform_words[platform].update(words)
        
        for action in actions:
            if action and action != "unknown":
                if action not in self.action_words:
                    self.action_words[action] = Counter()
                self.action_words[action].update(words)
    
    def is_blocked(self, text: str) -> Tuple[bool, str]:
        """فحص إذا المهمة محظورة."""
        text_lower = text.lower()
        
        for pattern in self.blocked_patterns:
            if re.search(pattern, text_lower):
                self.stats["blocked"] += 1
                return True, pattern
        
        return False, ""
    
    def _local_classify(self, text: str) -> Tuple[str, List[str], float]:
        """تصنيف محلي بالكلمات المفتاحية."""
        words = set(self._tokenize(text))
        if not words:
            return "unknown", ["unknown"], 0.0
        
        # المنصة
        platform_scores = {}
        for platform, keywords in self.platform_words.items():
            score = sum(keywords.get(w, 0) for w in words)
            if score > 0:
                platform_scores[platform] = score
        
        if platform_scores:
            best_platform = max(platform_scores, key=platform_scores.get)
            total = sum(platform_scores.values())
            platform_conf = platform_scores[best_platform] / total
        else:
            best_platform = "unknown"
            platform_conf = 0.0
        
        # الأفعال
        action_scores = {}
        for action, keywords in self.action_words.items():
            score = sum(keywords.get(w, 0) for w in words)
            if score > 0:
                action_scores[action] = score
        
        if action_scores:
            sorted_actions = sorted(action_scores.items(), key=lambda x: x[1], reverse=True)
            best_actions = [a for a, s in sorted_actions[:3]]
            total = sum(action_scores.values())
            action_conf = sorted_actions[0][1] / total
        else:
            best_actions = ["unknown"]
            action_conf = 0.0
        
        confidence = (platform_conf + action_conf) / 2
        return best_platform, best_actions, confidence
    
    def _check_memory(self, text: str) -> Optional[Dict]:
        """فحص الذاكرة."""
        key = self._hash(text)
        if key in self.memory:
            self.stats["memory_hits"] += 1
            return self.memory[key]
        return None
    
    async def _call_api(self, text: str) -> Optional[Dict]:
        """استدعاء API خارجي."""
        if not self.api_config["enabled"] or not self.api_config["api_key"]:
            return None
        
        self.stats["api_calls"] += 1
        
        prompt = f"""حلل هذه المهمة من منصة UNU الروسية وصنفها:

المهمة: {text[:500]}

أجب بـ JSON فقط:
{{"platform": "telegram|vk|tiktok|instagram|youtube|max|twitter|unknown", "actions": ["subscribe|like|comment|repost|view"], "blocked": false, "reason": ""}}"""
        
        try:
            if self.api_config["provider"] == "groq":
                url = "https://api.groq.com/openai/v1/chat/completions"
            else:
                url = "https://api.openai.com/v1/chat/completions"
            
            async with httpx.AsyncClient(timeout=self.api_config["timeout"]) as client:
                response = await client.post(
                    url,
                    headers={"Authorization": f"Bearer {self.api_config['api_key']}"},
                    json={
                        "model": self.api_config["model"],
                        "messages": [{"role": "user", "content": prompt}],
                        "temperature": 0.1,
                        "max_tokens": 200,
                    }
                )
                
                if response.status_code == 200:
                    data = response.json()
                    content = data["choices"][0]["message"]["content"]
                    
                    # استخراج JSON
                    match = re.search(r'\{.*\}', content, re.DOTALL)
                    if match:
                        result = json.loads(match.group())
                        return result
        except Exception as e:
            logger.warning("API call failed: %s", e)
        
        return None
    
    async def analyze(self, title: str, description: str = "", 
                      url: str = "", category: str = "") -> Dict:
        """
        تحليل المهمة.
        
        Returns:
            {
                "platform": str,
                "actions": list,
                "confidence": float,
                "blocked": bool,
                "block_reason": str,
                "source": "memory|local|api",
                "needs_review": bool,
            }
        """
        text = f"{title} {description} {url} {category}".strip()
        
        result = {
            "platform": "unknown",
            "actions": ["unknown"],
            "confidence": 0.0,
            "blocked": False,
            "block_reason": "",
            "source": "none",
            "needs_review": False,
        }
        
        # 1. فحص الحظر
        blocked, reason = self.is_blocked(text)
        if blocked:
            result["blocked"] = True
            result["block_reason"] = reason
            result["source"] = "blocked"
            return result
        
        # 2. فحص الذاكرة
        memory_result = self._check_memory(text)
        if memory_result:
            result.update({
                "platform": memory_result.get("platform", "unknown"),
                "actions": memory_result.get("actions", ["unknown"]),
                "confidence": 0.95,
                "source": "memory",
            })
            return result
        
        # 3. تصنيف محلي
        platform, actions, confidence = self._local_classify(text)
        self.stats["local_hits"] += 1
        
        if confidence >= 0.7:
            result.update({
                "platform": platform,
                "actions": actions,
                "confidence": confidence,
                "source": "local",
            })
            return result
        
        # 4. API خارجي
        api_result = await self._call_api(text)
        if api_result:
            result.update({
                "platform": api_result.get("platform", "unknown"),
                "actions": api_result.get("actions", ["unknown"]),
                "confidence": 0.85,
                "blocked": api_result.get("blocked", False),
                "block_reason": api_result.get("reason", ""),
                "source": "api",
            })
            
            # حفظ في الذاكرة
            self.learn(text, result["platform"], result["actions"])
            return result
        
        # 5. النتيجة المحلية حتى لو ثقة منخفضة
        result.update({
            "platform": platform,
            "actions": actions,
            "confidence": confidence,
            "source": "local",
            "needs_review": confidence < 0.5,
        })
        
        return result
    
    def learn(self, text: str, platform: str, actions: List[str], 
              success: bool = True):
        """تعلم من نتيجة."""
        key = self._hash(text)
        
        self.memory[key] = {
            "text": text[:200],
            "platform": platform,
            "actions": actions,
            "success": success,
            "timestamp": datetime.now().isoformat(),
        }
        
        if success:
            self._update_keywords(text, platform, actions)
        
        self.stats["learned"] += 1
        
        # حفظ كل 5 عينات
        if self.stats["learned"] % 5 == 0:
            self._save()
        
        logger.debug("Learned: %s -> %s", platform, actions)
    
    def set_api(self, provider: str, api_key: str, model: str = None):
        """إعداد API."""
        self.api_config["provider"] = provider
        self.api_config["api_key"] = api_key
        self.api_config["enabled"] = bool(api_key)
        
        if model:
            self.api_config["model"] = model
        elif provider == "groq":
            self.api_config["model"] = "llama-3.1-8b-instant"
        
        self._save()
        logger.info("API configured: %s", provider)
    
    def add_blocked_pattern(self, pattern: str):
        """إضافة نمط حظر."""
        if pattern not in self.blocked_patterns:
            self.blocked_patterns.append(pattern)
            logger.info("Added blocked pattern: %s", pattern)
    
    def get_stats(self) -> Dict:
        """إحصائيات."""
        return {
            "memory_size": len(self.memory),
            "platforms_learned": len(self.platform_words),
            "actions_learned": len(self.action_words),
            "local_hits": self.stats["local_hits"],
            "memory_hits": self.stats["memory_hits"],
            "api_calls": self.stats["api_calls"],
            "blocked": self.stats["blocked"],
            "learned": self.stats["learned"],
            "api_enabled": self.api_config["enabled"],
        }
    
    def get_learned_platforms(self) -> Dict[str, int]:
        """المنصات المتعلمة."""
        return {p: sum(c.values()) for p, c in self.platform_words.items()}


# Singleton
ai_brain = AIBrain()


async def analyze_task(title: str, description: str = "", 
                       url: str = "", category: str = "") -> Dict:
    """تحليل مهمة."""
    return await ai_brain.analyze(title, description, url, category)


def learn_task(text: str, platform: str, actions: List[str], success: bool = True):
    """تعلم من مهمة."""
    ai_brain.learn(text, platform, actions, success)


def get_brain_stats() -> Dict:
    """إحصائيات الدماغ."""
    return ai_brain.get_stats()
