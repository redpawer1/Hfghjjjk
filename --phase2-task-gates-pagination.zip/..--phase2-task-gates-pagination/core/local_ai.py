#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Local AI — مصنف محلي يتعلم من المهام
يستخدم TF-IDF + Naive Bayes للتصنيف السريع بدون API
"""

import json
import logging
import pickle
import re
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple, List, Dict
from collections import Counter

logger = logging.getLogger("LocalAI")

MODEL_DIR = Path("/root/unu-bot/data/models")
TRAINING_FILE = Path("/root/unu-bot/data/training_data.json")


class LocalClassifier:
    """مصنف محلي بسيط يعتمد على الكلمات المفتاحية والتردد."""
    
    def __init__(self):
        MODEL_DIR.mkdir(parents=True, exist_ok=True)
        
        # بيانات التدريب
        self.training_data: List[Dict] = []
        
        # نماذج الكلمات المفتاحية لكل منصة وفعل
        self.platform_keywords: Dict[str, Counter] = {}
        self.action_keywords: Dict[str, Counter] = {}
        
        # إحصائيات
        self.stats = {
            "total_trained": 0,
            "correct_predictions": 0,
            "total_predictions": 0,
        }
        
        self._load()
    
    def _load(self):
        """تحميل البيانات المحفوظة."""
        if TRAINING_FILE.exists():
            try:
                data = json.loads(TRAINING_FILE.read_text())
                self.training_data = data.get("training_data", [])
                self.stats = data.get("stats", self.stats)
                self._rebuild_keywords()
                logger.info("Loaded %d training samples", len(self.training_data))
            except Exception as e:
                logger.warning("Failed to load training data: %s", e)
    
    def _save(self):
        """حفظ البيانات."""
        data = {
            "training_data": self.training_data[-5000:],  # آخر 5000
            "stats": self.stats,
            "updated": datetime.now().isoformat(),
        }
        TRAINING_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2))
    
    def _tokenize(self, text: str) -> List[str]:
        """تقسيم النص لكلمات."""
        text = text.lower()
        # إزالة الروابط
        text = re.sub(r'https?://\S+', '', text)
        # استخراج الكلمات
        words = re.findall(r'[а-яёa-z]+', text)
        return words
    
    def _rebuild_keywords(self):
        """إعادة بناء قواميس الكلمات المفتاحية."""
        self.platform_keywords = {}
        self.action_keywords = {}
        
        for sample in self.training_data:
            text = sample.get("text", "")
            platform = sample.get("platform", "")
            actions = sample.get("actions", [])
            
            words = self._tokenize(text)
            
            if platform and platform != "unknown":
                if platform not in self.platform_keywords:
                    self.platform_keywords[platform] = Counter()
                self.platform_keywords[platform].update(words)
            
            for action in actions:
                if action and action != "unknown":
                    if action not in self.action_keywords:
                        self.action_keywords[action] = Counter()
                    self.action_keywords[action].update(words)
    
    def add_sample(self, text: str, platform: str, actions: List[str], 
                   was_correct: bool = True):
        """إضافة عينة تدريب."""
        sample = {
            "text": text[:500],
            "platform": platform,
            "actions": actions,
            "correct": was_correct,
            "timestamp": datetime.now().isoformat(),
        }
        
        self.training_data.append(sample)
        self.stats["total_trained"] += 1
        
        # تحديث الكلمات المفتاحية
        words = self._tokenize(text)
        
        if platform and platform != "unknown":
            if platform not in self.platform_keywords:
                self.platform_keywords[platform] = Counter()
            self.platform_keywords[platform].update(words)
        
        for action in actions:
            if action and action != "unknown":
                if action not in self.action_keywords:
                    self.action_keywords[action] = Counter()
                self.action_keywords[action].update(words)
        
        # حفظ كل 10 عينات
        if len(self.training_data) % 10 == 0:
            self._save()
        
        logger.debug("Added training sample: %s -> %s", platform, actions)
    
    def predict(self, text: str) -> Tuple[str, List[str], float]:
        """التنبؤ بالمنصة والأفعال."""
        self.stats["total_predictions"] += 1
        
        words = self._tokenize(text)
        if not words:
            return "unknown", ["unknown"], 0.0
        
        word_set = set(words)
        
        # التنبؤ بالمنصة
        platform_scores = {}
        for platform, keywords in self.platform_keywords.items():
            score = sum(keywords.get(w, 0) for w in word_set)
            if score > 0:
                platform_scores[platform] = score
        
        if platform_scores:
            best_platform = max(platform_scores, key=platform_scores.get)
            platform_confidence = platform_scores[best_platform] / sum(platform_scores.values())
        else:
            best_platform = "unknown"
            platform_confidence = 0.0
        
        # التنبؤ بالأفعال
        action_scores = {}
        for action, keywords in self.action_keywords.items():
            score = sum(keywords.get(w, 0) for w in word_set)
            if score > 0:
                action_scores[action] = score
        
        if action_scores:
            # أخذ أعلى 3 أفعال
            sorted_actions = sorted(action_scores.items(), key=lambda x: x[1], reverse=True)
            best_actions = [a for a, s in sorted_actions[:3] if s > 0]
            action_confidence = sorted_actions[0][1] / sum(action_scores.values()) if sorted_actions else 0
        else:
            best_actions = ["unknown"]
            action_confidence = 0.0
        
        # الثقة الإجمالية
        confidence = (platform_confidence + action_confidence) / 2
        
        return best_platform, best_actions, confidence
    
    def predict_with_fallback(self, text: str, regex_result: Dict = None) -> Dict:
        """التنبؤ مع fallback للـ regex."""
        platform, actions, confidence = self.predict(text)
        
        # لو الثقة منخفضة، استخدم نتيجة الـ regex
        if confidence < 0.5 and regex_result:
            return {
                "platform": regex_result.get("platform", "unknown"),
                "actions": regex_result.get("actions", ["unknown"]),
                "confidence": regex_result.get("confidence", 0.5),
                "source": "regex",
            }
        
        return {
            "platform": platform,
            "actions": actions,
            "confidence": confidence,
            "source": "local_ai",
        }
    
    def feedback(self, text: str, predicted_platform: str, actual_platform: str,
                 predicted_actions: List[str], actual_actions: List[str]):
        """تغذية راجعة للتعلم."""
        correct = (predicted_platform == actual_platform and 
                   set(predicted_actions) == set(actual_actions))
        
        if correct:
            self.stats["correct_predictions"] += 1
        
        # إضافة كعينة تدريب
        self.add_sample(text, actual_platform, actual_actions, correct)
        
        logger.info("Feedback: predicted=%s actual=%s correct=%s", 
                   predicted_platform, actual_platform, correct)
    
    def get_accuracy(self) -> float:
        """حساب الدقة."""
        if self.stats["total_predictions"] == 0:
            return 0.0
        return self.stats["correct_predictions"] / self.stats["total_predictions"]
    
    def get_stats(self) -> Dict:
        """إحصائيات النموذج."""
        return {
            "training_samples": len(self.training_data),
            "platforms_learned": len(self.platform_keywords),
            "actions_learned": len(self.action_keywords),
            "total_predictions": self.stats["total_predictions"],
            "accuracy": f"{self.get_accuracy() * 100:.1f}%",
        }
    
    def export_keywords(self) -> Dict:
        """تصدير الكلمات المفتاحية."""
        return {
            "platforms": {
                p: dict(c.most_common(20)) 
                for p, c in self.platform_keywords.items()
            },
            "actions": {
                a: dict(c.most_common(20)) 
                for a, c in self.action_keywords.items()
            },
        }


class SmartClassifier:
    """مصنف ذكي يجمع بين الـ regex والـ AI المحلي."""
    
    def __init__(self, regex_classifier=None):
        self.local_ai = LocalClassifier()
        self.regex = regex_classifier
        self.confidence_threshold = 0.7
    
    def classify(self, title: str, description: str = "", url: str = "", 
                 category: str = "") -> Dict:
        """تصنيف المهمة."""
        text = f"{title} {description} {url} {category}"
        
        # 1. جرب الـ AI المحلي أولاً
        local_platform, local_actions, local_confidence = self.local_ai.predict(text)
        
        # 2. لو الثقة عالية، استخدم النتيجة
        if local_confidence >= self.confidence_threshold:
            return {
                "platform": local_platform,
                "actions": local_actions,
                "confidence": local_confidence,
                "source": "local_ai",
                "needs_api": False,
            }
        
        # 3. لو فيه regex classifier، استخدمه
        if self.regex:
            try:
                regex_result = self.regex.classify(title, description, url, category)
                return {
                    "platform": regex_result.platform,
                    "actions": regex_result.actions,
                    "confidence": regex_result.confidence,
                    "source": "regex",
                    "needs_api": regex_result.confidence < 0.6,
                    "blocked": regex_result.blocked,
                    "proof": regex_result.proof,
                }
            except:
                pass
        
        # 4. النتيجة المحلية حتى لو ثقة منخفضة
        return {
            "platform": local_platform,
            "actions": local_actions,
            "confidence": local_confidence,
            "source": "local_ai",
            "needs_api": local_confidence < 0.5,
        }
    
    def learn(self, text: str, platform: str, actions: List[str]):
        """تعلم من نتيجة صحيحة."""
        self.local_ai.add_sample(text, platform, actions, True)
    
    def get_stats(self) -> Dict:
        return self.local_ai.get_stats()


# Singleton
local_classifier = LocalClassifier()
smart_classifier = SmartClassifier()


def classify_local(text: str) -> Tuple[str, List[str], float]:
    """تصنيف محلي سريع."""
    return local_classifier.predict(text)


def learn_from_task(text: str, platform: str, actions: List[str]):
    """تعلم من مهمة."""
    local_classifier.add_sample(text, platform, actions)


def get_ai_stats() -> Dict:
    """إحصائيات الـ AI."""
    return local_classifier.get_stats()
