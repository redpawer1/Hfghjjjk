#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Browser Guard — معالجة أخطاء المتصفح دون إسقاط المحرك
"""

import asyncio
import logging
from typing import Optional, Callable, Any
from functools import wraps

logger = logging.getLogger("BrowserGuard")


class BrowserGuard:
    """حماية من أخطاء المتصفح."""
    
    def __init__(self, max_retries: int = 3, retry_delay: float = 2.0):
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.error_count = 0
        self.last_error: Optional[str] = None
    
    async def safe_execute(self, func: Callable, *args, **kwargs) -> tuple[bool, Any]:
        """
        تنفيذ دالة مع حماية من الأخطاء.
        يرجع (success, result)
        """
        for attempt in range(self.max_retries):
            try:
                result = await func(*args, **kwargs)
                self.error_count = 0
                return True, result
            except Exception as e:
                self.error_count += 1
                self.last_error = str(e)
                logger.warning("Browser error (attempt %d/%d): %s", 
                             attempt + 1, self.max_retries, e)
                
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(self.retry_delay * (attempt + 1))
        
        return False, None
    
    def should_restart_browser(self) -> bool:
        """هل يجب إعادة تشغيل المتصفح؟"""
        return self.error_count >= 5
    
    def reset(self):
        """إعادة تعيين العدادات."""
        self.error_count = 0
        self.last_error = None


def browser_safe(max_retries: int = 3):
    """Decorator لحماية دوال المتصفح."""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            guard = BrowserGuard(max_retries=max_retries)
            success, result = await guard.safe_execute(func, *args, **kwargs)
            if not success:
                logger.error("Function %s failed after retries", func.__name__)
            return result
        return wrapper
    return decorator


# Singleton
browser_guard = BrowserGuard()
