#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Database — SQLite persistence layer
"""

import sqlite3
import json
import logging
import shutil
import time
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any
from contextlib import contextmanager

logger = logging.getLogger("Database")

DB_PATH = Path("/root/unu-bot/data/unu_bot.db")

class Database:
    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_tables()
    
    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()
    
    def _init_tables(self):
        if self.db_path.exists():
            backup = self.db_path.with_suffix(self.db_path.suffix + ".migration.bak")
            if not backup.exists():
                try:
                    shutil.copy2(self.db_path, backup)
                except OSError as error:
                    logger.warning("database backup failed: %s", error)
        with self._conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY,
                    account_id TEXT NOT NULL DEFAULT 'legacy',
                    task_id TEXT NOT NULL DEFAULT '',
                    url TEXT NOT NULL,
                    title TEXT,
                    platform TEXT,
                    actions TEXT,
                    status TEXT DEFAULT 'pending',
                    price REAL DEFAULT 0,
                    confidence REAL DEFAULT 0,
                    priority INTEGER DEFAULT 50,
                    attempts INTEGER DEFAULT 0,
                    reject_reason TEXT,
                    created_at TEXT,
                    completed_at TEXT,
                    proof_data TEXT,
                    UNIQUE(account_id, task_id),
                    UNIQUE(account_id, url)
                );
                
                CREATE TABLE IF NOT EXISTS daily_stats (
                    day TEXT PRIMARY KEY,
                    tasks_done INTEGER DEFAULT 0,
                    tasks_failed INTEGER DEFAULT 0,
                    earnings REAL DEFAULT 0,
                    platforms TEXT
                );
                
                CREATE TABLE IF NOT EXISTS platform_stats (
                    platform TEXT PRIMARY KEY,
                    total INTEGER DEFAULT 0,
                    success INTEGER DEFAULT 0,
                    failed INTEGER DEFAULT 0,
                    last_used TEXT
                );
                
                CREATE TABLE IF NOT EXISTS feedback (
                    id INTEGER PRIMARY KEY,
                    task_text TEXT,
                    was_rejected INTEGER,
                    reason TEXT,
                    created_at TEXT
                );
                
                CREATE TABLE IF NOT EXISTS pending_tasks (
                    id INTEGER PRIMARY KEY,
                    account_id TEXT NOT NULL DEFAULT 'legacy',
                    url TEXT NOT NULL,
                    data TEXT,
                    reason TEXT,
                    created_at TEXT
                );
                
                CREATE TABLE IF NOT EXISTS block_rules (
                    id INTEGER PRIMARY KEY,
                    pattern TEXT UNIQUE,
                    reason TEXT,
                    auto_added INTEGER DEFAULT 0,
                    created_at TEXT
                );
                
            """)
            columns = {
                row["name"]
                for row in conn.execute("PRAGMA table_info(tasks)").fetchall()
            }
            if "account_id" not in columns:
                conn.execute(
                    "ALTER TABLE tasks ADD COLUMN account_id TEXT NOT NULL DEFAULT 'legacy'"
                )
            table_sql = conn.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='tasks'"
            ).fetchone()["sql"] or ""
            if "URL TEXT UNIQUE" in table_sql.upper() or "TASK_ID" not in {
                row["name"].upper() for row in conn.execute("PRAGMA table_info(tasks)").fetchall()
            }:
                legacy_name = f"tasks_legacy_backup_{int(time.time())}"
                conn.execute("ALTER TABLE tasks RENAME TO " + legacy_name)
                conn.execute("""
                    CREATE TABLE tasks (
                        id INTEGER PRIMARY KEY,
                        account_id TEXT NOT NULL DEFAULT 'legacy',
                        task_id TEXT NOT NULL DEFAULT '',
                        url TEXT NOT NULL,
                        title TEXT,
                        platform TEXT,
                        actions TEXT,
                        status TEXT DEFAULT 'pending',
                        price REAL DEFAULT 0,
                        confidence REAL DEFAULT 0,
                        priority INTEGER DEFAULT 50,
                        attempts INTEGER DEFAULT 0,
                        reject_reason TEXT,
                        created_at TEXT,
                        completed_at TEXT,
                        proof_data TEXT,
                        UNIQUE(account_id, task_id),
                        UNIQUE(account_id, url)
                    )
                """)
                conn.execute(f"""
                    INSERT OR IGNORE INTO tasks
                    (id, account_id, task_id, url, title, platform, actions, status, price,
                     confidence, priority, attempts, reject_reason, created_at,
                     completed_at, proof_data)
                    SELECT id, account_id, CAST(id AS TEXT), url, title, platform, actions, status, price,
                           confidence, priority, attempts, reject_reason, created_at,
                           completed_at, proof_data
                    FROM {legacy_name}
                """)
                conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_platform ON tasks(platform)")
            pending_sql = conn.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='pending_tasks'"
            ).fetchone()["sql"] or ""
            if "URL TEXT UNIQUE" in pending_sql.upper():
                legacy_name = f"pending_tasks_legacy_backup_{int(time.time())}"
                conn.execute("ALTER TABLE pending_tasks RENAME TO " + legacy_name)
                conn.execute("""
                    CREATE TABLE pending_tasks (
                        id INTEGER PRIMARY KEY,
                        account_id TEXT NOT NULL DEFAULT 'legacy',
                        url TEXT NOT NULL,
                        data TEXT,
                        reason TEXT,
                        created_at TEXT,
                        UNIQUE(account_id, url)
                    )
                """)
                conn.execute(f"""
                    INSERT OR IGNORE INTO pending_tasks
                    (id, account_id, url, data, reason, created_at)
                    SELECT id, 'legacy', url, data, reason, created_at
                    FROM {legacy_name}
                """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_account ON tasks(account_id, id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_platform ON tasks(platform)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_pending_account ON pending_tasks(account_id, created_at)")
        logger.info("Database initialized: %s", self.db_path)
    
    def add_task(self, url: str, title: str, platform: str, actions: list,
                 price: float = 0, confidence: float = 0, priority: int = 50,
                 account_id: str = "legacy", task_id: str = "") -> bool:
        try:
            with self._conn() as conn:
                conflict = conn.execute(
                    "SELECT url FROM tasks WHERE account_id = ? AND task_id = ?",
                    (str(account_id or "legacy"), str(task_id or url)),
                ).fetchone()
                if conflict and str(conflict["url"]) != str(url):
                    logger.warning(
                        "task id/url conflict preserved once: account=%s task_id=%s",
                        account_id, task_id or url,
                    )
                    return False
                conn.execute("""
                    INSERT OR IGNORE INTO tasks 
                    (account_id, task_id, url, title, platform, actions, price, confidence, priority, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (str(account_id or "legacy"), str(task_id or url), url, title, platform,
                      json.dumps(actions), price, confidence, priority,
                      datetime.now().isoformat()))
            return True
        except Exception as e:
            logger.error("add_task error: %s", e)
            return False
    
    def update_task_status(self, url: str, status: str, reject_reason: str = None,
                           proof_data: dict = None, account_id: str = "legacy"):
        with self._conn() as conn:
            conn.execute("""
                UPDATE tasks SET status = ?, reject_reason = ?, proof_data = ?,
                completed_at = ?, attempts = attempts + 1
                WHERE url = ? AND account_id = ?
            """, (status, reject_reason, json.dumps(proof_data) if proof_data else None,
                  datetime.now().isoformat() if status in ('done', 'failed', 'rejected') else None,
                  url, str(account_id or "legacy")))
    
    def get_task_attempts(self, url: str, account_id: str = "legacy") -> int:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT attempts FROM tasks WHERE url = ? AND account_id = ?",
                (url, str(account_id or "legacy")),
            ).fetchone()
            return row['attempts'] if row else 0
    
    def is_task_done(self, url: str, account_id: str = "legacy") -> bool:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT status FROM tasks WHERE url = ? AND account_id = ?",
                (url, str(account_id or "legacy")),
            ).fetchone()
            return row and row['status'] in ('done', 'rejected', 'failed')
    
    def get_daily_stats(self, day: str = None) -> dict:
        day = day or datetime.now().strftime("%Y-%m-%d")
        with self._conn() as conn:
            row = conn.execute("SELECT * FROM daily_stats WHERE day = ?", (day,)).fetchone()
            if row:
                return dict(row)
            return {"day": day, "tasks_done": 0, "tasks_failed": 0, "earnings": 0.0}
    
    def update_daily_stats(self, tasks_done: int = 0, tasks_failed: int = 0, earnings: float = 0):
        day = datetime.now().strftime("%Y-%m-%d")
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO daily_stats (day, tasks_done, tasks_failed, earnings)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(day) DO UPDATE SET
                    tasks_done = tasks_done + excluded.tasks_done,
                    tasks_failed = tasks_failed + excluded.tasks_failed,
                    earnings = earnings + excluded.earnings
            """, (day, tasks_done, tasks_failed, earnings))
    
    def get_platform_stats(self, platform: str) -> dict:
        with self._conn() as conn:
            row = conn.execute("SELECT * FROM platform_stats WHERE platform = ?", (platform,)).fetchone()
            if row:
                return dict(row)
            return {"platform": platform, "total": 0, "success": 0, "failed": 0}
    
    def update_platform_stats(self, platform: str, success: bool):
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO platform_stats (platform, total, success, failed, last_used)
                VALUES (?, 1, ?, ?, ?)
                ON CONFLICT(platform) DO UPDATE SET
                    total = total + 1,
                    success = success + excluded.success,
                    failed = failed + excluded.failed,
                    last_used = excluded.last_used
            """, (platform, 1 if success else 0, 0 if success else 1, datetime.now().isoformat()))
    
    def add_feedback(self, task_text: str, was_rejected: bool, reason: str = ""):
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO feedback (task_text, was_rejected, reason, created_at)
                VALUES (?, ?, ?, ?)
            """, (task_text[:500], 1 if was_rejected else 0, reason, datetime.now().isoformat()))
    
    def get_rejection_count(self, reason: str) -> int:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT COUNT(*) as cnt FROM feedback WHERE reason = ? AND was_rejected = 1",
                (reason,)
            ).fetchone()
            return row['cnt'] if row else 0
    
    def add_pending_task(self, url: str, data: dict, reason: str, account_id: str = "legacy"):
        with self._conn() as conn:
            conn.execute("""
                INSERT OR REPLACE INTO pending_tasks (account_id, url, data, reason, created_at)
                VALUES (?, ?, ?, ?, ?)
            """, (str(account_id or "legacy"), url, json.dumps(data), reason, datetime.now().isoformat()))
    
    def get_pending_tasks(self, account_id: str = "legacy") -> List[dict]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM pending_tasks WHERE account_id = ? ORDER BY created_at",
                (str(account_id or "legacy"),),
            ).fetchall()
            return [dict(r) for r in rows]
    
    def remove_pending_task(self, url: str, account_id: str = "legacy"):
        with self._conn() as conn:
            conn.execute(
                "DELETE FROM pending_tasks WHERE url = ? AND account_id = ?",
                (url, str(account_id or "legacy")),
            )
    
    def add_block_rule(self, pattern: str, reason: str, auto: bool = False):
        with self._conn() as conn:
            conn.execute("""
                INSERT OR IGNORE INTO block_rules (pattern, reason, auto_added, created_at)
                VALUES (?, ?, ?, ?)
            """, (pattern, reason, 1 if auto else 0, datetime.now().isoformat()))
    
    def get_block_rules(self) -> List[dict]:
        with self._conn() as conn:
            rows = conn.execute("SELECT * FROM block_rules").fetchall()
            return [dict(r) for r in rows]
    
    def cleanup_old_tasks(self, keep_days: int = 7):
        with self._conn() as conn:
            conn.execute("""
                DELETE FROM tasks WHERE created_at < datetime('now', ?)
            """, (f'-{keep_days} days',))
        logger.info("Cleaned old tasks")
    
    def get_stats_summary(self) -> dict:
        with self._conn() as conn:
            total = conn.execute("SELECT COUNT(*) as c FROM tasks").fetchone()['c']
            done = conn.execute("SELECT COUNT(*) as c FROM tasks WHERE status = 'done'").fetchone()['c']
            failed = conn.execute("SELECT COUNT(*) as c FROM tasks WHERE status IN ('failed', 'rejected')").fetchone()['c']
            earnings = conn.execute("SELECT SUM(earnings) as e FROM daily_stats").fetchone()['e'] or 0
            return {"total": total, "done": done, "failed": failed, "earnings": earnings}

db = Database()
