#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bot Services — ربط كل الخدمات مع بعض
يُستورد في main.py ويوفر واجهة موحدة
"""

import asyncio
import logging
from typing import Optional, Callable, Any, List, Dict

logger = logging.getLogger("BotServices")

# Import all services
try:
    from .safety_config import safety_config
    HAS_SAFETY = True
except ImportError:
    HAS_SAFETY = False
    safety_config = None

try:
    from .ai_fallback import ai_fallback
    HAS_AI = True
except ImportError:
    HAS_AI = False
    ai_fallback = None

try:
    from .daily_report import daily_report
    HAS_REPORT = True
except ImportError:
    HAS_REPORT = False
    daily_report = None

try:
    from .error_alerts import error_alerts
    HAS_ALERTS = True
except ImportError:
    HAS_ALERTS = False
    error_alerts = None

try:
    from .smart_filter import smart_filter
    HAS_FILTER = True
except ImportError:
    HAS_FILTER = False
    smart_filter = None

try:
    from .browser_restart import browser_restart
    HAS_BROWSER = True
except ImportError:
    HAS_BROWSER = False
    browser_restart = None

try:
    from .task_lock import task_lock
    HAS_LOCK = True
except ImportError:
    HAS_LOCK = False
    task_lock = None


class BotServices:
    """
    واجهة موحدة لكل الخدمات.
    تُستخدم في main.py بدل استدعاء كل خدمة لوحدها.
    """
    
    def __init__(self):
        self.safety = safety_config
        self.ai = ai_fallback
        self.report = daily_report
        self.alerts = error_alerts
        self.filter = smart_filter
        self.browser = browser_restart
        self.lock = task_lock
        
        self._message_sender: Optional[Callable] = None
        self._browser_restart_func: Optional[Callable] = None
        
        logger.info("BotServices initialized: safety=%s ai=%s report=%s alerts=%s filter=%s browser=%s lock=%s",
                   HAS_SAFETY, HAS_AI, HAS_REPORT, HAS_ALERTS, HAS_FILTER, HAS_BROWSER, HAS_LOCK)
    
    def setup(self, message_sender: Callable = None, browser_restart_func: Callable = None):
        """
        إعداد الخدمات مع دوال الإرسال وإعادة التشغيل.
        يُستدعى من main.py بعد تهيئة Dashboard.
        """
        self._message_sender = message_sender
        self._browser_restart_func = browser_restart_func
        
        if self.report and message_sender:
            self.report.set_sender(message_sender)
        
        if self.alerts and message_sender:
            self.alerts.set_sender(message_sender)
        
        if self.browser and browser_restart_func:
            self.browser.set_restart_func(browser_restart_func)
        
        logger.info("BotServices setup complete")
    
    # === Safety ===
    
    def check_daily_limit(self, tasks_done: int) -> bool:
        """فحص الحد اليومي"""
        if not self.safety:
            return True
        return self.safety.check_daily_limit(tasks_done)
    
    def check_price(self, price: float) -> bool:
        """فحص السعر"""
        if not self.safety:
            return True
        return self.safety.check_price(price)
    
    def needs_approval(self, task_type: str = None) -> bool:
        """هل المهمة محتاجة موافقة؟"""
        if not self.safety:
            return False
        return self.safety.needs_approval(task_type)
    
    # === AI ===
    
    async def analyze_with_fallback(self, func: Callable, *args, **kwargs) -> tuple:
        """تحليل مع fallback بين المزودين"""
        if not self.ai:
            try:
                result = await func(*args, **kwargs)
                return True, result
            except Exception as e:
                return False, str(e)
        return await self.ai.execute_with_fallback(func, *args, **kwargs)
    
    def get_ai_provider(self) -> Optional[str]:
        """الحصول على مزود AI الحالي"""
        if not self.ai:
            return None
        return self.ai.get_current_provider()
    
    # === Filter ===
    
    def filter_tasks(self, tasks: List[Dict]) -> List[Dict]:
        """فلترة المهام"""
        if not self.filter:
            return tasks
        return self.filter.filter_tasks(tasks)
    
    def get_best_tasks(self, tasks: List[Dict], limit: int = 10) -> List[Dict]:
        """أفضل المهام"""
        if not self.filter:
            return tasks[:limit]
        return self.filter.get_best_tasks(tasks, limit)
    
    def set_price_range(self, min_price: float, max_price: float):
        """تحديد نطاق السعر"""
        if self.filter:
            self.filter.set_price_range(min_price, max_price)
    
    # === Lock ===
    
    async def acquire_task(self, task_id: str) -> bool:
        """الحصول على قفل المهمة"""
        if not self.lock:
            return True
        return await self.lock.acquire(task_id)
    
    async def release_task(self, task_id: str, completed: bool = True):
        """تحرير قفل المهمة"""
        if self.lock:
            await self.lock.release(task_id, completed)
    
    # === Browser ===
    
    def record_browser_error(self):
        """تسجيل خطأ متصفح"""
        if self.browser:
            self.browser.record_error()
        if self.alerts:
            self.alerts.record_error("browser_error")
    
    def record_browser_success(self):
        """تسجيل نجاح متصفح"""
        if self.browser:
            self.browser.record_success()
    
    # === Alerts ===
    
    def record_error(self, error_type: str, message: str = ""):
        """تسجيل خطأ وإرسال تنبيه لو لزم"""
        if self.alerts:
            self.alerts.record_error(error_type, message)
    
    # === Reports ===
    
    async def send_daily_report_if_needed(self, stats: Dict) -> bool:
        """إرسال التقرير اليومي لو لازم"""
        if not self.report:
            return False
        return await self.report.send_if_needed(stats)
    
    # === Stats ===
    
    def get_all_stats(self) -> Dict:
        """كل الإحصائيات"""
        stats = {}
        if self.safety:
            stats["safety"] = {
                "max_daily": self.safety.max_tasks_per_day,
                "human_approval": self.safety.require_human_approval,
            }
        if self.ai:
            stats["ai"] = self.ai.get_stats()
        if self.browser:
            stats["browser"] = self.browser.get_stats()
        if self.alerts:
            stats["errors"] = self.alerts.get_stats()
        if self.lock:
            stats["tasks"] = self.lock.get_stats()
        return stats


# Singleton
bot_services = BotServices()
