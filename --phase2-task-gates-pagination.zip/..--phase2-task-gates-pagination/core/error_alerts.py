#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Error Alerts — تنبيهات الأخطاء
"""

import logging
from datetime import datetime, timedelta
from typing import Optional, Callable, Set
from collections import defaultdict

logger = logging.getLogger("ErrorAlerts")


class ErrorAlerts:
    """نظام تنبيهات الأخطاء"""
    
    def __init__(self):
        self._send_func: Optional[Callable] = None
        self.error_counts = defaultdict(int)
        self.last_alert_time = {}
        self.alert_cooldown = timedelta(minutes=30)
        self.threshold = 5  # عدد الأخطاء قبل التنبيه
    
    def set_sender(self, func: Callable):
        """تعيين دالة الإرسال"""
        self._send_func = func
    
    def record_error(self, error_type: str, message: str = ""):
        """تسجيل خطأ"""
        self.error_counts[error_type] += 1
        count = self.error_counts[error_type]
        
        logger.warning("Error recorded: %s (count=%d)", error_type, count)
        
        # فحص إذا يجب التنبيه
        if count >= self.threshold:
            self._check_and_alert(error_type, message)
    
    def _check_and_alert(self, error_type: str, message: str):
        """فحص وإرسال تنبيه"""
        now = datetime.now()
        last_alert = self.last_alert_time.get(error_type)
        
        # تجنب التنبيهات المتكررة
        if last_alert and (now - last_alert) < self.alert_cooldown:
            return
        
        self.last_alert_time[error_type] = now
        count = self.error_counts[error_type]
        
        alert_text = f"""🚨 **تنبيه خطأ**

النوع: {error_type}
العدد: {count}
الرسالة: {message[:200]}
الوقت: {now.strftime('%H:%M:%S')}

⚠️ يرجى المراجعة
"""
        
        if self._send_func:
            try:
                import asyncio
                asyncio.create_task(self._send_func(alert_text))
                logger.info("Error alert sent: %s", error_type)
            except Exception as e:
                logger.error("Failed to send alert: %s", e)
    
    def reset_counter(self, error_type: str):
        """إعادة تعيين عداد خطأ"""
        self.error_counts[error_type] = 0
    
    def get_stats(self) -> dict:
        """إحصائيات الأخطاء"""
        return dict(self.error_counts)


# Singleton
error_alerts = ErrorAlerts()
