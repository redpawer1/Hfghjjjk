#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU Bot Monitor — Telegram alerts, hourly reports, health checks
"""

import asyncio
import logging
import psutil
from datetime import datetime
from typing import Optional, Callable
from .database import db
from .risk_manager import risk_manager

logger = logging.getLogger("Monitor")

class Monitor:
    def __init__(self, telegram_send: Callable = None):
        self.send = telegram_send
        self._last_hourly = datetime.now()
        self._last_daily = datetime.now().date()
        self._errors: list = []
        self._running = False
    
    async def start(self):
        """Start monitoring loop."""
        self._running = True
        logger.info("Monitor started")
        while self._running:
            await self._check()
            await asyncio.sleep(60)
    
    def stop(self):
        self._running = False
    
    async def _check(self):
        now = datetime.now()
        
        # Hourly report
        if (now - self._last_hourly).seconds >= 3600:
            await self._send_hourly_report()
            self._last_hourly = now
        
        # Daily report
        if now.date() != self._last_daily:
            await self._send_daily_report()
            self._last_daily = now.date()
        
        # Health check
        await self._health_check()
    
    async def _send_hourly_report(self):
        status = risk_manager.get_status()
        summary = db.get_stats_summary()
        
        msg = (
            f"📊 تقرير ساعي\n"
            f"✅ منفذ اليوم: {status['tasks_done']}\n"
            f"❌ فشل: {status['tasks_failed']}\n"
            f"💰 أرباح: {status['earnings']:.2f}₽\n"
            f"📦 إجمالي: {summary['done']}/{summary['total']}"
        )
        
        if self.send:
            await self.send(msg)
        logger.info("Hourly report sent")
    
    async def _send_daily_report(self):
        status = risk_manager.get_status()
        summary = db.get_stats_summary()
        
        msg = (
            f"📈 تقرير يومي\n"
            f"{'='*20}\n"
            f"✅ مهام ناجحة: {status['tasks_done']}\n"
            f"❌ مهام فاشلة: {status['tasks_failed']}\n"
            f"💰 أرباح اليوم: {status['earnings']:.2f}₽\n"
            f"📊 إجمالي الأرباح: {summary['earnings']:.2f}₽\n"
            f"🎯 نسبة النجاح: {summary['done']/(summary['total'] or 1)*100:.1f}%"
        )
        
        if self.send:
            await self.send(msg)
        logger.info("Daily report sent")
    
    async def _health_check(self):
        mem = psutil.virtual_memory()
        cpu = psutil.cpu_percent()
        
        if mem.percent > 90:
            await self.alert(f"⚠️ استهلاك الرام عالي: {mem.percent}%")
        
        if cpu > 95:
            await self.alert(f"⚠️ استهلاك CPU عالي: {cpu}%")
    
    async def alert(self, message: str):
        """Send immediate alert."""
        logger.warning("ALERT: %s", message)
        if self.send:
            await self.send(f"🚨 {message}")
    
    async def task_completed(self, platform: str, price: float, success: bool):
        """Log task completion."""
        if success:
            logger.info("Task done: %s +%.2f₽", platform, price)
        else:
            logger.info("Task failed: %s", platform)
    
    def get_system_stats(self) -> dict:
        return {
            "cpu": psutil.cpu_percent(),
            "memory": psutil.virtual_memory().percent,
            "disk": psutil.disk_usage('/').percent,
        }

monitor = Monitor()
