import asyncio
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from account_runtime import AccountCollectorGroup, AccountRuntime
from application.task_queue import TaskQueue
from persistence import BotPersistence
import test_task_flow as _task_flow


class Response:
    url = "https://unu.im/tasks/report/1"
    status_code = 200


class Client:
    async def get(self, *args, **kwargs):
        return Response()


class Runtime:
    def __init__(self):
        self.reservation_lock = asyncio.Lock()

    def reserve_task(self, url):
        return True


class Fleet:
    def __init__(self):
        self.runtimes = {"account-1": Runtime(), "account-2": Runtime()}

    def resolve_runtime(self, account_id):
        return self.runtimes.get(account_id)


class MultiAccountOverhaulTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.methods = _task_flow.TaskFlowTests._load_main_methods(
            "_fast_reserve",
            "_register_verification_record",
            "_verification_fingerprint",
            "_extract_task_id_from_url",
            "_get_task_details",
        )

    @staticmethod
    def details(account_id):
        return {
            "task_id": "1",
            "title": "Subscribe to Telegram",
            "title_tier": "accepted",
            "title_check_passed": True,
            "detail_check_passed": True,
            "title_platform": "telegram",
            "detail_platform": "telegram",
            "title_action": "subscribe",
            "detail_action": "subscribe",
            "analysis_status": "available",
            "ai_source": "ai",
            "unu_account_id": account_id,
        }

    def probe(self):
        methods = self.methods

        class Probe:
            for name, value in methods.items():
                locals()[name] = value

            def __init__(self):
                self._verification_records = {}
                self._account_task_details = {}
                self.tasks_details = {}
                self.verification_ttl_seconds = 300
                self._accepted_tasks = set()
                self._fast_reserve_inflight = set()
                self._http_client = Client()
                self.context = None
                self._active_unu_id = "account-1"
                self.fleet = Fleet()

            def _normalize_task_url(self, url):
                return url.rstrip("/")

            def _get_task_details(self, url, account_id=None):
                key = f"{account_id}:{url}" if account_id else url
                return self._account_task_details.get(key, self.tasks_details.get(url, {}))

        return Probe()

    def test_verification_is_bound_to_account(self):
        probe = self.probe()
        url = "https://unu.im/tasks/accept/task-1"
        first = self.details("account-1")
        probe._account_task_details["account-1:" + url] = first
        probe.tasks_details[url] = first
        self.assertTrue(probe._register_verification_record(url, first))
        self.assertFalse(
            asyncio.run(probe._fast_reserve(url, account_id="account-2"))
        )
        self.assertTrue(
            asyncio.run(probe._fast_reserve(url, account_id="account-1"))
        )

    def test_verification_rejects_stale_data_and_ttl(self):
        probe = self.probe()
        url = "https://unu.im/tasks/accept/task-1"
        details = self.details("account-1")
        probe._account_task_details["account-1:" + url] = details
        probe.tasks_details[url] = details
        self.assertTrue(probe._register_verification_record(url, details))
        details["title"] = "Changed title"
        self.assertFalse(
            asyncio.run(probe._fast_reserve(url, account_id="account-1"))
        )
        details["title"] = "Subscribe to Telegram"
        self.assertTrue(probe._register_verification_record(url, details))
        probe._verification_records["account-1:" + url]["expires_at"] = 0
        self.assertFalse(
            asyncio.run(probe._fast_reserve(url, account_id="account-1"))
        )

    def test_queue_deduplicates_within_account_but_not_between_accounts(self):
        with tempfile.TemporaryDirectory() as directory:
            queue = TaskQueue(Path(directory) / "queue.sqlite")
            self.assertTrue(queue.add("1", "u1", "title", account_id="a"))
            self.assertFalse(queue.add("1", "u2", "title", account_id="a"))
            self.assertTrue(queue.add("1", "u2", "title", account_id="b"))
            self.assertEqual(len(queue.get_pending(account_id="a")), 1)
            self.assertEqual(len(queue.get_pending(account_id="b")), 1)

    def test_history_storage_is_account_scoped(self):
        with tempfile.TemporaryDirectory() as directory:
            persistence = BotPersistence(Path(directory) / "state.sqlite")
            persistence.add_history("same-task", account_id="a")
            persistence.add_history("same-task", account_id="b")
            self.assertEqual(persistence.load_history_set(account_id="a"), {"same-task"})
            self.assertEqual(persistence.load_history_set(account_id="b"), {"same-task"})

    def test_account_collector_group_keeps_independent_collectors(self):
        class Collector:
            def __init__(self, account_id):
                self.account_id = account_id
                self.pending_urls = {account_id}
                self.stats = {"collected": 1}

            async def start(self):
                self.started = True

            async def stop(self):
                self.stopped = True

            def get_pending(self, limit=0):
                return [{"url": self.account_id, "account_id": self.account_id}]

        group = AccountCollectorGroup({
            "a": Collector("a"),
            "b": Collector("b"),
        })
        self.assertEqual(group.pending_urls, {"a", "b"})
        self.assertEqual({row["account_id"] for row in group.get_pending()}, {"a", "b"})
        self.assertEqual(AccountRuntime("a").account_id, "a")


if __name__ == "__main__":
    unittest.main()
