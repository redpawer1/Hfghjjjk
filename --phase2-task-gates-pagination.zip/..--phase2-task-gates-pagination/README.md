# UNU Bot

## تشغيل 24/7

1. ثبّت الاعتمادات:

   ```bash
   python3 -m pip install -r requirements.txt
   playwright install chromium
   ```

2. ضع ملفات الجلسات الحقيقية خارج شجرة المشروع داخل `/root/sessions/`.
   لا تُضمّن هذه الملفات في النسخ أو الأرشيفات القابلة للمشاركة.

3. أسماء الحساب الأول:

   ```text
   unu.json, vk.json, telegram.json, youtube.json, tiktok.json,
   instagram.json, x.json, rutube.json
   ```

   للحساب الثاني استخدم `-2` قبل الامتداد، مثل `unu-2.json` و`x-2.json`.
   القاعدة نفسها تعمل لباقي المنصات التي يدعمها المشروع.

4. اضبط الأسرار عبر متغيرات البيئة أو ملف `.env` محلي غير مُضاف إلى Git.
   لا تضع cookies أو مفاتيح داخل التقارير أو السجلات.

5. شغّل:

   ```bash
   POLL_INTERVAL_SECONDS=60 ./run_forever.sh
   ```

## systemd

```bash
sudo install -m 0644 deploy/unu-bot.service /etc/systemd/system/unu-bot.service
sudo systemctl daemon-reload
sudo systemctl enable --now unu-bot
sudo systemctl status unu-bot
```

يتولى `run_forever.sh` إعادة تشغيل العملية بعد الأعطال، بينما يحافظ النظام على
سجل دوري وheartbeat وتنظيف محدود للملفات المؤقتة.

## حدود التحقق

الاختبارات المحلية Mock ولا تثبت نجاح جلسة UNU حقيقية أو تنفيذًا على منصة خارجية.
للاختبار الحي يلزم وجود جلسات صالحة محليًا، ويجب أن يكون الاختبار قراءة فقط.
