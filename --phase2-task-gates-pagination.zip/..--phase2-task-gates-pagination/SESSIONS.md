# إضافة جلسة منصة

1. سجّل دخول في المتصفح على المنصة (أفيتو أو أوزون).
2. صدّر جلسة Playwright باسم المنصة:
   - avito.json
   - ozon.json
3. ارفع الملف إلى:
   /root/unu-bot/data/sessions/avito.json
   /root/unu-bot/data/sessions/ozon.json
4. البوت بيكتشف الملف تلقائي خلال دقيقة. متحتاجش تعدل كود.

الجلسات الحالية المتوقعة:
instagram.json  tiktok.json  vk.json  youtube.json
telegram.json   max.json     rutube.json  twitter.json
storage_state.json  (حساب UNU)

أفيتو وأوزون مرفوضين لحد ما تحط ملف الجلسة.
