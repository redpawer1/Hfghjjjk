#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Account fleet — تعدد حسابات UNU وحسابات المنصات.

data/accounts.json يتولد من الجلسات الموجودة ولا يُستبدل لو اتعدل.
الحالة بتتحفظ في data/fleet_state.json.
الحساب المتعطل يدخل كولدوان متزايد لحد يوم وبعدين يرجع يحاول.
"""
from __future__ import annotations

import json
import logging
import os
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
from account_runtime import AccountRuntime

logger = logging.getLogger("AccountFleet")


def _unu_identity(path: Path) -> str:
    """نفس حساب UNU حتى لو متسجل في أكتر من ملف."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return f"file:{path}"
    marks = []
    for item in data.get("cookies") or []:
        if not isinstance(item, dict):
            continue
        if "unu.im" not in str(item.get("domain") or ""):
            continue
        if item.get("name") in {"id", "hash"} and item.get("value"):
            marks.append(f"{item['name']}={item['value']}")
    if marks:
        return "|".join(sorted(marks))
    return f"file:{path.resolve()}"


def _dedupe_unu(accounts: list) -> list:
    kept = []
    seen = set()
    has_primary = any(
        Path(str(item.get("storage_state") or "")).name == "storage_state.json"
        and Path(str(item.get("storage_state") or "")).exists()
        for item in accounts
    )
    for item in accounts:
        path = Path(str(item.get("storage_state") or ""))
        if has_primary and path.name == "unu.json":
            logger.info("UNU alias dropped: %s", path)
            continue
        key = _unu_identity(path) if path.exists() else f"missing:{item.get('id')}"
        if key in seen:
            logger.info("UNU duplicate dropped: %s", path)
            continue
        seen.add(key)
        kept.append(item)
    for index, item in enumerate(kept):
        item["id"] = f"unu-{index + 1}"
    return kept

PLATFORM_NAMES = (
    "youtube", "tiktok", "instagram", "twitter", "x", "rutube",
    "ozon", "telegram", "wildberries", "vk", "max", "avito",
)

COOLDOWN_STEPS = (300, 900, 3600, 6 * 3600, 24 * 3600)

DEFAULT_PROOF = {
    "instagram": {"username": "virexohq1", "profile_url": "https://www.instagram.com/virexohq1"},
    "tiktok": {"username": "virexohq", "profile_url": "https://www.tiktok.com/@virexohq"},
    "max": {"username": "", "profile_url": "https://max.ru/u/f9LHodD0cOIeVY5jPgXZClogFIlVV5c_1_pbg6D9kyFdLQeUZwQvmtOj8m8"},
    "rutube": {"username": "56024403", "profile_url": "https://rutube.ru/channel/56024403/"},
    "youtube": {"username": "AjaebWalaken", "profile_url": "https://www.youtube.com/@AjaebWalaken"},
    "vk": {"username": "id1043297158", "profile_url": "https://m.vk.ru/id1043297158"},
    "twitter": {"username": "Yssyionbhhqxq", "profile_url": "https://x.com/Yssyionbhhqxq"},
    "x": {"username": "Yssyionbhhqxq", "profile_url": "https://x.com/Yssyionbhhqxq"},
}

HOURLY_CAP = {
    "instagram": 25, "tiktok": 30, "youtube": 20, "telegram": 60, "vk": 30,
    "rutube": 25, "max": 20, "twitter": 20, "x": 20, "ozon": 15, "wildberries": 15,
}

SESSION_ROOTS = (
    Path("/root/sessions"),
    Path("/root/unu-bot/data/sessions"),
    Path("data/sessions"),
)


def _now() -> float:
    return time.time()


def _today() -> str:
    return datetime.now().date().isoformat()


def _read_json(path: Path):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        logger.warning("json read failed %s: %s", path, error)
    return None


def _write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _canon_platform(name: str) -> str:
    name = (name or "").strip().lower()
    if name in {"x", "x.com"}:
        return "twitter"
    return name


class AccountFleet:
    def __init__(self, path: Optional[str] = None):
        self.path = Path(path or os.getenv("ACCOUNTS_FILE", "data/accounts.json"))
        self.state_path = Path(os.getenv("FLEET_STATE_FILE", "data/fleet_state.json"))
        self.accounts: Dict = {"version": 1, "unu": [], "platforms": {}}
        self.state: Dict = {"unu": {}, "platforms": {}}
        self._mtime = 0.0
        self._active_unu_id: Optional[str] = None
        self.active_lease: Optional[dict] = None
        self.hour_errors: List[dict] = []
        self.load()

    def load(self) -> None:
        raw = _read_json(self.path)
        has_accounts = isinstance(raw, dict) and (raw.get("unu") or raw.get("platforms"))
        if not has_accounts:
            raw = self._discover()
            try:
                if not self.path.exists():
                    _write_json(self.path, raw)
                    logger.info("Wrote discovered accounts to %s", self.path)
            except Exception as error:
                logger.warning("accounts.json write failed: %s", error)
        self.accounts = {
            "version": 1,
            "unu": list(raw.get("unu") or []),
            "platforms": dict(raw.get("platforms") or {}),
        }
        self._normalize()
        self._merge_discovered()
        state = _read_json(self.state_path)
        if isinstance(state, dict):
            self.state = {
                "unu": dict(state.get("unu") or {}),
                "platforms": dict(state.get("platforms") or {}),
            }
        try:
            self._mtime = self.path.stat().st_mtime if self.path.exists() else 0.0
        except Exception:
            self._mtime = 0.0
        logger.info(
            "Fleet loaded unu=%s platforms=%s",
            len(self.accounts["unu"]),
            {k: len(v) for k, v in self.accounts["platforms"].items()},
        )

    def reload_if_changed(self) -> None:
        try:
            if self.path.exists() and self.path.stat().st_mtime != self._mtime:
                logger.info("accounts.json changed — reloading")
                self.load()
                return
        except Exception as error:
            logger.debug("fleet reload: %s", error)
        # ملفات جلسة جديدة تتضاف حتى لو ما عدّلتش accounts.json
        if not getattr(self, "_last_scan", 0) or (time.time() - self._last_scan) > 60:
            self._last_scan = time.time()
            self._merge_discovered()

    def _discover(self) -> dict:
        unu = []
        platforms: Dict[str, list] = {}
        seen = set()

        def add_unu(path: Path):
            if not path.exists():
                return
            key = str(path.resolve())
            if key in seen:
                return
            seen.add(key)
            unu.append({
                "id": f"unu-{len(unu) + 1}",
                "label": path.stem,
                "enabled": True,
                "storage_state": str(path),
                "daily_cap": int(os.getenv("UNU_DAILY_CAP", "99999")),
                "proxy": "",
            })

        def add_platform(platform: str, path: Path, primary: bool):
            platform = _canon_platform(platform)
            if platform not in PLATFORM_NAMES and platform not in {"twitter"}:
                return
            if not path.exists():
                return
            key = str(path.resolve())
            if key in seen:
                return
            seen.add(key)
            bucket = platforms.setdefault(platform, [])
            proof = DEFAULT_PROOF.get(platform, {}) if primary else {}
            bucket.append({
                "id": f"{platform}-{len(bucket) + 1}",
                "label": path.stem,
                "enabled": True,
                "session": str(path),
                "username": proof.get("username", ""),
                "profile_url": proof.get("profile_url", ""),
                "hourly_cap": HOURLY_CAP.get(platform, 20),
                "daily_cap": 150,
            })

        for root in SESSION_ROOTS:
            if not root.exists():
                continue
            primary = root / "storage_state.json"
            alias = root / "unu.json"
            if primary.exists():
                add_unu(primary)
            elif alias.exists():
                add_unu(alias)
            for path in sorted(root.glob("unu_*.json")):
                add_unu(path)
            for path in sorted(root.glob("storage_state_*.json")):
                add_unu(path)
            for path in sorted(root.glob("*.json")):
                stem = path.stem.lower()
                if stem in {"storage_state", "unu"} or stem.startswith(("unu_", "storage_state")):
                    continue
                platform = stem
                primary = True
                for sep in ("_", "-"):
                    if sep in stem:
                        platform = stem.split(sep, 1)[0]
                        primary = False
                        break
                add_platform(platform, path, primary and stem in PLATFORM_NAMES)

        if not unu:
            unu.append({
                "id": "unu-1",
                "label": "primary",
                "enabled": True,
                "storage_state": "/root/sessions/storage_state.json",
                "daily_cap": int(os.getenv("UNU_DAILY_CAP", "99999")),
                "proxy": "",
            })
        return {"version": 1, "unu": _dedupe_unu(unu), "platforms": platforms}

    def _normalize(self) -> None:
        cleaned = []
        for index, item in enumerate(self.accounts["unu"]):
            if not isinstance(item, dict):
                continue
            item = dict(item)
            item["id"] = str(item.get("id") or f"unu-{index + 1}")
            item["enabled"] = bool(item.get("enabled", True))
            item["daily_cap"] = int(os.getenv("UNU_DAILY_CAP", "40"))
            item["storage_state"] = str(item.get("storage_state") or "")
            cleaned.append(item)
        self.accounts["unu"] = _dedupe_unu(cleaned)
        grouped = {}
        for platform, items in self.accounts["platforms"].items():
            platform = _canon_platform(str(platform))
            bucket = grouped.setdefault(platform, [])
            if not isinstance(items, list):
                continue
            for index, item in enumerate(items):
                if not isinstance(item, dict):
                    continue
                item = dict(item)
                item["id"] = str(item.get("id") or f"{platform}-{index + 1}")
                item["enabled"] = bool(item.get("enabled", True))
                item["platform"] = platform
                item["hourly_cap"] = int(item.get("hourly_cap") or HOURLY_CAP.get(platform, 20))
                item["daily_cap"] = int(item.get("daily_cap") or 150)
                item["session"] = str(item.get("session") or "")
                bucket.append(item)
        self.accounts["platforms"] = grouped

    def _merge_discovered(self) -> None:
        """أي ملف جلسة جديد يتضاف لوحده من غير ما يمسح تعديلاتك."""
        try:
            found = self._discover()
        except Exception as error:
            logger.debug("discover merge failed: %s", error)
            return
        changed = False
        known_unu = {a.get("storage_state") for a in self.accounts["unu"]}
        known_ids = set()
        for account in self.accounts["unu"]:
            path = Path(str(account.get("storage_state") or ""))
            if path.exists():
                known_ids.add(_unu_identity(path))
        for item in found.get("unu") or []:
            path = item.get("storage_state") or ""
            file_path = Path(path)
            if not path or path in known_unu or not file_path.exists():
                continue
            ident = _unu_identity(file_path)
            if ident in known_ids:
                logger.info("UNU session already known, skip %s", path)
                continue
            item["id"] = f"unu-{len(self.accounts['unu']) + 1}"
            self.accounts["unu"].append(item)
            known_unu.add(path)
            known_ids.add(ident)
            changed = True
            logger.info("Fleet added UNU account %s", path)
        for platform, items in (found.get("platforms") or {}).items():
            bucket = self.accounts["platforms"].setdefault(platform, [])
            known = {i.get("session") for i in bucket}
            for item in items:
                path = item.get("session") or ""
                if not path or path in known or not Path(path).exists():
                    continue
                item["id"] = f"{platform}-{len(bucket) + 1}"
                item["platform"] = platform
                bucket.append(item)
                known.add(path)
                changed = True
                logger.info("Fleet added %s account %s", platform, path)
        if changed and self.path.exists():
            try:
                _write_json(self.path, self.accounts)
            except Exception as error:
                logger.warning("accounts merge save failed: %s", error)

    def save_state(self) -> None:
        try:
            _write_json(self.state_path, self.state)
        except Exception as error:
            logger.warning("fleet state save failed: %s", error)

    def _slot(self, kind: str, account_id: str) -> dict:
        bucket = self.state.setdefault(kind, {})
        slot = bucket.get(account_id)
        if not isinstance(slot, dict):
            slot = {
                "ok": 0, "fail": 0, "streak": 0, "cooldown_until": 0,
                "day": _today(), "day_count": 0, "hour_window": [],
                "last_error": "", "last_ok": 0,
            }
            bucket[account_id] = slot
        if slot.get("day") != _today():
            slot["day"] = _today()
            slot["day_count"] = 0
        now = _now()
        slot["hour_window"] = [ts for ts in slot.get("hour_window") or [] if now - float(ts) < 3600]
        return slot

    def unu_accounts(self) -> List[dict]:
        self.reload_if_changed()
        return [a for a in self.accounts["unu"] if a.get("enabled")]

    def real_unu_accounts(self) -> List[dict]:
        return [a for a in self.unu_accounts() if a.get("storage_state") and Path(a["storage_state"]).exists()]

    def _unu_ready(self, account: dict) -> bool:
        if not account or not account.get("id"):
            return False
        path = account.get("storage_state") or ""
        return bool(path) and Path(path).exists()

    def healthy_unu(self, account_id: Optional[str] = None) -> List[dict]:
        ready = [a for a in self.unu_accounts() if self._unu_ready(a)]
        if account_id is not None:
            return [a for a in ready if str(a.get("id")) == str(account_id)]
        return ready

    def current_unu(self) -> Optional[dict]:
        accounts = self.healthy_unu()
        if not accounts:
            return None
        if self._active_unu_id:
            for account in accounts:
                if account["id"] == self._active_unu_id and self._unu_ready(account):
                    return account
        return None

    def get_unu(self, account_id: str) -> Optional[dict]:
        if not account_id:
            return None
        for account in self.unu_accounts():
            if account["id"] == account_id:
                return account
        return None

    def resolve_runtime(self, account_id: str) -> Optional[AccountRuntime]:
        account_id = str(account_id or "").strip()
        account = self.get_unu(account_id)
        if not account or not self._unu_ready(account):
            return None
        cookies = self.unu_cookies(account)
        if not cookies:
            return None
        runtime = getattr(self, "_runtimes", {}).get(account_id)
        if runtime is None or runtime.disconnected:
            if not hasattr(self, "_runtimes"):
                self._runtimes = {}
            runtime = AccountRuntime(
                account_id, account=account, cookies=cookies,
                storage_state=str(account.get("storage_state") or ""),
            )
            self._runtimes[account_id] = runtime
        elif runtime.cookies != cookies:
            old_client = runtime.api_client
            runtime.api_client = None
            runtime.cookies = dict(cookies)
            if old_client is not None and hasattr(old_client, "close"):
                old_client.close()
        return runtime

    def mark_unu(self, account_id: str, status: str, reason: str = "") -> None:
        account = self.get_unu(account_id)
        if not account:
            return
        slot = self._slot("unu", account_id)
        status = (status or "").lower()
        if status in {"ok", "success", "verified"}:
            slot["ok"] = int(slot.get("ok") or 0) + 1
            slot["streak"] = 0
            slot["cooldown_until"] = 0
            slot["day_count"] = int(slot.get("day_count") or 0) + 1
            slot["last_ok"] = _now()
            slot["last_error"] = ""
        else:
            slot["fail"] = int(slot.get("fail") or 0) + 1
            slot["streak"] = int(slot.get("streak") or 0) + 1
            slot["last_error"] = (reason or status)[:180]
            if status in {"session", "session_invalid", "banned", "rate_limit", "429"}:
                step = min(int(slot["streak"]) - 1, len(COOLDOWN_STEPS) - 1)
                slot["cooldown_until"] = _now() + COOLDOWN_STEPS[max(0, step)]
                if self._active_unu_id == account_id:
                    self._active_unu_id = None
        self._remember_error("unu", account_id, status, reason)
        self.save_state()

    def read_storage(self, account: Optional[dict]) -> Optional[dict]:
        if not account:
            return None
        data = _read_json(Path(account.get("storage_state") or ""))
        if isinstance(data, dict) and ("cookies" in data or "origins" in data):
            return data
        return None

    def unu_cookies(self, account: Optional[dict]) -> dict:
        state = self.read_storage(account) or {}
        cookies = {}
        for item in state.get("cookies") or []:
            if "unu.im" in str(item.get("domain") or "") and item.get("name"):
                cookies[item["name"]] = item["value"]
        return cookies

    def next_unu_after(self, account_id: str) -> Optional[dict]:
        self.mark_unu(account_id, "session", "rotate")
        return self.current_unu()

    def available_platforms(self) -> set:
        found = set()
        for platform, items in self.accounts["platforms"].items():
            for item in items:
                if item.get("enabled") and item.get("session") and Path(item["session"]).exists():
                    found.add(platform)
                    if platform == "twitter":
                        found.add("x")
        return found

    def _platform_ready(self, account: dict) -> bool:
        if not account or not account.get("enabled"):
            return False
        path = account.get("session") or ""
        if path and not Path(path).exists():
            return False
        slot = self._slot("platforms", account["id"])
        if float(slot.get("cooldown_until") or 0) > _now():
            return False
        if int(slot.get("day_count") or 0) >= int(account.get("daily_cap") or 150):
            return False
        if len(slot.get("hour_window") or []) >= int(account.get("hourly_cap") or 20):
            return False
        return True

    def lease_platform(self, platform: str) -> Optional[dict]:
        platform = _canon_platform(platform)
        if platform in {"", "website", "unknown", "other"}:
            self.active_lease = None
            return None
        items = list(self.accounts["platforms"].get(platform) or [])
        ready = [item for item in items if self._platform_ready(item)]
        if not ready:
            ready = [
                item for item in items
                if item.get("enabled") and Path(item.get("session") or "missing").exists()
            ]
        if not ready:
            self.active_lease = None
            return None
        ready.sort(key=lambda item: len(self._slot("platforms", item["id"]).get("hour_window") or []))
        chosen = dict(ready[0])
        chosen["platform"] = platform
        self.active_lease = chosen
        self.apply_lease(chosen)
        return chosen

    def apply_lease(self, lease: dict) -> None:
        platform = _canon_platform(lease.get("platform") or "")
        path = lease.get("session") or ""
        if platform and path:
            os.environ[f"FLEET_COOKIE_{platform.upper()}"] = path
            env_names = {
                "youtube": "YOUTUBE_COOKIES_FILE",
                "tiktok": "TIKTOK_COOKIES_FILE",
                "instagram": "INSTAGRAM_COOKIES_FILE",
                "twitter": "TWITTER_COOKIES_FILE",
                "vk": "VK_COOKIES_FILE",
                "max": "MAX_COOKIES_FILE",
                "rutube": "RUTUBE_COOKIES_FILE",
                "ozon": "OZON_COOKIES_FILE",
                "wildberries": "WILDBERRIES_COOKIES_FILE",
                "telegram": "TELEGRAM_WEB_COOKIES_FILE",
            }
            if platform in env_names:
                os.environ[env_names[platform]] = path
            try:
                import skill_manager as skill_mod
                if hasattr(skill_mod, "SM_COOKIE_FILES"):
                    skill_mod.SM_COOKIE_FILES[platform] = path
                    if platform == "twitter":
                        skill_mod.SM_COOKIE_FILES["x"] = path
                if hasattr(skill_mod, "_SM_COOKIE_MTIME"):
                    skill_mod._SM_COOKIE_MTIME.pop(platform, None)
            except Exception as error:
                logger.debug("skill cookie path update: %s", error)
        if lease.get("session_string"):
            os.environ["TELEGRAM_STRING_SESSION"] = str(lease["session_string"])

    def release_platform(self, lease: Optional[dict], success: bool, reason: str = "") -> None:
        if not lease:
            return
        slot = self._slot("platforms", lease["id"])
        if success:
            slot["ok"] = int(slot.get("ok") or 0) + 1
            slot["streak"] = 0
            slot["cooldown_until"] = 0
            slot["day_count"] = int(slot.get("day_count") or 0) + 1
            slot["last_ok"] = _now()
            slot["last_error"] = ""
        else:
            slot["fail"] = int(slot.get("fail") or 0) + 1
            slot["streak"] = int(slot.get("streak") or 0) + 1
            slot["last_error"] = (reason or "fail")[:180]
            kind = (reason or "").lower()
            if any(token in kind for token in ("session", "login", "auth", "rate", "429", "banned", "captcha")):
                step = min(int(slot["streak"]) - 1, len(COOLDOWN_STEPS) - 1)
                slot["cooldown_until"] = _now() + COOLDOWN_STEPS[max(0, step)]
        if success or "rate" in (reason or "").lower() or "429" in (reason or ""):
            slot["hour_window"] = list(slot.get("hour_window") or []) + [_now()]
        self._remember_error(lease.get("platform") or "platform", lease["id"], "ok" if success else "fail", reason)
        self.save_state()

    def proof_identity(self, platform: str) -> dict:
        platform = _canon_platform(platform)
        lease = self.active_lease
        if not lease or _canon_platform(lease.get("platform") or "") != platform:
            items = [item for item in self.accounts["platforms"].get(platform, []) if item.get("enabled")]
            lease = items[0] if items else None
        if not lease:
            proof = DEFAULT_PROOF.get(platform) or {}
            return {
                "username": proof.get("username") or "",
                "profile_url": proof.get("profile_url") or "",
                "locked": False,
            }
        return {
            "username": str(lease.get("username") or "").lstrip("@"),
            "profile_url": str(lease.get("profile_url") or ""),
            "locked": True,
        }

    def _remember_error(self, platform: str, account_id: str, status: str, reason: str) -> None:
        if status in {"ok", "success", "verified"}:
            return
        now = _now()
        self.hour_errors.append({
            "ts": now,
            "platform": platform,
            "account": account_id,
            "status": status,
            "reason": (reason or "")[:160],
        })
        self.hour_errors = [item for item in self.hour_errors if now - item["ts"] < 3600][-200:]

    def digest(self, bot=None) -> str:
        unu_lines = []
        for account in self.unu_accounts():
            slot = self._slot("unu", account["id"])
            cool = float(slot.get("cooldown_until") or 0)
            flag = "كولدوان" if cool > _now() else "جاهز"
            exists = "ملف" if Path(account.get("storage_state") or "").exists() else "لا ملف"
            unu_lines.append(
                f"• {account['id']} ({account.get('label')}) {flag} اليوم {slot.get('day_count')}/{account.get('daily_cap')} [{exists}]"
            )
        plat_lines = []
        for platform, items in sorted(self.accounts["platforms"].items()):
            ready = sum(1 for item in items if self._platform_ready(item))
            done = sum(int(self._slot("platforms", item["id"]).get("day_count") or 0) for item in items)
            plat_lines.append(f"• {platform}: {ready}/{len(items)} حساب، منفّذ اليوم {done}")
        recent = self.hour_errors[-8:]
        err_txt = "\n".join(
            f"• {item['platform']}/{item['account']}: {item['status']} {item['reason'][:80]}"
            for item in recent
        ) or "• لا شيء"
        done = getattr(bot, "daily_tasks_done", 0) if bot else 0
        money = getattr(bot, "daily_earnings", 0.0) if bot else 0.0
        uptime = ""
        if bot is not None and getattr(bot, "start_time", None):
            seconds = int((datetime.now() - bot.start_time).total_seconds())
            days, rem = divmod(seconds, 86400)
            hours, _rem = divmod(rem, 3600)
            uptime = f"{days}ي {hours}س"
        return (
            "📋 تقرير الساعة\n"
            f"شغال من: {uptime or 'الآن'}\n"
            f"اليوم: {done} مهمة | {float(money):.2f}₽\n\n"
            "حسابات UNU:\n" + ("\n".join(unu_lines) or "• لا يوجد")
            + "\n\nالمنصات:\n" + ("\n".join(plat_lines) or "• لا يوجد")
            + "\n\nآخر الأخطاء:\n" + err_txt
        )

    def attach(self, bot) -> None:
        count = max(1, len(self.real_unu_accounts()) or len(self.unu_accounts()))
        current = int(getattr(bot, "max_tasks_per_day", 40) or 40)
        bot.max_tasks_per_day = min(40 * count, 200)
        bot.max_concurrent_checks = 1
        bot._active_unu_id = None
        logger.info(
            "Fleet attached unu=%s daily_cap=%s concurrency=1",
            count, bot.max_tasks_per_day,
        )
