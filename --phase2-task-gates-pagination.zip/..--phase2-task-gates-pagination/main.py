#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
UNU BOT - Main Orchestrator

المسؤوليات:
- تشغيل Playwright وإدارة الـ browser lifecycle.
- تحميل والتحقق من Session.
- جمع روابط المهام.
- فحص الروابط مع rate limiting حقيقي.
- استخراج بيانات المهمة.
- تحليل المهمة بالـ AI مع validation للنتيجة.
- تنفيذ المهمة عن طريق SkillManager.
- تسليم الإثبات والتحقق من نجاح التسليم.
- إدارة limits / state / history.
- إرسال الإشعارات إلى Telegram.
- إغلاق الموارد بشكل صحيح عند انتهاء التشغيل.
"""

import asyncio
import hashlib
import html
import json
import logging
import os
import random
import re
import time
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Any, Optional
from urllib.parse import parse_qs, unquote, urlparse, urlunparse
import html as html_module

import httpx
from playwright.async_api import (
    Browser,
    BrowserContext,
    Page,
    TimeoutError as PlaywrightTimeoutError,
    async_playwright,
)

from telegram import Bot
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ForceReply
from telegram.constants import ParseMode

from config import APP, STEALTH, BOT_CONFIG
from platform_policy import EXECUTION_PLATFORMS, canonical_platform
from proof_manifest import build_proof_manifest
from proof_requirements import parse_proof_requirements
try:
    from config import PROXY
except Exception:
    PROXY = None  # type: ignore
from ai_core import brain
from skill_manager import SkillManager
from dashboard import Dashboard
from task_dictionary import task_dictionary
from core.bot_services import bot_services
try:
    from application import session_registry, TaskCollector, lifecycle, HealthMonitor

except ImportError:
    session_registry = None

try:
    from application.pre_filter import should_accept_task, detect_platform_from_title
    from application.session_registry import session_registry
except ImportError:
    should_accept_task = None
    detect_platform_from_title = None
    session_registry = None


    TaskCollector = None
    lifecycle = None
    HealthMonitor = None
try:
    from persistence import get_persistence, TASK_STATES
except Exception:
    get_persistence = None  # type: ignore
    TASK_STATES = ()
try:
    from normalization import normalize_platform as _norm_platform_unified
    from normalization import normalize_action as _norm_action_unified
except Exception:
    _norm_platform_unified = None  # type: ignore
    _norm_action_unified = None  # type: ignore


# ==========================================================
# Logging
# ==========================================================

logger = logging.getLogger("MainOrchestrator")

if not logger.handlers:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )


# ==========================================================
# Constants
# ==========================================================

UNU_BASE_URL = "https://unu.im"
TASK_SEARCH_URL = f"{UNU_BASE_URL}/tasks/search"
WORKS_PAGE_URL = f"{UNU_BASE_URL}/tasks/works"
TASK_REPORT_MARKER = "/tasks/report/"

DEFAULT_LOOP_DELAY = 20
DEFAULT_ERROR_DELAY = 30

PAGE_TIMEOUT = 60_000
CHECK_TIMEOUT = 45_000
DETAIL_TIMEOUT = 45_000
ACTION_TIMEOUT = 45_000

MAX_TELEGRAM_MESSAGE_LENGTH = 3900
MAX_TELEGRAM_CAPTION_LENGTH = 950
PROOF_APPROVAL_TIMEOUT = 900
PROOF_APPROVAL_POLL_TIMEOUT = 20

MAX_ACTIVITY_ITEMS = 100
MAX_STORED_TASKS = 500

DEFAULT_MAX_TASKS_PER_DAY = 99999
DEFAULT_MAX_CONCURRENT_CHECKS = 10

# عدد مرات إعادة محاولة التنقل قبل اعتبار الخطأ حقيقيًا.
MAX_NAVIGATION_RETRIES = 2

# عدد الثواني بين محاولات الفحص الجديدة.
CHECK_INTERVAL_SECONDS = 1.0

# مدة الانتظار بعد العمليات التي تغير الصفحة.
POST_ACTION_WAIT = 1.5

# ==========================================================
# Execution / Filtering / AI Gate
# ==========================================================

# المنصات المسموح بتنفيذها فقط (حسب طلب التشغيل)
PROOF_PROFILE_URLS = {
    "instagram": "https://www.instagram.com/virexohq1?stkn=MWdwZTgxb2d4NXlocA==",
    "tiktok": "https://www.tiktok.com/@virexohq?is_from_webapp=1&sender_device=pc",
    "max": "https://max.ru/u/f9LHodD0cOIeVY5jPgXZClogFIlVV5c_1_pbg6D9kyFdLQeUZwQvmtOj8m8",
    "rutube": "https://rutube.ru/channel/56024403/",
    "youtube": "https://www.youtube.com/@AjaebWalaken",
    "vk": "https://m.vk.ru/id1043297158",
    "twitter": "https://x.com/Yssyionbhhqxq",
    "x": "https://x.com/Yssyionbhhqxq",
}

PROOF_USERNAMES = {
    "instagram": "virexohq1",
    "tiktok": "virexohq",
    "youtube": "AjaebWalaken",
    "vk": "id1043297158",
    "twitter": "Yssyionbhhqxq",
    "x": "Yssyionbhhqxq",
    "rutube": "56024403",
}

# المنصات المفعّلة: TG / VK / Max / IG / TikTok / Twitter / YouTube / Rutube
ALLOWED_EXECUTION_PLATFORMS = set(EXECUTION_PLATFORMS)

CORE_FOCUS_PLATFORMS = EXECUTION_PLATFORMS

# مرادفات تُطبَّع إلى الاسم الـcanonical داخل الـGate
PLATFORM_CANONICAL_ALIASES = {
    "вк": "vk",
    "вконтакте": "vk",
    "vk reels": "vk",
    "вк рилс": "vk",
    "vk clips": "vk",
    "клипы": "vk",
    "rutube": "rutube",
    "рутуб": "rutube",
    "рутьюб": "rutube",

    "x": "twitter",
    "x.com": "twitter",
    "twitter/x": "twitter",
    "твиттер": "twitter",
    "макс": "max",
    "max messenger": "max",
    "авито": "avito",
    "avito.ru": "avito",
    "озон": "ozon",
    "ozon.ru": "ozon",
    "ozone.ru": "ozon",
    "google maps": "google_maps",
    "maps": "google_maps",
    "google map": "google_maps",
    "гугл карты": "google_maps",
    "google_map": "google_maps",
    "яндекс": "yandex",
    "яндекс карты": "yandex",
    "yandex maps": "yandex",
    "dzen": "yandex",
    "дзен": "yandex",
    "yt": "youtube",
    "ig": "instagram",
    "tt": "tiktok",
    "tg": "telegram",
}

DEFAULT_AI_SUPPORTED_PLATFORMS = set(ALLOWED_EXECUTION_PLATFORMS)

DEFAULT_AI_SUPPORTED_ACTIONS = {
    "subscribe",
    "like",
    "comment",
    "view",
    "share",
    "repost",
    "register",
    "review",
    "start_bot",
    "apply",
    "message",
    "favorite",
}

DEFAULT_AI_SUPPORTED_PROOFS = {
    "screenshot",
    "username",
    "text",
    "account_url",
    "comment",
}

# عدد محاولات إعادة تنفيذ الأخطاء القابلة لإعادة المحاولة.
MAX_EXECUTION_RETRIES = 2

# بداية الـbackoff.
EXECUTION_RETRY_BASE_DELAY = 2.0

# الحد الأقصى للـbackoff.
EXECUTION_RETRY_MAX_DELAY = 15.0

# كلمات تدل على Rate Limit / 429.
RATE_LIMIT_MARKERS = (
    "429",
    "too many requests",
    "rate limit",
    "rate-limit",
    "слишком много запросов",
)

# كلمات تدل على انتهاء الجلسة.
SESSION_ERROR_MARKERS = (
    "session expired",
    "session invalid",
    "unauthorized",
    "not authorized",
    "authentication",
    "login required",
    "войдите",
    "авторизац",
    "сессия истек",
)

# أخطاء الشبكة القابلة لإعادة المحاولة.
NETWORK_ERROR_MARKERS = (
    "connection",
    "connect",
    "network",
    "dns",
    "socket",
    "connection reset",
    "connection refused",
    "temporarily unavailable",
    "service unavailable",
    "bad gateway",
    "gateway timeout",
    "502",
    "503",
    "504",
)

# أخطاء الـtimeout.
TIMEOUT_ERROR_MARKERS = (
    "timeout",
    "timed out",
    "time out",
)


# ==========================================================
# Helpers
# ==========================================================

def now_ts() -> int:
    return int(time.time())


def safe_float(value: Any, default: float = 0.0) -> float:
    if value is None:
        return default

    try:
        text = str(value)
        text = text.replace(" ", "")
        text = text.replace(",", ".")
        match = re.search(r"-?\d+(?:\.\d+)?", text)

        if not match:
            return default

        return float(match.group(0))

    except Exception:
        return default


def normalize_text(value: Any) -> str:
    if value is None:
        return ""

    return re.sub(r"\s+", " ", str(value)).strip()


def chunk_text(text: str, max_length: int = MAX_TELEGRAM_MESSAGE_LENGTH):
    text = str(text or "")

    if len(text) <= max_length:
        return [text]

    chunks = []
    current = ""

    for line in text.splitlines():
        line = line.strip()

        if not line:
            continue

        candidate = line if not current else f"{current}\n{line}"

        if len(candidate) <= max_length:
            current = candidate
            continue

        if current:
            chunks.append(current)
            current = ""

        while len(line) > max_length:
            chunks.append(line[:max_length])
            line = line[max_length:]

        current = line

    if current:
        chunks.append(current)

    return chunks


# ==========================================================
# Rate Limiter
# ==========================================================

class AsyncRateLimiter:
    """
    Rate limiter بسيط لضمان وجود حد زمني حقيقي بين العمليات.

    الـ Semaphore وحده لا يعني "طلبات في الثانية".
    هنا بنستخدم lock + timestamp.
    """

    def __init__(self, interval: float):
        self.interval = max(0.0, float(interval))
        self._lock = asyncio.Lock()
        self._last_time = 0.0

    async def wait(self):
        async with self._lock:
            current = time.monotonic()
            elapsed = current - self._last_time

            if elapsed < self.interval:
                await asyncio.sleep(self.interval - elapsed)

            self._last_time = time.monotonic()


# ==========================================================
# Main Bot
# ==========================================================

class UnuBot:

    def __init__(self):

        # --------------------------------------------------
        # Runtime state
        # --------------------------------------------------

        self.tasks_done = 0
        self.earnings = 0.0

        self.running = False
        # New modular components
        self.task_collector = TaskCollector(self) if TaskCollector else None
        self._accepted_tasks = set()  # منع القبول المتكرر
        self.session_registry = session_registry
        self.health_monitor = HealthMonitor(self) if HealthMonitor else None
        self.mode = "execute"

        self.start_time = datetime.now()

        # --------------------------------------------------
        # Browser
        # --------------------------------------------------

        self.playwright = None
        self.browser: Optional[Browser] = None
        self.context: Optional[BrowserContext] = None
        self.page: Optional[Page] = None
        # صفحة تنفيذ المهمة الحالية. لا تستخدم صفحة التجميع المشتركة لهذا الغرض.
        self._active_task_page: Optional[Page] = None
        self._active_task_url: Optional[str] = None

        # تثبيت البصمة طوال عمر البوت؛ إعادة تشغيل الـ Context لا تغيّر الـ UA.
        self._session_user_agent: Optional[str] = None

        # --------------------------------------------------
        # Components
        # --------------------------------------------------

        self.skills: Optional[SkillManager] = None
        self.ai_brain = brain
        self.task_dictionary = task_dictionary
        self.dashboard: Optional[Dashboard] = None

        # --------------------------------------------------
        # Dashboard filters (تُحدَّث من لوحة التحكم)
        # --------------------------------------------------
        self.dashboard_filters: dict = {}
        self.filter_platform: str = "all"
        self.filter_price_min: float = 0.0
        self.filter_price_max: float = 999999.0
        self.filter_task_count: int = 0
        self.safe_mode: bool = True
        self.auto_skip_blocked: bool = True

        # --------------------------------------------------
        # Session
        # --------------------------------------------------

        self.storage_state: Optional[dict] = None

        # --------------------------------------------------
        # Task state
        # --------------------------------------------------

        self.history = set()
        self.invalid = set()
        self.invalid_reasons = {}
        self.validated = set()

        self.tasks_details = {}
        self._account_task_details = {}
        self._verification_records = {}
        self.verification_ttl_seconds = 300
        self._fast_reserve_inflight = set()

        # --------------------------------------------------
        # Classification Cache (LRU)
        # --------------------------------------------------
        self._classification_cache = {}
        self._cache_max_size = 5000
        self._last_balance = 0.0

        # --------------------------------------------------
        # Limits
        # --------------------------------------------------

        self.max_tasks_per_day = DEFAULT_MAX_TASKS_PER_DAY
        self.max_concurrent_checks = DEFAULT_MAX_CONCURRENT_CHECKS

        self.details_per_message = 50
        self.max_detailed = float("inf")
        self.detailed_count = 0

        self.cycle_limit = 9999
        self.error_limit = 5

        self.loop_delay = max(
            1,
            int(os.getenv("POLL_INTERVAL_SECONDS", "60") or DEFAULT_LOOP_DELAY),
        )
        self.error_delay = DEFAULT_ERROR_DELAY
        self._collection_gate = asyncio.Lock()
        self._browser_recovery_lock = asyncio.Lock()
        self._browser_generation = 0
        self._browser_recovered_at = 0.0
        self._last_collection_source = ""
        self._last_collection_error = ""
        self.last_cycle_started = 0.0
        self.last_cycle_finished = 0.0
        self.next_poll_at = 0.0
        self.collection_stats = {}

        # --------------------------------------------------
        # Daily counters
        # --------------------------------------------------

        self.daily_tasks_done = 0
        self.daily_earnings = 0.0
        self.daily_date = datetime.now().date()

        # --------------------------------------------------
        # Logging/state
        # --------------------------------------------------

        self.activity_log = deque(maxlen=MAX_ACTIVITY_ITEMS)
        # SQLite persistence (اختياري — لا يكسر لو فشل)
        self.persistence = None
        try:
            if get_persistence is not None:
                self.persistence = get_persistence()
                # استرجع history/invalid من DB
                self.history |= self.persistence.load_history_set("history")
                self.invalid |= self.persistence.load_history_set("invalid")
                self.validated |= self.persistence.load_history_set("validated")
                daily = self.persistence.get_daily()
                self.daily_tasks_done = int(daily.get("tasks_done") or 0)
                self.daily_earnings = float(daily.get("earnings") or 0.0)
                logger.info("📦 Persistence loaded | history=%s invalid=%s daily=%s",
                            len(self.history), len(self.invalid), daily)
        except Exception as _pers_err:
            logger.warning("Persistence init failed: %s", _pers_err)
            self.persistence = None

        # --------------------------------------------------
        # Locks
        # --------------------------------------------------

        self._state_lock = asyncio.Lock()
        self._execution_lock = asyncio.Lock()
        self._awaiting_human_decision = False  # type: bool

        self._main_loop_task: Optional[asyncio.Task] = None
        self._dashboard_task: Optional[asyncio.Task] = None

        # --------------------------------------------------
        # Rate limiter
        # --------------------------------------------------

        self.check_rate_limiter = AsyncRateLimiter(
            CHECK_INTERVAL_SECONDS
        )

        # --------------------------------------------------
        # Telegram
        # --------------------------------------------------

        self.telegram_bot: Optional[Bot] = None
        self._telegram_update_offset: Optional[int] = None
        self._pending_proof_approvals = {}

        # --------------------------------------------------
        # Shutdown
        # --------------------------------------------------

        self._shutdown_event = asyncio.Event()

    # ======================================================
    # General utilities
    # ======================================================

    def log(self, message: str):
        message = normalize_text(message)

        timestamp = datetime.now().strftime("%H:%M:%S")

        self.activity_log.append(
            f"🕒 {timestamp} — {message}"
        )

        logger.info(message)

    def _reset_daily_counter_if_needed(self):
        today = datetime.now().date()

        if today != self.daily_date:
            self.daily_date = today
            self.daily_tasks_done = 0
            self.daily_earnings = 0.0

            logger.info("🔄 تم تصفير العداد اليومي.")

    def _daily_limit_reached(self) -> bool:
        return False  # الحد اليومي متشال. المهام المعلقة مش بتتعدّ حد.
        self._reset_daily_counter_if_needed()
        open_n = max(0, int(getattr(self, "_open_reserved_count", 0) or 0))
        return False

    def _is_forbidden_task(self, details: dict, action: str = "") -> tuple:
        """فئة UNU هي الحكم. تسجيل / هوية / بطاقة بنك ممنوعة قبل الحجز."""
        details = details or {}
        blob = " ".join(
            str(details.get(k) or "")
            for k in ("title", "category", "task_type", "description", "info_for_work")
        ).lower().replace("ё", "е")
        category = str(details.get("category") or details.get("task_type") or "").lower().replace("ё", "е")
        action = str(action or details.get("action") or "").lower()
        for key in ("регистрац", "идентификац", "оформление заявки", "паспорт", "установка приложений"):
            if key in category:
                return True, "category:" + key
        for key in (
            "дебетов", "оформить карт", "банковск", "альфа-банк", "альфа банк",
            "паспорт", "идентификац", "селфи",
        ):
            if key in blob:
                return True, "text:" + key
        if action in {"register", "install", "call", "withdraw", "kyc"}:
            return True, "action:" + action
        return False, ""

    def _hard_booking_gate(self, details: dict, ai_analysis: dict, links: list) -> tuple:
        """قفل الحجز. الرابط هو الحكم، مش تخمين الـAI."""
        details = details or {}
        ai_analysis = ai_analysis or {}
        blob = " ".join(
            str(details.get(k) or "")
            for k in ("title", "category", "task_type", "description", "info_for_work", "raw_page_text")
        ).lower().replace("ё", "е")
        bad_words = (
            "авито", "avito", "букинг", "booking.com", "одноклассник", "ok.ru",
            "chrome.google", "расширени", "яндекс карт", "yandex maps",
            "wildberries" if False else "",
        )
        # منصات مش مدعومة في التنفيذ الفعلي دلوقتي حتى لو الـAI سمّاها غلط
        unsupported = (
            "авито", "avito", "букинг", "booking", "одноклассник", "ok.ru",
            "chrome", "хром", "расширени", "яндекс", "yandex", "дзен", "dzen",
            "пикабу", "habr", "vc.ru", "mail.ru",
        )
        for word in unsupported:
            if word and word in blob:
                return False, "unsupported_in_text:" + word
        russian = (
            "только для граждан рф", "только для росси", "гражданам рф",
            "только россия", "паспорт рф",
        )
        for phrase in russian:
            if phrase in blob:
                return False, "russian_only"
        hard = (
            "минимум 1000", "не менее 1000", "аккаунт старше",
            "только с компьютера", "геолокац",
        )
        for phrase in hard:
            if phrase in blob:
                return False, "hard_conditions"
        real_links = [
            str(u) for u in (links or [])
            if u and "unu.im" not in str(u).lower()
        ]
        if not real_links:
            return False, "no_real_target"
        host_map = {
            "telegram": ("t.me", "telegram.me", "telegram.org"),
            "vk": ("vk.com", "vk.ru", "vk.me"),
            "tiktok": ("tiktok.com",),
            "instagram": ("instagram.com",),
            "youtube": ("youtube.com", "youtu.be"),
            "twitter": ("twitter.com", "x.com"),
            "max": ("max.ru",),
            "rutube": ("rutube.ru",),
            "ozon": ("ozon.ru",),
            "wildberries": ("wildberries.ru", "wb.ru"),
        }
        platform = str(ai_analysis.get("platform") or "").strip().lower()
        joined = " ".join(real_links).lower()
        inferred = ""
        for name, hosts in host_map.items():
            if any(h in joined for h in hosts):
                inferred = name
                break
        if not inferred:
            return False, "target_host_unknown"
        if platform and platform != inferred:
            return False, f"platform_mismatch:{platform}!={inferred}"
        allowed_hosts = host_map.get(inferred, ())
        if not any(h in joined for h in allowed_hosts):
            return False, "host_not_allowed"
        return True, "ok"

    # ======================================================
    # URL utilities
    # ======================================================

    @staticmethod
    def _clean_url(url: str) -> str:

        if not url:
            return ""

        url = str(url).strip()
        url = url.strip("`")
        url = url.strip()
        # Decode HTML entities (" & etc)
        url = html_module.unescape(url)

        try:
            parsed = urlparse(url)

            if not parsed.scheme:
                return url

            # إزالة fragment فقط.
            parsed = parsed._replace(fragment="")

            return urlunparse(parsed)

        except Exception:
            return url

    @staticmethod
    def _normalize_task_url(url: str) -> str:

        url = UnuBot._clean_url(url)

        if url.endswith("/prepare"):
            url = url[:-8]

        return url.rstrip("/")

    def _extract_all_urls_from_text(self, text: str) -> list:
        """استخراج كل الروابط من النص (للمهام المركبة وMAX)."""
        if not text:
            return []
        # فك HTML entities
        text = html.unescape(text)
        # استخراج كل الروابط
        pattern = r"https?://[^\s<>\"')\]]+"
        urls = re.findall(pattern, text)
        # تنظيف وفك redirects
        cleaned = []
        for u in urls:
            u = u.rstrip('.,;:!?')
            # فك clickkk.ru redirects
            if 'clickkk.ru' in u:
                m = re.search(r'url=([^&]+)', u)
                if m:
                    u = unquote(m.group(1))
            # فك href.li
            if 'href.li/?' in u:
                u = u.split('href.li/?')[-1]
            if u.startswith('http'):
                cleaned.append(u)
        return list(dict.fromkeys(cleaned))

    def _extract_max_channels(self, text: str) -> list:
        """استخراج قنوات MAX من النص."""
        if not text:
            return []
        text = html.unescape(text)
        # نمط قنوات MAX
        pattern = r"https?://max\.ru/(?:channel_[^\s<>\"']+|u/[^\s<>\"']+)"
        channels = re.findall(pattern, text, re.IGNORECASE)
        return list(dict.fromkeys(channels))

    def _get_cached_classification(self, task_url: str) -> dict:
        """جلب التصنيف من الكاش."""
        return self._classification_cache.get(task_url)

    def _cache_classification(self, task_url: str, result: dict):
        """حفظ التصنيف في الكاش."""
        if len(self._classification_cache) >= self._cache_max_size:
            # حذف أقدم 1000
            keys = list(self._classification_cache.keys())[:1000]
            for k in keys:
                del self._classification_cache[k]
        self._classification_cache[task_url] = result

    @staticmethod
    def _accept_to_share(accept_url: str) -> str:

        accept_url = UnuBot._clean_url(accept_url)

        marker = "/tasks/accept/"

        if marker not in accept_url:
            return accept_url

        try:
            task_id = accept_url.split(marker, 1)[1]

            task_id = task_id.split("?", 1)[0]
            task_id = task_id.split("#", 1)[0]
            task_id = task_id.strip("/")

            if not task_id:
                return accept_url

            return f"{UNU_BASE_URL}/tasks/share/{task_id}"

        except Exception:
            return accept_url

    # ======================================================
    # Telegram notifications
    # ======================================================

    async def _get_telegram_bot(self) -> Bot:

        if self.telegram_bot is None:
            from telegram.request import HTTPXRequest
            # Telegram API مباشرة من غير بروكسي
            request = HTTPXRequest(
                connect_timeout=60,
                read_timeout=60,
                write_timeout=60,
                pool_timeout=60,
                proxy=None,
            )
            self.telegram_bot = Bot(
                token=BOT_CONFIG.BOT_TOKEN,
                request=request,
            )

        return self.telegram_bot

    async def _send_alert(
        self,
        msg,
        level="info",
        photo_path=None,
    ):

        emoji = {
            "info": "ℹ️",
            "warning": "⚠️",
            "error": "🚨",
        }.get(level, "ℹ️")

        try:

            bot = await self._get_telegram_bot()

            msg = str(msg or "")

            # ----------------------------------------------
            # Photo
            # ----------------------------------------------

            if photo_path:

                photo = Path(photo_path)

                if photo.exists():

                    caption = f"{emoji} {msg}"

                    if len(caption) <= MAX_TELEGRAM_CAPTION_LENGTH:

                        with photo.open("rb") as f:

                            await bot.send_photo(
                                chat_id=BOT_CONFIG.ADMIN_ID,
                                photo=f,
                                caption=caption,
                            )

                        return

                    # Caption طويل
                    with photo.open("rb") as f:

                        await bot.send_photo(
                            chat_id=BOT_CONFIG.ADMIN_ID,
                            photo=f,
                            caption=(
                                f"{emoji} "
                                "📸 تفاصيل المهمة"
                            ),
                        )

                    for part in chunk_text(msg):
                        await bot.send_message(
                            chat_id=BOT_CONFIG.ADMIN_ID,
                            text=f"{emoji} {part}",
                        )

                    return

            # ----------------------------------------------
            # Text
            # ----------------------------------------------

            parts = chunk_text(msg)

            for part in parts:

                await bot.send_message(
                    chat_id=BOT_CONFIG.ADMIN_ID,
                    text=f"{emoji} {part}",
                )

        except Exception as error:

            # لا نخفي الخطأ بالكامل.
            logger.error(
                "Telegram notification failed: %s",
                error,
            )


    def _should_require_proof_approval(self) -> bool:
        """تنفيذ مباشر. مفيش سؤال قبول على تيليجرام."""
        return False

    def _score_proof_screenshot_quality(
        self,
        screenshot_path: str | Path | None,
        details: dict | None = None,
    ) -> dict:
        """
        تقييم أولي لجودة الإثبات قبل إرساله للمراجعة.
        لا يحذف المسار؛ يعيد status/reasons فقط.
        """
        result = {
            "ok": True,
            "status": "ok",
            "reasons": [],
            "path": str(screenshot_path or ""),
        }
        if not screenshot_path:
            return {
                "ok": False,
                "status": "missing_screenshot",
                "reasons": ["no_path"],
                "path": "",
            }
        path = Path(str(screenshot_path))
        if not path.exists():
            return {
                "ok": False,
                "status": "missing_screenshot",
                "reasons": ["file_missing"],
                "path": str(path),
            }
        try:
            size = path.stat().st_size
            if size < 8_000:
                result["ok"] = False
                result["status"] = "screenshot_too_small"
                result["reasons"].append(f"size={size}")
        except Exception as error:
            result["reasons"].append(f"stat_error:{error}")

        skill_data = {}
        if isinstance(details, dict):
            raw = details.get("skill_result")
            if isinstance(raw, dict):
                skill_data = raw
            for key in ("execution_status", "skip_reason"):
                val = str(details.get(key) or skill_data.get(key) or "").lower()
                if any(x in val for x in (
                    "login", "qr", "captcha", "region_block",
                    "content_restricted", "ip_blocked",
                )):
                    result["ok"] = False
                    result["status"] = "bad_session_state"
                    result["reasons"].append(val)

            # مؤشرات من نتيجة الـSkill
            status = str(skill_data.get("status") or "").lower()
            if status in {
                "login_required", "captcha", "telegram_qr_or_phone_login",
                "region_block", "content_restricted", "ip_blocked",
                "http_404", "automation_block",
            }:
                result["ok"] = False
                result["status"] = status
                result["reasons"].append(status)

        return result

    async def resolve_proof_decision(
        self,
        approval_id: str,
        decision: str,
        text: str | None = None,
    ) -> bool:
        """
        يستقبل قرار المراجعة من Dashboard (بدون get_updates في main).
        decision: approve | reject | edit | manual | rescreen | rescreen_done
        """
        approval_id = str(approval_id or "").strip()
        decision = normalize_text(decision).lower()
        pending = self._pending_proof_approvals.get(approval_id)
        if not isinstance(pending, dict):
            logger.warning("resolve_proof_decision: unknown approval_id=%s", approval_id)
            return False

        pending["decision"] = decision
        if text is not None:
            pending["edit_text"] = str(text)
        event = pending.get("event")
        if event is not None:
            try:
                event.set()
            except Exception:
                pass
        return True

    def attach_proof_rescreen(
        self,
        screenshot_path: str,
        approval_id: str | None = None,
    ) -> bool:
        """
        يربط سكرين جديد بمراجعة إثبات معلّقة (بدل سكرين البوت).
        لو approval_id فاضي: يطبّق على آخر مراجعة بـ awaiting_rescreen.
        """
        path = str(screenshot_path or "").strip()
        if not path or not Path(path).exists():
            return False
        bag = getattr(self, "_pending_proof_approvals", {}) or {}
        target_id = str(approval_id or "").strip() or None
        if not target_id:
            # آخر مراجعة طالبة سكرين جديد
            for aid, pending in sorted(
                bag.items(),
                key=lambda kv: float((kv[1] or {}).get("created_at") or 0),
                reverse=True,
            ):
                if isinstance(pending, dict) and pending.get("awaiting_rescreen"):
                    target_id = str(aid)
                    break
        if not target_id or target_id not in bag:
            return False
        pending = bag[target_id]
        if not isinstance(pending, dict):
            return False
        pending["screenshot_path"] = path
        pending["awaiting_rescreen"] = False
        pending["decision"] = "rescreen_done"
        event = pending.get("event")
        if event is not None:
            try:
                event.set()
            except Exception:
                pass
        logger.info("proof rescreen attached: %s -> %s", target_id, path)
        return True

    async def _request_proof_approval(
        self,
        task_url: str,
        platform: str,
        action: str,
        details: dict,
        screenshot_path: str | Path | None,
    ) -> bool:
        """إرسال الإثبات للمراجعة مع أزرار نعم/لا/تعديل قبل UNU."""
        if not screenshot_path:
            logger.warning("Proof approval skipped: screenshot path is empty.")
            return False

        photo = Path(str(screenshot_path))
        if not photo.exists():
            logger.warning("Proof approval skipped: screenshot does not exist: %s", photo)
            return False

        # جودة الإثبات: لا نعرض سكرين login/QR كمراجعة «ناجحة»
        try:
            q = self._score_proof_screenshot_quality(photo, details)
            details["proof_quality"] = q
            if not q.get("ok"):
                logger.warning(
                    "screenshot quality blocked before review: %s reasons=%s",
                    q.get("status"),
                    q.get("reasons"),
                )
                details["ai_proof_verification"] = f"quality_blocked:{q.get('status')}"
                # نكمّل الإرسال للمراجعة مع تنبيه واضح في النص (قرار بشري)
        except Exception as qerr:
            logger.debug("proof quality score error: %s", qerr)

        bot = await self._get_telegram_bot()
        approval_id = f"{int(time.time() * 1000)}_{random.randint(1000, 9999)}"
        skill_data = details.get("skill_result")
        if not isinstance(skill_data, dict):
            skill_data = {}
        # يوزر تليجرام المعتمد للتنفيذ (من الإعدادات + نتيجة الـSkill)
        account_username = (
            details.get("username")
            or details.get("account_username")
            or details.get("platform_username")
            or skill_data.get("username")
            or skill_data.get("account_username")
            or getattr(BOT_CONFIG, "TG_USERNAME", None)
            or "غير متاح"
        )
        tg_login_proof = (
            getattr(BOT_CONFIG, "TG_USERNAME", None)
            or account_username
            or "غير متاح"
        )

        proposed_text = str(
            details.get("approved_proof_text")
            or self._build_proof_text(
                details.get("ai_analysis", {}),
                details,
            )
            or details.get("proof_text")
            or "تم تنفيذ المهمة بنجاح."
        ).strip()
        if not proposed_text:
            proposed_text = self._proof_account_username(str((details or {}).get("platform") or ""), details or {}) or getattr(BOT_CONFIG, "TG_USERNAME", "Mostafa33531")

        # يُستبدل لاحقًا بعد إرسال الرسالة بـ Event للانتظار
        self._pending_proof_approvals[approval_id] = {
            "task_url": task_url,
            "platform": platform,
            "action": action,
            "created_at": time.monotonic(),
            "decision": None,
        }

        def make_keyboard():
            return InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "✅ نعم، أرسل",
                        callback_data=f"unu_proof:approve:{approval_id}",
                    ),
                    InlineKeyboardButton(
                        "❌ لا، ارفض",
                        callback_data=f"unu_proof:reject:{approval_id}",
                    ),
                ],
                [
                    InlineKeyboardButton(
                        "✏️ تعديل النص",
                        callback_data=f"unu_proof:edit:{approval_id}",
                    ),
                    InlineKeyboardButton(
                        "🖐️ هعملها أنا",
                        callback_data=f"unu_proof:manual:{approval_id}",
                    ),
                ],
                [
                    InlineKeyboardButton(
                        "📸 سكرين الإثبات مش عاجبني — هبعت سكرين",
                        callback_data=f"unu_proof:rescreen:{approval_id}",
                    ),
                ],
            ])

        async def send_review_message(report_text: str):
            ai_note = details.get("ai_proof_verification") or details.get("ai_proof_verified")
            ai_line = ""
            if ai_note is not None:
                ai_line = f"\n🤖 رأي AI (استشاري): {ai_note}"
            metadata = (
                "🧐 مراجعة إثبات — لن يُرسل لـ UNU إلا بعد موافقتك\n\n"
                f"🌐 المنصة: {platform}\n"
                f"🎯 العملية: {action}\n"
                f"👤 حساب التشغيل: {account_username}\n"
                f"📱 إشعار لـ: {tg_login_proof}\n"
                f"🔗 المهمة: {task_url}\n"
                f"🆔 رقم المراجعة: {approval_id}"
                f"{ai_line}"
            )
            photo_caption = metadata[:MAX_TELEGRAM_CAPTION_LENGTH]
            with photo.open("rb") as file_handle:
                await bot.send_photo(
                    chat_id=BOT_CONFIG.ADMIN_ID,
                    photo=file_handle,
                    caption=photo_caption,
                )

            report_message = (
                "📝 نص التقرير الذي سيتم إرساله:\n\n"
                f"{report_text}\n\n"
                "اختر:\n"
                "✅ نعم = إرسال لـ UNU\n"
                "❌ لا = رفض المهمة على UNU\n"
                "✏️ تعديل = تغيير نص التقرير\n"
                "🖐️ هعملها أنا = تسيب المهمة معلّقة\n"
                "📸 سكرين مش عاجبني = ابعت صورة من الشات ثم اضغط نعم"
            )

            for part in chunk_text(report_message):
                await bot.send_message(
                    chat_id=BOT_CONFIG.ADMIN_ID,
                    text=part,
                    reply_markup=make_keyboard(),
                )

        try:
            await send_review_message(proposed_text)
        except Exception as error:
            self._pending_proof_approvals.pop(approval_id, None)
            logger.exception("Failed to send proof approval request: %s", error)
            return False

        # انتظار القرار عبر Event — الداشبورد يستدعي resolve_proof_decision
        # لتفادي تعارض get_updates مع Application.start_polling على نفس BOT_TOKEN.
        event = asyncio.Event()
        self._pending_proof_approvals[approval_id] = {
            "task_url": task_url,
            "platform": platform,
            "action": action,
            "created_at": time.monotonic(),
            "event": event,
            "decision": None,
            "edit_text": None,
            "proposed_text": proposed_text,
            "screenshot_path": str(photo),
            "awaiting_rescreen": False,
        }

        deadline = time.monotonic() + PROOF_APPROVAL_TIMEOUT
        editing_requested = False

        while time.monotonic() < deadline and self.running:
            remaining = max(0.5, deadline - time.monotonic())
            try:
                await asyncio.wait_for(event.wait(), timeout=min(remaining, 15.0))
            except asyncio.TimeoutError:
                continue

            event.clear()
            pending = self._pending_proof_approvals.get(approval_id) or {}
            decision = normalize_text(pending.get("decision") or "").lower()
            if not decision:
                continue

            if decision == "approve":
                details["approved_proof_text"] = proposed_text
                details["approval_decision"] = "approve"
                self._pending_proof_approvals.pop(approval_id, None)
                return True

            if decision == "reject":
                details["approval_decision"] = "reject"
                self._pending_proof_approvals.pop(approval_id, None)
                return False

            if decision == "manual":
                details["approval_decision"] = "manual"
                try:
                    self.track_manual_task(task_url, details)
                except Exception:
                    pass
                self._pending_proof_approvals.pop(approval_id, None)
                return False

            if decision == "rescreen":
                # المستخدم عايز يبدّل سكرين الإثبات بصورة من عنده
                pending["awaiting_rescreen"] = True
                pending["decision"] = None
                try:
                    await bot.send_message(
                        chat_id=BOT_CONFIG.ADMIN_ID,
                        text=(
                            "📸 ابعت دلوقتي صورة السكرين الجديدة في الشات (كسكرين عادي).\n"
                            f"رقم المراجعة: {approval_id}\n"
                            "بعد ما الصورة توصل هحدّث الإثبات وأبعتلك المعاينة تاني — "
                            "بعدين اضغط ✅ نعم لو تمام."
                        ),
                    )
                except Exception as error:
                    logger.warning("rescreen prompt failed: %s", error)
                continue

            if decision == "rescreen_done":
                # تم استبدال الصورة — أعد إرسال المعاينة
                new_path = pending.get("screenshot_path") or ""
                if new_path and Path(str(new_path)).exists():
                    photo = Path(str(new_path))
                    details["proof_screenshot_path"] = str(photo)
                    details["user_replaced_proof_screenshot"] = True
                    try:
                        await send_review_message(proposed_text)
                    except Exception as error:
                        logger.warning("resend after rescreen failed: %s", error)
                pending["decision"] = None
                pending["awaiting_rescreen"] = False
                continue

            if decision == "edit":
                editing_requested = True
                try:
                    await bot.send_message(
                        chat_id=BOT_CONFIG.ADMIN_ID,
                        text=(
                            "✏️ ابعت النص الجديد الآن في رسالة منفصلة.\n"
                            f"رقم المراجعة: {approval_id}\n"
                            "بعدها اضغط تعديل مرة أخرى أو أرسل: /edit_" + approval_id
                        ),
                        reply_markup=ForceReply(selective=True),
                    )
                except Exception as error:
                    logger.warning("Failed to request edited proof text: %s", error)
                # انتظر نص التعديل عبر resolve_proof_decision(..., text=...)
                continue

            if decision == "edit_text" or (editing_requested and pending.get("edit_text")):
                new_text = str(pending.get("edit_text") or "").strip()
                if new_text:
                    proposed_text = new_text
                    details["approved_proof_text"] = proposed_text
                    editing_requested = False
                    try:
                        await send_review_message(proposed_text)
                    except Exception as error:
                        logger.warning("Failed to resend edited proof preview: %s", error)
                continue

        self._pending_proof_approvals.pop(approval_id, None)
        details["approval_decision"] = "timeout"
        logger.warning("Proof approval timed out: %s", task_url)
        return False


    # ======================================================
    # Session
    # ======================================================


    async def _persist_storage_state(self) -> bool:
        """
        يحفظ cookies الحالية من BrowserContext إلى GOLDEN_SESSION_PATH
        حتى لا تموت جلسة PHPSESSID فجأة بعد التحديثات.
        """
        if not self.context:
            return False
        try:
            state = await self.context.storage_state()
            cookies = []
            for item in state.get("cookies") or []:
                if "unu.im" not in str(item.get("domain") or ""):
                    continue
                cookies.append(item)
            essential = {"hash", "id", "refid", "turbohash", "PHPSESSID", "uid", "token"}
            if len(cookies) > 12:
                filtered = [item for item in cookies if item.get("name") in essential]
                cookies = filtered or cookies[:8]
            state["cookies"] = cookies
            state["origins"] = []
            path = Path(APP.GOLDEN_SESSION_PATH)
            fleet = getattr(self, "fleet", None)
            acc_id = getattr(self, "_active_unu_id", None)
            if fleet and acc_id:
                account = fleet.get_unu(acc_id)
                if account and account.get("storage_state"):
                    path = Path(account["storage_state"])
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(
                __import__("json").dumps(state, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            logger.info("Persistent storage_state saved: %s", path)
            return True
        except Exception as error:
            logger.warning("persist storage_state failed: %s", error)
            return False

    async def _load_storage_state(self):

        path = Path(APP.GOLDEN_SESSION_PATH)

        if not path.exists():

            raise FileNotFoundError(
                f"Session file not found: {path}"
            )

        try:

            with path.open(
                "r",
                encoding="utf-8",
            ) as f:

                state = json.load(f)

        except json.JSONDecodeError as error:

            raise RuntimeError(
                f"Session JSON is invalid: {error}"
            )

        if not isinstance(state, dict):

            raise RuntimeError(
                "Session state must be a JSON object."
            )

        self.storage_state = state

        logger.info(
            "✅ تم تحميل Session بنجاح."
        )

    # ======================================================
    # Browser
    # ======================================================

    async def _launch_browser(self):

        await self._close_browser()

        self.playwright = (
            await async_playwright().start()
        )

        # اختيار واحد فقط لكل عمر البوت، حتى تظل Cookies والبصمة متسقة
        # عند إعادة تشغيل BrowserContext بعد خطأ تقني.
        if not self._session_user_agent:
            self._session_user_agent = STEALTH.get_random_agent()

        user_agent = self._session_user_agent

        # استخراج إصدار الكروم لمزامنة Client Hints
        match = re.search(r"Chrome/(\d+)\.", user_agent)
        major_version = match.group(1) if match else "131"

        # Client Hints يجب أن تطابق User-Agent بدل إجبار Win32 دائمًا.
        if "Android" in user_agent:
            platform_os = '"Android"'
        elif "Mac OS" in user_agent:
            platform_os = '"macOS"'
        elif "Linux" in user_agent:
            platform_os = '"Linux"'
        else:
            platform_os = '"Windows"'

        is_mobile = "?1" if "Mobile" in user_agent else "?0"

        extra_headers = {
            "sec-ch-ua": f'"Chromium";v="{major_version}", "Google Chrome";v="{major_version}", "Not:A-Brand";v="99"',
            "sec-ch-ua-mobile": is_mobile,
            "sec-ch-ua-platform": platform_os,
            "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
        }

        viewport = {
            "width": STEALTH.VIEWPORT_WIDTH,
            "height": STEALTH.VIEWPORT_HEIGHT,
        }

        # بروفايل منفصل لكل حساب UNU عشان الكوكيز ما تختلطش
        acc_id = re.sub(
            r"[^a-zA-Z0-9_-]",
            "_",
            str(getattr(self, "_active_unu_id", None) or "default"),
        )
        profile_dir = Path(APP.DATA_DIR) / "browser_profiles" / acc_id
        profile_dir.mkdir(parents=True, exist_ok=True)

        try:
            if PROXY is not None:
                _px = PROXY.playwright_proxy()
                if _px:
                    logger.info("🛰️ Proxy/Tor مفعّل للمتصفح: %s", _px.get("server"))
                else:
                    logger.info("🛰️ Proxy/Tor: OFF (IP السيرفر العادي)")
        except Exception as _px_err:
            logger.debug("proxy status log: %s", _px_err)

        storage_state_path = ""
        fleet = getattr(self, "fleet", None)
        active_account = (
            fleet.get_unu(self._active_unu_id)
            if fleet and getattr(self, "_active_unu_id", None)
            else None
        )
        if active_account:
            candidate = str(active_account.get("storage_state") or "")
            if candidate and Path(candidate).exists():
                storage_state_path = candidate

        self.context = await self.playwright.chromium.launch_persistent_context(
            user_data_dir=str(profile_dir),
            headless=True,
            user_agent=user_agent,
            viewport=viewport,
            device_scale_factor=STEALTH.PIXEL_RATIO,
            locale=STEALTH.LOCALE,
            timezone_id=STEALTH.TIMEZONE,
            extra_http_headers=extra_headers,
            **(
                {"proxy": PROXY.playwright_proxy()}
                if PROXY is not None and getattr(PROXY, "playwright_proxy", None)
                and PROXY.playwright_proxy()
                else {}
            ),
            **(
                {"storage_state": storage_state_path}
                if storage_state_path
                else {}
            ),
            args=[
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-blink-features=AutomationControlled",
                "--disable-webrtc",
                "--force-webrtc-ip-handling-policy=disable_non_proxied_udp",
                "--disable-features=IsolateOrigins,site-per-process",
                "--disable-infobars",
                "--disable-background-networking",
                "--disable-default-apps",
                "--disable-sync",
                "--metrics-recording-only",
                "--no-first-run",
                "--password-store=basic",
                "--use-mock-keychain",
            ],
        )

        self.browser = None

        # --------------------------------------------------
        # Advanced Stealth Injection (قوي جدًا)
        # --------------------------------------------------
        await self.context.add_init_script("""
            // 1. إخفاء webdriver تمامًا
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined,
                configurable: true
            });

            // 2. تنظيف آثار Playwright
            const pwProps = ['__playwright', '__pw', '__PW_inspect', 'playwright'];
            for (const prop of pwProps) {
                try { delete window[prop]; } catch (e) {}
            }

            // 3. Chrome runtime
            window.chrome = {
                runtime: {},
                loadTimes: function() {},
                csi: function() {},
                app: {}
            };

            // 4. Seed ثابت لنفس الجلسة (بصمة متسقة)
            const getSeed = () => {
                let h = 0;
                const s = navigator.userAgent + navigator.language + String(screen.width);
                for (let i = 0; i < s.length; i++) {
                    h = Math.imul(31, h) + s.charCodeAt(i) | 0;
                }
                return Math.abs(h);
            };
            let currentSeed = getSeed();
            const pseudoRandom = () => {
                currentSeed = Math.imul(741103597, currentSeed) + 1 | 0;
                return (currentSeed >>> 0) / 4294967296;
            };

            // 5. Hardware & Languages
            Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 8 });
            Object.defineProperty(navigator, 'deviceMemory', { get: () => 8 });
            Object.defineProperty(navigator, 'languages', {
                get: () => ['ru-RU', 'ru', 'en-US', 'en']
            });
            Object.defineProperty(navigator, 'plugins', {
                get: () => [1, 2, 3, 4, 5]
            });
            // لا نغيّر navigator.platform إلى قيمة تناقض User-Agent.

            // 6. Permissions
            const originalQuery = window.navigator.permissions.query;
            window.navigator.permissions.query = (parameters) => (
                parameters.name === 'notifications'
                    ? Promise.resolve({ state: Notification.permission })
                    : originalQuery(parameters)
            );

            // 7. WebGL Spoofing
            const getParameter = WebGLRenderingContext.prototype.getParameter;
            WebGLRenderingContext.prototype.getParameter = function(parameter) {
                if (parameter === 37445) return 'Intel Inc.';
                if (parameter === 37446) return 'Intel Iris OpenGL Engine';
                return getParameter.call(this, parameter);
            };

            // 8. WebRTC Leak Protection (SDP Spoof)
            const OriginalRTC = window.RTCPeerConnection || window.webkitRTCPeerConnection;
            if (OriginalRTC) {
                window.RTCPeerConnection = function(...args) {
                    const pc = new OriginalRTC(...args);
                    const originalCreateOffer = pc.createOffer.bind(pc);
                    pc.createOffer = function(options) {
                        return originalCreateOffer(options).then(offer => {
                            if (offer && offer.sdp) {
                                offer.sdp = offer.sdp.replace(
                                    /(IP4\\s+)[^\\s]+/g,
                                    '$110.0.0.' + Math.floor(pseudoRandom() * 255)
                                );
                            }
                            return offer;
                        });
                    };
                    return pc;
                };
                window.RTCPeerConnection.prototype = OriginalRTC.prototype;
            }

            // 9. Screen / Window matching
            Object.defineProperty(window, 'outerWidth', {
                get: () => window.innerWidth
            });
            Object.defineProperty(window, 'outerHeight', {
                get: () => window.innerHeight + 85
            });
            Object.defineProperty(window.screen, 'width', {
                get: () => window.innerWidth
            });
            Object.defineProperty(window.screen, 'height', {
                get: () => window.innerHeight + 85
            });
            Object.defineProperty(window.screen, 'availWidth', {
                get: () => window.innerWidth
            });
            Object.defineProperty(window.screen, 'availHeight', {
                get: () => window.innerHeight
            });

            // 10. Canvas Fingerprint Noise (consistent)
            const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
            HTMLCanvasElement.prototype.toDataURL = function(...args) {
                const context = this.getContext('2d');
                if (context) {
                    context.fillStyle = `rgba(255, 255, 255, ${pseudoRandom() * 0.01})`;
                    context.fillRect(0, 0, 1, 1);
                }
                return originalToDataURL.apply(this, args);
            };

            const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;
            CanvasRenderingContext2D.prototype.getImageData = function(...args) {
                const imageData = originalGetImageData.apply(this, args);
                for (let i = 0; i < imageData.data.length; i += 4) {
                    imageData.data[i] = imageData.data[i] + (pseudoRandom() > 0.5 ? 1 : -1);
                }
                return imageData;
            };

            // 11. AudioContext Noise
            if (window.AudioContext || window.webkitAudioContext) {
                const AudioCtx = window.AudioContext || window.webkitAudioContext;
                const originalCreateOscillator = AudioCtx.prototype.createOscillator;
                AudioCtx.prototype.createOscillator = function(...args) {
                    const oscillator = originalCreateOscillator.apply(this, args);
                    const originalStart = oscillator.start;
                    oscillator.start = function(...startArgs) {
                        try {
                            oscillator.frequency.value += pseudoRandom() * 0.0001;
                        } catch (e) {}
                        return originalStart.apply(this, startArgs);
                    };
                    return oscillator;
                };
            }

            // 12. Fonts protection
            const originalMeasureText = CanvasRenderingContext2D.prototype.measureText;
            CanvasRenderingContext2D.prototype.measureText = function(text) {
                const metrics = originalMeasureText.call(this, text);
                if (text && text.trim().length > 0) {
                    Object.defineProperty(metrics, 'width', {
                        get: () => metrics.width + (pseudoRandom() * 0.02 - 0.01)
                    });
                }
                return metrics;
            };
        """)

        # --------------------------------------------------
        # Storage state
        # --------------------------------------------------
        if self.storage_state:
            cookies = self.storage_state.get("cookies", [])
            if cookies:
                try:
                    await self.context.add_cookies(cookies)
                except Exception as error:
                    logger.warning("فشل تحميل cookies: %s", error)

        # الصفحة الرئيسية
        if len(self.context.pages) > 0:
            self.page = self.context.pages[0]
        else:
            self.page = await self.context.new_page()

        self.page.set_default_timeout(PAGE_TIMEOUT)
        self.page.set_default_navigation_timeout(PAGE_TIMEOUT)
        self._browser_generation += 1
        self._browser_recovered_at = time.time()
        self._last_collection_error = ""

        logger.info("🌐 Browser initialized with Advanced Stealth + Persistent Profile.")

    async def restart_browser(self, reason: str = "health_check") -> bool:
        """Restart the browser and resume the collection pipeline."""
        async with self._browser_recovery_lock:
            if not self.running:
                return False
            logger.warning("Browser recovery started: %s", reason)
            self._allow_new_task_collection = False
            try:
                await self._launch_browser()
                if not await self._is_session_valid():
                    self._last_collection_error = "session_invalid_after_browser_restart"
                    logger.warning("Browser recovered but UNU session is invalid")
                    return False
                collector = getattr(self, "task_collector", None)
                if collector is not None and not collector.running:
                    await collector.start()
                setattr(self, "_allow_new_task_collection", True)
                logger.info(
                    "Browser recovery complete; collection resumed generation=%s",
                    self._browser_generation,
                )
                return True
            except Exception as error:
                self._last_collection_error = f"{type(error).__name__}:{error}"
                logger.exception("Browser recovery failed")
                return False

    async def _close_browser(self):

        try:
            if self.context:
                for extra in list(self.context.pages):
                    if extra is not self.page:
                        try:
                            await extra.close()
                        except Exception:
                            pass
                await self.context.close()
        except Exception as error:
            logger.debug("Context close error: %s", error)
        finally:
            self.context = None
            self.page = None

        try:
            if self.browser:
                await self.browser.close()
        except Exception as error:
            logger.debug("Browser close error: %s", error)
        finally:
            self.browser = None

        try:
            if self.playwright:
                await self.playwright.stop()
        except Exception as error:
            logger.debug("Playwright stop error: %s", error)
        finally:
            self.playwright = None

    # ======================================================
    # Navigation
    # ======================================================

    async def _goto(
        self,
        page: Page,
        url: str,
        timeout: int = PAGE_TIMEOUT,
        retries: int = MAX_NAVIGATION_RETRIES,
    ) -> bool:

        last_error = None

        for attempt in range(retries + 1):

            try:

                await page.goto(
                    url,
                    timeout=timeout,
                    wait_until="domcontentloaded",
                )

                return True

            except PlaywrightTimeoutError as error:

                last_error = error

                logger.warning(
                    "Navigation timeout (%s/%s): %s",
                    attempt + 1,
                    retries + 1,
                    url,
                )

            except Exception as error:

                last_error = error

                logger.warning(
                    "Navigation failed (%s/%s): %s",
                    attempt + 1,
                    retries + 1,
                    error,
                )

            if attempt < retries:

                await asyncio.sleep(
                    1.5 * (attempt + 1)
                )

        logger.error(
            "Navigation permanently failed: %s",
            last_error,
        )

        return False

    # ======================================================
    # Session validation
    # ======================================================

    async def _is_session_valid(self) -> bool:

        if not self.page:
            return False

        try:

            success = await self._goto(
                self.page,
                TASK_SEARCH_URL,
                timeout=60_000,
                retries=1,
            )

            if not success:
                return False

            await self.page.wait_for_timeout(1000)

            current_url = (
                self.page.url.lower()
            )

            if any(
                x in current_url
                for x in [
                    "/login",
                    "/signin",
                    "/auth",
                ]
            ):
                return False

            body_text = ""

            try:
                body_text = (
                    await self.page.inner_text(
                        "body"
                    )
                ).lower()

            except Exception:
                pass

            login_words = [
                "войти",
                "авторизация",
                "login",
                "sign in",
            ]

            # لو الصفحة صراحة بتطلب تسجيل الدخول.
            if any(
                word in body_text
                for word in login_words
            ):
                # لا نعتبرها invalid بمجرد وجود
                # كلمة "login" عشوائيًا؛
                # URL أهم هنا.
                if "/login" in current_url:
                    return False

            return True

        except Exception as error:

            logger.error(
                "Session validation error: %s",
                error,
            )

            return False

    # ======================================================
    # Startup
    # ======================================================

    async def start(self):

        if self.running:
            logger.warning(
                "Bot is already running."
            )
            return

        self.running = True
        self.start_time = datetime.now()
        self._shutdown_event.clear()

        try:

            APP.setup_directories()

            await self._send_alert(
                "🚀 البوت بدأ التشغيل.",
                "info",
            )

            # ----------------------------------------------
            # Session
            # ----------------------------------------------

            await self._load_storage_state()

            # ----------------------------------------------
            # Skills
            # ----------------------------------------------

            self.skills = SkillManager()

            tg = self.skills.get_skill(
                "telegram"
            )

            if tg:

                await tg.initialize(
                    {
                        "api_id": BOT_CONFIG.TG_API_ID,
                        "api_hash": BOT_CONFIG.TG_API_HASH,
                        "phone": BOT_CONFIG.TG_PHONE,
                        "session_string": (
                            BOT_CONFIG.TG_STRING_SESSION
                        ),
                    }
                )

                logger.info(
                    "✅ Telegram skill initialized."
                )

            else:

                logger.warning(
                    "⚠️ Telegram skill غير موجود."
                )

            # ----------------------------------------------
            # Browser
            # ----------------------------------------------

            await self._launch_browser()

            # ----------------------------------------------
            # Session check
            # ----------------------------------------------

            if not await self._is_session_valid():
                recovered = False
                if hasattr(self, "_recover_unu_session"):
                    recovered = await self._recover_unu_session("startup_session_invalid")
                if not recovered:
                    await self._send_alert(
                        "جلسة UNU غير صالحة. البوت هيستنى ويحاول تاني من غير ما يقفل.",
                        "error",
                    )
                    self.running = False
                    return

            # ----------------------------------------------
            # Dashboard
            # ----------------------------------------------

            self.dashboard = Dashboard(
                BOT_CONFIG.BOT_TOKEN,
                BOT_CONFIG.ADMIN_ID,
                self,
            )

            self._dashboard_task = (
                asyncio.create_task(
                    self.dashboard.start()
                )
            )

            # Setup bot services
            bot_services.setup(
                message_sender=self.dashboard.send_message,
                browser_restart_func=getattr(self, "restart_browser", None),
            )

            # ----------------------------------------------
            # Main loop
            # ----------------------------------------------

            self._main_loop_task = (
                asyncio.current_task()
            )

            await self._main_loop()

        except asyncio.CancelledError:

            logger.info(
                "Main task cancelled."
            )

            raise

        except Exception as error:

            logger.exception(
                "Fatal bot error."
            )

            await self._send_alert(
                f"🚨 خطأ قاتل: {str(error)[:500]}",
                "error",
            )

        finally:

            await self.shutdown()

    # ======================================================
    # Main loop
    # ======================================================

    async def _sweep_bad_reservations(self):
        """يرفض المهام المحجوزة على مواقع مش مدعومة (بوكنج وأفيتو) من غير ما يلمس الشغل الجاري."""
        if getattr(self, "_execution_lock", None) and self._execution_lock.locked():
            return
        now = time.time()
        if now - float(getattr(self, "_last_bad_sweep", 0) or 0) < 180:
            return
        if not self.context:
            return
        self._last_bad_sweep = now
        try:
            fleet = getattr(self, "fleet", None)
            accounts = fleet.healthy_unu() if fleet else []
            if len(accounts) != 1:
                return
            runtime = fleet.resolve_runtime(str(accounts[0]["id"]))
            if runtime is None or runtime.browser_context is not self.context:
                return
            works = await asyncio.to_thread(runtime.get_api().get_works, "active")
        except Exception as error:
            logger.warning("bad-reservation list failed: %s", error)
            return

        bad_marks = (
            "booking.com", "букинг", "авито", "avito.ru",
            "одноклассник", "ok.ru", "chrome.google", "расширени",
        )
        for work in (works or [])[:6]:
            url = str(work.get("url") or "")
            if "/tasks/report/" not in url:
                continue
            page = None
            try:
                page = await self.context.new_page()
                await page.goto(url, wait_until="domcontentloaded", timeout=20000)
                text = ""
                try:
                    text = (await page.inner_text("body"))[:6000].lower()
                except Exception:
                    text = ""
                if any(mark in text for mark in bad_marks):
                    logger.warning("Refusing blocked open work: %s", url)
            except Exception as error:
                logger.warning("sweep open failed: %s", error)
                text = ""
            finally:
                if page is not None:
                    try:
                        await page.close()
                    except Exception:
                        pass
            if text and any(mark in text for mark in bad_marks):
                try:
                    refused = await self._refuse_task_on_unu(url, {"report_url": url})
                    logger.info("Sweep refuse %s -> %s", url, refused)
                except Exception as error:
                    logger.warning("sweep refuse failed: %s", error)

    async def _background_collect(self):
        """تجميع مستمر في الخلفية"""
        while self.running:
            try:
                if not getattr(self, "_allow_new_task_collection", True):
                    await asyncio.sleep(0.2)
                    continue
                # Collect new tasks
                api_tasks = await asyncio.wait_for(
                    self.get_tasks_api(max_pages=50),
                    timeout=max(30.0, float(os.getenv("COLLECTION_API_TIMEOUT_SECONDS", "90"))),
                )
                if api_tasks:
                    banned = getattr(self, "filter_banned_words", [])
                    
                    for t in api_tasks:
                        url = t.get("accept_url", "")
                        title = t.get("title", "").lower()
                        
                        if not url:
                            continue
                        
                        norm = self._normalize_task_url(url)
                        
                        # Skip if already processed
                        if norm in self.invalid or norm in self.history:
                            continue
                        
                        # Immediate rejection for banned words
                        if banned and any(w.lower() in title for w in banned):
                            self.invalid.add(norm)
                            self.invalid_reasons[norm] = "banned_word"
                            logger.info("🚫 Rejected (banned): %s", title[:50])
                            continue
                        
                        # فلتر السعر ملغي
                        
                        # الحجز بعد الفحص فقط. التجميع في الخلفية بيصفّ الطابور.
                        if not hasattr(self, "_pending_urls"):
                            self._pending_urls = set()
                        self._pending_urls.add(norm)
                
                await asyncio.sleep(2)  # كل 2 ثانية
            except Exception as e:
                logger.warning("Background collect error: %s", e)
                await asyncio.sleep(60)
    
    async def _main_loop(self):

        logger.info("🔄 Main loop started!")
        consecutive_errors = 0
        cycle_number = 0

        # Start background collection (use new TaskCollector if available)
        if self.task_collector:
            try:
                await asyncio.wait_for(self.task_collector.start(), timeout=35)
            except asyncio.TimeoutError:
                logger.error(
                    "TaskCollector startup timed out; main loop will continue and retry collection"
                )
            except Exception:
                logger.exception(
                    "TaskCollector startup failed; main loop will continue"
                )
            if self.task_collector.running:
                logger.info("🔄 TaskCollector started")
            else:
                logger.warning("🔄 TaskCollector is not running")
        if self.health_monitor:
            await self.health_monitor.start()
            logger.info("🏥 HealthMonitor started")
        elif not self.task_collector and (
            not hasattr(self, "_bg_collect_task") or self._bg_collect_task is None
        ):
            self._bg_collect_task = asyncio.create_task(self._background_collect())
            logger.info("🔄 Background collection started (legacy)")
        self._allow_new_task_collection = False
        
        while self.running:
            logger.info("🔄 Cycle %d starting...", cycle_number + 1)
            self.last_cycle_started = time.time()
            self.next_poll_at = 0.0
            self._allow_new_task_collection = False

            cycle_number += 1

            try:

                self._reset_daily_counter_if_needed()

                # ------------------------------------------
                # Daily limit
                # ------------------------------------------

                # Check via bot_services too
                tasks_done = getattr(self, "daily_tasks_done", 0)
                if not bot_services.check_daily_limit(tasks_done):
                    await self._send_alert(
                        f"🛑 تم الوصول للحد اليومي: {tasks_done}",
                        "warning",
                    )
                    await asyncio.sleep(min(self.loop_delay, 300))
                    continue

                if self._daily_limit_reached():

                    await self._send_alert(
                        (
                            "🛑 تم الوصول للحد اليومي: "
                            f"{self.max_tasks_per_day}"
                        ),
                        "warning",
                    )

                    await asyncio.sleep(
                        min(self.loop_delay, 300)
                    )

                    continue

                # ------------------------------------------
                # Session
                # ------------------------------------------

                fleet = getattr(self, "fleet", None)
                if not (fleet and getattr(self, "account_contexts", None)):
                    if not self.page:
                        raise RuntimeError("Main page is unavailable.")
                    if "/tasks/search" not in (self.page.url or ""):
                        if not await self._is_session_valid():
                            recovered = await self._recover_unu_session("session_invalid")
                            if not recovered:
                                await self._interruptible_sleep(90)
                            continue

                # ------------------------------------------
                # Collect — الأعمال المعلقة أولاً
                # ------------------------------------------

                all_urls = []
                works_by_account = {}
                try:
                    fleet = getattr(self, "fleet", None)
                    accounts = fleet.healthy_unu() if fleet else []
                    if accounts:
                        for account in accounts:
                            runtime = fleet.resolve_runtime(str(account["id"]))
                            if runtime is None:
                                continue
                            account_works = await asyncio.to_thread(
                                runtime.get_api().get_open_works
                            ) or []
                            account_items = []
                            for work_url in account_works:
                                norm_work = self._normalize_task_url(work_url)
                                if norm_work:
                                    account_items.append((norm_work, str(account["id"])))
                            works_by_account[str(account["id"])] = account_items
                    if works_by_account:
                        logger.info(
                            "📋 Open works first across accounts: %s",
                            sum(len(items) for items in works_by_account.values()),
                        )
                except Exception as error:
                    logger.warning("open works fetch failed: %s", error)

                # --- تطبيع المحجوز قبل بدء أي تجميع جديد ---
                works_norm = [
                    (url, account_id)
                    for account_id, items in works_by_account.items()
                    for url, _ in items
                ]

                if self.task_collector and hasattr(self.task_collector, "stats"):
                    logger.info(
                        "cycle stats collected=%s filtered=%s pending=%s works=%s",
                        self.task_collector.stats.get("collected", 0),
                        self.task_collector.stats.get("filtered", 0),
                        len(all_urls),
                        len(works_norm),
                    )

                # ==========================================================
                # إجبار: تنفيذ المحجوز أولاً بالكامل قبل أي مهمة جديدة
                # ==========================================================
                if works_norm:
                    # اسمح بإعادة المحاولة حتى لو كانت في history/invalid
                    for u, account_id in works_norm:
                        self.history.discard(u)
                        self.invalid.discard(u)
                        self.validated.discard(u)
                        try:
                            self.invalid_reasons.pop(f"{account_id}:{u}", None)
                        except Exception:
                            pass
                    logger.info(
                        "📋 FORCED reserved works first: %d | sample=%s",
                        len(works_norm),
                        (works_norm[0][0] or "")[-50:],
                    )
                    try:
                        # Account-scoped equivalent of: await self._check_urls_batch(works_norm)
                        works_results = [
                            await self._process_url_with_account(url, account_id)
                            for url, account_id in works_norm
                        ]
                        ok_w = sum(1 for r in (works_results or []) if r is True)
                        logger.info(
                            "📋 Reserved works done: ok=%s total=%s",
                            ok_w,
                            len(works_norm),
                        )
                    except Exception as works_err:
                        logger.exception("Reserved works batch failed: %s", works_err)

                # لا يبدأ جمع المهام الجديدة إلا بعد انتهاء فحص المحجوز.
                self._allow_new_task_collection = True
                try:
                    cycle_lim = int(getattr(self, "cycle_limit", 0) or 0)
                except Exception:
                    cycle_lim = 0
                try:
                    task_count_limit = int(
                        self._get_dashboard_setting("task_count", 0) or 0
                    )
                except Exception:
                    task_count_limit = 0
                try:
                    filter_count = int(getattr(self, "filter_task_count", 0) or 0)
                except Exception:
                    filter_count = 0
                task_count_limit = max(task_count_limit, filter_count)
                positive_limits = [n for n in (cycle_lim, task_count_limit) if n > 0]
                effective_limit = min(positive_limits) if positive_limits else 0
                if self.task_collector and not self.task_collector.running:
                    await self.task_collector.start()
                if self.task_collector:
                    for _ in range(8):
                        if self.task_collector.pending_urls:
                            all_urls = self.task_collector.get_pending(limit=effective_limit)
                            break
                        await asyncio.sleep(1)
                    if all_urls:
                        logger.info("Using %d pending URLs from TaskCollector", len(all_urls))
                elif hasattr(self, "_pending_urls") and self._pending_urls:
                    all_urls = list(self._pending_urls)
                    self._pending_urls.clear()
                    logger.info("Using %d pending URLs from background", len(all_urls))
                else:
                    all_urls = await self._scroll_and_collect()

                all_urls = list(dict.fromkeys(
                    self._normalize_task_url(u) for u in all_urls if u
                ))
                works_set = {url for url, _account_id in works_norm}
                all_urls = [u for u in all_urls if u not in works_set]

                # تنبيه لو الرصيد زاد
                try:
                    bal = await self.get_balance()
                    current = float(bal.get("available", 0) or 0)
                    if self._last_balance > 0 and current > self._last_balance + 1:
                        diff = current - self._last_balance
                        await self._send_alert(
                            f"💰 الرصيد زاد +{diff:.2f} ₽\nالمتاح: {current:.2f} ₽",
                            "info",
                        )
                    self._last_balance = current
                except Exception:
                    pass

                # ------------------------------------------
                # New URLs
                # ------------------------------------------

                unchecked = [
                    url
                    for url in all_urls
                    if (
                        url not in self.validated
                        and url not in self.invalid
                        and url not in self.history
                    )
                ]

                # ترتيب السعر ملغي — المحجوز اتنفّذ فوق

                # حد الدورة: أصغر حد موجب من الداشبورد. صفر يعني من غير حد.
                if effective_limit:
                    unchecked = unchecked[:effective_limit]
                logger.info(
                    "Cycle limit=%s unchecked=%s",
                    effective_limit or "none",
                    len(unchecked),
                )

                if unchecked:
                    self.detailed_count = 0
                    logger.info("Executing %d new tasks", len(unchecked))

                    owners = [self._task_owner_for_url(url) for url in unchecked]
                    results = [
                        await self._process_url_with_account(url, owner)
                        if owner else False
                        for url, owner in zip(unchecked, owners)
                    ]

                    for url, result in zip(
                        unchecked,
                        results,
                    ):

                        if result is True:
                            self.validated.add(url)
                        elif result is False:
                            self.invalid.add(url)
                        else:
                            logger.warning(
                                "Technical check failure, will retry: %s",
                                url,
                            )
                    if self.task_collector and hasattr(self.task_collector, "note_results"):
                        self.task_collector.note_results(unchecked, results)

                else:
                    logger.info("No new URLs this cycle")

                # ------------------------------------------
                # Report
                # ------------------------------------------

                await self._send_cycle_report(
                    all_urls
                )

                consecutive_errors = 0
                self.last_cycle_finished = time.time()

                # ------------------------------------------
                # Daily report via bot_services
                # ------------------------------------------

                try:
                    await bot_services.send_daily_report_if_needed({
                        "tasks_done": getattr(self, "tasks_done_today", 0),
                        "earnings": getattr(self, "earnings_today", 0.0),
                        "failed": getattr(self, "failed_count", 0),
                    })
                except Exception:
                    pass

                # ------------------------------------------
                # Wait
                # ------------------------------------------

                logger.info("Sleeping %ss", self.loop_delay)
                self.next_poll_at = time.time() + self.loop_delay

                await self._interruptible_sleep(
                    self.loop_delay
                )

            except asyncio.CancelledError:

                raise

            except Exception as error:

                consecutive_errors += 1

                logger.exception(
                    "Main loop error."
                )

                # Record error via bot_services
                bot_services.record_browser_error()
                bot_services.record_error("main_loop", str(error)[:200])

                await self._send_alert(
                    (
                        "🚨 خطأ في الدورة "
                        f"{cycle_number}: "
                        f"{str(error)[:500]}"
                    ),
                    "error",
                )

                # لو حصلت أخطاء متتالية،
                # نحاول إعادة تشغيل browser.
                if (
                    consecutive_errors
                    >= self.error_limit
                ):

                    await self._send_alert(
                        (
                            "🔄 أخطاء متتالية كثيرة، "
                            "سيتم إعادة تشغيل المتصفح."
                        ),
                        "warning",
                    )

                    try:

                        await self._launch_browser()

                        if not await self._is_session_valid():

                            recovered = await self._recover_unu_session("restart_session_invalid")
                            if recovered:
                                consecutive_errors = 0
                                continue

                            await self._interruptible_sleep(120)
                            continue

                        consecutive_errors = 0

                    except Exception as restart_error:

                        logger.exception(
                            "Browser restart failed."
                        )

                        await self._send_alert(
                            (
                                "🚨 فشل إعادة تشغيل "
                                f"المتصفح: "
                                f"{str(restart_error)[:300]}"
                            ),
                            "error",
                        )

                        await self._interruptible_sleep(
                            self.error_delay
                        )

                        continue

                await self._interruptible_sleep(
                    self.error_delay
                )

    # ======================================================
    # Batch checking
    # ======================================================



    def _persist_task_state(
        self,
        url: str,
        state: str,
        *,
        platform: str = "",
        action: str = "",
        price: float = 0.0,
        reason: str = "",
        payload: dict | None = None,
        success: bool | None = None,
        account_id: str = "legacy",
    ) -> None:
        """كتابة اختيارية لـ SQLite — لا ترمي استثناء للخارج."""
        pers = getattr(self, "persistence", None)
        if pers is None:
            return
        try:
            pers.upsert_task(
                url,
                state,
                platform=platform,
                action=action,
                price=price,
                reason=reason,
                payload=payload,
                account_id=account_id,
                task_id=str((payload or {}).get("task_id") or self._extract_task_id_from_url(url) or ""),
            )
            if success is not None:
                pers.log_attempt(
                    url, bool(success), status=state, detail=payload or {},
                    account_id=account_id,
                )
            kind = {
                "COMPLETED": "history",
                "VALIDATED": "validated",
                "FAILED_PERMANENT": "invalid",
                "BLOCKED": "invalid",
                "ABORTED": "invalid",
            }.get(state)
            if kind:
                pers.add_history(self._normalize_task_url(url), kind, account_id=account_id)
        except Exception as error:
            logger.debug("persist state failed: %s", error)

    async def _mark_task_invalid(
        self,
        task_url: str,
        reason: str,
        *,
        alert: bool = True,
        level: str = "warning",
    ) -> None:
        """يسجّل المهمة غير صالحة + يبعت السبب فورًا (مش في آخر الدورة فقط)."""
        norm = self._normalize_task_url(task_url)
        reason = normalize_text(reason) or "unknown"
        async with self._state_lock:
            self.invalid.add(norm)
            if not isinstance(getattr(self, "invalid_reasons", None), dict):
                self.invalid_reasons = {}
            self.invalid_reasons[norm] = reason
            # احتفظ بالسبب في details لو موجودة
            try:
                if norm in self.tasks_details and isinstance(self.tasks_details[norm], dict):
                    self.tasks_details[norm]["reject_reason"] = reason
            except Exception:
                pass
        try:
            self._persist_task_state(
                norm,
                "FAILED_PERMANENT",
                reason=reason,
                payload={"reject_reason": reason},
                success=False,
            )
        except Exception:
            pass
        if alert:
            try:
                await self._send_alert(
                    (
                        "Rejected: "
                        + str(norm)
                        + " | reason: "
                        + str(reason)
                    ),
                    level,
                )
            except Exception as error:
                logger.debug("invalid alert failed: %s", error)

    async def _mark_task_review(
        self,
        task_url: str,
        reason: str,
        *,
        warning: str = "",
        account_id: Optional[str] = None,
    ) -> None:
        """Preserve ambiguous/technical failures for explicit human review."""
        norm = self._normalize_task_url(task_url)
        owner = str(account_id or "").strip()
        details = self._get_task_details(norm, owner or None)
        if not details:
            details = {}
        self._set_task_details(norm, details, owner or None)
        details["decision_status"] = "needs_review"
        details["decision_reason"] = normalize_text(reason) or "needs_review"
        details["mismatch_warning"] = normalize_text(warning)
        details["analysis_timestamp"] = time.time()
        self._invalidate_task_verification(norm, owner or None)
        self._persist_task_state(
            norm,
            "MANUAL_REVIEW",
            reason=details["decision_reason"],
            payload={
                "decision_status": "needs_review",
                "decision_reason": details["decision_reason"],
                "mismatch_warning": details["mismatch_warning"],
            },
            success=False,
            account_id=owner or "legacy",
        )
        logger.warning(
            "Task preserved for review: %s | reason=%s",
            norm,
            details["decision_reason"],
        )


    async def _check_urls_batch(
        self,
        urls,
    ):

        semaphore = asyncio.Semaphore(
            max(
                1,
                int(
                    self.max_concurrent_checks
                ),
            )
        )

        async def worker(url):

            async with semaphore:

                await self.check_rate_limiter.wait()

                try:

                    return await self._process_url(
                        url
                    )

                except asyncio.CancelledError:

                    raise

                except Exception as error:

                    logger.exception(
                        "URL worker failed: %s",
                        url,
                    )

                    return None

        tasks = [
            asyncio.create_task(
                worker(url)
            )
            for url in urls
        ]

        try:

            return await asyncio.gather(
                *tasks,
                return_exceptions=False,
            )

        finally:

            for task in tasks:

                if not task.done():
                    task.cancel()

    # ======================================================
    # Process one URL (MODIFIED)
    # ======================================================


    def _classify_title_tier(self, title: str) -> dict:
        """accepted / suspicious / rejected — pre_filter ثم fallback محلي."""
        try:
            from application.pre_filter import classify_title
            result = classify_title(title)
            if isinstance(result, dict) and result.get("tier"):
                if result["tier"] == "high":
                    result["tier"] = "accepted"
                return result
        except Exception:
            pass
        raw = str(title or "")
        t = normalize_text(raw).lower().replace("ё", "е")
        t = t.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
        if not t:
            return {"tier": "suspicious", "reason": "empty_title", "platform": "", "action": ""}
        reject_keys = (
            "регистрац", "зарегистрир", "создать аккаунт", "идентификац", "паспорт",
            "оформить заявк", "оформить карт", "дебетов", "банковск",
            "установка приложени", "скачать приложение", "install app",
            "تسجيل", "انشاء حساب", "جواز سفر", "تثبيت تطبيق",
            "только для граждан рф", "гражданам рф", "звонок", "позвон",
            "aviso", "bux.money", "surfearner", "vktarget", "socpublic",
            "заработок", "никаких вложений", "кран ", "faucet",
        )
        for key in reject_keys:
            if key in t:
                return {"tier": "rejected", "reason": f"reject:{key}", "platform": "", "action": ""}
        # عنوان عام بدون منصة
        generic = (
            "легкое задание", "простое задание", "очень легко", "просто и быстро",
            "лёгкое задание", "задание часть",
        )
        platform = ""
        for name, markers in (
            ("telegram", ("telegram", "телеграм", "телега", "тг ", "t.me")),
            ("vk", ("вконтакте", " вк ", "vk.com", "vk.ru", " вк")),
            ("instagram", ("instagram", "инстаграм", "инста")),
            ("tiktok", ("tiktok", "тикток", "тик ток")),
            ("youtube", ("youtube", "ютуб", "ютюб")),
            ("twitter", ("twitter", "твиттер", " x.com", "ретвит")),
            ("rutube", ("rutube", "рутуб")),
            ("max", (" max", "макс", "max.ru")),
        ):
            if any(m in f" {t} " or m in t for m in markers):
                platform = name
                break
        action = ""
        for name, markers in (
            ("subscribe", ("подпис", "вступ", "follow", "subscribe")),
            ("like", ("лайк", "like", "нрав")),
            ("repost", ("репост", "ретвит", "retweet", "repost")),
            ("comment", ("коммент", "comment")),
            ("view", ("просмотр", "посмотр", "watch")),
            ("share", ("поделиться", "share")),
            ("review", ("отзыв", "review")),
        ):
            if any(m in t for m in markers):
                action = name
                break
        allowed = {"telegram", "vk", "max", "instagram", "tiktok", "twitter", "youtube", "rutube"}
        if platform in allowed and action:
            return {"tier": "accepted", "reason": f"clear:{platform}/{action}", "platform": platform, "action": action}
        if any(g in t for g in generic) and not platform:
            return {"tier": "rejected", "reason": "generic_no_platform", "platform": "", "action": ""}
        if platform in allowed:
            return {"tier": "suspicious", "reason": f"platform_only:{platform}", "platform": platform, "action": action or ""}
        if action:
            return {"tier": "suspicious", "reason": f"action_only:{action}", "platform": "", "action": action}
        return {"tier": "suspicious", "reason": "generic_title", "platform": "", "action": ""}

    @staticmethod
    def _reconcile_classifications(preliminary: dict, detailed: dict) -> dict:
        from classification_utils import reconcile_classifications

        return reconcile_classifications(
            preliminary,
            detailed,
            canonicalize_platform=lambda value: str(value or "").strip().lower(),
        )

    def _extract_task_id_from_url(self, url: str) -> str:
        normalized = str(url or "")
        match = re.search(
            r"/tasks/(?:accept|report)/[^/?#]*?-(\d+)(?:[/?#]|$)",
            normalized,
            re.IGNORECASE,
        )
        return match.group(1) if match else ""

    def _verification_fingerprint(self, details: dict) -> str:
        fields = {
            key: details.get(key)
            for key in (
                "task_id",
                "title",
                "description",
                "info_for_work",
                "raw_page_text",
                "title_tier",
                "title_platform",
                "title_action",
                "title_check_passed",
                "detail_title",
                "detail_platform",
                "detail_action",
                "platform",
                "action",
                "detail_check_passed",
                "unu_account_id",
                "analysis_status",
                "ai_source",
                "ai_result",
            )
        }
        payload = json.dumps(fields, ensure_ascii=False, sort_keys=True, default=str)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _invalidate_task_verification(
        self,
        url: str,
        account_id: Optional[str] = None,
    ) -> None:
        try:
            normalized = self._normalize_task_url(url)
        except Exception:
            normalized = str(url or "")
        if isinstance(getattr(self, "_verification_records", None), dict):
            if account_id:
                self._verification_records.pop(
                    f"{str(account_id).strip()}:{normalized}", None
                )
            else:
                self._verification_records.pop(normalized, None)

    def _register_verification_record(self, url: str, details: dict) -> bool:
        if not isinstance(details, dict) or "/tasks/report/" in str(url or "").lower():
            return False
        try:
            normalized = self._normalize_task_url(url)
        except Exception:
            normalized = str(url or "")
        task_id = str(
            details.get("task_id") or self._extract_task_id_from_url(normalized) or ""
        ).strip()
        if (
            not normalized
            or not task_id
            or details.get("title_tier") != "accepted"
            or details.get("title_check_passed") is not True
            or details.get("detail_check_passed") is not True
            or details.get("analysis_status") in {"unavailable", "failed"}
            or details.get("ai_source") in {"ai_unavailable", "rule_fallback"}
            or (
                isinstance(details.get("ai_result"), dict)
                and details["ai_result"].get("executable") is False
            )
        ):
            return False
        canonicalize = getattr(self, "_canonicalize_platform_name", lambda value: value)
        expected_platform = canonicalize(
            str(details.get("title_platform") or "").strip().lower()
        )
        actual_platform = canonicalize(
            str(details.get("detail_platform") or details.get("platform") or "").strip().lower()
        )
        expected_action = str(details.get("title_action") or "").strip().lower()
        actual_action = str(
            details.get("detail_action") or details.get("action") or ""
        ).strip().lower()
        if (
            (expected_platform and actual_platform != expected_platform)
            or (expected_action and actual_action != expected_action)
        ):
            return False
        account_id = str(details.get("unu_account_id") or "legacy").strip() or "legacy"
        record = {
            "account_id": account_id,
            "task_id": task_id,
            "url": normalized,
            "title_tier": details.get("title_tier"),
            "title_check_passed": True,
            "detail_check_passed": True,
            "title_platform": details.get("title_platform") or "",
            "title_action": details.get("title_action") or "",
            "detail_platform": details.get("detail_platform") or details.get("platform") or "",
            "detail_action": details.get("detail_action") or details.get("action") or "",
            "unu_account_id": details.get("unu_account_id") or "",
            "analysis_status": details.get("analysis_status"),
            "ai_source": details.get("ai_source"),
            "ai_result": details.get("ai_result"),
            "created_at": time.time(),
            "expires_at": time.time() + float(
                getattr(self, "verification_ttl_seconds", 300)
            ),
            "fingerprint": self._verification_fingerprint(details),
        }
        if not isinstance(getattr(self, "_verification_records", None), dict):
            self._verification_records = {}
        if account_id == "legacy":
            self._verification_records[normalized] = record
        self._verification_records[f"{account_id}:{normalized}"] = record
        return True

    async def _confirm_suspicious_title(self, title: str, url: str, details: dict | None = None) -> dict:
        """المشكوك: قاموس أولاً (على الشير لو متاح). AI فقط لو القاموس فشل والمحركات شغالة."""
        allowed = {
            "telegram", "tiktok", "instagram", "vk", "max",
            "youtube", "twitter", "rutube",
        }
        details = details or {}
        blob_parts = [
            title or "",
            str(details.get("description") or ""),
            str(details.get("info_for_work") or ""),
            str(details.get("category") or ""),
            str(details.get("raw_page_text") or "")[:1200],
        ]
        urls = []
        for key in ("target_urls", "links", "extracted_links"):
            val = details.get(key)
            if isinstance(val, (list, tuple)):
                urls.extend(str(x) for x in val if x)
            elif val:
                urls.append(str(val))
        if details.get("target_url"):
            urls.append(str(details["target_url"]))
        try:
            urls.extend(self._extract_all_urls_from_text(" ".join(blob_parts)))
        except Exception:
            pass
        urls = list(dict.fromkeys(u for u in urls if u and "unu.im" not in u.lower()))
        dict_details = {
            "title": title,
            "description": details.get("description"),
            "info_for_work": details.get("info_for_work"),
            "category": details.get("category"),
            "target_urls": urls,
            "target_url": urls[0] if urls else "",
        }
        try:
            found = self.task_dictionary.find(" ".join(blob_parts), dict_details) or {}
        except Exception as err:
            logger.debug("dict confirm failed: %s", err)
            found = {}
        platform = str(found.get("platform") or "").lower()
        if platform == "x":
            platform = "twitter"
        action = str(found.get("action") or "").lower()
        conf = float(found.get("confidence") or 0)
        executable = found.get("executable", True)
        if platform in allowed and action and executable is not False and conf >= 0.74:
            logger.info(
                "Suspicious confirmed by dictionary: %s/%s conf=%.2f",
                platform, action, conf,
            )
            return {
                "tier": "accepted",
                "reason": "dict_share_confirm",
                "platform": platform,
                "action": action,
                "dict_result": found,
            }
        # AI فقط كملجأ أخير — ولو فشل نرفض من غير ما نكسر الدورة
        try:
            brain = getattr(self, "ai_brain", None)
            if brain is None:
                try:
                    from ai_core import brain as _b
                    brain = _b
                except Exception:
                    brain = None
            if brain and hasattr(brain, "analyze_task"):
                ai = await brain.analyze_task(" ".join(blob_parts)[:1800], urls)
                if isinstance(ai, dict):
                    ap = str(ai.get("platform") or "").lower()
                    if ap == "x":
                        ap = "twitter"
                    aa = str(ai.get("action") or "").lower()
                    if ap in allowed and aa and ai.get("executable", True) is not False:
                        logger.info("Suspicious confirmed by AI: %s/%s", ap, aa)
                        return {
                            "tier": "accepted",
                            "reason": "ai_confirm",
                            "platform": ap,
                            "action": aa,
                            "ai_result": ai,
                        }
        except Exception as err:
            logger.warning("AI confirm skipped/failed: %s", err)
        logger.info("Suspicious rejected (dict+AI): %s", (title or "")[:60])
        return {}

    async def _process_url(
        self,
        url: str,
        account_id: Optional[str] = None,
    ) -> Optional[bool]:

        url = self._normalize_task_url(url)
        get_details = getattr(self, "_get_task_details", None)
        if callable(get_details):
            seeded = get_details(url, account_id)
        else:
            seeded = (
                (getattr(self, "tasks_details", {}) or {}).get(url)
                if isinstance(getattr(self, "tasks_details", None), dict)
                else {}
            ) or {}
        has_details = bool(seeded)
        owner = str(account_id or seeded.get("unu_account_id") or "").strip()
        if owner:
            self._invalidate_task_verification(url, owner)
        else:
            self._invalidate_task_verification(url)

        if not url:
            return False

        valid = await self._check_url(url)

        if valid is not True:
            return valid

        # الرابط الذي تم جمعه قد يكون accept أو share.
        # نستخدم share للقراءة فقط، ونحتفظ بالرابط الأصلي
        # لاستخدامه لاحقًا في القبول بعد موافقة AI.
        accept_url = url
        share_url = self._accept_to_share(url)

        is_works = "/tasks/report/" in (url or "")
        title = str((seeded or {}).get("title") or "")
        classified = {"tier": "accepted", "reason": "works", "platform": "", "action": ""}

        if not is_works:
            classified = self._classify_title_tier(title)
            tier = classified.get("tier")
            logger.info(
                "Title tier=%s reason=%s | %s",
                tier, classified.get("reason"), (title or "")[:60],
            )
            if tier == "rejected" and str(classified.get("reason") or "").startswith("reject:"):
                reason = classified.get("reason") or "explicit_title_rule"
                self.invalid.add(url)
                self.invalid_reasons[url] = reason
                rejected = dict(seeded or {})
                rejected.update({
                    "unu_account_id": owner,
                    "accept_url": accept_url,
                    "title_tier": "rejected",
                    "title_check_passed": False,
                    "decision_status": "rejected",
                    "decision_reason": reason,
                    "analysis_timestamp": time.time(),
                })
                self._store_task_details(url, rejected)
                logger.info("🚫 Title rejected: %s", (title or "")[:60])
                return False
            if tier != "accepted":
                details_hint = dict(seeded or {})
                review = dict(details_hint)
                review.update({
                    "unu_account_id": owner,
                    "accept_url": accept_url,
                    "title_analysis": dict(classified),
                    "title_analysis_status": "suspicious",
                    "decision_status": "needs_review",
                    "decision_reason": "suspicious_title_without_verified_details",
                    "analysis_timestamp": time.time(),
                })
                if has_details:
                    self._store_task_details(url, review)
                    await self._mark_task_review(
                        url, "suspicious_title_without_verified_details", account_id=owner
                    )
                    return False
        else:
            logger.info("📋 Open works (reserved) first: %s", url[-50:])
            share_url = url

        supplied_details = (
            not is_works
            and classified.get("tier") != "accepted"
            and bool(str(seeded.get("description") or "").strip())
        )
        details = dict(seeded) if supplied_details else await self._inspect_task_detailed(share_url)
        if not details:
            review = dict(seeded or {})
            review.update({
                "unu_account_id": owner,
                "accept_url": accept_url,
                "share_url": share_url,
                "decision_status": "needs_review",
                "decision_reason": "missing_task_details",
                "analysis_status": "incomplete",
                "analysis_timestamp": time.time(),
            })
            self._store_task_details(url, review)
            await self._mark_task_review(url, "missing_task_details", account_id=owner)
            return False
        merged_details = dict(seeded or {})
        merged_details.update(details)
        details = merged_details
        if owner and not details.get("unu_account_id"):
            details["unu_account_id"] = owner

        details["share_url"] = share_url
        details["accept_url"] = accept_url
        details["fast_reserved"] = False
        details["title_tier"] = classified.get("tier")
        details["title_tier_reason"] = classified.get("reason")
        details["title_platform"] = classified.get("platform") or ""
        details["title_action"] = classified.get("action") or ""
        if classified.get("platform") and not details.get("platform"):
            details["platform"] = classified["platform"]
        if classified.get("action") and not details.get("action"):
            details["action"] = classified["action"]

        if not is_works:
            detail_title = str(details.get("title") or "").strip()
            if not detail_title:
                await self._mark_task_review(url, "missing_detail_title", account_id=owner)
                return False
            detail_classified = self._classify_title_tier(detail_title)
            canonicalize = getattr(self, "_canonicalize_platform_name", lambda value: value)
            expected_platform = canonicalize(str(classified.get("platform") or "").lower())
            expected_action = str(classified.get("action") or "").lower()
            actual_platform = canonicalize(str(detail_classified.get("platform") or "").lower())
            actual_action = str(detail_classified.get("action") or "").lower()
            from classification_utils import reconcile_classifications

            reconciliation = reconcile_classifications(
                classified,
                detail_classified,
                canonicalize_platform=lambda value: str(value or "").strip().lower(),
            )
            mismatch = bool(reconciliation["mismatch"])
            if mismatch:
                logger.warning(
                    "Title/detail mismatch: %s | title=%s detail=%s",
                    url,
                    classified,
                    detail_classified,
                )
                details["mismatch_warning"] = reconciliation["warning"]
                details["classification_mismatch"] = reconciliation["mismatch_fields"]
            if detail_classified.get("tier") != "accepted":
                details["decision_status"] = "needs_review"
                details["decision_reason"] = "detailed_title_not_accepted"
            details["detail_check_passed"] = True

        if is_works:
            details["already_accepted"] = True
            details["report_url"] = url
            details["source_page"] = "works"
            details["detail_check_passed"] = True

        details["title_check_passed"] = classified.get("tier") == "accepted"
        details.setdefault("decision_status", "accepted")
        details.setdefault("decision_reason", "detailed_analysis_complete")
        if details.get("decision_status") == "needs_review":
            details["analysis_status"] = "needs_review"
        details["analysis_timestamp"] = time.time()
        self._store_task_details(url, details)
        if (
            not is_works
            and details.get("decision_status") == "accepted"
            and details.get("detail_check_passed") is True
        ):
            self._register_verification_record(url, details)
        await self._try_execute_task(url, details)
        if not is_works:
            if details.get("execution_success") is not True:
                self._invalidate_task_verification(url)
        return bool(details.get("execution_success", False))

    # ======================================================
    # Store task
    # ======================================================

    def _store_task_details(
        self,
        url: str,
        details: dict,
    ):

        account_id = str(details.get("unu_account_id") or "").strip()
        self._invalidate_task_verification(url, account_id or None)
        self._set_task_details(url, details, account_id)
        # ملاحظة: لا نضيف url إلى self.history هنا
        # حتى لا يمنع _try_execute_task من الوصول إلى AI.
        # self.history.add(url)  # تم إزالة هذا السطر

        # منع نمو الذاكرة بلا حدود.
        if len(self.tasks_details) > MAX_STORED_TASKS:

            excess = (
                len(self.tasks_details)
                - MAX_STORED_TASKS
            )

            old_urls = list(
                self.tasks_details.keys()
            )[:excess]

            for old_url in old_urls:

                self.tasks_details.pop(
                    old_url,
                    None,
                )

                self.history.discard(
                    old_url
                )

    def _set_task_details(
        self,
        url: str,
        details: dict,
        account_id: Optional[str] = None,
    ) -> None:
        normalized = self._normalize_task_url(url)
        owner = str(account_id or details.get("unu_account_id") or "").strip()
        if owner:
            if not isinstance(getattr(self, "_account_task_details", None), dict):
                self._account_task_details = {}
            self._account_task_details[f"{owner}:{normalized}"] = details
        if not owner or owner == "legacy":
            self.tasks_details[normalized] = details

    def _get_task_details(
        self,
        url: str,
        account_id: Optional[str] = None,
    ) -> dict:
        normalized = self._normalize_task_url(url)
        owner = str(account_id or "").strip()
        scoped = getattr(self, "_account_task_details", {})
        if owner and isinstance(scoped, dict):
            value = scoped.get(f"{owner}:{normalized}")
            if isinstance(value, dict):
                return value
        if owner:
            return {}
        value = getattr(self, "tasks_details", {}).get(normalized)
        return value if isinstance(value, dict) else {}

    # ======================================================
    # Task notification
    # ======================================================

    async def _notify_task(
        self,
        url: str,
        details: dict,
    ):

        # هذه الدالة محفوظة للتوافق، لكن لا ترسل وصف أو تفاصيل
        # للمهمة أثناء التجميع/الفحص. الإشعار النهائي يتم من
        # _try_execute_task بعد نجاح التنفيذ وتسليم الإثبات.
        logger.debug(
            "Task details notification suppressed until completion: %s",
            url,
        )
        return

    # ======================================================
    # URL validation (مبسطة - أي رابط accept/share صالح)
    # ======================================================

    async def _check_url(
        self,
        url: str,
    ) -> Optional[bool]:

        # أي رابط يحتوي على accept أو share نعتبره صالحًا
        # بدون فتح الصفحة أو فحص المحتوى.
        if "/tasks/accept/" in url or "/tasks/share/" in url or "/tasks/report/" in url:
            return True

        # لو الرابط مش accept/share/report نعتبره غير صالح
        return False

    # ======================================================
    # Basic inspection
    # ======================================================

    async def _inspect_task(
        self,
        share_url: str,
    ) -> dict:

        if not self.context:
            return {}

        new_page = None

        details = {
            "platform": "other",
            "action": "غير معروف",
            "price": "غير معروف",
            "target_url": "غير موجود",
        }

        try:

            new_page = (
                await self.context.new_page()
            )

            new_page.set_default_timeout(
                DETAIL_TIMEOUT
            )

            success = await self._goto(
                new_page,
                share_url,
                timeout=DETAIL_TIMEOUT,
                retries=1,
            )

            if not success:
                return details

            await new_page.wait_for_timeout(
                800
            )

            body_text = await new_page.inner_text(
                "body"
            )

            # ------------------------------------------------
            # Price
            # ------------------------------------------------

            price_match = re.search(
                r"(\d+(?:[.,]\d+)?)\s*(?:руб|₽|p|P|Р)",
                body_text,
                re.IGNORECASE,
            )

            if price_match:

                details["price"] = (
                    price_match.group(1)
                )

            # ------------------------------------------------
            # External URL
            # ------------------------------------------------

            external_links = (
                await new_page.evaluate(
                    """
                    () => {
                        return [...document.querySelectorAll('a[href]')]
                            .map(a => a.href)
                            .filter(href =>
                                href.startsWith('http') &&
                                !href.includes('unu.im')
                            );
                    }
                    """
                )
            )

            if external_links:

                details["target_url"] = (
                    external_links[0]
                )

            # ------------------------------------------------
            # Platform
            # ------------------------------------------------

            target = (
                details["target_url"]
                .lower()
            )

            details["platform"] = (
                self._detect_platform(
                    target,
                    body_text,
                )
            )

            details["action"] = (
                self._detect_action(
                    body_text
                )
            )

        except Exception as error:

            logger.warning(
                "Basic inspection failed: %s",
                error,
            )

        finally:

            if new_page:

                try:
                    await new_page.close()
                except Exception:
                    pass

        return details

    # ======================================================
    # Screenshot inspection: share -> + -> full Screenshot -> AI handoff
    # ======================================================

    async def _inspect_task_detailed(
        self,
        share_url: str,
    ) -> dict:

        if not self.context:
            return {}

        new_page = None

        details = {
            "title": "غير معروف",
            "price": "غير معروف",
            "description": "لا يوجد وصف",
            "work_time": "غير محدد",
            "proof": "غير محدد",
            "target_urls": [],
            "info_for_work": "",
            "platform": "other",
            "action": "غير معروف",
            "screenshot_path": "",
        }

        try:

            new_page = (
                await self.context.new_page()
            )

            new_page.set_default_timeout(
                DETAIL_TIMEOUT
            )

            success = await self._goto(
                new_page,
                share_url,
                timeout=DETAIL_TIMEOUT,
                retries=1,
            )

            if not success:
                return details

            await new_page.wait_for_timeout(
                1500
            )

            # ------------------------------------------------
            # Check for deleted/not found task
            # ------------------------------------------------
            page_text = await new_page.inner_text("body")
            if any(err in page_text.lower() for err in [
                "задание не найдено",
                "произошла ошибка",
                "task not found",
                "was deleted",
                "было удалено",
            ]):
                logger.info("🗑️ Task deleted/not found: %s", share_url)
                details["status"] = "deleted"
                details["error"] = "task_not_found"
                return details

            # ------------------------------------------------
            # Basic extraction (title + price)
            # ------------------------------------------------

            basic_data = await new_page.evaluate(
                """
                () => {
                    const clean = value => String(value || '').replace(/\\s+/g, ' ').trim();
                    const rows = [...document.querySelectorAll('div, li, article, section, tr')];
                    let title = '', price = '';

                    for (const row of rows) {
                        const text = clean(row.innerText);
                        if (!text || text.length > 600) continue;
                        const priceMatch = text.match(/(\\d+(?:[.,]\\d+)?)\\s*(?:руб|₽|p|P|Р)/i);
                        if (!priceMatch) continue;
                        price = priceMatch[1];

                        const titleElement = row.querySelector('a, strong, b, h3, h4, [class*="title"]');
                        if (titleElement) {
                            title = clean(titleElement.innerText);
                        }
                        if (!title) {
                            let rawTitle = text.replace(priceMatch[0], '').trim();
                            rawTitle = rawTitle.replace(/^Название\\s*/i, '').trim();
                            rawTitle = rawTitle.replace(/^Оплата\\s*/i, '').trim();
                            if (rawTitle && rawTitle.length > 0) title = rawTitle;
                        }
                        if (title && !title.includes('Просмотр задания')) break;
                    }
                    return { title, price };
                }
                """
            )

            if basic_data.get("title"):
                details["title"] = normalize_text(basic_data["title"])
            if basic_data.get("price"):
                details["price"] = normalize_text(basic_data["price"])

            # ------------------------------------------------
            # Press the + button / task title to expand details
            # ------------------------------------------------

            task_opened = False

            # First: try clicking on the task title
            clickable_selectors = [
                "a.task-title", ".task-title", ".task-name",
                "[class*='task-title']", "[class*='task-name']",
                "[class*='task__title']", "tr a", "td a"
            ]

            for selector in clickable_selectors:
                try:
                    elements = await new_page.query_selector_all(selector)
                    for element in elements:
                        try:
                            if await element.is_visible():
                                text = (await element.inner_text()).strip()
                                if text and len(text) > 2:
                                    await element.scroll_into_view_if_needed()
                                    await new_page.wait_for_timeout(300)
                                    # Behavior Stealth: محاكاة تحريك الماوس ثم Click مع تأخير
                                    box = await element.bounding_box()
                                    if box:
                                        await new_page.mouse.move(
                                            box["x"] + box["width"] / 2,
                                            box["y"] + box["height"] / 2,
                                            steps=random.randint(8, 15)
                                        )
                                        await asyncio.sleep(random.uniform(0.15, 0.4))
                                    await element.click(force=True, timeout=5000, delay=random.randint(40, 120))
                                    task_opened = True
                                    logger.info(f"تم الضغط على اسم المهمة: {text}")
                                    break
                        except Exception:
                            continue
                    if task_opened:
                        break
                except Exception:
                    continue

            # Second: try clicking on a + button
            if not task_opened:
                plus_selectors = ["button", "[role='button']", ".expand", ".toggle", "[class*='expand']"]
                for selector in plus_selectors:
                    try:
                        elements = await new_page.query_selector_all(selector)
                        for element in elements:
                            try:
                                if not await element.is_visible():
                                    continue
                                text = (await element.inner_text()).strip()
                                if text == "+" or text == "＋":
                                    await element.scroll_into_view_if_needed()
                                    await new_page.wait_for_timeout(300)
                                    # Behavior Stealth: محاكاة الماوس والتأخير
                                    box = await element.bounding_box()
                                    if box:
                                        await new_page.mouse.move(
                                            box["x"] + box["width"] / 2,
                                            box["y"] + box["height"] / 2,
                                            steps=random.randint(8, 15)
                                        )
                                        await asyncio.sleep(random.uniform(0.15, 0.4))
                                    await element.click(force=True, timeout=5000, delay=random.randint(40, 120))
                                    task_opened = True
                                    logger.info("تم الضغط على علامة +")
                                    break
                            except Exception:
                                continue
                        if task_opened:
                            break
                    except Exception:
                        continue

            # Third: fallback JavaScript click
            if not task_opened:
                try:
                    clicked = await new_page.evaluate("""
                    () => {
                        const allElements = [...document.querySelectorAll('a, button, div, span')];
                        for (const element of allElements) {
                            const text = (element.innerText || element.textContent || '').trim();
                            const className = String(element.className || '').toLowerCase();
                            if (text === '+' || className.includes('expand') || className.includes('toggle') || className.includes('accordion')) {
                                element.click();
                                return true;
                            }
                        }
                        return false;
                    }
                    """)
                    if clicked:
                        task_opened = True
                        logger.info("تم فتح التفاصيل باستخدام JavaScript")
                except Exception as error:
                    logger.warning(f"فشل الضغط بـ JavaScript: {error}")

            if task_opened:
                await new_page.wait_for_timeout(3000)

            # ------------------------------------------------
            # Extract body structure (with footer protection)
            # ------------------------------------------------

            extracted_data = await new_page.evaluate(
                """
                () => {
                    const lines = document.body.innerText.split('\\n').map(l => l.trim()).filter(Boolean);

                    let description = 'لا يوجد وصف';
                    let work_time = 'غير محدد';
                    let proof = 'غير محدد';
                    let info_for_work = '';
                    let category = '';
                    let task_type = '';
                    const raw_page_text = lines.join(' ');

                    let linkIndex = -1;
                    let proofIndex = -1;
                    let timeIndex = -1;
                    let infoForWorkIndex = -1;
                    let priceIndex = -1;
                    let categoryIndex = -1;
                    let typeIndex = -1;

                    // كلمات التذييل (جدار الحماية)
                    const footerStopWords = ['Мобильное приложение', 'Партнёрская программа', 'Служба поддержки', 'Информация', 'FAQ', 'API', '© UNU'];

                    for(let i=0; i<lines.length; i++){
                        const line = lines[i];
                        if(line.includes('Ссылка:')) linkIndex = i;
                        else if(line.includes('Информация для работы:')) infoForWorkIndex = i;
                        else if(line.includes('Предоставить в отчёте:')) proofIndex = i;
                        else if(line.includes('Время для работы:')) timeIndex = i;
                        else if(/^(Категория|Раздел|Category)\\s*:/i.test(line)) categoryIndex = i;
                        else if(/^(Тип задания|Тип|Task type|Type)\\s*:/i.test(line)) typeIndex = i;
                        else if(/(\\d+(?:[.,]\\d+)?)\\s*(?:руб|₽|p|P|Р)/i.test(line)) priceIndex = i;
                    }

                    // استخراج معلومات العمل
                    if(infoForWorkIndex >= 0 && infoForWorkIndex + 1 < lines.length){
                        info_for_work = lines[infoForWorkIndex + 1];
                    }

                    // تصنيف UNU إن كان ظاهرًا في بطاقة المهمة.
                    if(categoryIndex >= 0){
                        const sameLine = lines[categoryIndex].replace(/^(Категория|Раздел|Category)\\s*:\\s*/i, '').trim();
                        category = sameLine || (categoryIndex + 1 < lines.length ? lines[categoryIndex + 1] : '');
                    }

                    if(typeIndex >= 0){
                        const sameLine = lines[typeIndex].replace(/^(Тип задания|Тип|Task type|Type)\\s*:\\s*/i, '').trim();
                        task_type = sameLine || (typeIndex + 1 < lines.length ? lines[typeIndex + 1] : '');
                    }

                    // استخراج الوصف
                    let startDesc = -1;
                    if (linkIndex >= 0) startDesc = linkIndex + 1;
                    else if (priceIndex >= 0) startDesc = priceIndex + 1;

                    if (startDesc >= 0) {
                        let descLines = [];
                        let endDesc = lines.length;
                        if (proofIndex > startDesc) endDesc = Math.min(endDesc, proofIndex);
                        if (timeIndex > startDesc) endDesc = Math.min(endDesc, timeIndex);

                        for(let i=startDesc; i<endDesc; i++) {
                            const currentLine = lines[i];
                            if (footerStopWords.some(word => currentLine.includes(word))) {
                                break;
                            }
                            descLines.push(currentLine);
                        }
                        description = descLines.join(' ');
                        description = description.replace(/^Ссылка:\\s*/, '');
                    }

                    // استخراج الوقت
                    if(timeIndex >= 0) {
                        let line = lines[timeIndex];
                        let timeParts = line.match(/Время для работы:?\\s*([^\\n]*)/);
                        if(timeParts && timeParts[1].trim().length > 0){
                            work_time = timeParts[1].trim();
                        } else if(timeIndex + 1 < lines.length) {
                            let nextLine = lines[timeIndex + 1];
                            if(nextLine && nextLine.length < 50){
                                work_time = nextLine;
                            }
                        }
                    }

                    // استخراج الإثبات
                    if(proofIndex >= 0) {
                        let proofLines = [];
                        let endProof = (timeIndex > proofIndex) ? timeIndex : lines.length;

                        for(let i=proofIndex; i<endProof; i++) {
                            const line = lines[i];
                            if (footerStopWords.some(word => line.includes(word))) {
                                break;
                            }
                            proofLines.push(line);
                        }
                        proof = proofLines.join(' ');
                    }

                    return { description, proof, work_time, info_for_work, category, task_type, raw_page_text };
                }
                """
            )

            if extracted_data.get("description"):
                details["description"] = normalize_text(extracted_data["description"])
            if extracted_data.get("work_time"):
                details["work_time"] = normalize_text(extracted_data["work_time"])
            if extracted_data.get("proof"):
                details["proof"] = normalize_text(extracted_data["proof"])
            if extracted_data.get("info_for_work"):
                details["info_for_work"] = normalize_text(extracted_data["info_for_work"])
            if extracted_data.get("category"):
                details["category"] = normalize_text(extracted_data["category"])
            if extracted_data.get("task_type"):
                details["task_type"] = normalize_text(extracted_data["task_type"])
            if extracted_data.get("raw_page_text"):
                details["raw_page_text"] = normalize_text(extracted_data["raw_page_text"])

            # ------------------------------------------------
            # External links (with zoppa.ru decoding)
            # ------------------------------------------------

            external_links = await new_page.evaluate(
                """
                () => {
                    const links = [...document.querySelectorAll('a[href]')]
                        .map(a => a.href)
                        .filter(href => href.startsWith('http') && !href.includes('unu.im'));
                    return [...new Set(links)];
                }
                """
            )

            final_links = []
            blocked_urls = [
                'unu.im',
                't.me/unu_supportbot',
                't.me/unuru_ann',
                'telegram.me/unu_supportbot',
                'telegram.me/unuru_ann',
                'telegram.me/unu'
            ]

            for link in external_links:
                if any(blocked in link for blocked in blocked_urls):
                    continue

                if "zoppa.ru" in link:
                    try:
                        from urllib.parse import urlparse, parse_qs, unquote
                        parsed = urlparse(link)
                        params = parse_qs(parsed.query)
                        if "url" in params:
                            unzipped_url = unquote(params["url"][0])
                            final_links.append(unzipped_url)
                        else:
                            final_links.append(link)
                    except:
                        final_links.append(link)
                else:
                    final_links.append(link)

            final_links = list(dict.fromkeys(final_links))
            filtered_links = []
            for link in final_links:
                low = str(link or "").lower()
                if any(b in low for b in (
                    "unu.im", "play.google.com", "apps.apple.com", "itunes.apple.com",
                    "t.me/unu", "telegram.me/unu", "disk.yandex", "drive.google",
                    "docs.google", "google.com", "facebook.com/unu",
                )):
                    continue
                try:
                    if self._is_generic_platform_homepage(link) or self._is_blocked_target_url(link):
                        continue
                except Exception:
                    pass
                filtered_links.append(link)
            if filtered_links:
                final_links = filtered_links
            details["target_urls"] = final_links

            # ------------------------------------------------
            # Platform & Action — الرابط أولاً، النص بعد كده
            # ------------------------------------------------

            first_url = final_links[0] if final_links else ""
            plat_from_url = self._platform_from_target_url(first_url)
            if not plat_from_url:
                for extra in final_links[1:8]:
                    plat_from_url = self._platform_from_target_url(extra)
                    if plat_from_url:
                        break
            combined_text = (str(details.get("title") or "") + " " + str(details.get("description") or "")).lower()

            if plat_from_url:
                details["platform"] = plat_from_url
            elif "youtube" in combined_text or "ютуб" in combined_text:
                details["platform"] = "youtube"
            elif "tiktok" in combined_text or "тикток" in combined_text:
                details["platform"] = "tiktok"
            elif "instagram" in combined_text or "инстаграм" in combined_text:
                details["platform"] = "instagram"
            elif "rutube" in combined_text or "рутуб" in combined_text:
                details["platform"] = "rutube"
            elif "twitter" in combined_text or "твиттер" in combined_text or re.search(r"\bx\.com\b", combined_text):
                details["platform"] = "twitter"
            elif "вконтакте" in combined_text or re.search(r"\bвк\b", combined_text) or re.search(r"\bvk\b", combined_text):
                details["platform"] = "vk"
            elif "telegram" in combined_text or "телеграм" in combined_text or re.search(r"\bтг\b", combined_text):
                details["platform"] = "telegram"
            elif "озон" in combined_text or "ozon" in combined_text:
                details["platform"] = "ozon"
            elif "wildberries" in combined_text or "вайлдберриз" in combined_text:
                details["platform"] = "wildberries"
            elif "макс" in combined_text or re.search(r"\bmax\b", combined_text):
                details["platform"] = "max"
            elif "авито" in combined_text or "avito" in combined_text:
                details["platform"] = "avito"
            elif first_url.startswith("http"):
                details["platform"] = "website"
            else:
                details["platform"] = "other"

            # Action detection from category first (more reliable)
            category = (details.get("category") or "").lower()
            
            CATEGORY_ACTIONS = {
                # Социальные сети
                "лайк": "like",
                "репост": "share",
                "подписчик": "subscribe",
                "голосован": "vote",
                "ботах": "start_bot",
                "приложениях соц": "start_bot",
                "активность в соцсетях": "subscribe",
                "марафон": "subscribe",
                "розыгрыш": "subscribe",
                "просмотр": "view",
                # Регистрация
                "регистрац": "register",
                "оформление заявки": "register",
                "идентификац": "register",
                # Приложения
                "установка приложений": "install",
                "оценка приложений": "review",
                "магазинах приложений": "review",
                # Комментарии и отзывы
                "комментар": "comment",
                "отзыв": "review",
                "медицинские отзывы": "review",
                "2gis": "review",
                "flamp": "review",
                "yell": "review",
                "avito": "review",
                "юла": "review",
                "google.карт": "review",
                "zoon": "review",
                "hh": "review",
                "dreamjob": "review",
                "profi": "review",
                "rabota": "review",
                "irecommend": "review",
                "отзовик": "review",
                "яндекс": "review",
                "аудио отзыв": "review",
                "видео отзыв": "review",
                "поиск/просмотр объявления": "view",
                "сообщение/переписка": "message",
                "активность по карточке": "like",
                "избранное": "favorite",
                "заявка через звонок": "call",
                # Просмотр видео
                "просмотр видео": "view",
                # Прочее
                "клики/переходы": "view",
                "поиск информации": "view",
                "тестирование": "view",
                "активность 5+": "view",
                "активность 10+": "view",
                "активность 30+": "view",
                "рерайтинг": "comment",
                "рефералом": "register",
                "другое": "unknown",
            }
            
            action_from_category = None
            for cat_key, action in CATEGORY_ACTIONS.items():
                if cat_key in category:
                    action_from_category = action
                    break
            
            if action_from_category:
                details["action"] = action_from_category
                logger.info("📋 Category-based action: %s → %s", category[:30], action_from_category)
            elif "регистрац" in combined_text or "оформлен" in combined_text:
                details["action"] = "register"
            elif "подпис" in combined_text:
                details["action"] = "subscribe"
            elif "лайк" in combined_text:
                details["action"] = "like"
            elif "коммент" in combined_text:
                details["action"] = "comment"
            elif "просмотр" in combined_text:
                details["action"] = "view"
            elif "репост" in combined_text or "share" in combined_text:
                details["action"] = "share"
            elif "отзыв" in combined_text or "оцен" in combined_text:
                details["action"] = "review"
            else:
                details["action"] = "unknown"

            # ------------------------------------------------
            # Screenshot
            # ------------------------------------------------

            screenshot_dir = Path(APP.SCREENSHOTS_DIR)
            screenshot_dir.mkdir(parents=True, exist_ok=True)

            timestamp = int(time.time())
            screenshot_path = screenshot_dir / f"task_{timestamp}_{random.randint(1000, 9999)}.png"

            try:
                await new_page.screenshot(path=str(screenshot_path), full_page=False)
                details["screenshot_path"] = str(screenshot_path)
            except Exception as error:
                logger.warning(f"Screenshot failed: {error}")

            # work_id_extract_v1: رقم العمل من العنوان/النص لرابط report/worker
            try:
                blob_ids = " ".join(
                    str(details.get(k) or "")
                    for k in ("title", "description", "info_for_work", "raw_page_text")
                )
                m_work = re.search(
                    r"(?:Работа|работ[аые]|order|заказ)\s*#?\s*(\d{6,})",
                    blob_ids,
                    re.I,
                )
                if m_work:
                    details["work_id"] = m_work.group(1)
                    details["report_url"] = f"{UNU_BASE_URL}/tasks/report/{m_work.group(1)}/worker"
            except Exception:
                pass
            logger.info(f"✅ استخراج ناجح: {details['title']} | {details['price']} руб")

        except Exception as error:
            logger.exception(f"Detailed inspection failed: {error}")

        finally:
            if new_page:
                try:
                    await new_page.close()
                except Exception:
                    pass

        return details

    # ======================================================
    # Expand task (not used directly, kept for compatibility)
    # ======================================================

    async def _try_expand_task(
        self,
        page: Page,
    ) -> bool:
        # This function is kept for compatibility but the new detailed inspection
        # already handles expansion internally. It will be called from the old logic
        # but we'll just return True to avoid breaking anything.
        return True

    # ======================================================
    # Platform detection
    # ======================================================

    @staticmethod
    def _detect_platform(
        target_url: str,
        text: str,
    ) -> str:
        """كشف المنصة من الرابط أولاً (أدق)، ثم من النص."""

        target = (
            normalize_text(
                target_url
            )
            .lower()
        )

        text = (
            normalize_text(text)
            .lower()
        )
        blob = f"{target} {text}"

        # ----- أولوية الرابط (ما فيش تخمين غلط) -----
        if (
            "max.ru/" in target
            or target.startswith("https://max.ru")
            or target.startswith("http://max.ru")
            or "max.ru/join/" in target
            or "max.ru/u/" in target
        ):
            return "max"

        if (
            "t.me/" in target
            or "telegram.me/" in target
            or "web.telegram.org" in target
        ):
            return "telegram"

        if (
            "vk.com/" in target
            or "vk.ru/" in target
            or "m.vk.ru/" in target
            or "m.vk.com/" in target
        ):
            return "vk"

        if "tiktok.com/" in target:
            return "tiktok"

        if (
            "youtube.com/" in target
            or "youtu.be/" in target
        ):
            return "youtube"

        if "rutube.ru/" in target:
            return "rutube"

        if (
            "instagram.com/" in target
        ):
            return "instagram"

        if (
            "x.com/" in target
            or "twitter.com/" in target
        ):
            return "twitter"

        if (
            "facebook.com/" in target
            or "fb.com/" in target
            or "fb.me/" in target
        ):
            return "facebook"

        # ----- النص (بعد الرابط) -----
        # Max قبل telegram عشان ما يتخلطش
        if any(
            x in blob
            for x in (
                "max.ru",
                "канал в max",
                "в max",
                "мессенджер max",
                "подписаться на канал в max",
                "max messenger",
            )
        ):
            return "max"

        if (
            "telegram" in text
            or "телеграм" in text
            or "тг " in f" {text} "
            or " t.me/" in blob
        ):
            # تجنب: كلمة telegram جوه جملة مش مهمة تيليجرام
            if "max.ru" not in blob:
                return "telegram"

        if (
            "вконтакте" in text
            or " вк " in f" {text} "
            or "vk.com" in text
            or "vk.ru" in text
        ):
            return "vk"

        if "tiktok" in text or "тикток" in text:
            return "tiktok"

        if "avito" in text or "авито" in text or "avito.ru" in blob:
            return "avito"

        if "booking.com" in blob or "букинг" in text:
            return "booking"

        if "ozon" in text or "озон" in text:
            return "ozon"

        if "youtube" in text or "ютуб" in text or "ютюб" in text:
            return "youtube"

        if "rutube" in text or "рутуб" in text:
            return "rutube"

        if "instagram" in text or "инстаграм" in text or "инста" in text:
            return "instagram"

        if (
            "twitter" in text
            or "твиттер" in text
            or " x.com" in blob
        ):
            return "twitter"

        if "facebook" in text or "фейсбук" in text:
            return "facebook"

        if (
            "yandex" in text
            or "карты" in text
            or "google maps" in text
            or "гугл карты" in text
        ):
            return "review"

        if target.startswith("http"):
            return "website"

        return "other"

    # ======================================================
    # Action detection
    # ======================================================

    def _force_action_from_url_and_text(
        self,
        platform: str,
        action: str,
        target_url: str,
        details: dict,
        ai_analysis: dict | None = None,
    ) -> str:
        """
        تمييز احترافي للـ action من شكل الرابط + نص المهمة لكل منصة:

        Instagram:
          /reel/ /reels/ /p/ /tv/  → like (أو comment لو النص يطلب تعليق)
          بروفايل /username       → subscribe

        TikTok:
          /video/ /@user/video/   → like (أو comment)
          /@user فقط              → subscribe

        YouTube / RuTube:
          /watch /shorts /video/  → view أو like حسب النص
          /channel /@ /c/         → subscribe

        VK:
          wall- /video /clip      → like
          club/ public/ id        → subscribe

        X/Twitter:
          /status/                → like
          بروفايل بدون status     → subscribe

        Telegram:
          t.me/joinchat /+        → subscribe
          t.me/username (قناة)    → subscribe
          بوتات ممنوعة من سياسة منفصلة

        الأولوية النهائية: نص المهمة الصريح يغلب افتراض الرابط.
        """
        platform = self._canonicalize_platform_name(platform or "")
        action = normalize_text(action or "").lower()
        url = normalize_text(target_url or "").lower()
        blob_parts = []
        for source in (details or {}, ai_analysis or {}):
            if not isinstance(source, dict):
                continue
            for key in (
                "title", "description", "info_for_work", "proof",
                "raw_page_text", "summary", "category", "task_type",
            ):
                if source.get(key):
                    blob_parts.append(str(source.get(key)))
        blob = normalize_text(" ".join(blob_parts)).lower().replace("ё", "е")

        def has_any(text: str, markers) -> bool:
            return any(m in text for m in markers)

        # فئة UNU الرسمية (إن وُجدت)
        unu_cat = normalize_text(
            str((details or {}).get("category") or (details or {}).get("task_type") or "")
        ).lower().replace("ё", "е")

        like_markers = (
            "лайк", "like", "нравится", "إعجاب", "لايك", "heart",
            "поставить лайк", "поставь лайк", "класс",
        )
        comment_markers = (
            "коммент", "комментарий", "comment", "تعليق",
            "оставить комментарий", "написать комментарий",
        )
        sub_markers = (
            "подпис", "подпиш", "подписаться", "subscribe", "follow",
            "вступить", "اشتراك", "متابعة", "фоллов",
        )
        view_markers = (
            "просмотр", "просмотреть", "смотреть", "view", "watch",
            "مشاهدة", "посетить", "досмотреть",
        )
        share_markers = ("поделиться", "share", "репост", "repost", "retweet", "مشاركة")

        # نص صريح يغلب الرابط
        if has_any(blob, comment_markers) and not has_any(blob, sub_markers):
            text_pref = "comment"
        elif has_any(blob, like_markers) and not has_any(blob, sub_markers):
            text_pref = "like"
        elif has_any(blob, share_markers):
            text_pref = "share"
        elif has_any(blob, view_markers) and not has_any(blob, sub_markers) and not has_any(blob, like_markers):
            text_pref = "view"
        elif has_any(blob, sub_markers) and not has_any(blob, like_markers) and not has_any(blob, comment_markers):
            text_pref = "subscribe"
        else:
            text_pref = ""

        # فئة UNU: Лайки / Подписки / Репосты / Комментарии
        if not text_pref or text_pref == action:
            if any(x in unu_cat for x in ("лайк", "like", "классы")):
                text_pref = "like"
            elif any(x in unu_cat for x in ("репост", "repost", "ретвит")):
                text_pref = "repost"
            elif any(x in unu_cat for x in ("коммент", "comment")):
                text_pref = "comment"
            elif any(x in unu_cat for x in ("подпис", "subscribe", "вступл")):
                text_pref = "subscribe"
            elif any(x in unu_cat for x in ("просмотр", "view", "смотр")):
                text_pref = "view"

        # عنوان صريح
        title_l = normalize_text(str((details or {}).get("title") or "")).lower().replace("ё", "е")
        if "поставить лайк" in title_l or "поставить лайк" in blob:
            text_pref = "like"
        if "сделать репост" in title_l or "репост последней" in blob or "репост в twitter" in title_l or "репост в твиттер" in title_l:
            text_pref = "repost"
        if has_any(blob, ("репост", "ретвит", "retweet", "repost")) and (
            "twitter" in blob or "твиттер" in blob or "x.com" in blob or platform in {"twitter", "x"}
        ):
            text_pref = "repost"

        # ---------- Instagram ----------
        if platform == "instagram" or "instagram.com" in url or "instagr.am" in url:
            is_media = any(x in url for x in (
                "/reel/", "/reels/", "/p/", "/tv/", "/stories/",
            ))
            is_profile = (not is_media) and (
                "instagram.com/" in url
                and not any(x in url for x in ("/explore", "/accounts", "/direct"))
            )
            if is_media:
                if text_pref == "comment":
                    return "comment"
                if text_pref == "like" or not text_pref:
                    return "like"
                if text_pref == "subscribe":
                    # نادر: لايك المنشور + اشتراك — نفضّل like على الريل
                    return "like"
                return "like"
            if is_profile or "/@" not in url:
                if text_pref == "comment":
                    return "comment"
                if text_pref == "like":
                    return "like"
                return "subscribe"

        # ---------- TikTok ----------
        if platform == "tiktok" or "tiktok.com" in url:
            is_video = any(x in url for x in ("/video/", "/v/", "/photo/"))
            is_profile = (not is_video) and ("/@" in url or "tiktok.com/@" in url)
            if is_video:
                if text_pref == "comment":
                    return "comment"
                if text_pref in {"like", ""}:
                    return "like"
                if text_pref == "view":
                    return "view"
                return "like"
            if is_profile or text_pref == "subscribe":
                return "subscribe"
            if text_pref:
                return text_pref

        # ---------- YouTube ----------
        if platform == "youtube" or "youtube.com" in url or "youtu.be" in url:
            is_video = any(x in url for x in (
                "watch?", "/shorts/", "/live/", "youtu.be/",
            ))
            is_channel = any(x in url for x in (
                "/channel/", "/@", "/c/", "/user/",
            )) and not is_video
            if is_video:
                if text_pref == "like":
                    return "like"
                if text_pref == "comment":
                    return "comment"
                if text_pref == "subscribe":
                    return "subscribe"
                return "view" if text_pref in {"", "view"} else text_pref
            if is_channel:
                return "subscribe" if text_pref in {"", "subscribe"} else text_pref

        # ---------- RuTube ----------
        if platform == "rutube" or "rutube.ru" in url:
            is_video = any(x in url for x in ("/video/", "/shorts/", "/play/"))
            is_channel = "/channel/" in url or "/u/" in url
            if is_video:
                if text_pref == "like":
                    return "like"
                if text_pref == "comment":
                    return "comment"
                if text_pref == "subscribe":
                    return "subscribe"
                return "view" if text_pref in {"", "view"} else text_pref
            if is_channel:
                return "subscribe"

        # ---------- VK ----------
        if platform == "vk" or "vk.com" in url or "vk.ru" in url or "m.vk." in url:
            is_post = any(x in url for x in (
                "wall", "/video", "clip", "clips", "story",
            ))
            is_community = any(x in url for x in (
                "club", "public", "event", "id",
            )) and not is_post
            if is_post:
                if text_pref == "comment":
                    return "comment"
                if text_pref in {"like", "share", "repost"}:
                    return text_pref if text_pref != "repost" else "repost"
                if text_pref == "subscribe":
                    return "subscribe"
                return "like"
            if is_community or text_pref == "subscribe":
                return "subscribe"
            if text_pref:
                return text_pref

        # ---------- X / Twitter ----------
        if platform in {"twitter", "x"} or "twitter.com" in url or "x.com" in url:
            is_status = "/status/" in url
            if is_status:
                if text_pref == "comment":
                    return "comment"
                if text_pref in {"share", "repost"}:
                    return "repost"
                return "like"
            # بروفايل
            if text_pref:
                return text_pref
            return "subscribe"

        # ---------- Max ----------
        if platform == "max" or "max.ru" in url:
            if text_pref:
                return text_pref
            if any(x in url for x in ("/u/", "join", "channel")):
                return "subscribe"
            return action or "subscribe"

        # ---------- Telegram (قنوات/جروبات فقط — البوتات محجوبة بسياسة منفصلة) ----------
        if platform == "telegram" or "t.me/" in url or "telegram.me/" in url:
            if text_pref:
                return text_pref
            return "subscribe"

        # عام: فضّل نص المهمة ثم action الحالي
        if text_pref:
            return text_pref
        return action or "unknown"

    @staticmethod
    def _detect_action(text: str) -> str:

        text = (
            normalize_text(text)
            .lower()
        )

        if any(
            x in text
            for x in [
                "регистрац",
                "зарегистр",
                "зарегистрируйтесь",
                "создать аккаунт",
                "забрать бонус",
                "registration",
                "register",
                "sign up",
                "إنشاء حساب",
                "تسجيل",
            ]
        ):
            return "register"

        # اللايك قبل الاشتراك — عشان "Поставить лайك" ما يتفسرش اشتراك
        if any(
            x in text
            for x in [
                "лайк",
                "like",
                "нравится",
                "поставить лайк",
                "поставь лайк",
                "إعجاب",
                "لايك",
                "heart",
            ]
        ):
            return "like"

        if any(
            x in text
            for x in [
                "коммент",
                "комментарий",
                "comment",
                "تعليق",
                "оставить комментарий",
            ]
        ):
            return "comment"

        if any(
            x in text
            for x in [
                "подпис",
                "подпиш",
                "подписаться",
                "subscribe",
                "follow",
                "вступить",
                "اشتراك",
                "متابعة",
            ]
        ):
            return "subscribe"

        if any(
            x in text
            for x in [
                "коммент",
                "комментарий",
                "comment",
                "تعليق",
            ]
        ):
            return "comment"

        if any(
            x in text
            for x in [
                "запустить бота",
                "запусти бота",
                "нажать start",
                "нажмите start",
                "start bot",
                "تشغيل بوت",
                "تشغيل البوت",
            ]
        ):
            return "start_bot"

        if any(
            x in text
            for x in [
                "просмотр",
                "просмотреть",
                "посмотр",
                "смотреть",
                "смотри",
                "зайти",
                "зайти на сайт",
                "заход",
                "войти на сайт",
                "посетить",
                "найти",
                "поиск",
                "через поиск",
                "перейти",
                "переход",
                "серфинг",
                "клик",
                "view",
                "visit",
                "browse",
                "مشاهدة",
                "زيارة",
            ]
        ):
            return "view"

        if any(
            x in text
            for x in [
                "репост",
                "repost",
                "share",
                "мнение",
                "مشاركة",
            ]
        ):
            return "share"

        if any(
            x in text
            for x in [
                "отзыв",
                "review",
                "оцен",
                "تقييم",
                "مراجعة",
            ]
        ):
            return "review"

        return "unknown"

    # ======================================================
    # AI normalization
    # ======================================================

    def _normalize_ai_result(
        self,
        result: Any,
        details: dict,
    ) -> dict:

        if not isinstance(result, dict):
            result = {}

        platform = normalize_text(
            result.get("platform")
        ).lower()

        action = normalize_text(
            result.get("action")
        ).lower()

        proof = normalize_text(
            result.get("required_proof")
        ).lower()

        # --------------------------------------------------
        # Platform aliases
        # --------------------------------------------------

        platform_aliases = {
            "telegram": "telegram",
            "телеграм": "telegram",
            "tg": "telegram",

            "vk": "vk",
            "вконтакте": "vk",

            "tiktok": "tiktok",
            "тикток": "tiktok",

            "facebook": "facebook",
            "fb": "facebook",

            "youtube": "youtube",
            "ютуб": "youtube",

            "instagram": "instagram",
            "инстаграм": "instagram",

            "review": "review",
            "отзыв": "review",

            "website": "website",
            "site": "website",

            "other": "other",
        }

        platform = platform_aliases.get(
            platform,
            platform,
        )

        # --------------------------------------------------
        # Action aliases (بما فيها العربي)
        # --------------------------------------------------

        if (
            "лайк" in action
            or "like" in action
            or "избраж" in action
            or "إعجاب" in action
            or "لايك" in action
        ):
            action = "like"

        elif (
            "коммент" in action
            or "comment" in action
            or "تعليق" in action
        ):
            action = "comment"

        elif (
            "подпис" in action
            or "subscribe" in action
            or "متابع" in action
            or "اشتراك" in action
            or "متابعة" in action
        ):
            action = "subscribe"

        elif (
            "запустить" in action
            or "запусти" in action
            or "start bot" in action
            or "تشغيل بوت" in action
            or "تشغيل البوت" in action
        ):
            action = "start_bot"

        elif (
            "просмотр" in action
            or "view" in action
            or "مشاهدة" in action
            or "مشاهده" in action
            or "зайти" in action
            or "заход" in action
            or "посетить" in action
            or "перейти" in action
        ):
            action = "view"

        elif (
            "репост" in action
            or "share" in action
            or "مشاركة" in action
        ):
            action = "share"

        elif (
            "регистра" in action
            or "register" in action
            or "تسجيل" in action
        ):
            action = "register"

        elif (
            "оцен" in action
            or "review" in action
            or "تقييم" in action
        ):
            action = "review"

        # --------------------------------------------------
        # Fallback: لو الـ AI رجع action غير مدعوم
        # نستخدم الاستخراج المحلي لو مدعوم
        # --------------------------------------------------

        extracted_platform = normalize_text(
            details.get("platform", "other")
        ).lower()

        extracted_action = self._detect_action(
            " ".join(
                    str(details.get(key, ""))
                    for key in (
                        "title",
                        "description",
                        "info_for_work",
                        "proof",
                    )
            )
        )

        if platform not in DEFAULT_AI_SUPPORTED_PLATFORMS:
            if extracted_platform in DEFAULT_AI_SUPPORTED_PLATFORMS:
                platform = extracted_platform
            else:
                platform = "other"

        if platform in {"other", "unknown", "website", "none", "null", ""}:
            for _u in self._task_target_urls(details if isinstance(details, dict) else {}):
                guessed = self._platform_from_target_url(_u)
                if guessed in DEFAULT_AI_SUPPORTED_PLATFORMS:
                    platform = guessed
                    break
        else:
            for _u in self._task_target_urls(details if isinstance(details, dict) else {}):
                guessed = self._platform_from_target_url(_u)
                if guessed in DEFAULT_AI_SUPPORTED_PLATFORMS:
                    platform = guessed
                    break
        try:
            if detect_platform_from_title and isinstance(details, dict):
                title_plat = detect_platform_from_title(str(details.get("title") or ""))
                if title_plat == "x":
                    title_plat = "twitter"
                if title_plat and title_plat in DEFAULT_AI_SUPPORTED_PLATFORMS:
                    _urls_now = self._task_target_urls(details)
                    if any(self._platform_from_target_url(u) == title_plat for u in _urls_now):
                        platform = title_plat
        except Exception:
            pass

        if action in {"follow", "join", "unfollow"}:
            action = "subscribe"
        if action in {"retweet"}:
            action = "repost"
        if action in {"favourite"}:
            action = "favorite"

        if action not in DEFAULT_AI_SUPPORTED_ACTIONS:
            if extracted_action in DEFAULT_AI_SUPPORTED_ACTIONS:
                action = extracted_action
            else:
                action = "unknown"

        # --------------------------------------------------
        # Proof
        # --------------------------------------------------

        valid_proofs = {
            "screenshot",
            "username",
            "text",
            "account_url",
            "comment",
        }

        if proof not in valid_proofs:
            proof = "text"

        instr = str((details or {}).get("proof") or "").lower().replace("ё", "е")
        if any(w in instr for w in ("ник", "логин", "имя пользователя", "имя аккаунта")):
            proof = "username"
        elif any(w in instr for w in ("ссылк", "на профиль", "на аккаунт", "на страницу")):
            proof = "account_url"
        elif "комментар" in instr:
            proof = "comment"
        elif any(w in instr for w in ("отзыв", "текст коммента")):
            proof = "text"
        elif any(w in instr for w in ("скрин", "screenshot", "фото")):
            proof = "screenshot"

        # تصحيح ريل/بوست إنستا: لايك مش اشتراك
        try:
            targets = details.get("target_urls") if isinstance(details, dict) else None
            target = ""
            if isinstance(targets, (list, tuple)) and targets:
                target = str(targets[0])
            elif isinstance(details, dict):
                target = str(details.get("target_url") or details.get("url") or "")
            # force_max_platform_v1
            _blob_max = " ".join(
                str(details.get(k) or "")
                for k in ("title", "description", "info_for_work", "raw_page_text")
            ).lower()
            _turl = (target or "").lower()
            # أي إشارة لـ max.ru في الرابط/النص → max (حتى لو AI قال website/telegram)
            if (
                "max.ru" in _blob_max or "max.ru" in _turl
                or "max.ru/join/" in _turl or "max.ru/u/" in _turl
                or "в max" in _blob_max or "канал в max" in _blob_max
                or "подписаться на канал в max" in _blob_max
                or "мессенджер max" in _blob_max
            ):
                platform = "max"

            action = self._force_action_from_url_and_text(
                platform,
                action,
                target,
                details if isinstance(details, dict) else {},
                result if isinstance(result, dict) else {},
            )
        except Exception:
            pass

        # توحيد أفعال X/Twitter
        try:
            _p = self._canonicalize_platform_name(platform or "")
            _a = normalize_text(action or "").lower()
            if _p in {"twitter", "x"} and _a in {"share", "retweet"}:
                action = "repost"
            if _p == "instagram" and _a == "follow":
                action = "subscribe"
        except Exception:
            pass

        return {
            "platform": platform or "other",
            "action": action or "unknown",
            "required_proof": proof,
            "summary": normalize_text(
                result.get(
                    "summary",
                    "",
                )
            ),
        }

    # ======================================================
    # Execution filters
    # ======================================================

    def _get_dashboard_setting(
        self,
        key: str,
        default: Any = None,
    ) -> Any:
        """
        قراءة إعداد من Dashboard بدون كسر البوت.

        ترتيب الأولوية:
        1) dashboard.settings[key]
        2) self.dashboard_filters[key]
        3) attributes المباشرة (filter_platform / filter_price_min ...)
        4) default
        """

        # 1) Dashboard object settings
        try:
            if self.dashboard is not None:
                settings = getattr(
                    self.dashboard,
                    "settings",
                    None,
                )
                if isinstance(settings, dict) and key in settings:
                    return settings.get(key, default)
        except Exception as error:
            logger.debug(
                "Dashboard setting read failed [%s]: %s",
                key,
                error,
            )

        # 2) synced payload on core
        try:
            filters_map = getattr(self, "dashboard_filters", None)
            if isinstance(filters_map, dict) and key in filters_map:
                return filters_map.get(key, default)
        except Exception:
            pass

        # 3) direct attributes written by Dashboard.sync_settings_to_core
        attr_map = {
            "platform": "filter_platform",
            "price_min": "filter_price_min",
            "price_max": "filter_price_max",
            "task_count": "filter_task_count",
            "safe_mode": "safe_mode",
            "auto_skip_blocked": "auto_skip_blocked",
            "daily_limit": "max_tasks_per_day",
            "mode": "mode",
            "cycle_limit": "cycle_limit",
            "error_limit": "error_limit",
        }
        try:
            attr_name = attr_map.get(key)
            if attr_name and hasattr(self, attr_name):
                value = getattr(self, attr_name)
                if value is not None:
                    return value
        except Exception:
            pass

        return default

    def _task_price(
        self,
        details: dict,
    ) -> Optional[float]:
        """
        استخراج سعر المهمة بشكل آمن.
        None = السعر غير معروف.
        """

        raw_price = details.get(
            "price"
        )

        if raw_price in (
            None,
            "",
            "غير معروف",
            "unknown",
            "None",
        ):
            return None

        try:

            value = safe_float(
                raw_price,
                default=-1.0,
            )

            if value < 0:
                return None

            return value

        except Exception:

            return None

    def _task_platform(
        self,
        details: dict,
    ) -> str:
        """
        يستخرج المنصة من details مع اكتشاف من العنوان/الوصف/الروابط
        عشان مهام زي «вк рилс» ما تتسابش other وتترفّض.
        """
        platform = normalize_text(
            details.get("platform", "other")
        ).lower()
        platform = self._canonicalize_platform_name(platform)

        if platform in (globals().get("ALLOWED_EXECUTION_PLATFORMS") or set()) or platform in {
            "telegram", "vk", "max", "instagram", "tiktok", "youtube", "rutube", "twitter", "x"
        }:
            return "twitter" if platform == "x" else platform

        blob = " ".join(
            str(details.get(k) or "")
            for k in ("title", "description", "info_for_work", "raw_page_text", "proof")
        ).lower()
        try:
            for u in (details.get("target_urls") or []):
                blob += " " + str(u).lower()
        except Exception:
            pass

        rules = [
            ("telegram", (
                "t.me/", "telegram.me/", "telegram", "телеграм", "телега",
                "тг ", "в телеграм", "подписаться в telegram", "канал в telegram",
            )),
            ("vk", (
                "vk.com", "vk.ru", "m.vk.", "вконтакте", " вк ", "вк рилс",
                "vk reels", "vk clips", "вконтакте", "паблик", "группу vk",
            )),
            ("instagram", (
                "instagram.com", "instagr.am", "инстаграм", "инста ",
                "в инстаграм", "instagram", "insta",
            )),
            ("tiktok", (
                "tiktok.com", "tiktok", "тикток", "тик ток", "в тикток",
            )),
            ("youtube", (
                "youtube.com", "youtu.be", "ютуб", "youtube", "на ютуб",
            )),
            ("rutube", (
                "rutube.ru", "rutube", "рутуб", "на рутуб",
            )),
            ("max", (
                "max.ru", "max messenger", "макс", "в max",
                "подписаться на канал в max", "канал в max",
                "max.ru/u/", "max.ru/", "мессенджер max",
            )),
            ("twitter", (
                "twitter.com", "x.com/", " твитт", " twitter", "в twitter",
            )),
        ]
        for name, markers in rules:
            if any(m in blob for m in markers):
                return name

        if platform and platform != "other":
            return platform
        return "other"

    def _task_action(
        self,
        details: dict,
    ) -> str:

        action = normalize_text(
            details.get(
                "action",
                "unknown",
            )
        ).lower()

        if not action:
            action = "unknown"

        return action

    def _platform_from_target_url(self, url: str) -> str:
        """منصة التنفيذ من رابط الهدف نفسه، مش من كلمة عابرة في الوصف."""
        u = self._unwrap_redirect_url(str(url or "")).lower()
        if not u.startswith("http"):
            return ""
        pairs = (
            (("t.me/", "telegram.me/", "telegram.org"), "telegram"),
            (("youtu.be", "youtube.com", "youtube.ru"), "youtube"),
            (("tiktok.com",), "tiktok"),
            (("instagram.com",), "instagram"),
            (("vk.com", "vk.ru", "vk.me", "m.vk."), "vk"),
            (("rutube.ru",), "rutube"),
            (("twitter.com", "x.com/"), "twitter"),
            (("max.ru",), "max"),
            (("ozon.ru",), "ozon"),
            (("wildberries.ru", "wb.ru"), "wildberries"),
            (("avito.ru",), "avito"),
            (("booking.com",), "booking"),
        )
        for keys, name in pairs:
            if any(k in u for k in keys):
                return name
        return ""

    def _task_target_urls(
        self,
        details: dict,
    ) -> list:
        """روابط الهدف الحقيقية فقط. فوتر UNU ومتاجر التطبيقات مش أهداف."""
        urls = details.get("target_urls", [])
        if not isinstance(urls, (list, tuple)):
            urls = []

        cleaned = []
        for url in urls:
            clean = self._unwrap_redirect_url(self._clean_url(url))
            if clean and clean.startswith(("http://", "https://")):
                cleaned.append(clean)

        combined = " ".join(
            str(details.get(k) or "")
            for k in ("description", "title", "info_for_work")
        )
        for url in re.findall(r"https?://[^\s\)\]\"\'<>]+", combined):
            clean = self._unwrap_redirect_url(self._clean_url(url))
            if clean and clean.startswith(("http://", "https://")):
                cleaned.append(clean)

        noise = (
            "unu.im", "play.google.com", "apps.apple.com", "itunes.apple.com",
            "disk.yandex", "drive.google", "docs.google", "google.com",
            "yandex.ru/search", "wa.me", "t.me/unu", "telegram.me/unu",
            "facebook.com", "ok.ru",
        )
        kept = []
        for clean in cleaned:
            low = clean.lower()
            if any(b in low for b in noise):
                continue
            try:
                if self._is_generic_platform_homepage(clean):
                    continue
                if self._is_blocked_target_url(clean):
                    continue
            except Exception:
                pass
            kept.append(clean)
        kept = list(dict.fromkeys(kept))
        if kept:
            return kept
        fallback = []
        for clean in cleaned:
            low = clean.lower()
            if "unu.im" in low or "play.google" in low or "apps.apple" in low:
                continue
            fallback.append(clean)
        return list(dict.fromkeys(fallback))

    def _canonicalize_platform_name(self, platform: str) -> str:
        """توحيد اسم المنصة إلى قيمة canonical."""
        platform = normalize_text(platform).lower()
        if not platform:
            return "other"
        platform = canonical_platform(platform)
        aliases = globals().get("PLATFORM_CANONICAL_ALIASES", {})
        platform = aliases.get(platform, platform)
        # توحيد x → twitter للفلاتر الداخلية
        if platform == "x":
            platform = "twitter"
        return platform

    def _is_execution_platform_allowed(self, platform: str) -> bool:
        """هل المنصة ضمن قائمة التنفيذ المسموحة فقط؟"""
        platform = self._canonicalize_platform_name(platform)
        allowed = globals().get("ALLOWED_EXECUTION_PLATFORMS", DEFAULT_AI_SUPPORTED_PLATFORMS)
        if platform in allowed:
            return True
        # مهام التعليق/التقييم على خرائط جوجل قد تأتي كـ review
        if platform == "review":
            return True
        return False

    def _dashboard_platform_allowed(
        self,
        platform: str,
    ) -> bool:
        """
        فلتر المنصة (مبسّط حسب طلب التشغيل):
        - يتجاهل تصنيف/فلتر المنصة من الداشبورد
        - يسمح فقط بالمنصات الثمانية:
          telegram / vk / max / instagram / tiktok / youtube / rutube / x|twitter
        """
        platform = self._canonicalize_platform_name(platform)
        return self._is_execution_platform_allowed(platform)

    def _passes_task_filters(
        self,
        task_url: str,
        details: dict,
    ) -> tuple[bool, str]:
        """
        الفلترة الحقيقية قبل AI وقبل Skill.

        الترتيب:
        1. Daily limit
        2. Duplicate
        3. Price
        4. Platform
        5. Target (بدون رفض صارم هنا)
        """

        # --------------------------------------------------
        # 1. Daily limit
        # --------------------------------------------------

        if self._daily_limit_reached():

            return (
                False,
                "daily_limit",
            )

        # --------------------------------------------------
        # 2. Duplicate
        # --------------------------------------------------

        normalized_task_url = (
            self._normalize_task_url(
                task_url
            )
        )

        if (
            normalized_task_url in self.history
        ):

            return (
                False,
                "duplicate",
            )

        # --------------------------------------------------
        # 3. Platform
        # --------------------------------------------------

        platform = self._task_platform(
            details
        )

        # platform_filter مبكرًا فقط لو المنصة *معروفة* وممنوعة.
        # لو other/unknown لسه — نكمّل للـ AI/القاموس وبعدين Gate يقرر.
        # (سبب رفض الـ60 مهمة: معظمها كانت other قبل التحليل)
        if platform not in {"other", "unknown", "", "none", "null"}:
            if not self._dashboard_platform_allowed(platform):
                return (
                    False,
                    "platform_filter:" + str(platform),
                )

        # --------------------------------------------------
        # 4. Target
        #   ملاحظة: لو مفيش target مش هنرفض هنا،
        #   لأننا ممكن نستخرجه من الوصف في `_task_target_urls`
        #   والـ AI Gate هو اللي هيتأكد نهائي.
        # --------------------------------------------------

        targets = self._task_target_urls(
            details
        )

        if not targets:

            # مش هنرفض هنا، لكن ممكن نرفض في AI Gate
            # أو نعتبرها غير قابلة للتنفيذ لو الوصف
            # خالي من أي روابط.
            logger.debug(
                "No targets extracted yet for: %s",
                task_url,
            )

        return (
            True,
            "allowed",
        )

    # ======================================================
    # AI Gate
    # ======================================================


    def _is_telegram_miniapp_task(
        self,
        details: dict,
        ai_analysis: dict,
    ) -> bool:
        """
        يكتشف مهام تيليجرام اللي تطلب ميني-آب / مهام داخل البوت
        (مش مجرد اشتراك في قناة/جروب).
        """
        parts = []
        for source in (details, ai_analysis):
            if not isinstance(source, dict):
                continue
            for key in (
                "title",
                "description",
                "info_for_work",
                "proof",
                "summary",
                "raw_page_text",
            ):
                val = source.get(key)
                if val:
                    parts.append(str(val))
        text = normalize_text(" ".join(parts)).lower()
        text = text.replace("ё", "е")

        mini_markers = (
            "mini app",
            "miniapp",
            "mini-app",
            "webapp",
            "web app",
            "web-app",
            "мини-приложен",
            "мини приложен",
            "миниапп",
            "мини-апп",
            "открыть приложение",
            "откройте приложение",
            "запустить мини",
            "внутри бота",
            "в мини-приложении",
            "в мини приложении",
            "выполнить задания в боте",
            "выполнять задания в боте",
            "проходить задания",
            "пройди задания",
            "сделай задания в боте",
            "игры в боте",
            "тапать",
            "тапай",
            "farm",
            "кликер",
            "clicker",
            "бот с заданиями",
            "меню бота",
            "кнопки бота",
            "приложения бота",
            "t.me/.*\\?startapp",
            "startapp",
            "ميني اب",
            "ميني-اب",
            "ميني آب",
            "مهام داخل البوت",
            "مهام جوه البوت",
            "افتح التطبيق",
            "تطبيق البوت",
        )
        if any(m in text for m in mini_markers):
            return True
        # رابط startapp صريح
        targets = details.get("target_urls") if isinstance(details, dict) else None
        if isinstance(targets, (list, tuple)):
            for url in targets:
                u = normalize_text(url).lower()
                if "startapp" in u or "tgwebapp" in u or "miniapp" in u:
                    return True
        return False


    def _is_blocked_target_url(self, url: str) -> str:
        """يرجع سبب الرفض أو سلسلة فارغة."""
        u = normalize_text(url).lower()
        if not u:
            return ""
        # تعزيز قنوات تيليجرام — مش اشتراك عادي
        if "telegram.me/boost/" in u or "t.me/boost/" in u or "/boost/" in u and ("t.me" in u or "telegram" in u):
            return "telegram_boost_blocked"
        # صفحات رئيسية فارغة
        bare = {
            "https://www.youtube.com/", "https://youtube.com/",
            "https://www.instagram.com/", "https://instagram.com/",
            "https://www.tiktok.com/", "https://tiktok.com/",
            "https://vk.com/", "https://vk.ru/", "https://m.vk.ru/",
            "https://www.rutube.ru/", "https://rutube.ru/",
            "https://x.com/", "https://twitter.com/",
            
        }
        if u.rstrip("/") + "/" in bare or u in bare or u.rstrip("/") in {x.rstrip("/") for x in bare}:
            return f"generic_homepage:{u}"
        if "unu.im/users/change-ref" in u or "unu.im/partner/competitions" in u:
            return "unu_internal_link_blocked"
        return ""


    def _detect_compound_actions(self, text: str) -> list:
        """يرجع قائمة أفعال لو المهمة مركّبة (اشتراك + لايك / ريبوست / مشاهدة ...)."""
        t = normalize_text(text or "").lower().replace("ё", "е")
        actions = []
        if any(x in t for x in (
            "подписаться", "подпишись", "подписка", "subscribe", "вступить", "вступите",
            "follow", "фоллов",
        )):
            actions.append("subscribe")
        if any(x in t for x in (
            "поставить лайк", "лайк на", "лайки", "like the", "like last", "like to the",
            "лайкнуть", "поставить like", "heart", "реакц", "reaction",
        )):
            actions.append("like")
        if any(x in t for x in ("комментар", "comment", "оставить отзыв", "напишите")):
            actions.append("comment")
        if any(x in t for x in ("репост", "repost", "ретвит", "retweet")):
            actions.append("repost")
        if any(x in t for x in ("поделиться", "share")) and "repost" not in actions:
            actions.append("share")
        if any(x in t for x in (
            "просмотр", "просмотреть", "посмотреть", "смотреть", "view", "watch",
            "прослушать", "последние",
        )):
            actions.append("view")
        out = []
        for a in actions:
            if a not in out:
                out.append(a)
        return out

    def _unwrap_redirect_url(self, url: str) -> str:
        """href.li/?https://t.me/... → https://t.me/..."""
        u = str(url or "").strip()
        if not u:
            return ""
        low = u.lower()
        for prefix in (
            "https://href.li/?",
            "http://href.li/?",
            "https://href.li/",
            "http://href.li/",
        ):
            if low.startswith(prefix.replace("https://", "https://").split("?")[0]) or "href.li/?" in low:
                # query after href.li/?
                if "href.li/?" in low:
                    part = u.split("href.li/?", 1)[-1]
                    part = part.split("&")[0].strip()
                    if part.startswith("http"):
                        return part
                break
        return u

    def _telegram_url_kind(self, url: str) -> str:
        """
        bot | channel_post | channel_or_user | joinchat | unknown
        """
        u = self._unwrap_redirect_url(url)
        low = normalize_text(u).lower()
        if "t.me/" not in low and "telegram.me/" not in low:
            return "unknown"
        if "boost/" in low:
            return "boost"
        if "start=" in low or "startapp" in low or "tgwebapp" in low:
            return "bot"
        m = re.search(r"(?:t\.me|telegram\.me)/([a-zA-Z0-9_]+)/(\d+)", low)
        if m:
            return "channel_post"  # منشور في قناة/جروب
        m = re.search(r"(?:t\.me|telegram\.me)/(joinchat|\\+|c)/", low)
        if m:
            return "joinchat"
        m = re.search(r"(?:t\.me|telegram\.me)/([a-zA-Z0-9_]+)", low)
        if m:
            uname = m.group(1).lower()
            if uname in {"share", "proxy", "socks", "addstickers", "setlanguage"}:
                return "unknown"
            if uname.endswith("bot") or uname.endswith("_bot") or uname.startswith("bot"):
                return "bot"
            return "channel_or_user"
        return "unknown"

    def _is_telegram_bot_task(
        self,
        details: dict,
        ai_analysis: dict | None = None,
    ) -> bool:
        """
        بوت = رابط بوت / start= / أو تعليمات تشغيل بوت واضحة.
        منشور قناة t.me/name/123 أو قناة عادية → مش بوت.
        """
        details = details or {}
        ai_analysis = ai_analysis or {}

        action = normalize_text(
            ai_analysis.get("action") or details.get("action") or ""
        ).lower()
        if action in {"start_bot", "bot_start", "open_bot"}:
            # التصنيف وحده مش كفاية. لازم رابط بوت حقيقي.
            pass

        urls = []
        for source in (details, ai_analysis):
            if not isinstance(source, dict):
                continue
            tlist = source.get("target_urls")
            if isinstance(tlist, (list, tuple)):
                urls.extend(str(x) for x in tlist if x)
            for key in ("target_url", "url", "link"):
                if source.get(key):
                    urls.append(str(source.get(key)))

        # فك href.li
        urls = [self._unwrap_redirect_url(u) for u in urls if u]

        blob_text = " ".join(
            str(details.get(k) or "")
            for k in ("title", "description", "info_for_work", "raw_page_text", "category")
        ).lower().replace("ё", "е")
        blob_text += " " + " ".join(
            str(ai_analysis.get(k) or "")
            for k in ("summary", "title", "description")
        ).lower()

        kinds = [self._telegram_url_kind(u) for u in urls]
        has_bot_url = any(k == "bot" for k in kinds)
        has_channel_post = any(k == "channel_post" for k in kinds)
        has_channel = any(k in {"channel_post", "channel_or_user", "joinchat"} for k in kinds)
        has_tg = has_bot_url or has_channel or any(
            ("t.me/" in u.lower() or "telegram.me/" in u.lower()) for u in urls
        )

        # مواقع غير تيليجرام واضحة
        non_bot_site_markers = (
            "socpublic.com", "goo.su/", "ozon.ru", "ozone.ru", "avito.ru",
            "авито", "play.google.com", "google play",
            "расширение для браузера", "плагин", "маркетплейс",
            "корзин", "избранное", "disk.yandex", "drive.google",
        )
        if any(m in blob_text or any(m in u.lower() for u in urls) for m in non_bot_site_markers):
            if not has_bot_url:
                return False

        # منشور قناة/جروب صريح → مش بوت (حتى لو النص ذكر «бот» بشكل عابر)
        if has_channel_post and not has_bot_url:
            # إلا لو تعليمات تشغيل بوت قوية جدًا مع رابط بوت
            return False

        if has_bot_url:
            return True

        # نص بوت قوي — فقط لو مفيش رابط منشور قناة يفسّر المهمة
        bot_text_markers = (
            "запуск бота", "запустить бота", "запустите бота", "запуск бот",
            "старт бота", "start bot",
            "нажмите «старт»", "нажмите старт", "нажать старт", "press start",
            "проверить подписку", "проверка подписки",
            "новых пользователей бота", "новые пользователи бота",
            "только для новых пользователей бота",
            "действия в ботах", "в ботах/приложениях",
            "мини-приложение", "mini app", "mini-app", "tgwebapp",
            "открыть бота", "перейти в бота", "перейдите в бота",
            "бот фиксирует", "после успешного подключения",
            "тг бот", "tg bot", "телеграм бот", "telegram bot",
            "перейти в новый тг бот", "перейти в новый телеграм бот",
        )
        strong_hits = sum(1 for m in bot_text_markers if m in blob_text)
        title_l = str(details.get("title") or "").lower().replace("ё", "е")

        if has_channel and not has_bot_url:
            return False

        if strong_hits >= 2 and has_bot_url:
            return True
        if has_bot_url and ("запуск бота" in title_l or "запуск бота" in blob_text):
            return True
        if not has_bot_url:
            return False
        if any(
            x in title_l
            for x in ("запуск бота", "start bot", "тг бот", "телеграм бот")
        ):
            return True

        plat = normalize_text(
            ai_analysis.get("platform") or details.get("platform") or ""
        ).lower()
        try:
            plat = self._canonicalize_platform_name(plat)
        except Exception:
            pass
        non_tg = {
            "vk", "instagram", "tiktok", "youtube", "rutube", "twitter", "x",
    "website",
            "avito", "facebook", "max", "yandex", "google_maps", "google_play",
            "app_store", "pinterest", "reddit", "discord", "website", "other",
        }
        if plat in non_tg and not has_tg:
            return False

        return False


    def _telegram_execution_allowed(
        self,
        details: dict,
        ai_analysis: dict,
    ) -> tuple:
        """
        سياسة تيليجرام النهائية (حسب طلب التشغيل):

        ✅ مسموح فقط: قنوات / جروبات / رسائل خاصة
           (اشتراك، تفاعل، كومنت، لايك، مشاهدة...)

        ❌ ممنوع بالكامل: أي بوت تيليجرام
           (start / ref / start_bot / ميني-آب / مهام داخل البوت)

        الفحص يتم حتى لو التصنيف اتجاب website بالغلط.
        """
        # لو مفيش أي رابط t.me/telegram.me أصلًا → مش مهمة بوت تيليجرام
        # (حتى لو النص قال «تسجيل عبر Telegram أو الموقع أو MAX»)
        try:
            _urls_chk = []
            for _src in (details, ai_analysis):
                if not isinstance(_src, dict):
                    continue
                _t = _src.get("target_urls") or []
                if isinstance(_t, (list, tuple)):
                    _urls_chk.extend(str(x) for x in _t if x)
                for _k in ("target_url", "url", "link"):
                    if _src.get(_k):
                        _urls_chk.append(str(_src.get(_k)))
            _has_tm = any(
                ("t.me/" in u.lower() or "telegram.me/" in u.lower())
                for u in _urls_chk
            )
            _blob = " ".join(
                str((details or {}).get(k) or "")
                for k in ("title", "description", "info_for_work", "raw_page_text")
            ).lower()
            # تسجيل/QR/موقع/drive بدون رابط t.me = مش بوت
            if not _has_tm and any(
                x in _blob
                for x in (
                    "drive.google", "google.com/file", "qr", "регистрац",
                    "loyalty", "q club", "на сайте", "через max", "через сайт",
                    "ozon", "socpublic", "расширен",
                )
            ):
                return True, "not_telegram_registration_text"
            if not _has_tm:
                # من غير رابط تيليجرام: سياسة البوتات لا تنطبق
                platform_early = self._canonicalize_platform_name(
                    (ai_analysis or {}).get("platform")
                    or (details or {}).get("platform")
                    or ""
                )
                if platform_early != "telegram":
                    return True, "not_telegram"
                # platform=telegram بالغلط من النص — اعتبرها مش تيليجرام
                return True, "telegram_mentioned_only_no_link"
        except Exception:
            pass

        # حظر البوتات دائمًا — قبل حتى فحص platform
        if self._is_telegram_bot_task(details, ai_analysis):
            return False, "telegram_bot_blocked"

        if self._is_telegram_miniapp_task(details, ai_analysis):
            return False, "telegram_miniapp_blocked"

        platform = self._canonicalize_platform_name(
            (ai_analysis or {}).get("platform")
            or (details or {}).get("platform")
            or ""
        )
        # لو في رابط تيليجرام بوت في التفاصيل برضو (احتياطي)
        try:
            targets = []
            for src in (details, ai_analysis):
                if isinstance(src, dict):
                    t = src.get("target_urls") or []
                    if isinstance(t, (list, tuple)):
                        targets.extend(t)
            for u in targets:
                ul = normalize_text(u).lower()
                if ("t.me/" in ul or "telegram.me/" in ul) and (
                    "start=" in ul or re.search(r"/[a-z0-9_]*bot(?:\?|$)", ul)
                ):
                    return False, "telegram_bot_blocked"
        except Exception:
            pass

        if platform != "telegram":
            return True, "not_telegram"

        entity = self._detect_telegram_entity_kind(details, ai_analysis)
        action = normalize_text(
            (ai_analysis or {}).get("action")
            or (details or {}).get("action")
            or ""
        ).lower()

        # "start" لوحده مش كفاية (تسجيل/QR عبر تيليجرام في نص المهمة)
        if action in {"start_bot", "open_bot", "bot_start", "startbot"}:
            return False, "telegram_bot_blocked"

        if entity == "bot":
            return False, "telegram_bot_blocked"

        if entity in {"channel", "group", "private", "user"}:
            return True, f"telegram_{entity}_allowed:{action or 'any'}"

        # unknown بدون علامات بوت → اسمح (قنوات عامة)
        return True, f"telegram_unknown_allowed:{action or 'any'}"

    def _detect_telegram_entity_kind(
        self,
        details: dict,
        ai_analysis: dict,
    ) -> str:
        """
        يحاول تمييز: channel / group / bot / private / user / unknown
        من الروابط والنص — بدون تنفيذ شبكة إضافية.
        """
        parts = []
        urls = []
        for source in (details, ai_analysis):
            if not isinstance(source, dict):
                continue
            for key in (
                "title", "description", "info_for_work", "proof",
                "summary", "raw_page_text",
            ):
                val = source.get(key)
                if val:
                    parts.append(str(val))
            t = source.get("target_urls")
            if isinstance(t, (list, tuple)):
                urls.extend(str(x) for x in t if x)
            elif isinstance(t, str) and t:
                urls.append(t)
            for key in ("target_url", "url", "link"):
                if source.get(key):
                    urls.append(str(source.get(key)))

        text = normalize_text(" ".join(parts)).lower().replace("ё", "е")
        joined_urls = " ".join(urls).lower()

        # إشارات بوت
        bot_markers = (
            " bot", "бот", "start bot", "запустить бота", "t.me/",
        )
        # من الرابط: username ينتهي بـ bot
        import re as _re
        for u in urls:
            u_l = normalize_text(u).lower()
            if "startapp" in u_l or "tgwebapp" in u_l:
                return "bot"
            m = _re.search(r"(?:t\.me|telegram\.me)/([a-zA-Z0-9_]+)", u_l)
            if m:
                uname = m.group(1).lower()
                if uname.endswith("bot") or uname.endswith("_bot"):
                    return "bot"
                if uname in {"joinchat", "addstickers", "share", "proxy"}:
                    continue
                # +invite = غالبًا جروب/قناة
                if uname.startswith("+"):
                    return "group"
            if "/c/" in u_l:
                return "channel"
            if "joinchat" in u_l or "/+" in u_l:
                return "group"

        if any(x in text for x in (
            "мини-приложен", "mini app", "miniapp", "startapp",
            "запустить бота", "start bot", "нажмите start",
        )) and any(x in text for x in ("бот", "bot")):
            # لو وصف بوت بدون ما نقدر نجزم — اعتبره bot
            if "канал" not in text and "группу" not in text and "группу" not in text:
                return "bot"

        if any(x in text for x in (
            "канал", "channel", "подписаться на канал", "قناة",
        )):
            return "channel"
        if any(x in text for x in (
            "группу", "group", "чат", "вступить в группу", "جروب", "مجموعة",
        )):
            return "group"
        if any(x in text for x in (
            "личный", "private", "л с", "رسالة خاصة", "خاص",
            "напишите в лс", "в личные сообщения",
        )):
            return "private"

        if any(x in text for x in ("бот", " bot", "telegram bot")):
            return "bot"

        return "unknown"

    def _needs_ai_assisted_execution(
        self,
        platform: str,
        action: str,
    ) -> bool:
        """
        التقييمات + ياندكس + خرائط جوجل تعتمد على AI في تجهيز النص/التقييم
        قبل ما الـ Skill ينفّذ.
        """
        platform = self._canonicalize_platform_name(platform)
        action = normalize_text(action).lower()
        if platform in {"yandex", "google_maps", "review"}:
            return True
        if action in {"review", "comment"} and platform in {
            "yandex",
            "google_maps",
            "review",
            "website",
        }:
            return True
        return False

    async def _prepare_ai_assisted_execution(
        self,
        task_page,
        target_url: str,
        details: dict,
        ai_analysis: dict,
    ) -> dict:
        """
        تجهيز تنفيذ بالذكاء الاصطناعي لمهام:
        - تقييم / مراجعة
        - ياندكس
        - خرائط جوجل
        بدون حذف أي مسار Skill قائم؛ يضيف نص التقييم/التعليق فقط.
        """
        platform = self._canonicalize_platform_name(
            ai_analysis.get("platform") or details.get("platform") or ""
        )
        action = normalize_text(ai_analysis.get("action") or "").lower()
        payload = {}

        # سكرين الهدف إن أمكن
        target_shot = None
        try:
            target_shot = await self._capture_target_context_screenshot(
                task_page,
                target_url,
                details,
            )
        except Exception as error:
            logger.warning("AI-assist target screenshot failed: %s", error)

        task_shot = (
            details.get("screenshot_path")
            or details.get("detail_screenshot_path")
        )

        description = " | ".join(
            str(v or "")
            for v in (
                details.get("title"),
                details.get("description"),
                details.get("info_for_work"),
                ai_analysis.get("summary"),
            )
            if v
        )

        # توليد نص تقييم/تعليق عبر AI
        text = ""
        generator = getattr(self.ai_brain, "generate_comment", None)
        if callable(generator):
            try:
                text = await generator(
                    task_description=(
                        "Generate a short natural review/rating text for maps/yandex.\n"
                        "Language: Russian. 2-4 sentences. No spam.\n"
                        f"{description[:4000]}"
                    ),
                    task_screenshot=task_shot,
                    target_screenshot=target_shot,
                    platform=platform,
                    language_hint="ru",
                )
                text = normalize_text(text)
            except Exception as error:
                logger.warning("AI review generation failed: %s", error)

        if not text:
            # fallback عبر مسار التعليق الموجود
            try:
                text = await self._generate_comment_via_ai(
                    details,
                    ai_analysis,
                    task_shot,
                    target_shot,
                )
            except Exception:
                text = "Хорошее место, рекомендую!"

        if not text:
            text = "Хорошее место, рекомендую!"

        # تقييم نجوم افتراضي لو المطلوب تقييم
        rating = 5
        try:
            import re as _re
            blob = description.lower()
            m = _re.search(r"([1-5])\s*(звезд|star|نجوم|نجمة)", blob)
            if m:
                rating = int(m.group(1))
        except Exception:
            rating = 5

        payload = {
            "comment_text": text,
            "text": text,
            "review_text": text,
            "rating": rating,
            "stars": rating,
            "task_screenshot": task_shot,
            "target_screenshot": target_shot,
            "ai_assisted": True,
            "ai_assist_platform": platform,
            "ai_assist_action": action,
        }
        details["generated_review"] = text
        details["generated_comment"] = text
        details["review_rating"] = rating
        details["ai_assisted_execution"] = True

        try:
            await self._send_alert(
                (
                    "🤖 تجهيز AI للتنفيذ (تقييم/خرائط/ياندكس):\n"
                    f"🌐 {platform} | 🎯 {action}\n"
                    f"⭐ {rating}\n"
                    f"📝 {text[:400]}\n"
                    f"🔗 {target_url}"
                ),
                "info",
                photo_path=target_shot or task_shot,
            )
        except Exception:
            pass

        return payload


    def _is_generic_platform_homepage(self, url: str) -> bool:
        """
        أي رابط صفحة منصة عامة بدون محتوى محدد → مرفوض.
        يشمل يوتيوب وإنستا وتيك توك وVK وX وماكس وروتاب وياندكس وجوجل وغيرها.
        """
        raw = self._clean_url(url or "").strip()
        if not raw:
            return True
        try:
            from urllib.parse import urlparse
            if "://" not in raw:
                raw = "https://" + raw
            p = urlparse(raw)
            host = (p.hostname or "").lower()
            if host.startswith("www."):
                host = host[4:]
            path = (p.path or "/").rstrip("/") or "/"
            query = (p.query or "").strip()
            # شيل trailing index
            if path.endswith("/index.html"):
                path = path[: -len("/index.html")] or "/"
        except Exception:
            return False

        # مضيفات منصات معروفة
        social_hosts = {
            "youtube.com", "m.youtube.com", "youtu.be", "music.youtube.com",
            "instagram.com", "www.instagram.com",
            "tiktok.com", "www.tiktok.com", "vm.tiktok.com",
            "vk.com", "vk.ru", "m.vk.com",
            "rutube.ru", "www.rutube.ru",
            "x.com", "twitter.com", "mobile.twitter.com",
            "facebook.com", "fb.com", "m.facebook.com",
            "max.ru", "web.max.ru",
            "t.me", "telegram.me", "telegram.org", "web.telegram.org",
            "yandex.ru", "ya.ru", "maps.yandex.ru", "dzen.ru",
            "google.com", "maps.google.com", "play.google.com",
            "reddit.com", "www.reddit.com",
            "linkedin.com", "www.linkedin.com",
            "pinterest.com", "www.pinterest.com",
            "twitch.tv", "www.twitch.tv",
            "discord.com", "discord.gg",
            "ok.ru", "www.ok.ru",
            "likee.video", "snapchat.com",
            "threads.net", "www.threads.net",
        }
        # تطابق host أو subdomain
        def host_match(h: str) -> bool:
            if h in social_hosts:
                return True
            for base in list(social_hosts):
                if h.endswith("." + base):
                    return True
            return False

        if not host_match(host):
            # مواقع عامة: لو path جذر فقط بدون query غالبًا مش مهمة محتوى
            if path in {"/", ""} and not query and host and "." in host:
                # لا نرفض أي موقع عشوائي — فقط الجذور الواضحة للمنصات أعلاه
                return False
            return False

        # مسارات محتوى حقيقية (لو موجودة → مش homepage)
        content_markers = (
            "/watch", "/shorts/", "/reel/", "/reels/", "/p/", "/tv/",
            "/video/", "/videos/", "/clip/", "/channel/", "/@", "/c/",
            "/user/", "/users/", "/id", "/wall", "/topic", "/product",
            "/playlist", "/status/", "/posts/", "/post/", "/story/",
            "/stories/", "/live/", "/room/", "/invite", "/joinchat",
            "/maps/place", "/maps?q=", "/maps/@",
        )
        path_q = path + ("?" + query if query else "")
        if any(m in path_q for m in content_markers):
            return False
        # يوتيوب: لازم watch أو shorts أو @channel
        if "youtube" in host or host == "youtu.be":
            if host == "youtu.be" and path not in {"/", ""}:
                return False  # youtu.be/VIDEO_ID
            if any(x in path for x in ("/watch", "/shorts/", "/channel/", "/@", "/playlist", "/clip")):
                return False
            return True
        # إنستا: لازم /p/ أو /reel/ أو username بعمق
        if "instagram" in host:
            if any(x in path for x in ("/p/", "/reel/", "/reels/", "/tv/", "/stories/")):
                return False
            parts = [x for x in path.split("/") if x]
            # /username فقط غالبًا بروفايل — نسمح به لو فيه username (اشتراك)
            if len(parts) == 1 and parts[0] not in {
                "accounts", "directory", "explore", "about", "legal", "developer"
            }:
                return False
            return True
        # تيك توك (يشمل vt.tiktok.com / vm.tiktok.com روابط مختصرة)
        if "tiktok" in host:
            if any(x in path for x in ("/@", "/video/", "/t/", "/photo/")):
                return False
            # روابط مختصرة: /ZSq15FbVc أو /xxxxx طول معقول = محتوى مش homepage
            parts = [x for x in path.split("/") if x]
            if parts and len(parts[0]) >= 5 and parts[0].lower() not in {
                "foryou", "following", "friends", "live", "shop", "search",
                "upload", "messages", "activity", "login", "signup",
            }:
                return False
            if host in {"vt.tiktok.com", "vm.tiktok.com"} and parts:
                return False
            return True
        # VK
        if host in {"vk.com", "vk.ru", "m.vk.com"} or host.endswith(".vk.com"):
            if path not in {"/", "/feed", "/login"} and path != "":
                return False
            return True
        # X/Twitter
        if host in {"x.com", "twitter.com", "mobile.twitter.com"}:
            if path not in {"/", "/home", "/explore", "/login", "/i"} and path != "":
                # /user/status/id محتوى
                return False
            return True
        # Telegram t.me/username محتوى
        if host in {"t.me", "telegram.me"}:
            parts = [x for x in path.split("/") if x]
            if parts and parts[0] not in {"share", "proxy", "socks", "addstickers"}:
                return False
            return True
        # باقي المنصات: الجذر فقط = عام
        if path in {"/", ""} and not query:
            return True
        if path in {"/feed", "/home", "/explore", "/login", "/signin", "/signup", "/register"}:
            return True
        return False

    def _is_blocked_unu_internal_url(self, url: str) -> bool:
        """روابط UNU داخلية مش مهام تنفيذ (إحالة / مسابقات شركاء)."""
        u = normalize_text(url).lower()
        if not u:
            return False
        blocked_parts = (
            "/users/change-ref/",
            "/partner/competitions/",
            "/users/change-ref",
            "/partner/competition",
            "unu.im/users/change-ref",
            "unu.im/partner/competitions",
        )
        return any(p in u for p in blocked_parts)

    def _collect_task_candidate_urls(self, details: dict, ai_analysis: dict | None = None) -> list:
        urls = []
        for source in (details, ai_analysis or {}):
            if not isinstance(source, dict):
                continue
            for key in ("target_urls", "links", "urls"):
                val = source.get(key)
                if isinstance(val, (list, tuple)):
                    urls.extend(str(x) for x in val if x)
                elif isinstance(val, str) and val:
                    urls.append(val)
            for key in ("target_url", "url", "link", "accept_url", "share_url"):
                if source.get(key):
                    urls.append(str(source.get(key)))
        # من النص
        blob = " ".join(
            str((details or {}).get(k) or "")
            for k in ("title", "description", "info_for_work", "proof", "raw_page_text")
        )
        for m in re.findall(r"https?://[^\s<>\"']+", blob):
            urls.append(m)
        # unique
        out = []
        seen = set()
        for u in urls:
            cu = self._clean_url(u)
            if cu and cu not in seen:
                seen.add(cu)
                out.append(cu)
        return out

    def _validate_target_url_policy(
        self,
        details: dict,
        ai_analysis: dict | None = None,
        target_url: str = "",
    ) -> tuple:
        """
        - رفض روابط UNU: change-ref / partner/competitions
        - رفض الصفحة الرئيسية العامة لأي منصة بدون محتوى
        """
        candidates = self._collect_task_candidate_urls(details, ai_analysis)
        if target_url:
            candidates = [self._clean_url(target_url)] + candidates

        # Check for specific content links (channels, posts, etc.)
        has_content_link = False
        for u in candidates:
            if not self._is_generic_platform_homepage(u) and not self._is_blocked_unu_internal_url(u):
                # Has a specific content URL
                has_content_link = True
                break

        for u in candidates:
            if self._is_blocked_unu_internal_url(u):
                return False, f"blocked_unu_internal:{u}"
            # Only reject homepage if NO specific content links exist
            if self._is_generic_platform_homepage(u) and not has_content_link:
                return False, f"generic_homepage:{u}"
        return True, "url_policy_ok"


    def _platform_is_execution_allowed(self, platform: str) -> bool:
        """هل المنصة ضمن قائمة التشغيل الحالية فقط؟"""
        p = normalize_text(platform).lower()
        aliases = globals().get("PLATFORM_CANONICAL_ALIASES") or {}
        p = aliases.get(p, p)
        if p == "x":
            p = "twitter"
        allowed = globals().get("ALLOWED_EXECUTION_PLATFORMS") or set()
        return p in allowed

    def _validate_execution_policy(
        self,
        details: dict,
        ai_analysis: dict,
    ) -> tuple:
        """
        سياسة تشغيل إضافية فوق الـ AI Gate:
        - تيليجرام قنوات/جروبات/خاص: مسموح التفاعل
        - تيليجرام بوتات: بدون ميني-آب ومهام داخلية
        """
        ok, reason = self._telegram_execution_allowed(details, ai_analysis)
        if not ok:
            return False, reason

        url_ok, url_reason = self._validate_target_url_policy(details, ai_analysis)
        if not url_ok:
            return False, url_reason

        return True, "policy_ok"

    def _validate_ai_gate(
        self,
        ai_analysis: dict,
        details: dict,
    ) -> tuple[bool, str]:
        """
        الـAI يقترح فقط.
        هذه الدالة هي الـGate النهائي قبل Skill.

        تتحقق من:
        - platform
        - action
        - proof
        - target
        - summary
        """

        if not isinstance(
            ai_analysis,
            dict,
        ):

            return (
                False,
                "ai_result_not_dict",
            )

        # روابط هدف محظورة (boost / homepage / unu internal)
        try:
            for _tu in self._task_target_urls(details) or []:
                _br = self._is_blocked_target_url(_tu)
                if _br:
                    return False, _br
            _t1 = str((details or {}).get("target_url") or "")
            if _t1:
                _br = self._is_blocked_target_url(_t1)
                if _br:
                    return False, _br
        except Exception:
            pass

        # حظر بوتات تيليجرام قبل أي تصنيف منصة
        try:
            if self._is_telegram_bot_task(details, ai_analysis):
                return False, "telegram_bot_blocked"
        except Exception:
            pass

        platform = normalize_text(
            ai_analysis.get(
                "platform",
                "",
            )
        ).lower()
        platform = self._canonicalize_platform_name(platform)
        ai_analysis["platform"] = platform

        action = normalize_text(
            ai_analysis.get(
                "action",
                "",
            )
        ).lower()

        proof = normalize_text(
            ai_analysis.get(
                "required_proof",
                "",
            )
        ).lower()

        summary = normalize_text(
            ai_analysis.get(
                "summary",
                "",
            )
        )

        # --------------------------------------------------
        # Platform
        # --------------------------------------------------

        if not self._is_execution_platform_allowed(platform):
            return (
                False,
                f"unsupported_platform:{platform}",
            )

        if platform not in (
            DEFAULT_AI_SUPPORTED_PLATFORMS
        ):

            return (
                False,
                f"unsupported_platform:{platform}",
            )

        # --------------------------------------------------
        # Action
        # --------------------------------------------------

        if action not in (
            DEFAULT_AI_SUPPORTED_ACTIONS
        ):

            return (
                False,
                f"unsupported_action:{action}",
            )

        # --------------------------------------------------
        # Proof
        # --------------------------------------------------

        if proof not in (
            DEFAULT_AI_SUPPORTED_PROOFS
        ):

            return (
                False,
                f"invalid_proof:{proof}",
            )

        # --------------------------------------------------
        # Target
        # --------------------------------------------------

        target_urls = (
            self._task_target_urls(
                details
            )
        )

        if not target_urls:

            return (
                False,
                "ai_gate_missing_target",
            )

        # --------------------------------------------------
        # Summary - generate default if missing
        # --------------------------------------------------

        if not summary:
            # Generate basic summary from available data
            platform = ai_analysis.get("platform", "unknown")
            action = ai_analysis.get("action", "unknown")
            summary = f"{action} on {platform}"
            ai_analysis["summary"] = summary

        return (
            True,
            "allow",
        )

    # ======================================================
    # Skill result compatibility
    # ======================================================

    def _is_non_retryable_skill_status(self, status: str) -> bool:
        """حالات فشل نهائية لا تستحق إعادة محاولة في نفس الدورة."""
        status = normalize_text(status).lower()
        blocked = {
            "login_required",
            "captcha",
            "challenge_or_block",
            "automation_block",
            "automation_detected",
            "region_block",
            "content_restricted",
            "ip_blocked",
            "http_404",
            "http_500",
            "http_502",
            "http_503",
            "http_504",
            "telegram_qr_or_phone_login",
            "tiktok_login_wall",
            "rate_limited",
            "unsupported_action",
            "platform_filter",
            "daily_limit",
        }
        if status in blocked:
            return True
        if status.startswith("http_40") or status.startswith("http_50"):
            return True
        return False

    def _should_auto_skip_blocked(self) -> bool:
        try:
            return bool(self._get_dashboard_setting("auto_skip_blocked", True))
        except Exception:
            return True

    @staticmethod
    def _normalize_skill_result(result):
        """توحيد نتائج SkillManager القديمة والجديدة بدون تغيير طريقة التشغيل."""
        if isinstance(result, tuple) and len(result) == 2:
            ok, data = result
            return bool(ok), data if isinstance(data, dict) else {}

        if isinstance(result, dict):
            return bool(result.get("success", result.get("ok", False))), result

        return bool(result), {}

    # ======================================================
    # Error classification
    # ======================================================

    def _classify_execution_error(
        self,
        error: Exception,
    ) -> str:
        """
        تصنيف الخطأ لتحديد:
        retry / backoff / skip / stop.
        """

        if isinstance(
            error,
            asyncio.CancelledError,
        ):
            raise error

        text = normalize_text(
            str(error)
        ).lower()

        error_type = (
            type(error).__name__.lower()
        )

        combined = (
            f"{error_type} {text}"
        )

        # Session = Stop
        if any(
            marker in combined
            for marker in SESSION_ERROR_MARKERS
        ):
            return "session"

        # 429 = Backoff
        if any(
            marker in combined
            for marker in RATE_LIMIT_MARKERS
        ):
            return "rate_limit"

        # Timeout = Retry
        if (
            isinstance(
                error,
                PlaywrightTimeoutError,
            )
            or any(
                marker in combined
                for marker in TIMEOUT_ERROR_MARKERS
            )
        ):
            return "timeout"

        # Network = Retry
        if any(
            marker in combined
            for marker in NETWORK_ERROR_MARKERS
        ):
            return "network"

        # Invalid / unsupported = Skip
        if any(
            marker in combined
            for marker in (
                "invalid task",
                "task not found",
                "not found",
                "unsupported",
                "unknown action",
                "unknown platform",
                "invalid target",
            )
        ):
            return "invalid"

        # باقي أخطاء الـSkill
        return "skill"

    async def _execution_backoff(
        self,
        attempt: int,
        error_type: str,
    ):
        """
        Backoff تدريجي للأخطاء القابلة لإعادة المحاولة.
        """

        delay = min(
            EXECUTION_RETRY_MAX_DELAY,
            EXECUTION_RETRY_BASE_DELAY
            * (
                2 ** attempt
            ),
        )

        # زيادة بسيطة للـ429.
        if error_type == "rate_limit":
            delay *= 2

        delay = min(
            EXECUTION_RETRY_MAX_DELAY,
            delay,
        )

        logger.warning(
            "⏳ Execution backoff: %.1fs | type=%s | attempt=%s",
            delay,
            error_type,
            attempt + 1,
        )

        await self._interruptible_sleep(
            delay
        )

    # ======================================================
    # Execute task (REPLACED)
    # ======================================================


    async def _capture_target_context_screenshot(
        self,
        page,
        target_url: str,
        details: dict,
    ) -> Optional[str]:
        """سكرين ثاني من الفيديو/المنشور المطلوب للتعليق عليه."""
        if not page or not target_url:
            return None
        try:
            await page.goto(
                target_url,
                wait_until="domcontentloaded",
                timeout=DETAIL_TIMEOUT,
            )
            await page.wait_for_timeout(1800)
            # محاولة إغلاق النوافذ الشائعة إن وُجدت على الـ skill
            try:
                if self.skills and hasattr(self.skills, "skills"):
                    pass
            except Exception:
                pass
            screenshot_dir = Path(APP.SCREENSHOTS_DIR)
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            path = screenshot_dir / (
                f"comment_target_{now_ts()}_{random.randint(1000, 9999)}.png"
            )
            await page.screenshot(path=str(path), full_page=False)
            details["comment_target_screenshot"] = str(path)
            return str(path)
        except Exception as error:
            logger.warning("Target context screenshot failed: %s", error)
            return None

    async def _generate_comment_via_ai(
        self,
        details: dict,
        ai_analysis: dict,
        task_screenshot: Optional[str],
        target_screenshot: Optional[str],
    ) -> str:
        """
        يبني نص التعليق عبر الذكاء الاصطناعي باستخدام:
        - وصف المهمة + الإثبات المطلوب
        - سكرين تفاصيل المهمة
        - سكرين الفيديو/المنشور الهدف
        """
        description = " | ".join(
            str(v or "")
            for v in (
                details.get("title"),
                details.get("description"),
                details.get("info_for_work"),
                ai_analysis.get("summary"),
            )
            if v
        )
        # 1) لو الـ AI brain فيه دالة توليد تعليق مخصّصة
        generator = getattr(self.ai_brain, "generate_comment", None)
        if callable(generator):
            try:
                text = await generator(
                    task_description=description[:5000],
                    task_screenshot=task_screenshot,
                    target_screenshot=target_screenshot,
                    platform=ai_analysis.get("platform", ""),
                    language_hint="ru",
                )
                text = normalize_text(text)
                if text:
                    return text
            except Exception as error:
                logger.warning("generate_comment failed: %s", error)

        # 2) fallback: تحليل نصي يطلب جملة تعليق قصيرة
        analyzer = getattr(self.ai_brain, "analyze_task", None)
        prompt = (
            "TASK TYPE: generate_social_comment_only\n"
            "Write ONE short natural comment in Russian for the content described.\n"
            "Do not include hashtags spam. 1-2 sentences max.\n"
            f"Task instructions:\n{description[:3000]}\n"
            "Return JSON only: {\"comment\": \"...\"}"
        )
        if callable(analyzer):
            try:
                result = await analyzer(text_description=prompt)
                if isinstance(result, dict):
                    for key in ("comment", "text", "summary"):
                        val = normalize_text(result.get(key, ""))
                        if val and key == "comment":
                            return val
                        if val and "comment" in val.lower():
                            continue
                    # لو رجع summary كتعليق
                    summary = normalize_text(result.get("summary", ""))
                    if summary and len(summary) < 280:
                        return summary
            except Exception as error:
                logger.warning("comment analyze fallback failed: %s", error)

        # 3) fallback آمن جدًا
        return "Отличный контент, спасибо!"

    async def _prepare_comment_payload(
        self,
        task_page,
        target_url: str,
        details: dict,
        ai_analysis: dict,
    ) -> dict:
        """
        مسار التعليقات:
        سكرين المهمة + سكرين الهدف → AI → نص التعليق.
        """
        task_shot = (
            details.get("screenshot_path")
            or details.get("detail_screenshot_path")
        )
        target_shot = await self._capture_target_context_screenshot(
            task_page,
            target_url,
            details,
        )
        comment_text = await self._generate_comment_via_ai(
            details,
            ai_analysis,
            task_shot,
            target_shot,
        )
        details["generated_comment"] = comment_text
        details["comment_text"] = comment_text
        details["comment_task_screenshot"] = task_shot
        details["comment_target_screenshot"] = target_shot
        try:
            await self._send_alert(
                (
                    "💬 تم توليد تعليق للمهمة:\n"
                    f"{comment_text}\n\n"
                    f"🔗 {target_url}"
                ),
                "info",
                photo_path=target_shot or task_shot,
            )
        except Exception:
            pass
        return {
            "comment_text": comment_text,
            "text": comment_text,
            "task_screenshot": task_shot,
            "target_screenshot": target_shot,
        }

    async def _try_execute_task(
        self,
        task_url: str,
        details: dict,
    ):
        if not isinstance(details, dict):
            logger.warning("Invalid task details: %s", task_url)
            return

        # نتيجة المهمة تُحفظ داخل details لتجنب اعتبار
        # المهمة ناجحة قبل اكتمال التنفيذ والتسليم.
        details["execution_success"] = False

        owner = str(details.get("unu_account_id") or "").strip()
        fleet = getattr(self, "fleet", None)
        if not owner or owner == "legacy" or not fleet or fleet.resolve_runtime(owner) is None:
            details["execution_status"] = "blocked_account_resolution"
            logger.warning("Execution blocked: unresolved task owner | %s", task_url)
            marker = getattr(self, "_mark_task_review", None)
            if callable(marker):
                await marker(task_url, "unresolved_account", account_id=owner or None)
            else:
                invalid = getattr(self, "_mark_task_invalid", None)
                if callable(invalid):
                    await invalid(task_url, "unresolved_account", alert=False)
            return

        # ==================================================
        # MODE GATE — لا حجز accept إلا في أوضاع التنفيذ
        # ==================================================
        mode_now = normalize_text(getattr(self, "mode", "") or "").lower()
        if mode_now not in {"execute", "test"}:
            logger.info(
                "⏭️ Skip execution (mode=%s): %s",
                mode_now,
                task_url,
            )
            details["execution_status"] = f"skipped_mode_{mode_now or 'unknown'}"
            return

        # ==================================================
        # PRE-EXECUTION FILTERS
        # ==================================================

        if (
            (
                details.get("title_tier") == "rejected"
                and str(details.get("title_tier_reason") or "").startswith("reject:")
            )
            or details.get("title_tier") != "accepted"
            or details.get("title_check_passed") is not True
            or details.get("detail_check_passed") is not True
            or details.get("decision_status") not in {"accepted", "ACCEPTED"}
        ):
            mark_review = getattr(self, "_mark_task_review", None)
            if callable(mark_review):
                await mark_review(task_url, "verification_gate_failed")
            else:
                await self._mark_task_invalid(
                    task_url,
                    "verification_gate_failed",
                    alert=False,
                )
            logger.warning("Execution blocked by verification gate: %s", task_url)
            return

        # --------------------------------------------------
        # Filters must happen BEFORE AI / Skill.
        # --------------------------------------------------

        allowed, reason = (
            self._passes_task_filters(
                task_url,
                details,
            )
        )

        # Check for AI platform tasks (need manual or special handling)
        task_text = " ".join([
            str(details.get("title", "") or ""),
            str(details.get("description", "") or ""),
        ]).lower()
        
        ai_platform_keywords = ["ai-платформ", "нейросет", "chatgpt", "claude", "gemini", "gpt-"]
        is_ai_platform = any(kw in task_text for kw in ai_platform_keywords)
        
        if is_ai_platform:
            logger.info("🤖 AI platform task detected: %s", task_url)
            await self._mark_task_invalid(
                task_url,
                "ai_platform_task:requires_external_ai",
                alert=False,
            )
            return

        # Crypto/payment tasks (scam/unsafe)
        crypto_keywords = [
            "usdt", "binance", "bitcoin", "btc ", "eth ", "crypto",
            "крипто", "бинанс", "биткоин", "кошелек",
            "send money", "отправить деньги", "trc20", "bep20", "erc20",
            "binance-pay", "криптовалют",
        ]
        is_crypto = any(kw in task_text for kw in crypto_keywords)
        # Also check URLs
        target_urls = self._task_target_urls(details) or []
        crypto_domains = ("binance.com", "coinbase.com", "kraken.com", "bybit.com", "okx.com")
        is_crypto_url = any(any(d in u.lower() for d in crypto_domains) for u in target_urls)
        
        if is_crypto or is_crypto_url:
            logger.info("💰 Crypto/payment task blocked: %s", task_url)
            await self._mark_task_invalid(
                task_url,
                "crypto_payment_blocked",
                alert=False,
            )
            return

        # Registration/bonus tasks on unknown sites
        registration_keywords = [
            "зарегистр", "регистрац", "бонус", "реферал",
            "sign up", "register", "signup", "referral",
            "создать аккаунт", "подтвердить почту",
        ]
        is_registration = any(kw in task_text for kw in registration_keywords)
        
        # Check if it's a known platform or unknown site
        known_domains = (
            "t.me", "telegram", "vk.com", "vk.ru", "instagram", "tiktok",
            "youtube", "youtu.be", "twitter", "x.com", "rutube", "max.ru",
            "avito.ru", "ozon.ru",
        )
        target_urls = self._task_target_urls(details) or []
        is_known_platform = any(any(d in u.lower() for d in known_domains) for u in target_urls)
        
        # Only block registration on suspicious/scam-like sites
        suspicious_domains = (
            "earn", "money", "cash", "bonus", "free", "win",
            "invest", "profit", "income",
        )
        is_suspicious = any(any(s in u.lower() for s in suspicious_domains) for u in target_urls)
        
        if is_registration and not is_known_platform and is_suspicious:
            logger.info("📝 Suspicious registration task blocked: %s", task_url)
            await self._mark_task_invalid(
                task_url,
                "suspicious_registration",
                alert=False,
            )
            return

        # Mobile app tasks (can't automate)
        mobile_keywords = [
            "приложени", "в приложении", "скачать приложение",
            "app store", "google play", "play market",
            "сбербанк", "сбер", "купер", "kuper",
            "мобильн", "на телефон", "android", "ios",
            "идентификац", "паспорт", "селфи",
        ]
        is_mobile_app = any(kw in task_text for kw in mobile_keywords)
        
        if is_mobile_app:
            logger.info("📱 Mobile app task blocked: %s", task_url)
            await self._mark_task_invalid(
                task_url,
                "mobile_app_task",
                alert=False,
            )
            return

        if not allowed:

            logger.info(
                "⏭️ Task filtered: %s | reason=%s",
                task_url,
                reason,
            )

            # daily_limit لا تُسجَّل invalid (هتتعالج لاحقًا)
            if reason not in (
                "daily_limit",
                "daily_limit_reached",
            ):
                await self._mark_task_invalid(
                    task_url,
                    reason or "filtered",
                    alert=False,
                )
            else:
                await self._send_alert(
                    "Daily limit pause | " + str(task_url),
                    "info",
                )
            return

        # ==================================================
        # REQUIRED DATA
        # ==================================================

        links = self._task_target_urls(
            details
        )

        if not links:
            # محاولة أخيرة: استخراج من صفحة المهمة مباشرة
            try:
                if self.page and task_url:
                    await self.page.goto(task_url, timeout=15000, wait_until="domcontentloaded")
                    await asyncio.sleep(2)
                    page_text = await self.page.content()
                    extra_urls = re.findall(r"https?://[^\s\)\]\"\'<>]+", page_text)
                    blocked = ("unu.im", "disk.yandex", "google.com", "ibb.co")
                    for url in extra_urls:
                        clean = self._clean_url(url)
                        if clean and clean.startswith("http") and not any(b in clean.lower() for b in blocked):
                            links.append(clean)
                    links = list(dict.fromkeys(links))
                    if links:
                        logger.info("Extracted %d URLs from task page: %s", len(links), task_url)
                        details["target_urls"] = links
            except Exception as e:
                logger.debug("Fallback URL extraction failed: %s", e)

        if not links:
            logger.warning("No valid target URLs: %s", task_url)
            await self._mark_task_invalid(task_url, "no_target_url", alert=False)
            return

        description = normalize_text(
            details.get(
                "description",
                "",
            )
        )

        screenshot_path = normalize_text(
            details.get(
                "screenshot_path",
                "",
            )
        )

        # يسمح بالتحليل من Screenshot حتى لو تعذر استخراج
        # نص الصفحة، مع إبقاء نص خام مساعد عند توفره.
        if not description and not screenshot_path:

            logger.warning(
                "No task description or screenshot: %s",
                task_url,
            )
            await self._mark_task_invalid(
                task_url,
                "no_description_or_screenshot",
                alert=False,
            )
            return

        if not description:
            description = (
                "حلل Screenshot المهمة بالكامل، واستخرج كل البيانات "
                "والتعليمات والإثبات المطلوب قبل اتخاذ القرار."
            )

        # ==================================================
        # DICTIONARY FIRST / AI FALLBACK
        # ==================================================
        # القاموس يبحث أولًا في النص المستخرج من share و +.
        # عند عدم وجود تطابق واضح فقط نرسل المهمة إلى AI.
        task_text = " ".join(
            str(details.get(key, "") or "")
            for key in (
                "title",
                "category",
                "task_type",
                "raw_page_text",
                "description",
                "info_for_work",
                "proof",
            )
        ).strip()

        dictionary_result = self.task_dictionary.find(
            task_text,
            details,
        )

        # لو القاموس رفض التنفيذ صراحة (بوت / boost / homepage) نسجّل السبب ونوقف
        if dictionary_result is not None and dictionary_result.get("executable") is False:
            reject = str(dictionary_result.get("reject_reason") or "dictionary_blocked")
            logger.warning(
                "🛑 Dictionary blocked task: %s | platform=%s action=%s reason=%s",
                task_url,
                dictionary_result.get("platform"),
                dictionary_result.get("action"),
                reject,
            )
            await self._mark_task_invalid(
                task_url,
                "dictionary:" + reject,
                alert=False,
            )
            return

        # نحافظ على نتيجة القاموس حتى لو فيه category من UNU.
        # القواعد عالية الأولوية (v8/v9/extra) أدق من نص التصنيف العام.
        # فقط لو القاموس ضعيف (confidence < 0.75) ومعاه category صريح نفضّل AI.
        explicit_unu_type = normalize_text(
            details.get("category") or details.get("task_type")
        )
        if (
            explicit_unu_type
            and dictionary_result
            and float(dictionary_result.get("confidence") or 0) < 0.75
            and not str(dictionary_result.get("rule_id", "")).startswith(
                ("category_", "v8_", "v9_", "extra_", "v6_", "v7_")
            )
        ):
            logger.info(
                "Dictionary low confidence with explicit UNU type → AI fallback | %s",
                task_url,
            )
            dictionary_result = None

        if dictionary_result is not None:
            ai_result = dictionary_result
            details["analysis_source"] = "dictionary"
            # ربط حقول القاموس بالمهمة (روابط متعددة / خطوات مركبة)
            if dictionary_result.get("target_urls"):
                details["target_urls"] = list(dictionary_result["target_urls"])
                if not details.get("target_url") and dictionary_result.get("target_url"):
                    details["target_url"] = dictionary_result["target_url"]
            if dictionary_result.get("targets"):
                details["targets"] = dictionary_result["targets"]
            if dictionary_result.get("actions_list"):
                details["actions_list"] = dictionary_result["actions_list"]
            if dictionary_result.get("steps"):
                details["steps"] = dictionary_result["steps"]
            if dictionary_result.get("repeat"):
                details["repeat"] = dictionary_result["repeat"]
            if dictionary_result.get("is_compound"):
                details["is_compound"] = True
            # حدّث قائمة الروابط من القاموس لو رجّع روابط أوضح
            dict_urls = [
                self._clean_url(u)
                for u in (dictionary_result.get("target_urls") or [])
                if u and "unu.im" not in str(u).lower()
            ]
            if dict_urls:
                # ادمج مع الروابط الموجودة، والقاموس أولوية
                merged = list(dict.fromkeys(dict_urls + list(links or [])))
                links = merged
                details["target_urls"] = merged
                details["target_url"] = merged[0]
            logger.info(
                "📚 Dictionary matched: %s | %s/%s conf=%.2f rule=%s urls=%s",
                task_url,
                dictionary_result.get("platform"),
                dictionary_result.get("action"),
                float(dictionary_result.get("confidence") or 0),
                dictionary_result.get("rule_id"),
                len(links or []),
            )
        else:
            details["analysis_source"] = "ai"
            logger.info(
                "🧠 No dictionary match; sending task to AI: %s",
                task_url,
            )
            try:
                # تقليل ضغط Gemini Vision (429): نمرّر السكرين فقط لو النص قصير/ضعيف
                _txt = str(task_text or description or "")
                _ss = details.get("screenshot_path")
                if len(_txt) >= 180:
                    _ss = None  # النص كافي للتصنيف بدون Vision
                try:
                    ai_result = await asyncio.wait_for(
                        self.ai_brain.analyze_task(
                            text_description=_txt,
                            screenshot_path=_ss,
                        ),
                        timeout=35,
                    )
                except asyncio.TimeoutError:
                    logger.error("⏱️ AI analyze_task timeout — task not accepted | %s", task_url)
                    await self._mark_task_review(task_url, "ai_unavailable:timeout")
                    return
            except asyncio.CancelledError:
                raise
            except Exception as error:
                error_type = self._classify_execution_error(error)
                logger.exception(
                    "AI analysis failed | type=%s",
                    error_type,
                )
                await self._send_alert(
                    (
                        "⚠️ فشل تحليل المهمة بالـAI:\n"
                        f"{task_url}\n"
                        f"النوع: {error_type}\n"
                        f"{str(error)[:300]}"
                    ),
                    "warning",
                )
                await self._mark_task_review(task_url, "ai_unavailable")
                return

        # ==================================================
        # NORMALIZE AI RESULT
        # ==================================================

        logger.info(
            "✅ AI/Dictionary result ready | task=%s platform=%s action=%s source=%s",
            task_url,
            (ai_result or {}).get("platform") if isinstance(ai_result, dict) else "?",
            (ai_result or {}).get("action") if isinstance(ai_result, dict) else "?",
            details.get("analysis_source"),
        )
        ai_analysis = (
            self._normalize_ai_result(
                ai_result,
                details,
            )
        )
        if (
            details.get("analysis_source") == "ai"
            and (
                str((ai_result or {}).get("source") or "") in {"rule_fallback", "ai_unavailable"}
                or str((ai_result or {}).get("analysis_status") or "") == "unavailable"
                or (ai_result or {}).get("executable") is False
            )
        ):
            await self._mark_task_review(task_url, "ai_unavailable")
            return
        details["ai_source"] = str((ai_result or {}).get("source") or "")
        details["analysis_status"] = str((ai_result or {}).get("analysis_status") or "available")
        canonicalize = getattr(self, "_canonicalize_platform_name", lambda value: value)
        expected_platform = canonicalize(str(details.get("title_platform") or "").lower())
        expected_action = str(details.get("title_action") or "").lower()
        actual_platform = canonicalize(str(ai_analysis.get("platform") or "").lower())
        actual_action = str(ai_analysis.get("action") or "").lower()
        from classification_utils import reconcile_classifications

        reconciliation = reconcile_classifications(
            {
                "platform": expected_platform,
                "action": expected_action,
            },
            {
                "platform": actual_platform,
                "action": actual_action,
            },
            canonicalize_platform=lambda value: str(value or "").strip().lower(),
        )
        if reconciliation["mismatch"]:
            logger.warning(
                "Title/analysis mismatch: %s | expected=%s/%s actual=%s/%s",
                task_url,
                expected_platform,
                expected_action,
                actual_platform,
                actual_action,
            )
            details["classification_mismatch"] = reconciliation["mismatch_fields"]
            details["mismatch_warning"] = reconciliation["warning"]
        try:
            blob_c = " ".join(
                str(details.get(k) or "")
                for k in ("title", "description", "info_for_work", "raw_page_text")
            )
            compounds = self._detect_compound_actions(blob_c)
            if compounds:
                details["compound_actions"] = compounds
                ai_analysis["compound_actions"] = compounds
                if "like" in compounds and str(ai_analysis.get("action") or "") == "subscribe":
                    details["needs_like_after_subscribe"] = True
                logger.info("Compound actions detected: %s | %s", compounds, task_url)
        except Exception as _ce:
            logger.debug("compound: %s", _ce)

        # ==================================================
        # AI FINAL GATE
        # ==================================================

        ai_allowed, ai_reason = (
            self._validate_ai_gate(
                ai_analysis,
                details,
            )
        )

        if not ai_allowed:

            logger.warning(
                "🛑 AI Gate rejected task: %s | reason=%s",
                task_url,
                ai_reason,
            )

            await self._mark_task_review(task_url, "ai_gate:" + str(ai_reason))
            return

        if (
            details.get("detail_check_passed") is not True
            or details.get("decision_status") == "needs_review"
            or details.get("analysis_status") == "unavailable"
            or details.get("ai_source") in {"ai_unavailable", "rule_fallback"}
            or (ai_result or {}).get("executable") is False
        ):
            await self._mark_task_review(task_url, "verification_gate_failed")
            logger.warning("Execution blocked after analysis gate: %s", task_url)
            return

        platform = ai_analysis[
            "platform"
        ]

        action = ai_analysis[
            "action"
        ]

        cat_blob = str(details.get("category") or "").lower()
        if any(k in cat_blob for k in ("регистрац", "идентификац", "оформление заявки", "паспорт")):
            action = "register"
            ai_analysis["action"] = "register"
            details["action"] = "register"

        forbidden, why = self._is_forbidden_task(details, action)
        if forbidden:
            logger.warning("🛑 Forbidden before accept: %s | %s", why, task_url)
            await self._mark_task_invalid(task_url, "forbidden:" + why, alert=False)
            return

        proof = ai_analysis[
            "required_proof"
        ]

        # ==================================================
        # EXECUTION POLICY (تيليجرام اشتراك فقط / بدون ميني-آب)
        # ==================================================
        policy_ok, policy_reason = self._validate_execution_policy(
            details,
            ai_analysis,
        )
        if not policy_ok:
            logger.warning(
                "🛑 Execution policy rejected: %s | %s",
                task_url,
                policy_reason,
            )
            async with self._state_lock:
                self.invalid.add(
                    self._normalize_task_url(task_url)
                )
            return

        # ==================================================
        # FINAL TARGET CHECK
        # ==================================================

        target_url = self._clean_url(
            links[0]
        )

        url_ok, url_reason = self._validate_target_url_policy(
            details, ai_analysis, target_url
        )
        if not url_ok:
            logger.warning("URL policy rejected: %s | %s", task_url, url_reason)
            async with self._state_lock:
                self.invalid.add(self._normalize_task_url(task_url))
            return

        if not target_url.startswith(
            (
                "http://",
                "https://",
            )
        ):

            logger.warning(
                "Invalid target URL: %s",
                target_url,
            )

            return

        # لا نفتح accept قبل التأكد البرمجي من وجود Skill قادرة على التنفيذ.
        # هذا الفحص مستقل عن رأي الـAI ولا يسمح بتحويل مهمة غير مدعومة إلى تنفيذ.
        # الرابط نفسه هو الحكم. القاموس لو سمّى المنصة غلط (بوكنج = تيليجرام) نرفض قبل الحجز.
        _allowed_hosts = (
            "youtube.com", "youtu.be", "tiktok.com", "instagram.com",
            "twitter.com", "x.com", "rutube.ru",
            "t.me", "telegram.me", "telegram.org",
            "wildberries.ru", "wb.ru", "vk.com", "vk.ru", "vk.me", "max.ru",
        )
        _bad_marks = (
            "booking.com", "букинг", "авито", "avito.ru", "avito.",
            "одноклассник", "ok.ru", "chrome.google", "расширени",
        )
        _target_blob = " ".join(str(u) for u in (links or [])).lower()
        _title_blob = " ".join(
            str(details.get(k) or "") for k in ("title", "category", "task_type")
        ).lower()
        _host_ok = any(h in _target_blob for h in _allowed_hosts)
        _marked_bad = any(w in _target_blob or w in _title_blob for w in _bad_marks)
        if (not _host_ok) or _marked_bad:
            logger.warning(
                "🛑 Target blocked before accept: host_ok=%s bad=%s | %s",
                _host_ok,
                _marked_bad,
                task_url,
            )
            async with self._state_lock:
                self.invalid.add(self._normalize_task_url(task_url))
            return

        _exec_ok = {
            "youtube", "tiktok", "instagram", "twitter", "x",
            "rutube", "telegram", "vk", "max",
        }
        if str(platform or "").strip().lower() not in _exec_ok:
            logger.warning(
                "🛑 Platform blocked before accept: %s/%s | %s",
                platform,
                action,
                task_url,
            )
            async with self._state_lock:
                self.invalid.add(self._normalize_task_url(task_url))
            return

        if not self.skills or not self.skills.supports_action(platform, action):
            logger.info(
                "⏭️ Task skipped before accept: no capable skill | platform=%s action=%s url=%s",
                platform,
                action,
                task_url,
            )
            async with self._state_lock:
                self.invalid.add(self._normalize_task_url(task_url))
            return

        # ==================================================
        # RE-CHECK DAILY LIMIT UNDER STATE LOCK
        # ==================================================
        #
        # مهم:
        # الفلتر الأول ممكن يمر،
        # لكن مهمة أخرى قد تكون أنهت الحد أثناء الانتظار.
        # لذلك نعيد التحقق قبل حجز التنفيذ.
        # ==================================================

        execution_key = (
            f"{self._normalize_task_url(task_url)}|"
            f"{platform}|"
            f"{action}|"
            f"{target_url}"
        )

        async with self._state_lock:

            self._reset_daily_counter_if_needed()

            if self._daily_limit_reached():

                logger.warning(
                    "Daily limit reached before execution: %s",
                    task_url,
                )

                return

            # ------------------------------------------------
            # Duplicate protection.
            # ------------------------------------------------

            if execution_key in self.history:

                logger.info(
                    "⏭️ Duplicate execution blocked: %s",
                    task_url,
                )

                return

            # نحجز المهمة قبل أي await خارجي.
            self.history.add(
                execution_key
            )

        # ==================================================
        # EXECUTION LOCK
        # ==================================================
        #
        # كل عملية تنفيذ فعلية واحدة فقط.
        # الفلترة وAI خارج الـlock.
        # التنفيذ + submit + counters داخله.
        # ==================================================

        # lock wait with timeout (prevent silent freeze)
        logger.info("waiting for execution lock: %s", task_url)
        try:
            await asyncio.wait_for(self._execution_lock.acquire(), timeout=120)
        except asyncio.TimeoutError:
            # متسرقش قفل مهمة لسه بتتنفّذ، ومتبعتش تنبيه كل شوية.
            logger.warning("execution lock busy, retry later: %s", task_url)
            self.history.discard(execution_key)
            return
        logger.info("execution lock acquired: %s", task_url)
        _lock_deadline = asyncio.get_event_loop().time() + 90
        try:

            # ------------------------------------------------
            # Double-check بعد الحصول على lock.
            # ------------------------------------------------

            async with self._state_lock:

                self._reset_daily_counter_if_needed()

                if self._daily_limit_reached():

                    logger.warning(
                        "Daily limit reached inside execution lock: %s",
                        task_url,
                    )

                    self.history.discard(
                        execution_key
                    )

                    return

            # ------------------------------------------------
            # HARD BOOKING GATE — لا حجز قبل تأكيد الرابط والمنصة
            # ------------------------------------------------
            gate_ok, gate_reason = self._hard_booking_gate(details, ai_analysis, links)
            if not gate_ok and details.get("already_accepted"):
                # مهمة محجوزة: متترفضش نهائي لو الرابط على منصة مسموحة
                allowed_hosts = ("t.me", "telegram.me", "vk.com", "tiktok.com", "instagram.com", "youtube.com", "youtu.be", "twitter.com", "x.com", "rutube.ru", "max.ru")
                joined = " ".join(str(u) for u in (links or [])).lower()
                if any(h in joined for h in allowed_hosts):
                    logger.info("📋 Works gate relaxed (%s): %s", gate_reason, task_url)
                    gate_ok = True
                    gate_reason = "works_relaxed"
            if not gate_ok:
                logger.warning("🛑 Hard booking gate: %s | %s", gate_reason, task_url)
                self.history.discard(execution_key)
                if gate_reason in {"no_real_target", "target_host_unknown"}:
                    logger.info("uncertain, postpone: %s", task_url)
                    return
                async with self._state_lock:
                    self.invalid.add(self._normalize_task_url(task_url))
                return

            # ------------------------------------------------
            # Accept task
            # ------------------------------------------------

            try:
                if details.get("already_accepted") or "/tasks/report/" in str(task_url):
                    accepted = True
                    self._active_task_url = details.get("report_url") or task_url
                    logger.info("📋 Works task already accepted, skip accept: %s", task_url)
                else:
                    accepted = (
                        await self._accept_task_in_unu(
                            details.get("accept_url") or task_url
                        )
                    )

            except asyncio.CancelledError:

                raise

            except Exception as error:

                error_type = (
                    self._classify_execution_error(
                        error
                    )
                )

                logger.exception(
                    "Accept task failed | type=%s",
                    error_type,
                )

                # Session error = stop.
                if error_type == "session":

                    self.running = False
                    self._shutdown_event.set()

                    await self._send_alert(
                        (
                            "🚨 Session انتهت أثناء قبول المهمة:\n"
                            f"{task_url}"
                        ),
                        "error",
                    )

                else:

                    await self._send_alert(
                        (
                            "⚠️ فشل قبول المهمة:\n"
                            f"{task_url}\n"
                            f"النوع: {error_type}"
                        ),
                        "warning",
                    )

                self.history.discard(
                    execution_key
                )

                return

            if not accepted:

                logger.warning(
                    "Could not accept task: %s",
                    task_url,
                )

                self.history.discard(
                    execution_key
                )

                return

            self._open_reserved_count = max(0, int(getattr(self, "_open_reserved_count", 0) or 0)) + 1

            # احفظ رابط صفحة UNU الفعلي بعد التحويل (report) للإثبات لاحقًا
            try:
                details["unu_proof_page_url"] = getattr(self, "_active_task_url", None) or (
                    details.get("accept_url") or task_url
                )
                if "/tasks/report/" in str(details["unu_proof_page_url"] or ""):
                    details["report_url"] = details["unu_proof_page_url"]
            except Exception:
                pass

            # accept فتح بنجاح، والصفحة محفوظة الآن للتنفيذ والإثبات.
            # صفحة UNU (_active_task_page) تفضل للإثبات فقط بعد accept→report.
            # التنفيذ على تاب جديد حتى لا يضيع فورم التقرير.
            unu_proof_page = self._active_task_page
            if not unu_proof_page or unu_proof_page.is_closed():
                logger.warning("Accept/report page missing for proof later: %s", task_url)
                await self._handle_accepted_task_abort(
                    task_url,
                    details,
                    reason="accept_page_missing",
                    refuse=True,
                    execution_key=execution_key,
                )
                return

            task_page = None
            try:
                task_page = await self.context.new_page()
                task_page.set_default_timeout(ACTION_TIMEOUT)
                task_page.set_default_navigation_timeout(ACTION_TIMEOUT)
                logger.info(
                    "🆕 تاب تنفيذ منفصل عن صفحة UNU | proof_url=%s",
                    self._active_task_url or accept_url if False else getattr(self, "_active_task_url", ""),
                )
            except Exception as exe_page_err:
                logger.error("Failed to open execution tab: %s", exe_page_err)
                await self._handle_accepted_task_abort(
                    task_url,
                    details,
                    reason="execution_page_open_failed",
                    refuse=True,
                    execution_key=execution_key,
                )
                return

            # تهيئة قصيرة قبل التنفيذ؛ الجاهزية الفعلية
            # يتم التحقق منها داخل الـSkill قبل الضغط.
            pre_execution_delay = random.uniform(1.0, 2.5)
            logger.info(
                "تهيئة التنفيذ، انتظار %.1f ثانية...",
                pre_execution_delay,
            )
            await asyncio.sleep(pre_execution_delay)
            execution_started_at = time.monotonic()

            # ==================================================
            # SKILL EXECUTION WITH ERROR CLASSIFICATION
            # ==================================================

            success = False

            for attempt in range(
                MAX_EXECUTION_RETRIES + 1
            ):

                try:

                    # ------------------------------------------------
                    # SkillManager availability
                    # ------------------------------------------------

                    if not self.skills:

                        raise RuntimeError(
                            "SkillManager is not initialized."
                        )

                    # ------------------------------------------------
                    # Execute
                    # ------------------------------------------------

                    # مسار التعليقات + التقييمات/ياندكس/خرائط جوجل عبر AI
                    skill_kwargs = {}
                    if self._needs_ai_assisted_execution(platform, action):
                        try:
                            ai_payload = await self._prepare_ai_assisted_execution(
                                task_page,
                                target_url,
                                details,
                                ai_analysis,
                            )
                            skill_kwargs.update(ai_payload)
                        except Exception as ai_assist_error:
                            logger.warning(
                                "AI-assisted prep failed: %s",
                                ai_assist_error,
                            )
                    elif action in {"comment", "review"}:
                        try:
                            comment_payload = await self._prepare_comment_payload(
                                task_page,
                                target_url,
                                details,
                                ai_analysis,
                            )
                            skill_kwargs.update(comment_payload)
                        except Exception as comment_error:
                            logger.warning(
                                "Comment prep failed: %s",
                                comment_error,
                            )
                    if skill_kwargs.get("comment_text"):
                        details["comment_text"] = skill_kwargs.get("comment_text")
                    elif skill_kwargs.get("text") and not details.get("comment_text"):
                        details["comment_text"] = skill_kwargs.get("text")

                    # Session Health Gate قبل التنفيذ
                    gate_ok, gate_status, gate_health = await self._pre_skill_session_gate(
                        task_page,
                        platform,
                        details,
                    )
                    if not gate_ok:
                        details["execution_status"] = gate_status
                        details["session_health"] = gate_health
                        if gate_status == "captcha":
                            ss_cap = None
                            try:
                                if task_page and not task_page.is_closed():
                                    ss_dir = Path("data/screenshots")
                                    ss_dir.mkdir(parents=True, exist_ok=True)
                                    ss_cap = str(ss_dir / f"captcha_{int(time.time())}.png")
                                    await task_page.screenshot(path=ss_cap)
                            except Exception:
                                ss_cap = None
                            cap_decision = await self._handle_captcha_pause(
                                task_url, platform, details, ss_cap
                            )
                            if cap_decision == "resumed":
                                gate_ok2, gate_status2, gate_health2 = await self._pre_skill_session_gate(
                                    task_page, platform, details
                                )
                                if not gate_ok2:
                                    success = False
                                    skill_data = {
                                        "status": gate_status2,
                                        "session_health": gate_health2,
                                    }
                                    details["skill_result"] = skill_data
                                    # يسقط لمسار الفشل بعد Accept
                                    break
                            else:
                                success = False
                                skill_data = {
                                    "status": "captcha",
                                    "session_health": gate_health,
                                    "captcha_decision": cap_decision,
                                }
                                details["skill_result"] = skill_data
                                break
                        else:
                            success = False
                            skill_data = {
                                "status": gate_status,
                                "session_health": gate_health,
                            }
                            details["skill_result"] = skill_data
                            break

                    # كل الروابط المستخرجة (مهام مركّبة: اشتراك+لايك / عدة منشورات)
                    try:
                        _all_targets = self._task_target_urls(details) or []
                        if target_url and target_url not in _all_targets:
                            _all_targets = [target_url] + list(_all_targets)
                        details["all_target_urls"] = list(dict.fromkeys(
                            [str(u) for u in _all_targets if u]
                        ))
                        skill_kwargs = dict(skill_kwargs or {})
                        skill_kwargs.setdefault("all_target_urls", details["all_target_urls"])
                        skill_kwargs.setdefault("target_urls", details["all_target_urls"])
                    except Exception:
                        details["all_target_urls"] = [target_url] if target_url else []

                    # ---- تنفيذ كل روابط الهدف بالترتيب (مهام 5 جروبات وغيرها) ----
                    targets_list = []
                    try:
                        targets_list = list(details.get("all_target_urls") or [])
                    except Exception:
                        targets_list = []
                    if not targets_list and target_url:
                        targets_list = [target_url]
                    # unique preserve order
                    _seen_t = set()
                    _uniq_t = []
                    for _u in targets_list:
                        _us = str(_u or "").strip()
                        if _us and _us not in _seen_t:
                            _seen_t.add(_us)
                            _uniq_t.append(_us)
                    targets_list = _uniq_t or ([target_url] if target_url else [])

                    success = False
                    skill_data = {}
                    multi_results = []
                    last_proof = None

                    for _ti, _turl in enumerate(targets_list):
                        logger.info(
                            "Multi-target execute %s/%s | %s | %s | %s",
                            _ti + 1,
                            len(targets_list),
                            platform,
                            action,
                            _turl,
                        )
                        try:
                            skill_result = await self.skills.route_task(
                                platform=platform,
                                action=action,
                                target_url=_turl,
                                page=task_page,
                                **skill_kwargs,
                            )
                        except Exception as _route_err:
                            logger.warning("route_task multi error: %s", _route_err)
                            skill_result = (False, {"status": "route_exception", "error": str(_route_err)[:300]})

                        _ok, _data = self._normalize_skill_result(skill_result)
                        if not isinstance(_data, dict):
                            _data = {}
                        _data["target_url"] = _turl
                        _data["target_index"] = _ti + 1
                        multi_results.append({"ok": _ok, "data": _data})
                        if _ok:
                            skill_data = _data
                            last_proof = (
                                _data.get("action_proof_path")
                                or _data.get("proof_path")
                                or _data.get("screenshot_path")
                                or last_proof
                            )
                        else:
                            logger.warning(
                                "Multi-target item failed %s/%s status=%s url=%s",
                                _ti + 1,
                                len(targets_list),
                                _data.get("status"),
                                _turl,
                            )
                        # تأخير بشري بين الروابط
                        if _ti + 1 < len(targets_list):
                            await asyncio.sleep(random.uniform(1.5, 3.5))

                    ok_count = sum(1 for r in multi_results if r.get("ok"))
                    total_count = len(targets_list) or len(multi_results) or 1
                    # قاعدة صارمة: كل الروابط المطلوبة لازم تنجح
                    # 5/5 SUCCESS | 4/5 PARTIAL_FAILURE | 0/5 FAILED
                    if total_count <= 1:
                        success = ok_count >= 1
                    else:
                        success = ok_count == total_count

                    if not success and multi_results:
                        # احتفظ بآخر data للتشخيص
                        skill_data = multi_results[-1].get("data") or skill_data or {}
                    if last_proof:
                        skill_data = dict(skill_data or {})
                        skill_data["screenshot_path"] = last_proof
                        skill_data["proof_path"] = last_proof
                        skill_data["action_proof_path"] = last_proof
                    skill_data = dict(skill_data or {})
                    skill_data["multi_target_results"] = multi_results
                    skill_data["multi_target_count"] = total_count
                    skill_data["multi_target_ok"] = ok_count
                    if total_count > 1 and ok_count > 0 and ok_count < total_count:
                        skill_data["status"] = "partial_failure"
                        skill_data["execution_status"] = "partial_failure"
                        details["execution_status"] = "partial_failure"
                        logger.warning(
                            "PARTIAL multi-target %s/%s — لا يُحسب نجاح كامل",
                            ok_count,
                            total_count,
                        )
                    elif total_count > 1 and ok_count == total_count:
                        skill_data["status"] = skill_data.get("status") or "done"
                        logger.info("ALL multi-target OK %s/%s", ok_count, total_count)
                    details["skill_result"] = skill_data
                    details["all_target_urls"] = targets_list

                    extra_actions = []
                    try:
                        extra_actions = [
                            a for a in (details.get("compound_actions") or [])
                            if a and a != action and a in {
                                "like", "subscribe", "comment", "share", "repost", "view",
                            }
                        ]
                    except Exception:
                        extra_actions = []
                    if success and extra_actions and task_page and not task_page.is_closed():
                        for extra in extra_actions:
                            try:
                                if self.skills and not self.skills.supports_action(platform, extra):
                                    logger.info("compound skip unsupported %s/%s", platform, extra)
                                    continue
                            except Exception:
                                pass
                            for _turl in targets_list:
                                try:
                                    extra_kwargs = dict(skill_kwargs or {})
                                    if extra in {"comment", "review"} and not extra_kwargs.get("comment_text"):
                                        extra_kwargs["comment_text"] = details.get("comment_text") or "Отлично!"
                                    _ok_e, _data_e = self._normalize_skill_result(
                                        await self.skills.route_task(
                                            platform=platform,
                                            action=extra,
                                            target_url=_turl,
                                            page=task_page,
                                            **{k: v for k, v in extra_kwargs.items() if k not in {"all_target_urls", "target_urls"}},
                                        )
                                    )
                                    logger.info("compound %s -> %s | %s", extra, _ok_e, _turl)
                                    if isinstance(_data_e, dict) and _data_e.get("comment_text"):
                                        details["comment_text"] = _data_e.get("comment_text")
                                except Exception as _ex:
                                    logger.warning("compound extra failed %s: %s", extra, _ex)

                    if task_page and not task_page.is_closed():
                        has_shot = bool(
                            skill_data.get("action_proof_path")
                            or skill_data.get("proof_path")
                            or skill_data.get("screenshot_path")
                        )
                        if not has_shot:
                            try:
                                shot_dir = Path(APP.SCREENSHOTS_DIR)
                                shot_dir.mkdir(parents=True, exist_ok=True)
                                shot = shot_dir / f"proof_{now_ts()}_{random.randint(1000, 9999)}.png"
                                await task_page.screenshot(path=str(shot), full_page=False)
                                skill_data["screenshot_path"] = str(shot)
                                skill_data["proof_path"] = str(shot)
                                details["proof_screenshot_path"] = str(shot)
                                logger.info("proof screenshot before tab close: %s", shot)
                            except Exception as shot_err:
                                logger.warning("proof screenshot before close failed: %s", shot_err)

                    # أغلق تاب التنفيذ فقط — صفحة UNU (_active_task_page) تفضل للتقرير
                    try:
                        if task_page and (not self._active_task_page or task_page is not self._active_task_page):
                            if not task_page.is_closed():
                                await task_page.close()
                            logger.info("🔒 أُغلق تاب التنفيذ؛ صفحة UNU للإثبات ما زالت مفتوحة: %s",
                                        getattr(self, "_active_task_url", ""))
                    except Exception as _close_exe:
                        logger.debug("execution tab close: %s", _close_exe)

                    # استخدم إثبات الـSkill نفسها إن توفر، ولا تستبدله
                    # بصورة عامة من صفحة UNU.
                    skill_proof = (
                        skill_data.get("action_proof_path")
                        or skill_data.get("proof_path")
                        or skill_data.get("screenshot_path")
                    )
                    if skill_proof and Path(skill_proof).exists():
                        details["proof_screenshot_path"] = skill_proof

                    details["execution_duration"] = round(
                        time.monotonic() - execution_started_at,
                        2,
                    )

                    # نجاح صريح بعد نتيجة الـSkill.
                    if success:

                        break

                    # False من الـSkill:
                    # لا نعتبره Exception.
                    logger.warning(
                        "Skill returned False: "
                        "task=%s attempt=%s",
                        task_url,
                        attempt + 1,
                    )

                    # لا نعمل retry تلقائيًا على False
                    # لأن الـSkill نفسها قالت إن التنفيذ لم ينجح.
                    break

                except asyncio.CancelledError:

                    raise

                except Exception as error:

                    error_type = (
                        self._classify_execution_error(
                            error
                        )
                    )

                    logger.exception(
                        (
                            "Skill execution failed | "
                            "type=%s | attempt=%s/%s"
                        ),
                        error_type,
                        attempt + 1,
                        MAX_EXECUTION_RETRIES + 1,
                    )

                    # ------------------------------------------------
                    # Session Error → STOP
                    # ------------------------------------------------

                    if error_type == "session":

                        self.running = False
                        self._shutdown_event.set()

                        await self._send_alert(
                            (
                                "🚨 Session انتهت أثناء التنفيذ:\n"
                                f"{task_url}"
                            ),
                            "error",
                        )

                        self.history.discard(
                            execution_key
                        )

                        return

                    # ------------------------------------------------
                    # Invalid Task → SKIP
                    # ------------------------------------------------

                    if error_type == "invalid":

                        logger.warning(
                            "⏭️ Invalid task skipped: %s",
                            task_url,
                        )

                        async with self._state_lock:

                            self.invalid.add(
                                self._normalize_task_url(
                                    task_url
                                )
                            )

                        self.history.discard(
                            execution_key
                        )

                        return

                    # ------------------------------------------------
                    # Retryable errors
                    # ------------------------------------------------

                    if error_type in (
                        "network",
                        "timeout",
                        "rate_limit",
                    ):

                        if attempt < MAX_EXECUTION_RETRIES:

                            await self._execution_backoff(
                                attempt,
                                error_type,
                            )

                            continue

                    # ------------------------------------------------
                    # Skill error / exhausted retries
                    # ------------------------------------------------

                    await self._send_alert(
                        (
                            "🚨 فشل تنفيذ المهمة:\n"
                            f"{task_url}\n"
                            f"النوع: {error_type}\n"
                            f"المحاولة: {attempt + 1}"
                        ),
                        "error",
                    )

                    success = False
                    break

            # ==================================================
            # SKILL RESULT CHECK
            # ==================================================

            if not success:

                logger.warning(
                    "❌ Task execution did not succeed: %s",
                    task_url,
                )
                # ============================================================
                # بعد accept + فشل المهارة:
                # - نبعت مساعدة يدوية دايمًا (من غير رفض أوتوماتيك)
                # - الرفض على UNU يحصل فقط لو دوست «تخطي»
                # - timeout → تنبيه تاني والمهمة تفضل معلّقة (من غير refuse)
                # ============================================================
                skill_data = details.get("skill_result")
                if not isinstance(skill_data, dict):
                    skill_data = {}
                fail_status = normalize_text(
                    skill_data.get("status")
                    or details.get("execution_status")
                    or "failed"
                ).lower() or "failed"
                details["execution_status"] = fail_status
                skill_data["status"] = skill_data.get("status") or fail_status
                details["skill_result"] = skill_data

                plat_for_assist = self._canonicalize_platform_name(
                    str((details or {}).get("platform") or platform or "")
                ) or "unknown"

                policy_block = any(
                    x in fail_status
                    for x in (
                        "telegram_bot_blocked",
                        "telegram_boost_blocked",
                        "telegram_miniapp_blocked",
                        "platform_filter",
                        "generic_homepage",
                        "unsupported_platform",
                    )
                )

                # بعد accept: المساعدة أولاً دائمًا (حتى لو المنصة unknown)
                if not policy_block:
                    try:
                        target = ""
                        try:
                            links = self._task_target_urls(details) or []
                            details["all_target_urls"] = links
                            target = links[0] if links else ""
                        except Exception:
                            target = ""
                        if not target:
                            target = str(
                                details.get("target_url")
                                or ""
                            )

                        self._awaiting_human_decision = True
                        logger.info(
                            "🆘 طلب مساعدة بعد accept (بدون رفض تلقائي) | %s | %s/%s | %s",
                            task_url,
                            plat_for_assist,
                            details.get("action") or action,
                            fail_status,
                        )
                        assist = await self._request_manual_assist(
                            task_url=task_url,
                            platform=str(
                                details.get("platform")
                                or platform
                                or plat_for_assist
                                or ""
                            ),
                            action=str(details.get("action") or action or ""),
                            target_url=str(target or ""),
                            details=details,
                            reason=fail_status or "skill_failed",
                            timeout_sec=1800.0,  # 30 دقيقة
                        )
                        assist_status = normalize_text(
                            (assist or {}).get("status") or ""
                        ).lower()

                        if assist.get("ok") and assist.get("screenshot_path"):
                            details["proof_screenshot_path"] = assist["screenshot_path"]
                            details["skill_result"] = {
                                **skill_data,
                                "status": "manual_assist_done",
                                "screenshot_path": assist["screenshot_path"],
                                "proof_path": assist["screenshot_path"],
                                "proof_source": "manual_user",
                            }
                            success = True
                            logger.info(
                                "✅ مساعدة يدوية — نكمّل الإثبات: %s",
                                assist.get("screenshot_path"),
                            )
                        elif assist_status == "skipped":
                            # رفض فقط عند زر تخطّي الصريح (status=skipped)
                            logger.info("مستخدم اختار تخطّي — رفض على UNU: %s", task_url)
                            await self._handle_accepted_task_abort(
                                task_url,
                                details,
                                reason="user_skip_assist",
                                refuse=True,
                                execution_key=execution_key,
                            )
                            return
                        else:
                            # timeout أو فشل المساعدة — لا نرفض؛ المهمة تفضل معلّقة
                            logger.warning(
                                "مساعدة بدون رد/timeout — بدون رفض UNU | %s | %s",
                                task_url,
                                assist,
                            )
                            try:
                                await self._send_alert(
                                    (
                                        "⏳ المهمة لسه معلّقة بعد فشل التنفيذ — مستنيك تساعد\n"
                                        f"{task_url}\n"
                                        f"السبب: {fail_status}\n"
                                        f"المنصة: {plat_for_assist} | {details.get('action') or action}\n"
                                        f"الهدف: {target or '—'}\n"
                                        "ارفضها يدويًا من UNU لو مش هتعملها، "
                                        "أو ابعت سكرين في الشات لو ظهرت رسالة المساعدة."
                                    ),
                                    "warning",
                                )
                            except Exception:
                                pass
                            # لا refuse — تحرير القفل في finally
                            return
                    except Exception as assist_error:
                        logger.exception(
                            "assist crash — بدون رفض تلقائي: %s",
                            assist_error,
                        )
                        try:
                            await self._send_alert(
                                (
                                    "🆘 فشل مسار المساعدة — المهمة معلّقة، راجع يدويًا\n"
                                    f"{task_url}\n"
                                    f"{assist_error}"
                                ),
                                "warning",
                            )
                        except Exception:
                            pass
                        return
                else:
                    # حظر سياسة فقط → رفض
                    await self._handle_accepted_task_abort(
                        task_url,
                        details,
                        reason=fail_status or "policy_block",
                        refuse=True,
                        execution_key=execution_key,
                    )
                    return

                if not success:
                    return

            # ==================================================
            # PROOF SCREENSHOT AFTER EXECUTION
            # ==================================================
            # Screenshot التفاصيل السابقة يثبت شكل المهمة فقط.
            # نلتقط Screenshot جديدًا بعد نجاح الـSkill ليكون
            # هو الإثبات الفعلي المرفق مع التقرير.
            proof_screenshot_path = details.get("proof_screenshot_path")

            # لا نستبدل Screenshot الصادرة من الـ Skill بصورة عامة من صفحة UNU.
            # نستخدم رابط الهدف نفسه كـfallback إذا لم تُرجع المهارة إثباتاً خاصاً بها.
            if not proof_screenshot_path:
                try:
                    if task_page and not task_page.is_closed() and target_url:
                        # بعد الفعل، نعرض الرابط الذي تم تنفيذ المهمة عليه
                        # قبل التقاط الإثبات؛ لا نأخذ Screenshot من صفحة UNU.
                        await task_page.goto(
                            target_url,
                            timeout=ACTION_TIMEOUT,
                            wait_until="domcontentloaded",
                        )
                        await task_page.wait_for_timeout(1800)
                    screenshot_dir = Path(APP.SCREENSHOTS_DIR)
                    screenshot_dir.mkdir(parents=True, exist_ok=True)
                    proof_screenshot_path = screenshot_dir / (
                        f"proof_{now_ts()}_{random.randint(1000, 9999)}.png"
                    )
                    if task_page and not task_page.is_closed():
                        await task_page.screenshot(
                            path=str(proof_screenshot_path),
                            full_page=True,
                        )
                        details["proof_screenshot_path"] = str(
                            proof_screenshot_path
                        )
                        logger.info(
                            "✅ Fallback proof screenshot captured: %s",
                            proof_screenshot_path,
                        )
                except Exception as screenshot_error:
                    logger.warning(
                        "Proof screenshot capture failed: %s",
                        screenshot_error,
                    )

            if not proof_screenshot_path or not Path(str(proof_screenshot_path)).exists():
                # المهمة اتحجزت ومفيش سكرين — اطلب مساعدة منك بدل الرفض الصامت
                details["execution_status"] = "proof_missing"
                logger.warning(
                    "proof_missing after accept — requesting manual assist: %s",
                    task_url,
                )
                try:
                    _links = self._task_target_urls(details) or []
                    _target = target_url or (_links[0] if _links else "")
                except Exception:
                    _target = target_url or ""
                self._awaiting_human_decision = True
                assist = await self._request_manual_assist(
                    task_url=task_url,
                    platform=str(
                        (details.get("platform") if isinstance(details, dict) else None)
                        or platform
                        or ""
                    ),
                    action=str(
                        (details.get("action") if isinstance(details, dict) else None)
                        or action
                        or ""
                    ),
                    target_url=str(_target or ""),
                    details=details,
                    reason="proof_missing",
                    timeout_sec=600.0,
                )
                if assist.get("ok") and assist.get("screenshot_path"):
                    proof_screenshot_path = assist["screenshot_path"]
                    details["proof_screenshot_path"] = str(proof_screenshot_path)
                    details["execution_status"] = "assisted_proof"
                    details["manual_assist"] = assist
                    logger.info(
                        "Manual assist provided proof screenshot: %s",
                        proof_screenshot_path,
                    )
                else:
                    # تخطّي أو انتهاء الوقت → رفض على UNU
                    logger.error(
                        "proof_missing — no assist screenshot, refusing: %s",
                        task_url,
                    )
                    await self._handle_accepted_task_abort(
                        task_url,
                        details,
                        reason="proof_missing_no_assist",
                        refuse=True,
                        execution_key=execution_key,
                    )
                    try:
                        if self._active_task_page and not self._active_task_page.is_closed():
                            await self._refuse_task_on_unu(
                                details.get("accept_url") or task_url,
                                details,
                            )
                    except Exception as _ref_err:
                        logger.warning("extra refuse after proof_missing: %s", _ref_err)
                    return

            # ==================================================
            # AI PROOF CHECK (استشاري فقط — لا يمنع مراجعتك ولا يرسل لـ UNU)
            # ==================================================
            # الذكاء يقيّم السكرين ويبلّغك فقط.
            # القرار النهائي عندك: نعم / لا / تعديل.
            # الإرسال إلى UNU يحدث فقط بعد موافقتك الصريحة.
            # مراجعة AI للإثبات معطّلة — نمرّر مباشرة لموافقتك البشرية
            ai_verified, ai_verification_status = await self._verify_proof_with_ai(
                proof_screenshot_path,
                ai_analysis,
                details,
            )
            details["ai_proof_verification"] = ai_verification_status
            details["ai_proof_verified"] = True
            if False and not ai_verified:
                try:
                    await self._send_alert(
                        (
                            "ℹ️ رأي الذكاء الاصطناعي في الإثبات (استشاري):\n"
                            f"{task_url}\n"
                            f"التقييم: {ai_verification_status}\n"
                            "لن يُرسل لـ UNU إلا بعد موافقتك."
                        ),
                        "warning",
                        photo_path=proof_screenshot_path,
                    )
                except Exception:
                    pass
            else:
                logger.info(
                    "AI proof advisory: verified for %s",
                    task_url,
                )

            # ==================================================
            # HUMAN PROOF APPROVAL (إجباري قبل UNU)
            # القفل يبقى ممسوك عمدًا: مفيش مهمة تانية تتأكد/تتنفّذ
            # لحد ما ترد نعم/لا/تعديل — عشان السكرين والإثبات ميتلخبطوش.
            # ==================================================
            # Release lock so other tasks can continue
            details["execution_lock_released_for_approval"] = True
            try:
                self._execution_lock.release()
            except RuntimeError:
                pass
            self._awaiting_human_decision = False  # Don't block other tasks
            logger.info(
                "📋 إثبات جاهز للمراجعة (المهام التانية مستمرة): %s",
                task_url,
            )

            # ==================================================
            # HUMAN PROOF APPROVAL (إجباري قبل UNU)
            # ==================================================
            details["ai_analysis"] = ai_analysis
            built_proof_text = self._build_proof_text(
                ai_analysis,
                details,
            )
            if built_proof_text:
                details["proof_text"] = built_proof_text
            elif not details.get("proof_missing"):
                details["proof_text"] = (
                    self._proof_account_username(
                        str((details or {}).get("platform") or ""), details or {}
                    )
                    or getattr(BOT_CONFIG, "TG_USERNAME", "Mostafa33531")
                )
            else:
                details["proof_text"] = ""
                await self._send_alert(
                    (
                        "⚠️ متطلبات الإثبات غير قابلة للتنفيذ تلقائيًا:\n"
                        f"{task_url}\n"
                        f"المطلوب: {details.get('proof_missing')}"
                    ),
                    "warning",
                )
                await self._handle_accepted_task_abort(
                    task_url,
                    details,
                    reason="missing_or_unsupported_proof_requirement",
                    refuse=True,
                    execution_key=execution_key,
                )
                return

            # تقييم جودة السكرين قبل المراجعة (لا يمنع المسار بالكامل إلا لو باين login/QR)
            quality = await self._score_proof_screenshot_quality_v2(
                proof_screenshot_path,
                details,
            )
            details["proof_quality"] = quality
            if not quality.get("ok"):
                await self._send_alert(
                    (
                        "⚠️ جودة الإثبات ضعيفة — راجع قبل الموافقة:\n"
                        f"{task_url}\n"
                        f"status={quality.get('status')}\n"
                        f"reasons={quality.get('reasons')}"
                    ),
                    "warning",
                    photo_path=proof_screenshot_path,
                )

            # إعداد الداشبورد: لو require_proof_approval=False → إرسال مباشر
            if not self._should_require_proof_approval():
                details["approval_status"] = "auto_approved"
                details["approval_decision"] = "approve"
                details["approved_proof_text"] = details.get("proof_text") or self._proof_account_username(str(details.get("platform") or ""), details) or getattr(BOT_CONFIG, "TG_USERNAME", "Mostafa33531")
                approved = True
                logger.info("Proof approval off — submitting directly | %s", task_url)
            else:
                # لا يتم إرسال الإثبات إلى UNU قبل موافقة Admin — أبدًا.
                approved = await self._request_proof_approval(
                    task_url=task_url,
                    platform=platform,
                    action=action,
                    details=details,
                    screenshot_path=proof_screenshot_path,
                )

            if not approved:
                decision = normalize_text(
                    details.get("approval_decision") or "timeout"
                ).lower()

                if decision == "reject":
                    details["approval_status"] = "rejected_by_admin"
                    details["execution_status"] = "refused_on_unu"
                    refused = await self._refuse_task_on_unu(
                        task_url,
                        details,
                    )
                    await self._send_alert(
                        (
                            "❌ تم رفض الإثبات — جاري/تم رفض المهمة على UNU:\n"
                            f"{task_url}\n"
                            f"رفض UNU: {'نعم' if refused else 'فشل الضغط تلقائيًا، راجع الصفحة'}"
                        ),
                        "warning",
                    )
                    async with self._state_lock:
                        self.invalid.add(self._normalize_task_url(task_url))
                    return

                if decision == "manual":
                    details["approval_status"] = "manual_by_admin"
                    details["execution_status"] = "left_for_manual"
                    # تُترك المهمة معلّقة على UNU (مأخوذة في العمل) بدون تقرير
                    await self._send_alert(
                        (
                            "🖐️ هتعملها أنت — المهمة متساببة معلّقة على UNU:\n"
                            f"{task_url}\n"
                            "البوت هيكمل المهمة اللي بعدها."
                        ),
                        "info",
                    )
                    # لا نضيفها invalid عشان متتكررش كفحص فاشل؛ نضعها في history كمعالجة
                    async with self._state_lock:
                        self.history.add(self._normalize_task_url(task_url))
                    return

                details["approval_status"] = "rejected_or_timeout"
                details["execution_status"] = "proof_pending"
                await self._send_alert(
                    (
                        "⏸️ تم إيقاف تسليم الإثبات (انتهت المهلة أو لم تتم الموافقة):\n"
                        f"{task_url}"
                    ),
                    "warning",
                )
                return

            details["approval_status"] = "approved"

            # ==================================================
            # PROOF SUBMISSION
            # ==================================================

            submitted = False

            for attempt in range(
                MAX_EXECUTION_RETRIES + 1
            ):

                try:

                    submitted = (
                        await self._submit_proof(
                            task_url,
                            ai_analysis,
                            details,
                        )
                    )

                    if submitted:
                        break

                    logger.warning(
                        (
                            "Proof submission returned False: "
                            "task=%s attempt=%s"
                        ),
                        task_url,
                        attempt + 1,
                    )

                    # False = الموقع رفض/لم يؤكد.
                    # نعطي محاولة أخرى فقط.
                    if attempt < MAX_EXECUTION_RETRIES:

                        await self._execution_backoff(
                            attempt,
                            "verification",
                        )

                except asyncio.CancelledError:

                    raise

                except Exception as error:

                    error_type = (
                        self._classify_execution_error(
                            error
                        )
                    )

                    logger.exception(
                        (
                            "Proof submission failed | "
                            "type=%s | attempt=%s/%s"
                        ),
                        error_type,
                        attempt + 1,
                        MAX_EXECUTION_RETRIES + 1,
                    )

                    if error_type == "session":

                        self.running = False
                        self._shutdown_event.set()

                        await self._send_alert(
                            (
                                "🚨 Session انتهت أثناء تسليم الإثبات:\n"
                                f"{task_url}"
                            ),
                            "error",
                        )

                        self.history.discard(
                            execution_key
                        )

                        return

                    if (
                        error_type in (
                            "network",
                            "timeout",
                            "rate_limit",
                        )
                        and attempt
                        < MAX_EXECUTION_RETRIES
                    ):

                        await self._execution_backoff(
                            attempt,
                            error_type,
                        )

                        continue

                    break

            # ==================================================
            # PROOF / VERIFICATION FAILURE
            # ==================================================

            if not submitted:

                details["submission_status"] = "failed"
                details["execution_status"] = "proof_pending"
                logger.warning(
                    "⚠️ Execution succeeded but proof verification failed: %s",
                    task_url,
                )

                await self._send_alert(
                    (
                        "⚠️ تم تنفيذ المهمة "
                        "لكن فشل التحقق من تسليم الإثبات:\n"
                        f"{task_url}\n"
                        "الحالة: REVIEW"
                    ),
                    "warning",
                )

                # لا نزيد counters.
                # ولا نعلن SUCCESS.
                return

            # ==================================================
            # SUCCESS + ATOMIC STATE UPDATE
            # ==================================================

            details["submission_status"] = "verified"
            details["execution_status"] = "verified"
            try:
                await self._persist_storage_state()
            except Exception:
                pass
            details["verified_at"] = datetime.now().isoformat()

            price = safe_float(
                details.get(
                    "price",
                    0,
                )
            )

            async with self._state_lock:

                self._reset_daily_counter_if_needed()

                # Double protection قبل زيادة العدادات.
                if (
                    self.daily_tasks_done
                    >= self.max_tasks_per_day
                ):

                    logger.warning(
                        (
                            "Daily limit reached before "
                            "counter commit: %s"
                        ),
                        task_url,
                    )

                    return

                self.tasks_done += 1
                self.daily_tasks_done += 1

                self.earnings += price
                self.daily_earnings += price

                # نخلي الرابط الأساسي معروف كمنفذ.
                self.history.add(
                    self._normalize_task_url(
                        task_url
                    )
                )

                # ونحتفظ بمفتاح التنفيذ.
                self.history.add(
                    execution_key
                )

            # ==================================================
            # FINAL SUCCESS NOTIFICATION
            # ==================================================

            # لا تُعتبر المهمة مكتملة إلا بعد نجاح التنفيذ
            # وتسليم الإثبات والتحقق من نتيجة Отправить.
            details["execution_success"] = True

            await self._send_alert(
                (
                    "✅💰 تم تنفيذ وتسليم المهمة بنجاح!\n\n"
                    f"💰 السعر: {price}\n"
                    f"🌐 المنصة: {platform}\n"
                    f"🎯 العملية: {action}\n"
                    f"📎 الإثبات: {proof}\n"
                    f"📊 اليوم: "
                    f"{self.daily_tasks_done}/"
                    f"{self.max_tasks_per_day}\n"
                    f"🌐 {task_url}"
                ),
                "info",
            )

            # الآن فقط انتهت دورة المهمة كاملة: تنفيذ + إثبات + تسليم.
            if self._active_task_page:
                try:
                    if not self._active_task_page.is_closed():
                        await self._active_task_page.close()
                except Exception as error:
                    logger.debug("Task accept page close error: %s", error)
                finally:
                    self._active_task_page = None
                    self._active_task_url = None

    # ======================================================
    # Accept task
    # ======================================================

        finally:
            self._awaiting_human_decision = False
            if not (isinstance(details, dict) and details.get("execution_lock_released_for_approval")):
                try:
                    self._execution_lock.release()
                except RuntimeError:
                    pass


    async def _fast_reserve(
        self,
        accept_url: str,
        verification: Optional[dict] = None,
        account_id: Optional[str] = None,
    ) -> bool:
        """حجز سريع عبر API بعد اجتياز بوابة الفحص المزدوج."""
        if not isinstance(accept_url, str) or not accept_url.strip():
            return False

        # Compatibility argument is intentionally ignored; only the internal record is trusted.
        del verification
        try:
            normalized = self._normalize_task_url(accept_url)
        except Exception:
            normalized = accept_url
        records = getattr(self, "_verification_records", None)
        requested_account = str(account_id or "").strip()
        record = None
        if isinstance(records, dict) and requested_account:
            record = records.get(f"{requested_account}:{normalized}")
        if record is None and isinstance(records, dict) and not requested_account:
            record = records.get(normalized)
        if not isinstance(record, dict):
            logger.warning("Fast reserve blocked: missing internal verification | %s", accept_url)
            return False

        now = time.time()
        task_id = self._extract_task_id_from_url(normalized)
        record_account = str(record.get("account_id") or "legacy")
        if (
            not requested_account
            or requested_account != record_account
            or (record_account == "legacy" and requested_account != "legacy")
        ):
            logger.warning("Fast reserve blocked: wrong owning account | %s", accept_url)
            return False
        if (
            record.get("url") != normalized
            or not task_id
            or record.get("task_id") != task_id
            or float(record.get("expires_at") or 0) <= now
        ):
            records.pop(f"{record_account}:{normalized}", None)
            logger.warning("Fast reserve blocked: stale or mismatched verification | %s", accept_url)
            return False

        get_details = getattr(self, "_get_task_details", None)
        if callable(get_details):
            current_details = get_details(normalized, requested_account)
        else:
            current_details = (
                (getattr(self, "tasks_details", {}) or {}).get(normalized)
                if isinstance(getattr(self, "tasks_details", None), dict)
                else {}
            ) or {}
        if (
            not isinstance(current_details, dict)
            or str(current_details.get("unu_account_id") or "legacy") != record_account
            or self._verification_fingerprint(current_details) != record.get("fingerprint")
            or str(current_details.get("task_id") or task_id) != task_id
        ):
            records.pop(f"{record_account}:{normalized}", None)
            logger.warning("Fast reserve blocked: task data changed | %s", accept_url)
            return False

        details = record
        if (
            details.get("title_tier") != "accepted"
            or details.get("title_check_passed") is not True
            or details.get("detail_check_passed") is not True
            or details.get("analysis_status") in {"unavailable", "failed"}
            or details.get("ai_source") in {"ai_unavailable", "rule_fallback"}
            or (
                isinstance(details.get("ai_result"), dict)
                and details["ai_result"].get("executable") is False
            )
        ):
            logger.warning("Fast reserve blocked by verification gate | %s", accept_url)
            return False

        canonicalize = getattr(self, "_canonicalize_platform_name", lambda value: value)
        expected_platform = canonicalize(
            str(details.get("title_platform") or "").strip().lower()
        )
        actual_platform = canonicalize(
            str(
                details.get("detail_platform")
                or details.get("verified_platform")
                or details.get("platform")
                or ""
            ).strip().lower()
        )
        expected_action = str(details.get("title_action") or "").strip().lower()
        actual_action = str(
            details.get("detail_action")
            or details.get("verified_action")
            or details.get("action")
            or ""
        ).strip().lower()
        if (
            (expected_platform and not actual_platform)
            or (expected_action and not actual_action)
            or (expected_platform and actual_platform != expected_platform)
            or (expected_action and actual_action != expected_action)
        ):
            logger.warning("Fast reserve blocked by title/detail mismatch | %s", accept_url)
            return False

        # منع القبول المتكرر
        accepted = getattr(self, "_accepted_tasks", set())
        accepted_key = f"{record_account}:{normalized}"
        if accepted_key in accepted or normalized in accepted or accept_url in accepted:
            return False
        inflight = getattr(self, "_fast_reserve_inflight", None)
        if not isinstance(inflight, set):
            inflight = set()
            self._fast_reserve_inflight = inflight
        if accepted_key in inflight:
            return False
        inflight.add(accepted_key)
        try:
            fleet = getattr(self, "fleet", None)
            runtime = fleet.resolve_runtime(record_account) if fleet else None
            if runtime is None:
                logger.warning("Fast reserve blocked: owning account unavailable | %s", record_account)
                return False
            async with runtime.reservation_lock:
                if accepted_key in accepted:
                    return False
                reserved = await asyncio.to_thread(runtime.reserve_task, normalized)
            if reserved:
                logger.info("⚡ Fast reserve success: %s", task_id)
                self._accepted_tasks.add(accepted_key)
                return True
            return False
        except Exception as e:
            logger.debug("Fast reserve failed: %s", e)
            return False
        finally:
            inflight.discard(accepted_key)

    async def _accept_task_in_unu(
        self,
        accept_url: str,
    ) -> bool:

        """فتح accept والتحقق منها مع إبقاء الصفحة لتنفيذ المهمة والإثبات."""
        if not self.context:
            return False

        new_page = None
        try:
            if self._active_task_page:
                try:
                    if not self._active_task_page.is_closed():
                        await self._active_task_page.close()
                except Exception:
                    pass
                self._active_task_page = None
                self._active_task_url = None

            new_page = await self.context.new_page()
            new_page.set_default_timeout(ACTION_TIMEOUT)
            new_page.set_default_navigation_timeout(ACTION_TIMEOUT)

            success = await self._goto(
                new_page,
                accept_url,
                timeout=ACTION_TIMEOUT,
                retries=1,
            )
            if not success:
                return False

            # UNU يحوّل accept تلقائيًا لصفحة التقرير غالبًا.
            # نثبت الصفحة دي للإثبات فقط — التنفيذ على تاب منفصل.
            await new_page.wait_for_timeout(2000)
            try:
                for _ in range(10):
                    if "/tasks/report/" in (new_page.url or ""):
                        break
                    await new_page.wait_for_timeout(350)
            except Exception:
                pass

            final_url = new_page.url or accept_url
            try:
                body_low = (await new_page.inner_text("body")).lower()
            except Exception:
                body_low = ""
            bad_markers = (
                "задание недоступно",
                "уже выполняется другим",
                "вы уже выполняли",
                "лимит заданий",
                "задание не найдено",
                "не найдено",
                "ошибка доступа",
            )
            on_report = "/tasks/report/" in (final_url or "")
            has_form = ("textarea" in (await new_page.content()).lower()) or ("отчёт" in body_low) or ("отчет" in body_low)
            if any(b in body_low for b in bad_markers) and not on_report:
                logger.warning("Accept rejected by UNU: %s | %s", accept_url, final_url)
                return False
            if not on_report and not has_form:
                logger.warning("Accept did not open a report form: %s", final_url)
                return False
            self._active_task_page = new_page
            self._active_task_url = final_url
            if "/tasks/report/" in (final_url or ""):
                logger.info("✅ UNU accept→report مفتوحة للإثبات: %s", final_url)
            else:
                logger.info("✅ صفحة UNU محفوظة للإثبات (Skill على تاب منفصل): %s", final_url)
            new_page = None
            return True

        except Exception as error:
            logger.error("Accept page open error: %s", error)
            return False
        finally:
            if new_page:
                try:
                    await new_page.close()
                except Exception:
                    pass

    # ======================================================
    # Proof generation
    # ======================================================

    def _proof_account_username(
        self,
        platform: str = "",
        details: dict | None = None,
    ) -> str:
        """يوزر مختصر (للتوافق)."""
        details = details or {}
        skill = details.get("skill_result") if isinstance(details.get("skill_result"), dict) else {}
        for key in (
            "account_username", "platform_username", "username",
            "executor_username", "proof_username",
        ):
            val = details.get(key) or skill.get(key)
            if val and str(val).strip() and str(val).strip().lower() not in {
                "unknown", "none", "null", "n/a",
            }:
                return str(val).strip().lstrip("@")
        plat = normalize_text(platform or details.get("platform") or "").lower()
        if plat in {"x"}:
            plat = "twitter"
        profiles = globals().get("PROOF_PROFILE_URLS") or {}
        url = str(profiles.get(plat) or "")
        if url:
            m = re.search(
                r"(?:instagram\.com/|tiktok\.com/@|youtube\.com/@|x\.com/|twitter\.com/)([A-Za-z0-9._]+)",
                url,
                re.I,
            )
            if m:
                return m.group(1)
            m2 = re.search(r"(?:vk\.(?:com|ru)|m\.vk\.(?:com|ru))/(id\d+|[A-Za-z0-9._]+)", url, re.I)
            if m2:
                return m2.group(1)
        tg = getattr(BOT_CONFIG, "TG_USERNAME", None)
        return str(tg).strip().lstrip("@") if tg else ""

    def _proof_profile_url(self, platform: str) -> str:
        plat = normalize_text(platform or "").lower()
        if plat == "x":
            plat = "twitter"
        profiles = globals().get("PROOF_PROFILE_URLS") or {}
        url = str(profiles.get(plat) or "").strip()
        return url if url.startswith("http") else ""

    def _proof_kinds(self, details: dict | None) -> list:
        """ترتيب ما يطلبه حقل «Предоставить в отчёте»."""
        requirements = parse_proof_requirements(details)
        if isinstance(details, dict):
            details["proof_requirements"] = requirements
        return [
            "link" if kind == "account_url" else kind
            for kind in requirements.get("kinds", [])
            if kind not in requirements.get("unsupported", [])
        ]

    def _proof_report_text(
        self,
        platform: str = "",
        details: dict | None = None,
    ) -> str:
        """
        نص التقرير يطابق «Предоставить в отчёте»:
        ник → اليوزر، ссылка → رابط الحساب، комментарий → النص اللي اتكتب،
        скрин → الملف بيتترفع لوحده والنص يبقى الهوية المطلوبة لو اتطلبت.
        """
        details = details or {}
        plat = normalize_text(platform or details.get("platform") or "").lower()
        if plat in {"x"}:
            plat = "twitter"

        skill = details.get("skill_result") if isinstance(details.get("skill_result"), dict) else {}
        user = self._proof_account_username(plat, details)
        names = globals().get("PROOF_USERNAMES") or {}
        if not user and not (details or {}).get("_fleet_locked"):
            user = str(names.get(plat) or "").strip().lstrip("@")

        url = ""
        for key in ("profile_url", "account_url", "proof_url", "repost_url"):
            val = details.get(key) or skill.get(key)
            if val and str(val).startswith("http"):
                url = str(val).strip()
                break
        if not url:
            url = self._proof_profile_url(plat)

        comment = ""
        for key in ("comment_text", "posted_comment", "generated_comment", "review_text", "text"):
            val = details.get(key) or skill.get(key)
            if val and str(val).strip() and len(str(val).strip()) >= 2:
                comment = str(val).strip()
                break

        proof_raw = str(details.get("proof") or "").lower()
        wants_at = any(x in proof_raw for x in ("@", "собач", "с собакой"))
        if user and wants_at and not user.startswith("http"):
            user = "@" + user.lstrip("@")

        kinds = self._proof_kinds(details)
        action = normalize_text(details.get("action") or "").lower()
        requirements = details.get("proof_requirements") or parse_proof_requirements(details)
        missing = []
        if not kinds:
            if action in {"comment", "review"} and comment:
                kinds = ["comment"]
            elif url:
                kinds = ["link"]
            elif user:
                kinds = ["username"]

        parts = []
        for kind in kinds:
            if kind == "username" and user:
                parts.append(user)
            elif kind == "username":
                missing.append(kind)
            elif kind == "link" and url:
                parts.append(url)
            elif kind == "link":
                missing.append("account_url")
            elif kind == "comment" and comment:
                parts.append(comment)
            elif kind == "comment":
                missing.append(kind)
            elif kind == "screenshot":
                continue
        if requirements.get("unsupported"):
            details["proof_missing"] = list(requirements["unsupported"])
            details["proof_status"] = "unsupported_requirement"
            return ""
        if missing and requirements.get("strict"):
            details["proof_missing"] = list(dict.fromkeys(missing))
            details["proof_status"] = "missing_required_proof"
            return ""
        if not parts:
            if action in {"comment", "review"} and comment:
                parts.append(comment)
            elif user and "ник" in proof_raw:
                parts.append(user)
            elif url:
                parts.append(url)
            elif user:
                parts.append(user)
            else:
                parts.append("выполнено")

        seen = []
        for part in parts:
            if part and part not in seen:
                seen.append(part)
        return "\n".join(seen)

    def _build_proof_text(
        self,
        ai_analysis: dict,
        details: dict,
    ) -> Optional[str]:
        if not isinstance(details, dict):
            details = {}
        ai_analysis = ai_analysis or {}
        platform = normalize_text(
            ai_analysis.get("platform") or details.get("platform") or ""
        ).lower()
        if platform and not details.get("platform"):
            details["platform"] = platform
        if ai_analysis.get("action") and not details.get("action"):
            details["action"] = ai_analysis.get("action")
        text = self._proof_report_text(platform, details)
        return text or None

    async def _verify_proof_with_ai(
        self,
        screenshot_path: str | Path,
        ai_analysis: dict,
        details: dict,
    ) -> tuple[bool, str]:
        """
        مراجعة AI لسكرين الإثبات مُعطّلة عمدًا (طلب التشغيل).
        القرار النهائي عندك عبر أزرار نعم/لا/تعديل.
        الدالة محفوظة للتوافق ولا تُستدعى لرفض تلقائي.
        """
        image_path = Path(str(screenshot_path or ""))
        if not image_path.exists():
            details["ai_proof_verification"] = "skipped_no_file"
            return True, "ai_proof_review_disabled"
        details["ai_proof_verification"] = "ai_proof_review_disabled"
        details["ai_proof_verified"] = True
        # لا نستدعي Gemini/Vision على سكرين الإثبات
        return True, "ai_proof_review_disabled"

    # ======================================================
    # Submit proof
    # ======================================================




    async def _score_proof_screenshot_quality_v2(
        self,
        screenshot_path: str | Path | None,
        details: dict | None = None,
    ) -> dict:
        """
        طبقة جودة إثبات أقوى فوق التقييم الأساسي:
        - حجم الملف
        - صورة بيضاء/فارغة تقريباً (Pillow إن وُجد)
        - حالات login/QR/captcha من skill_result
        """
        base = self._score_proof_screenshot_quality(screenshot_path, details)
        if not base.get("ok"):
            return base

        path = Path(str(screenshot_path))
        details = details if isinstance(details, dict) else {}
        platform = details.get("platform") or details.get("title_platform") or ""
        action = details.get("action") or details.get("title_action") or ""
        manifest = build_proof_manifest(
            path,
            platform=platform,
            action=action,
            page_url=details.get("target_url") or details.get("page_url") or "",
            stage=details.get("proof_stage") or "end",
        )
        result["manifest"] = manifest
        try:
            size = path.stat().st_size
            if size < 12_000:
                base["ok"] = False
                base["status"] = "screenshot_too_small"
                base["reasons"].append(f"size={size}")
                return base
        except Exception as error:
            base["reasons"].append(f"stat:{error}")

        # كشف سكرين أبيض/فارغ
        try:
            from PIL import Image
            import statistics
            with Image.open(path) as img:
                img = img.convert("L").resize((64, 64))
                pixels = list(img.getdata())
                if pixels:
                    mean_v = sum(pixels) / len(pixels)
                    var_v = statistics.pvariance(pixels) if len(pixels) > 1 else 0
                    # أبيض تقريباً أو تباين منخفض جداً
                    if mean_v > 245 and var_v < 30:
                        base["ok"] = False
                        base["status"] = "screenshot_blank_white"
                        base["reasons"].append(f"mean={mean_v:.1f},var={var_v:.1f}")
                    elif mean_v < 8 and var_v < 30:
                        base["ok"] = False
                        base["status"] = "screenshot_blank_black"
                        base["reasons"].append(f"mean={mean_v:.1f},var={var_v:.1f}")
                    elif var_v < 5:
                        base["ok"] = False
                        base["status"] = "screenshot_low_variance"
                        base["reasons"].append(f"var={var_v:.1f}")
        except ImportError:
            base["reasons"].append("pillow_missing")
        except Exception as error:
            base["reasons"].append(f"image_scan:{type(error).__name__}")

        return base

    async def _pre_skill_session_gate(
        self,
        page,
        platform: str,
        details: dict,
    ) -> tuple:
        """
        فحص صحة الجلسة/الصفحة قبل route_task.
        يرجع (ok, status, health_dict)
        """
        health = {
            "status": "unknown",
            "platform": platform,
            "logged_in": None,
            "reason": "",
        }
        try:
            skill_mgr = getattr(self, "skills", None)
            # استخدم فحص الـBaseSkill عبر أي skill متاح
            probe = None
            if skill_mgr is not None:
                skills_map = getattr(skill_mgr, "skills", {}) or {}
                probe = skills_map.get(platform) or skills_map.get("telegram") or next(iter(skills_map.values()), None)
            if probe is not None and hasattr(probe, "_session_health_check"):
                health = await probe._session_health_check(page, platform)
            else:
                # فحص خفيف من main
                if page is None:
                    health = {"status": "missing_page", "reason": "no_page", "platform": platform}
                else:
                    try:
                        body = (await page.content())[:8000].lower()
                    except Exception:
                        body = ""
                    if any(x in body for x in ("captcha", "разверните картинку", "не ботом", "recaptcha")):
                        health = {"status": "captcha", "reason": "captcha_markers", "platform": platform}
                    elif any(x in body for x in ("войти", "log in", "login", "sign in", "вход")):
                        health = {"status": "login_required", "reason": "login_markers", "platform": platform, "logged_in": False}
                    else:
                        health = {"status": "ready", "reason": "heuristic_ok", "platform": platform, "logged_in": True}
        except Exception as error:
            health = {
                "status": "page_error",
                "reason": str(error)[:200],
                "platform": platform,
            }

        details["session_health"] = health
        status = normalize_text(health.get("status") or "").lower()
        if status in {
            "captcha",
            "login_required",
            "automation_block",
            "region_block",
            "content_restricted",
            "ip_blocked",
            "http_404",
            "missing_page",
            "telegram_qr_or_phone_login",
        }:
            return False, status, health
        return True, status or "ready", health

    async def _handle_captcha_pause(
        self,
        task_url: str,
        platform: str,
        details: dict,
        screenshot_path: str | Path | None = None,
        timeout_sec: float = 180.0,
    ) -> str:
        """
        عند اكتشاف كابتشا سلوكية:
        - ينبهك
        - ينتظر حتى ترسل /captcha_done أو تنتهي المهلة
        - لا يحل السلايدر أوتوماتيك
        يرجع: resumed | timeout | skipped
        """
        self._captcha_resume_event = getattr(self, "_captcha_resume_event", None) or asyncio.Event()
        self._captcha_resume_event.clear()
        self._captcha_paused = True
        try:
            await self._send_alert(
                (
                    "🧩 كابتشا / فحص روبوت — البوت واقف:\\n"
                    f"منصة: {platform}\\n"
                    f"مهمة: {task_url}\\n"
                    "حلّ الفحص في المتصفح لو ظاهر، بعدين ابعت في البوت:\\n"
                    "/captcha_done\\n"
                    "أو تجاهل: /captcha_skip"
                ),
                "error",
                photo_path=screenshot_path,
            )
        except Exception:
            pass

        try:
            await asyncio.wait_for(self._captcha_resume_event.wait(), timeout=timeout_sec)
        except asyncio.TimeoutError:
            self._captcha_paused = False
            return "timeout"

        self._captcha_paused = False
        decision = normalize_text(getattr(self, "_captcha_decision", "resumed") or "resumed").lower()
        return decision if decision in {"resumed", "skipped", "timeout"} else "resumed"

    def resolve_captcha_decision(self, decision: str = "resumed") -> bool:
        """يستدعى من الداشبورد/الأوامر: resumed | skipped"""
        self._captcha_decision = normalize_text(decision or "resumed").lower()
        ev = getattr(self, "_captcha_resume_event", None)
        if ev is not None:
            try:
                ev.set()
            except Exception:
                return False
        return True

    def track_manual_task(self, task_url: str, details: dict | None = None) -> None:
        """تتبع مهام (هعملها أنا) لعدم إعادة قبولها بالغلط في نفس الدورة."""
        if not hasattr(self, "_manual_tasks"):
            self._manual_tasks = set()
        self._manual_tasks.add(self._normalize_task_url(task_url))
        try:
            path = Path(APP.DATA_DIR if hasattr(APP, "DATA_DIR") else "data") / "manual_tasks.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            existing = []
            if path.exists():
                try:
                    existing = json.loads(path.read_text(encoding="utf-8"))
                except Exception:
                    existing = []
            if not isinstance(existing, list):
                existing = []
            existing.append({
                "task_url": task_url,
                "ts": time.time(),
                "platform": (details or {}).get("platform"),
                "action": (details or {}).get("action"),
            })
            path.write_text(json.dumps(existing[-200:], ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as error:
            logger.debug("track_manual_task failed: %s", error)

    async def _request_manual_assist(
        self,
        task_url: str,
        platform: str,
        action: str,
        target_url: str,
        details: dict,
        reason: str = "session_or_control_failed",
        timeout_sec: float = 600.0,
    ) -> dict:
        """تشغيل ذاتي: مفيش انتظار على تيليجرام. الفشل يتحرر فورًا."""
        logger.info(
            "manual assist skipped (autonomous) | %s | %s | %s",
            task_url,
            platform,
            reason,
        )
        return {"ok": False, "status": "skipped", "reason": "autonomous_no_assist"}

        assist_id = f"assist_{int(time.time()*1000)}_{random.randint(1000,9999)}"
        if not hasattr(self, "_pending_manual_assists"):
            self._pending_manual_assists = {}
        event = asyncio.Event()
        self._pending_manual_assists[assist_id] = {
            "event": event,
            "screenshot_path": None,
            "status": "waiting",
            "task_url": task_url,
            "target_url": target_url,
            "platform": platform,
            "action": action,
            "created_at": time.monotonic(),
        }

        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "✅ تم — استخدم السكرين",
                    callback_data=f"unu_assist:done:{assist_id}",
                ),
            ],
            [
                InlineKeyboardButton(
                    "⏭️ تخطّي المهمة دي",
                    callback_data=f"unu_assist:skip:{assist_id}",
                ),
            ],
        ])

        # كل روابط الهدف (مهام 5 جروبات VK وغيرها)
        extra_links = []
        try:
            if isinstance(details, dict):
                raw = details.get("all_target_urls") or details.get("target_urls") or []
                if isinstance(raw, (list, tuple)):
                    extra_links = [str(u) for u in raw if u]
        except Exception:
            extra_links = []
        if target_url and str(target_url) not in extra_links:
            extra_links.insert(0, str(target_url))
        seen = set()
        uniq_links = []
        for u in extra_links:
            if u not in seen:
                seen.add(u)
                uniq_links.append(u)
        if uniq_links:
            links_block = "\n".join(
                f"{i+1}) {html.escape(u)}" for i, u in enumerate(uniq_links)
            )
        else:
            links_block = html.escape(str(target_url or "غير متاح"))

        text = (
            "🆘 <b>محتاج مساعدتك</b>\n"
            "البوت معرفش يكمّل لوحده.\n\n"
            f"📌 <b>السبب:</b> <code>{html.escape(str(reason))}</code>\n"
            f"🌐 <b>المنصة:</b> {html.escape(str(platform))} | "
            f"<b>الفعل:</b> {html.escape(str(action))}\n"
            f"🔗 <b>مهمة UNU:</b>\n{html.escape(str(task_url or ''))}\n"
            f"🎯 <b>روابط الهدف ({len(uniq_links) or 1}) — اعمل المطلوب على كلها:</b>\n"
            f"{links_block}\n\n"
            "ازاي تكمل؟\n"
            "1️⃣ افتح الروابط فوق واعمل المطلوب بنفسك\n"
            "2️⃣ ابعت هنا <b>صورة السكرين</b> (كسكرين عادي)\n"
            "3️⃣ اضغط الزر ✅ تم — استخدم السكرين\n\n"
            "⚠️ زر تخطّي = رفض المهمة على UNU. لو هتساعد متضغطش تخطّي.\n"
            "أو اضغط ⏭️ تخطّي لو مش هتعملها."
        )

        try:
            bot = getattr(self, "bot", None)
            if bot is None:
                from telegram import Bot
                bot = Bot(token=BOT_CONFIG.BOT_TOKEN)
            await bot.send_message(
                chat_id=BOT_CONFIG.ADMIN_ID,
                text=text,
                reply_markup=keyboard,
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=True,
            )
        except Exception as error:
            logger.warning("manual assist button message failed: %s", error)
            try:
                await self._send_alert(
                    f"🆘 مساعدة يدوية | {platform}/{action}\n{target_url}\nاضغط الأزرار في الرسالة.",
                    "warning",
                )
            except Exception:
                pass

        try:
            await asyncio.wait_for(event.wait(), timeout=timeout_sec)
        except asyncio.TimeoutError:
            self._pending_manual_assists.pop(assist_id, None)
            return {"ok": False, "status": "assist_timeout", "screenshot_path": None}

        pending = self._pending_manual_assists.pop(assist_id, {}) or {}
        status = normalize_text(pending.get("status") or "").lower()
        path = pending.get("screenshot_path")
        if status == "done" and path and Path(str(path)).exists():
            return {"ok": True, "status": "manual_done", "screenshot_path": str(path)}
        return {"ok": False, "status": status or "assist_skipped", "screenshot_path": None}

    def resolve_manual_assist(
        self,
        assist_id: str,
        decision: str = "done",
        screenshot_path: str | None = None,
    ) -> bool:
        """أزرار الداشبورد: done / skip + مسار الصورة."""
        assist_id = str(assist_id or "").strip()
        if assist_id.startswith("done_"):
            assist_id = assist_id[5:]
        if assist_id.startswith("skip_"):
            assist_id = assist_id[5:]
        bag = getattr(self, "_pending_manual_assists", {}) or {}
        pending = bag.get(assist_id)
        if not isinstance(pending, dict):
            for k, v in list(bag.items()):
                if assist_id in str(k) or str(k) in assist_id:
                    pending = v
                    assist_id = k
                    break
        if not isinstance(pending, dict):
            return False

        decision = normalize_text(decision).lower()
        if decision in {"done", "ok", "yes", "approve"}:
            if screenshot_path:
                pending["screenshot_path"] = str(screenshot_path)
            # آخر صورة محفوظة من الداشبورد
            if not pending.get("screenshot_path"):
                latest = getattr(self, "_latest_assist_photo", None)
                if latest and Path(str(latest)).exists():
                    pending["screenshot_path"] = str(latest)
            if not pending.get("screenshot_path"):
                pending["status"] = "waiting_photo"
                return False
            pending["status"] = "done"
        elif decision in {"skip", "skipped", "reject", "no", "cancel"}:
            # تخطّي صريح فقط — أي قرار تاني مش رفض
            pending["status"] = "skipped"
        else:
            # قرار غير معروف: نفضل الانتظار مش skip
            logger.warning("resolve_manual_assist unknown decision=%s — keep waiting", decision)
            return False

        ev = pending.get("event")
        if ev is not None:
            try:
                ev.set()
            except Exception:
                pass
        return True

    def attach_assist_photo(self, screenshot_path: str) -> bool:
        """يحفظ آخر سكرين من الداشبورد لربطه بزر ✅ تم."""
        if not screenshot_path:
            return False
        path = Path(str(screenshot_path))
        if not path.exists():
            return False
        self._latest_assist_photo = str(path)
        # لو في مساعدة واحدة بس منتظرة — اربط الصورة بيها
        bag = getattr(self, "_pending_manual_assists", {}) or {}
        waiting = [v for v in bag.values() if isinstance(v, dict) and v.get("status") in {"waiting", "waiting_photo"}]
        if len(waiting) == 1:
            waiting[0]["screenshot_path"] = str(path)
            waiting[0]["status"] = "waiting_photo"
        return True


    async def _handle_accepted_task_abort(
        self,
        task_url: str,
        details: dict,
        reason: str,
        *,
        refuse: bool = True,
        execution_key: str | None = None,
    ) -> None:
        """
        بعد ما المهمة اتحجزت بـ accept ومفيش تنفيذ/إثبات ناجح:
        - تنبيه واضح
        - محاولة رفض على UNU (افتراضي) عشان متفضلش معلّقة صامتة
        - تحرير history لو مطلوب
        """
        details = details if isinstance(details, dict) else {}
        details["execution_success"] = False
        details["abort_reason"] = str(reason or "unknown")
        details["execution_status"] = details.get("execution_status") or f"aborted:{reason}"

        refused = False
        if refuse:
            try:
                refused = await self._refuse_task_on_unu(
                    details.get("accept_url") or task_url,
                    details,
                )
            except Exception as error:
                logger.warning("abort refuse failed: %s", error)
                refused = False

        try:
            await self._send_alert(
                (
                    "⚠️ مهمة اتسجّلت بـ accept بدون إكمال:\n"
                    f"{task_url}\n"
                    f"السبب: {reason}\n"
                    f"رفض UNU: {'نعم ✅' if refused else 'لا ❌ — افتح الرابط على UNU واضغط Отказаться'}\n"
                    "المهمة اتحجزت والتنفيذ فشل؛ راجع الرابط فوق."
                ),
                "warning",
            )
        except Exception:
            pass

        if execution_key:
            try:
                async with self._state_lock:
                    self.history.discard(execution_key)
                    self.invalid.add(self._normalize_task_url(task_url))
            except Exception:
                pass

        logger.warning(
            "Accepted-task abort | url=%s reason=%s refused=%s",
            task_url,
            reason,
            refused,
        )

    async def _refuse_task_on_unu(
        self,
        accept_url: str,
        details: dict | None = None,
    ) -> bool:
        """
        رفض المهمة على UNU:
        1) الضغط على «Отказаться от выполнения?»
        2) تأكيد النافذة «Точно отказаться...» (حسناً / OK)
        """
        if not self.context:
            return False

        page = self._active_task_page
        created_page = False
        try:
            if not page or page.is_closed():
                page = await self.context.new_page()
                created_page = True

            page.set_default_timeout(ACTION_TIMEOUT)
            page.set_default_navigation_timeout(ACTION_TIMEOUT)

            try:
                page.on("dialog", lambda dialog: asyncio.create_task(dialog.accept()))
            except Exception:
                pass

            open_urls = []
            det = details if isinstance(details, dict) else {}
            for k in ("report_url", "unu_proof_page_url", "proof_page_url", "worker_url"):
                u = det.get(k)
                if u and str(u) not in open_urls:
                    open_urls.append(str(u))
            m_id = re.search(r"/tasks/(?:accept|report)/[a-z0-9]+-(\d+)", str(accept_url or ""), re.I)
            if not m_id:
                m_id = re.search(r"/tasks/report/(\d+)", str(accept_url or ""))
            if m_id:
                wid = m_id.group(1)
                open_urls.append(f"https://unu.im/tasks/report/{wid}/worker")
            if accept_url:
                open_urls.append(str(accept_url))

            async def _js_refuse(target) -> bool:
                try:
                    return bool(await target.evaluate(
                        """() => {
                            const nodes = Array.from(document.querySelectorAll('a, button, span, div, input'));
                            const el = nodes.find(n => {
                                const t = (n.innerText || n.value || '').trim();
                                return /отказаться от выполнения/i.test(t) && t.length < 80;
                            });
                            if (!el) return false;
                            el.click();
                            return true;
                        }"""
                    ))
                except Exception:
                    return False

            clicked_refuse = False
            for target_url in open_urls:
                ok = await self._goto(
                    page,
                    target_url,
                    timeout=ACTION_TIMEOUT,
                    retries=1,
                )
                if not ok:
                    continue
                await page.wait_for_timeout(800)
                if await _js_refuse(page):
                    clicked_refuse = True
                    accept_url = target_url
                    break

            # 1) رابط/زر الرفض
            refuse_selectors = [
                "text=Отказаться от выполнения?",
                "a:has-text('Отказаться от выполнения')",
                "button:has-text('Отказаться от выполнения')",
                "text=Отказаться от выполнения",
                "a:has-text('Отказаться')",
                "button:has-text('Отказаться')",
                "a:has-text('отказаться от выполнения')",
                "text=Отказ",
                "a:has-text('Отказ')",
            ]
            if not clicked_refuse:
                for sel in refuse_selectors:
                    try:
                        loc = page.locator(sel).first
                        if await loc.count():
                            await loc.click(timeout=5000, force=True)
                            clicked_refuse = True
                            break
                    except Exception:
                        continue

            if not clicked_refuse:
                # جرّب صفحة report/worker لو المهمة اتحوّلت بعد accept
                alt_urls = []
                try:
                    det = details if isinstance(details, dict) else {}
                    for k in ("report_url", "proof_page_url", "worker_url"):
                        u = det.get(k)
                        if u and str(u) not in alt_urls:
                            alt_urls.append(str(u))
                    # استخرج work id من accept أو من الصفحة الحالية
                    cur = ""
                    try:
                        cur = page.url or ""
                    except Exception:
                        cur = ""
                    if "/tasks/report/" in cur and cur not in alt_urls:
                        alt_urls.append(cur)
                    import re as _re
                    m = _re.search(r"/tasks/accept/[a-z0-9]+-(\d+)", str(accept_url or ""), _re.I)
                    if m:
                        wid = m.group(1)
                        alt_urls.append(f"https://unu.im/tasks/report/{wid}/worker")
                        alt_urls.append(f"https://unu.im/tasks/report/{wid}")
                except Exception:
                    pass

                for alt in alt_urls:
                    try:
                        logger.info("Refuse retry on alt page: %s", alt)
                        ok2 = await self._goto(page, alt, timeout=ACTION_TIMEOUT, retries=1)
                        if not ok2:
                            continue
                        await page.wait_for_timeout(1000)
                        for sel in refuse_selectors:
                            try:
                                loc = page.locator(sel).first
                                if await loc.count() and await loc.is_visible():
                                    await loc.click(timeout=5000)
                                    clicked_refuse = True
                                    accept_url = alt
                                    break
                            except Exception:
                                continue
                        if clicked_refuse:
                            break
                    except Exception as alt_err:
                        logger.debug("refuse alt failed: %s", alt_err)

                if not clicked_refuse:
                    logger.warning("Refuse link not found on: %s", accept_url)
                    return False

            await page.wait_for_timeout(800)

            # 2) تأكيد الديالوج (المتصفح أو مودال الموقع)
            confirmed = False
            # dialog handler لو ظهر alert/confirm أصلي
            try:
                page.once(
                    "dialog",
                    lambda dialog: asyncio.create_task(dialog.accept()),
                )
            except Exception:
                pass

            confirm_selectors = [
                "button:has-text('حسناً')",
                "button:has-text('حسنا')",
                "button:has-text('OK')",
                "button:has-text('Ok')",
                "button:has-text('Да')",
                "button:has-text('Подтвердить')",
                "button:has-text('Да, отказаться')",
                "button:has-text('Подтверждаю')",
                "button:has-text('Yes')",
                "button:has-text('Confirm')",
                "text=حسناً",
                "text=حسنا",
                "text=Точно отказаться",
                # أزرار المودال (الصورة العربية: حسناً / إلغاء)
                ".modal button >> nth=0",
                "[role='dialog'] button >> nth=0",
                ".modal button",
                "[role='dialog'] button",
            ]
            for sel in confirm_selectors:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() and await loc.is_visible(timeout=1500):
                        await loc.click(timeout=4000)
                        confirmed = True
                        break
                except Exception:
                    continue

            # بعض المتصفحات تستخدم confirm() — ننتظر لحظة
            await page.wait_for_timeout(1500)

            if details is not None:
                details["unu_refused"] = True
                details["unu_refuse_confirmed"] = bool(confirmed or clicked_refuse)

            logger.info(
                "UNU task refuse attempted | url=%s confirmed=%s",
                accept_url,
                confirmed or clicked_refuse,
            )
            return bool(clicked_refuse)
        except Exception as error:
            logger.exception("Refuse task on UNU failed: %s", error)
            return False
        finally:
            if created_page and page is not None:
                try:
                    if not page.is_closed():
                        await page.close()
                except Exception:
                    pass


    @staticmethod
    def _extract_unu_work_ids(accept_url: str, details: dict | None = None) -> list:
        """استخراج أرقام عمل محتملة لبناء رابط /tasks/report/{id}/worker."""
        ids = []
        details = details or {}
        for key in (
            "work_id", "report_id", "task_work_id", "order_id",
            "job_id", "execution_id", "assignment_id",
        ):
            val = details.get(key)
            if val is None:
                continue
            digits = re.sub(r"\D+", "", str(val))
            if digits and digits not in ids:
                ids.append(digits)

        url = str(accept_url or "")
        # لا نستخدم رقم بعد شرطة في accept كـ report id — غالبًا غلط ويودّي لصفحة خطأ.
        # نعتمد فقط: work_id الصريح، رابط report الحالي، أو «Работа #» من النص.
        if "/tasks/report/" in url:
            mrep = re.search(r"/tasks/report/(\d+)", url)
            if mrep and mrep.group(1) not in ids:
                ids.append(mrep.group(1))

        for key in ("title", "description", "info_for_work", "raw_page_text"):
            blob = str(details.get(key) or "")
            m2 = re.search(
                r"(?:Работа|работ[аые]|order|заказ)\s*#?\s*(\d{6,})",
                blob,
                re.I,
            )
            if m2 and m2.group(1) not in ids:
                ids.append(m2.group(1))
        return ids

    def _build_report_worker_urls(
        self,
        accept_url: str,
        details: dict | None = None,
        page_url: str = "",
    ) -> list:
        """قائمة روابط تقرير محتملة بدون حذف أي مسار قديم."""
        urls = []
        details = details or {}
        # لو details فيها report_url جاهز
        for key in ("report_url", "report_worker_url", "submit_report_url"):
            u = str(details.get(key) or "").strip()
            if u.startswith("http") and u not in urls:
                urls.append(u)

        for wid in self._extract_unu_work_ids(accept_url, details):
            candidate = f"{UNU_BASE_URL}/tasks/report/{wid}/worker"
            if candidate not in urls:
                urls.append(candidate)
            candidate2 = f"{UNU_BASE_URL}/tasks/report/{wid}"
            if candidate2 not in urls:
                urls.append(candidate2)

        # من page_url الحالي لو فيه report
        pu = str(page_url or "")
        if "/tasks/report/" in pu and pu not in urls:
            urls.append(pu.split("#")[0])
        return urls

    async def _discover_report_url_from_page(self, page) -> str:
        """يبحث في الصفحة عن رابط /tasks/report/.../worker."""
        if not page:
            return ""
        try:
            found = await page.evaluate(
                """
                () => {
                    const out = [];
                    document.querySelectorAll('a[href]').forEach(a => {
                        const h = a.href || '';
                        if (h.includes('/tasks/report/')) out.push(h);
                    });
                    return out;
                }
                """
            )
            if isinstance(found, list):
                for href in found:
                    href = str(href or "").split("#")[0].strip()
                    if "/tasks/report/" in href:
                        return href
        except Exception as error:
            logger.debug("discover report url failed: %s", error)
        return ""

    async def _page_looks_like_unu_error(self, page) -> bool:
        if not page:
            return True
        try:
            title = (await page.title() or "").lower()
            if "ошибка" in title or "error" in title:
                return True
            body = (await page.inner_text("body") or "").lower()
            markers = (
                "произошла ошибка",
                "ошибка сервера",
                "страница не найдена",
                "session expired",
                "войдите",
            )
            return any(m in body for m in markers)
        except Exception:
            return False

    async def _find_report_textarea(self, page):
        """يرجع (locator_or_none, frame)."""
        report_selectors = [
            "textarea[name='report']",
            "textarea[name='comment']",
            "textarea[name='text']",
            "textarea[id*='report']",
            "textarea[id*='comment']",
            "textarea[placeholder*='отч']",
            "textarea[placeholder*='коммент']",
            "textarea[placeholder*='report']",
            "textarea.form-control",
            "textarea",
            "[contenteditable='true']",
        ]
        report_area = None
        report_frame = page
        for selector in report_selectors:
            try:
                candidate = page.locator(selector).first
                if await candidate.count() and await candidate.is_enabled():
                    report_area = candidate
                    break
            except Exception:
                continue
        if report_area is None:
            for frame in page.frames:
                if frame == page.main_frame:
                    continue
                for selector in report_selectors:
                    try:
                        candidate = frame.locator(selector).first
                        if await candidate.count() and await candidate.is_enabled():
                            report_area = candidate
                            report_frame = frame
                            break
                    except Exception:
                        continue
                if report_area is not None:
                    break
        return report_area, report_frame



    async def _pre_skill_session_health(self, platform: str, page=None) -> dict:
        """
        فحص سريع قبل التنفيذ:
        - لو الـSkillManager فيه session_health استخدمه
        - وإلا رجّع ready
        لا يوقف المسار القديم؛ يعيد status فقط.
        """
        result = {"status": "ready", "platform": platform, "logged_in": True}
        try:
            skills = getattr(self, "skills", None)
            if skills is None:
                return result
            # محاولة مهارة المنصة
            skill = None
            try:
                if hasattr(skills, "get_skill"):
                    skill = skills.get_skill(platform)
                elif hasattr(skills, "skills"):
                    skill = (skills.skills or {}).get(str(platform).lower())
            except Exception:
                skill = None
            checker = None
            if skill is not None:
                checker = getattr(skill, "_session_health_check", None) or getattr(skill, "session_health_check", None)
            if callable(checker) and page is not None:
                try:
                    out = checker(page, platform)
                    if hasattr(out, "__await__"):
                        out = await out
                    if isinstance(out, dict):
                        return out
                except Exception as err:
                    result["status"] = "health_check_error"
                    result["reason"] = str(err)[:200]
            # cookie expiry monitor لو موجود
            mon = getattr(skills, "cookie_expiry_monitor", None)
            if callable(mon):
                try:
                    info = mon(platform)
                    if hasattr(info, "__await__"):
                        info = await info
                    if isinstance(info, dict) and info.get("expired"):
                        result["status"] = "login_required"
                        result["reason"] = "cookie_expired"
                        result["cookie_monitor"] = info
                except Exception:
                    pass
        except Exception as error:
            result["status"] = "health_error"
            result["reason"] = str(error)[:200]
        return result

    async def _maybe_request_manual_assist_on_login(
        self,
        task_url: str,
        platform: str,
        action: str,
        target_url: str,
        details: dict,
        reason: str,
    ) -> bool:
        """
        لو الجلسة منتهية: يطلب مساعدة يدوية بأزرار بدل فشل صامت.
        يعيد True لو المستخدم كمّل بمساعدة.
        """
        try:
            if hasattr(self, "_request_manual_assist"):
                return bool(await self._request_manual_assist(
                    task_url=task_url,
                    platform=platform,
                    action=action,
                    target_url=target_url,
                    details=details,
                    reason=reason or "login_required",
                ))
        except Exception as error:
            logger.warning("manual assist on login failed: %s", error)
        return False

    async def _submit_proof(
        self,
        accept_url: str,
        ai_analysis: dict,
        details: dict,
    ) -> bool:

        if not self.context:
            return False

        # إعادة استخدام صفحة accept التي نفذت عليها الـSkill؛ لا ننشئ صفحة
        # منفصلة حتى يبقى سياق المهمة والإثبات في نفس الصفحة.
        new_page = self._active_task_page
        if not new_page or new_page.is_closed():
            logger.warning(
                "No active accept page — opening accept then report/worker if needed: %s",
                accept_url,
            )
            try:
                new_page = await self.context.new_page()
                new_page.set_default_timeout(ACTION_TIMEOUT)
                new_page.set_default_navigation_timeout(ACTION_TIMEOUT)
                ok = await self._goto(
                    new_page,
                    accept_url,
                    timeout=ACTION_TIMEOUT,
                    retries=1,
                )
                if not ok:
                    # جرّب report مباشرة
                    for report_url in self._build_report_worker_urls(accept_url, details):
                        ok2 = await self._goto(
                            new_page,
                            report_url,
                            timeout=ACTION_TIMEOUT,
                            retries=1,
                        )
                        if ok2 and not await self._page_looks_like_unu_error(new_page):
                            details["report_worker_url_used"] = report_url
                            break
                    else:
                        try:
                            await new_page.close()
                        except Exception:
                            pass
                        return False
                self._active_task_page = new_page
                self._active_task_url = accept_url
            except Exception as open_err:
                logger.error("Failed to reopen task page for proof: %s", open_err)
                return False

        try:
            new_page.set_default_timeout(ACTION_TIMEOUT)
            new_page.set_default_navigation_timeout(ACTION_TIMEOUT)

            # مهم: نفضل على نفس صفحة الـ accept بعد القبول.
            # مفيش goto/reload إلا لو الصفحة فعلاً اتقفلت أو مش على مسار المهمة.
            current_url = (new_page.url or "").lower()
            still_on_unu_form = (
                "unu.im" in current_url
                and (
                    "/tasks/accept/" in current_url
                    or "/tasks/report/" in current_url
                    or "/tasks/share/" in current_url
                )
            )

            if still_on_unu_form:
                await new_page.wait_for_timeout(random.randint(400, 900))
                logger.info(
                    "Submitting proof on SAME UNU page (no reload): %s",
                    new_page.url,
                )
            else:
                # الصفحة اتسرقت للتنفيذ بالغلط — نرجع للرابط الفعلي المحفوظ بعد accept
                restore = (
                    str(getattr(self, "_active_task_url", "") or "")
                    or str(details.get("report_worker_url_used") or "")
                    or str(details.get("report_url") or "")
                    or accept_url
                )
                logger.warning(
                    "UNU proof page left domain/path — restore once to: %s (was %s)",
                    restore,
                    new_page.url,
                )
                success = await self._goto(
                    new_page,
                    restore,
                    timeout=ACTION_TIMEOUT,
                    retries=1,
                )
                if not success:
                    return False
                await new_page.wait_for_timeout(1800)

            # لو نفس الصفحة لكن ظهر خطأ UNU → انقل فورًا لـ report/worker
            try:
                if await self._page_looks_like_unu_error(new_page):
                    logger.warning(
                        "Accept page shows UNU error before report form — switching to report/worker"
                    )
                    discovered = await self._discover_report_url_from_page(new_page)
                    for report_url in (
                        ([discovered] if discovered else [])
                        + self._build_report_worker_urls(accept_url, details, new_page.url or "")
                    ):
                        if not report_url:
                            continue
                        ok = await self._goto(
                            new_page,
                            report_url,
                            timeout=ACTION_TIMEOUT,
                            retries=1,
                        )
                        if ok and not await self._page_looks_like_unu_error(new_page):
                            details["report_worker_url_used"] = report_url
                            self._active_task_url = report_url
                            logger.info("Switched to report worker page: %s", report_url)
                            break
            except Exception as pre_err:
                logger.debug("pre-report switch failed: %s", pre_err)

            details["ai_analysis"] = ai_analysis
            proof_text = (
                details.get("approved_proof_text")
                or self._build_proof_text(ai_analysis, details)
            )
            if not proof_text:
                logger.warning("No valid proof available.")
                return False

            # ------------------------------------------------
            # 1. محاولة رفع ملف (Screenshot) لو موجود
            # ------------------------------------------------
            screenshot_path = (
                details.get("proof_screenshot_path")
                or details.get("screenshot_path")
            )
            file_uploaded = False

            if screenshot_path and Path(screenshot_path).exists():
                file_inputs = await new_page.query_selector_all('input[type="file"]')
                for file_input in file_inputs:
                    try:
                        await file_input.set_input_files(screenshot_path)
                        file_uploaded = True
                        logger.info("✅ تم رفع ملف السكرينشوت")
                        await new_page.wait_for_timeout(800)
                        break
                    except Exception:
                        continue

            # ------------------------------------------------
            # 2. كتابة النص في الـ textarea
            # ------------------------------------------------
            report_selectors = [
                "textarea[name='report']",
                "textarea[name='comment']",
                "textarea[name='text']",
                "textarea[id*='report']",
                "textarea[id*='comment']",
                "textarea[placeholder*='отч']",
                "textarea[placeholder*='коммент']",
                "textarea[placeholder*='report']",
                "textarea.form-control",
                "textarea",
                "[contenteditable='true']",
            ]

            report_area = None
            report_frame = new_page

            # البحث في الصفحة الأساسية أولاً.
            for selector in report_selectors:
                try:
                    candidate = new_page.locator(selector).first
                    if await candidate.count() and await candidate.is_enabled():
                        report_area = candidate
                        break
                except Exception:
                    continue

            # بعض إصدارات صفحة UNU تضع النموذج داخل iframe.
            if report_area is None:
                for frame in new_page.frames:
                    if frame == new_page.main_frame:
                        continue
                    for selector in report_selectors:
                        try:
                            candidate = frame.locator(selector).first
                            if await candidate.count() and await candidate.is_enabled():
                                report_area = candidate
                                report_frame = frame
                                break
                        except Exception:
                            continue
                    if report_area is not None:
                        break

            if not report_area:
                debug_path = Path(APP.SCREENSHOTS_DIR) / (
                    f"proof_form_missing_{now_ts()}_{random.randint(1000, 9999)}.png"
                )
                try:
                    await new_page.screenshot(path=str(debug_path), full_page=True)
                except Exception:
                    pass
                logger.warning(
                    "Report textarea not found on current page. url=%s title=%s debug=%s — trying report/worker URLs",
                    new_page.url,
                    await new_page.title(),
                    debug_path,
                )

                # ------------------------------------------------
                # Fallback: لو صفحة accept فيها مشكلة → /tasks/report/{id}/worker
                # بدون إغلاق سياق الجلسة؛ نفس الـ page.
                # ------------------------------------------------
                discovered = await self._discover_report_url_from_page(new_page)
                report_candidates = []
                if discovered:
                    report_candidates.append(discovered)
                report_candidates.extend(
                    self._build_report_worker_urls(
                        accept_url,
                        details,
                        page_url=new_page.url or "",
                    )
                )
                # إزالة تكرار مع الإبقاء على الترتيب
                seen_u = set()
                uniq_candidates = []
                for u in report_candidates:
                    u = str(u or "").strip()
                    if not u or u in seen_u:
                        continue
                    seen_u.add(u)
                    uniq_candidates.append(u)

                opened_report = False
                for report_url in uniq_candidates:
                    try:
                        logger.info("Trying UNU report worker page: %s", report_url)
                        ok = await self._goto(
                            new_page,
                            report_url,
                            timeout=ACTION_TIMEOUT,
                            retries=1,
                        )
                        if not ok:
                            continue
                        await new_page.wait_for_timeout(1500)
                        if await self._page_looks_like_unu_error(new_page):
                            logger.warning("Report page looks like error: %s", report_url)
                            continue
                        report_area, report_frame = await self._find_report_textarea(new_page)
                        if report_area is not None:
                            opened_report = True
                            details["report_worker_url_used"] = report_url
                            self._active_task_url = report_url
                            logger.info("✅ Report form found on: %s", report_url)
                            break
                    except Exception as rep_err:
                        logger.warning("Report URL attempt failed (%s): %s", report_url, rep_err)
                        continue

                if not opened_report or report_area is None:
                    logger.warning(
                        "Report textarea still missing after accept + report/worker fallbacks: %s",
                        accept_url,
                    )
                    return False

            # كتابة بشرية بطيئة بدل fill الفوري
            await report_area.scroll_into_view_if_needed()
            await report_area.click()
            await asyncio.sleep(random.uniform(0.3, 0.7))
            try:
                await report_area.fill("")  # تأكد إنها فاضية
                await report_area.type(
                    proof_text,
                    delay=random.randint(35, 90)
                )
            except Exception:
                # contenteditable لا يدعم fill في بعض إصدارات Playwright.
                await report_area.press("Control+A")
                await report_area.press("Backspace")
                await report_area.type(
                    proof_text,
                    delay=random.randint(35, 90)
                )

            await new_page.wait_for_timeout(800)

            # ------------------------------------------------
            # 3. الضغط على زر الإرسال
            # ------------------------------------------------
            submit_selectors = [
                "button:has-text('Отправить')",
                "button:has-text('Отправить отчёт')",
                "button:has-text('Отправить отчет')",
                "button[type='submit']",
                "input[type='submit']",
            ]

            submit_button = None
            for selector in submit_selectors:
                try:
                    candidate = new_page.locator(selector).first
                    if await candidate.is_visible():
                        submit_button = candidate
                        break
                except Exception:
                    continue

            if not submit_button:
                logger.warning("Submit button not found.")
                return False

            await submit_button.scroll_into_view_if_needed()

            # حركة ماوس قبل الضغط
            box = await submit_button.bounding_box()
            if box:
                await new_page.mouse.move(
                    box["x"] + box["width"] / 2,
                    box["y"] + box["height"] / 2,
                    steps=random.randint(8, 15)
                )
                await asyncio.sleep(random.uniform(0.2, 0.5))

            await submit_button.click(
                timeout=7000,
                delay=random.randint(40, 120)
            )

            await new_page.wait_for_timeout(2800)

            # ------------------------------------------------
            # 4. التحقق من النجاح
            # ------------------------------------------------
            body_text = (await report_frame.locator("body").inner_text()).lower()

            success_markers = [
                "отчёт отправлен",
                "отчет отправлен",
                "задание выполнено",
                "успешно",
                "принят",
                "отправлено",
                "отчёт принят",
                "отчет принят",
                "работа принята",
                "спасибо",
                "thank",
                "submitted",
                "success",
            ]

            error_markers = [
                "ошибка",
                "не удалось",
                "обязательное поле",
                "неправильно",
                "заполните",
            ]

            if any(marker in body_text for marker in success_markers):
                return True

            if any(marker in body_text for marker in error_markers):
                logger.warning("Site reported submission error.")
                return False

            # لو الـ textarea اختفت → غالبًا نجح
            try:
                if not await report_area.is_visible():
                    return True
            except Exception:
                return True

            # لو مفيش error markers → نعتبره نجاح (UNU مش دايمًا بيظهر رسالة نجاح)
            logger.info("No error markers found — considering submission successful")
            return True

        except Exception as error:
            logger.error("Submit proof error: %s", error)
            return False

        finally:
            # لا نغلق صفحة accept هنا؛ قد تكون هذه محاولة تسليم فاشلة
            # وستحتاج دورة الإعادة إلى نفس الصفحة والسياق.
            # يتم إغلاقها عند بدء مهمة جديدة أو في shutdown().
            pass

    # ======================================================
    # Scroll and collect
    # ======================================================

    async def _scroll_and_collect(self):
        """
        تجميع روابط /tasks/accept/ من قائمة UNU.
        يحاول API أولاً (أسرع + أكتر صفحات)، ثم المتصفح كـ fallback.
        حماية من التعليق:
          - حد أقصى لفات السكرول
          - حد أقصى للزمن
          - مهلة على evaluate / More
          - وقف لو More من غير روابط جديدة
        الروابط فريدة (set) — مفيش تكرار.
        """
        # ---- API first (fast, multi-page) ----
        try:
            api_tasks = await self.get_tasks_api(max_pages=50)
            if api_tasks:
                urls = set()
                filtered_count = 0
                # Get filters
                banned_words = getattr(self, "filter_banned_words", [])
                
                for t in api_tasks:
                    url = t.get("accept_url", "")
                    title = t.get("title", "").lower()
                    
                    if not url or "/tasks/accept/" not in url:
                        continue
                    
                    # Banned words filter
                    if banned_words and any(w.lower() in title for w in banned_words):
                        filtered_count += 1
                        continue
                    
                    urls.add(self._normalize_task_url(url))
                
                if urls:
                    self._last_collection_source = "api"
                    self._last_collection_stats = {
                        "source": "api",
                        "tasks": len(api_tasks),
                        "urls": len(urls),
                        "filtered": filtered_count,
                    }
                    logger.info("API collected %d task URLs (filtered %d)", len(urls), filtered_count)
                    return list(urls)
        except Exception as e:
            logger.warning("API collect failed, falling back to browser: %s", e)
            self._last_collection_source = "browser_fallback"
            self._last_collection_error = f"{type(e).__name__}:{e}"

        # ---- Browser fallback ----
        if not self.page:
            return []

        self._last_collection_source = "browser"


        collected_urls: set = set()
        scrolls_without_progress = 0
        previous_count = 0
        more_clicks_without_new = 0

        # حدود آمنة — تمنع اللّف اللانهائي حتى مع شبكة بطيئة/تور
        max_scroll_rounds = 40
        max_collect_seconds = 120.0
        max_more_without_new = 5
        max_no_progress = 4
        evaluate_timeout = 20.0
        more_timeout = 12.0

        started_at = time.monotonic()
        scroll_rounds = 0

        while self.running:
            scroll_rounds += 1

            # ---- سقف اللفات ----
            if scroll_rounds > max_scroll_rounds:
                logger.info(
                    "⏹️ توقف التجميع: حد اللفات %s | روابط=%s",
                    max_scroll_rounds,
                    len(collected_urls),
                )
                try:
                    await self._send_alert(
                        f"⏹️ توقف التجميع بعد {max_scroll_rounds} لفة | روابط: {len(collected_urls)}",
                        "info",
                    )
                except Exception:
                    pass
                break

            # ---- سقف الزمن ----
            if (time.monotonic() - started_at) > max_collect_seconds:
                logger.info(
                    "⏹️ توقف التجميع: مهلة %ss | روابط=%s",
                    int(max_collect_seconds),
                    len(collected_urls),
                )
                try:
                    await self._send_alert(
                        f"⏹️ توقف التجميع بعد {int(max_collect_seconds)}ث | روابط: {len(collected_urls)}",
                        "info",
                    )
                except Exception:
                    pass
                break

            # ------------------------------------------------
            # جمع الروابط الحالية (مرة واحدة لكل لفة)
            # ------------------------------------------------
            links = []
            try:
                links = await asyncio.wait_for(
                    self.page.evaluate(
                        """
                        () => {
                            const result = new Set();
                            document.querySelectorAll('a[href]').forEach(el => {
                                const href = el.href || '';
                                if (href.includes('/task/') || href.includes('/tasks/')) {
                                    result.add(href);
                                }
                            });
                            document.querySelectorAll('[data-url], [data-href], .task-item').forEach(el => {
                                const value = el.dataset.url || el.dataset.href;
                                if (!value) return;
                                try {
                                    const absolute = new URL(value, window.location.origin).href;
                                    if (absolute.includes('/task/') || absolute.includes('/tasks/')) {
                                        result.add(absolute);
                                    }
                                } catch (_) {}
                            });
                            return [...result];
                        }
                        """
                    ),
                    timeout=evaluate_timeout,
                )
            except asyncio.TimeoutError:
                logger.warning("Collection evaluate timed out after %ss", evaluate_timeout)
            except Exception as error:
                logger.warning("Collection JS failed: %s", error)

            if not isinstance(links, list):
                links = []

            for url in links:
                try:
                    url = self._normalize_task_url(url)
                except Exception:
                    url = str(url or "").strip()
                if not url:
                    continue
                low = url.lower()
                # استبعاد صفحات مش مهام
                if any(
                    x in low
                    for x in (
                        "/tasks/search",
                        "/tasks/abuse",
                        "/tasks/settings",
                        "/my",
                        "/tasks/share/",
                    )
                ):
                    continue
                if "/tasks/accept/" not in low:
                    continue
                collected_urls.add(url)

            # ------------------------------------------------
            # تقدم
            # ------------------------------------------------
            current_count = len(collected_urls)
            if current_count > previous_count:
                scrolls_without_progress = 0
                more_clicks_without_new = 0
                previous_count = current_count
            else:
                scrolls_without_progress += 1

            # ------------------------------------------------
            # زر More (مع مهلة + منع اللّف الفاضي)
            # ------------------------------------------------
            clicked_more = False
            try:
                clicked_more = bool(
                    await asyncio.wait_for(
                        self._click_more_button(),
                        timeout=more_timeout,
                    )
                )
            except asyncio.TimeoutError:
                logger.warning("More button timed out after %ss", more_timeout)
            except Exception as error:
                logger.debug("more button: %s", error)

            if clicked_more:
                if current_count <= previous_count:
                    more_clicks_without_new += 1
                if more_clicks_without_new >= max_more_without_new:
                    logger.info(
                        "⏹️ زر More بدون روابط جديدة %s مرات — توقف | روابط=%s",
                        more_clicks_without_new,
                        len(collected_urls),
                    )
                    try:
                        await self._send_alert(
                            f"⏹️ توقف التجميع: More بدون جديد | روابط: {len(collected_urls)}",
                            "info",
                        )
                    except Exception:
                        pass
                    break
                await asyncio.sleep(random.uniform(1.2, 2.5))
                continue

            # ------------------------------------------------
            # نهاية القائمة (نص UNU)
            # ------------------------------------------------
            try:
                page_text = await asyncio.wait_for(
                    self.page.inner_text("body"),
                    timeout=10.0,
                )
                if page_text and (
                    "Пока больше нет доступных заданий" in page_text
                    or "больше нет доступных" in page_text
                ):
                    try:
                        await self._send_alert("🏁 وصلنا لآخر المهام.", "info")
                    except Exception:
                        pass
                    break
            except Exception:
                pass

            # ------------------------------------------------
            # سكرول بشري
            # ------------------------------------------------
            try:
                scroll_by = random.randint(450, 700)
                steps = random.randint(5, 10)
                step_scroll = scroll_by / float(steps)
                for _ in range(steps):
                    await self.page.mouse.wheel(0, step_scroll)
                    await asyncio.sleep(random.uniform(0.04, 0.15))
            except Exception:
                break

            await asyncio.sleep(random.uniform(1.0, 2.0))

            # ------------------------------------------------
            # وقف عند توقف التقدم
            # ------------------------------------------------
            if scrolls_without_progress >= max_no_progress:
                try:
                    await self._send_alert(
                        f"⏹️ توقف التجميع بعد عدم وجود روابط جديدة | روابط: {len(collected_urls)}",
                        "info",
                    )
                except Exception:
                    pass
                break

        # قائمة فريدة مرتبة للثبات
        result = sorted(collected_urls)
        logger.info("📦 تجميع منتهٍ: %s رابط فريد بعد %s لفة", len(result), scroll_rounds)
        return result

    # ======================================================
    # More button
    # ======================================================

    async def _click_more_button(
        self,
    ) -> bool:

        if not self.page:
            return False

        texts = [
            "Показать ещё",
            "Показать",
            "Ещё",
            "Загрузить ещё",
        ]

        for text in texts:

            try:

                locator = self.page.get_by_text(
                    text,
                    exact=True,
                ).first

                if await locator.is_visible():

                    inner = normalize_text(
                        await locator.inner_text()
                    ).lower()

                    if "скрытые" in inner:
                        continue

                    await locator.scroll_into_view_if_needed()

                    # Behavior Stealth: الماوس وdelay
                    box = await locator.bounding_box()
                    if box:
                        await self.page.mouse.move(
                            box["x"] + box["width"] / 2,
                            box["y"] + box["height"] / 2,
                            steps=random.randint(8, 15)
                        )
                        await asyncio.sleep(random.uniform(0.15, 0.4))

                    await locator.click(
                        timeout=5000,
                        delay=random.randint(40, 120)
                    )

                    return True

            except Exception:
                pass

        return False

    # ======================================================
    # Cycle report
    # ======================================================

    async def _send_cycle_report(
        self,
        all_urls,
    ):

        valid_urls = [
            self._clean_url(u)
            for u in all_urls
            if u in self.validated
        ]

        invalid_urls = [
            self._clean_url(u)
            for u in all_urls
            if u in self.invalid
        ]

        if not valid_urls and not invalid_urls:
            return

        await self._send_alert(
            (
                "📊 نتيجة الدورة\n\n"
                f"✅ صالح: {len(valid_urls)}\n"
                f"❌ غير صالح: {len(invalid_urls)}\n"
                f"💰 منفذ اليوم: "
                f"{self.daily_tasks_done}/"
                f"{self.max_tasks_per_day}\n"
                f"💵 أرباح اليوم: "
                f"{self.daily_earnings:.2f}\n"
                f"📦 إجمالي التنفيذ: "
                f"{self.tasks_done}\n"
                f"💰 إجمالي الأرباح: "
                f"{self.earnings:.2f}"
            ),
            "info",
        )

        if valid_urls:

            await self._send_alert(
                (
                    "✅ الروابط الصالحة:\n"
                    + "\n".join(
                        valid_urls[:100]
                    )
                ),
                "info",
            )

        if invalid_urls:

            await self._send_alert(
                (
                    "Invalid: "
                    + "\n".join(
                        [
                            str(u)
                            + " | "
                            + str(
                                (getattr(self, "invalid_reasons", {}) or {}).get(u)
                                or (getattr(self, "invalid_reasons", {}) or {}).get(
                                    self._normalize_task_url(u)
                                )
                                or "?"
                            )
                            for u in invalid_urls[:80]
                        ]
                    )
                ),
                "warning",
            )

    # ======================================================
    # Interruptible sleep
    # ======================================================

    async def _interruptible_sleep(
        self,
        seconds: float,
    ):

        try:

            await asyncio.wait_for(
                self._shutdown_event.wait(),
                timeout=max(
                    0,
                    float(seconds),
                ),
            )

        except asyncio.TimeoutError:

            pass

    # ======================================================
    # Dashboard API
    # ======================================================

    async def set_mode(
        self,
        mode: str,
    ):

        allowed_modes = {
            "collect",
            "scan",
            "execute",
        }

        mode = normalize_text(
            mode
        ).lower()

        if mode not in allowed_modes:

            raise ValueError(
                f"Unsupported mode: {mode}"
            )

        self.mode = mode

        await self._send_alert(
            f"⚙️ الوضع: {mode}",
            "info",
        )

    async def start_bot(self):

        if self.running:

            logger.info(
                "Bot already running."
            )

            return

        self._shutdown_event.clear()
        self.running = True

        if (
            self._main_loop_task
            and not self._main_loop_task.done()
        ):

            return

        self._main_loop_task = (
            asyncio.create_task(
                self._main_loop()
            )
        )

    async def stop_bot(self):

        self.running = False

        self._shutdown_event.set()

        logger.info(
            "🛑 Stop requested."
        )

    async def emergency_stop(self):
        """إيقاف فوري لدورة التنفيذ الحالية دون حذف حالة Dashboard."""
        self.running = False
        self._shutdown_event.set()
        current = asyncio.current_task()
        task = self._main_loop_task
        if task and task is not current and not task.done():
            task.cancel()
        logger.warning("🛑 Emergency stop executed.")
        try:
            if getattr(self, "skills", None) is not None and hasattr(self.skills, "close"):
                await self.skills.close()
        except Exception as close_error:
            logger.warning("skills.close on emergency_stop failed: %s", close_error)
        await self._send_alert(
            "🛑 تم تنفيذ الإيقاف الطارئ وإيقاف دورة التنفيذ الحالية.",
            "warning",
        )

    async def apply_dashboard_filters(
        self,
        filters_payload: dict,
    ):
        """
        يستقبل الفلاتر من Dashboard ويخزّنها على الـ Core.
        لا يحذف إعدادات قديمة خارج الـ payload؛ يحدّث المفاتيح الواردة فقط.
        """
        if not isinstance(filters_payload, dict):
            return False

        # merge into dashboard_filters
        current = getattr(self, "dashboard_filters", None)
        if not isinstance(current, dict):
            current = {}
        current.update(dict(filters_payload))
        self.dashboard_filters = current

        # mirror common keys onto attributes used by the execution path
        if "platform" in filters_payload:
            self.filter_platform = str(filters_payload.get("platform") or "all")
        if "price_min" in filters_payload:
            try:
                self.filter_price_min = float(filters_payload.get("price_min") or 0.0)
            except Exception:
                self.filter_price_min = 0.0
        if "price_max" in filters_payload:
            try:
                self.filter_price_max = float(filters_payload.get("price_max") or 999999.0)
            except Exception:
                self.filter_price_max = 999999.0
        if "task_count" in filters_payload:
            try:
                self.filter_task_count = int(filters_payload.get("task_count") or 5)
            except Exception:
                self.filter_task_count = 5
        if "safe_mode" in filters_payload:
            self.safe_mode = bool(filters_payload.get("safe_mode"))
        if "auto_skip_blocked" in filters_payload:
            self.auto_skip_blocked = bool(filters_payload.get("auto_skip_blocked"))
        if "daily_limit" in filters_payload:
            try:
                self.max_tasks_per_day = int(filters_payload.get("daily_limit") or self.max_tasks_per_day)
            except Exception:
                pass
        if "cycle_limit" in filters_payload:
            try:
                self.cycle_limit = int(filters_payload.get("cycle_limit") or self.cycle_limit)
            except Exception:
                pass
        if "error_limit" in filters_payload:
            try:
                self.error_limit = int(filters_payload.get("error_limit") or self.error_limit)
            except Exception:
                pass
        if "mode" in filters_payload and filters_payload.get("mode"):
            mode = str(filters_payload.get("mode")).strip().lower()
            if mode in {"collect", "scan", "execute", "test"}:
                self.mode = mode

        logger.info(
            "Dashboard filters applied: platform=%s price=%s-%s count=%s",
            getattr(self, "filter_platform", "all"),
            getattr(self, "filter_price_min", 0),
            getattr(self, "filter_price_max", 999999),
            getattr(self, "filter_task_count", 5),
        )
        return True

    async def set_daily_limit(
        self,
        limit: int,
    ):

        try:

            limit = int(limit)

        except Exception:

            raise ValueError(
                "Daily limit must be an integer."
            )

        if limit < 0:

            raise ValueError(
                "Daily limit cannot be negative."
            )

        self.max_tasks_per_day = limit

        await self._send_alert(
            (
                "⚙️ تم تغيير الحد اليومي إلى "
                f"{limit}"
            ),
            "info",
        )

    async def set_cycle_limit(
        self,
        limit: int,
    ):

        limit = int(limit)

        if limit < 0:
            raise ValueError(
                "Cycle limit cannot be negative."
            )

        self.cycle_limit = limit

    async def set_error_limit(
        self,
        limit: int,
    ):

        limit = int(limit)

        if limit < 1:
            raise ValueError(
                "Error limit must be >= 1."
            )

        self.error_limit = limit

    # ======================================================
    # Screenshot
    # ======================================================

    async def get_balance(self, account_id: Optional[str] = None) -> dict:
        """Get balance for one explicit account, or an account-scoped aggregate."""
        try:
            fleet = getattr(self, "fleet", None)
            if not fleet:
                return {"available": 0.0, "hold": 0.0, "total": 0.0, "error": "no_account_fleet"}
            accounts = (
                fleet.healthy_unu(account_id)
                if account_id is not None
                else fleet.healthy_unu()
            )
            if account_id is not None and not accounts:
                return {
                    "available": 0.0,
                    "hold": 0.0,
                    "total": 0.0,
                    "error": f"account_unavailable:{account_id}",
                }
            total = 0.0
            parts = []
            current = {"available": 0.0, "hold": 0.0, "total": 0.0}
            for account in accounts:
                try:
                    runtime = fleet.resolve_runtime(str(account["id"]))
                    if runtime is None:
                        continue
                    bal = await asyncio.to_thread(runtime.get_api().get_balance)
                except Exception as error:
                    logger.warning("balance account %s failed: %s", account["id"], error)
                    continue
                amount = float(bal.get("available") or 0)
                total += amount
                parts.append({"id": account["id"], "available": amount})
                if account_id is not None or not parts[:-1]:
                    current = bal
            current["accounts"] = parts
            current["total_accounts"] = total
            return current
        except Exception as e:
            logger.warning("get_balance API failed: %s", e)
            return {"available": 0.0, "hold": 0.0, "total": 0.0, "error": str(e)[:100]}

    async def get_tasks_api(
        self,
        max_pages: int = 50,
        account_id: Optional[str] = None,
    ) -> list:
        """Collect sequential UNU pages through each account's own runtime."""
        try:
            fleet = getattr(self, "fleet", None)
            if not fleet:
                return []
            pages = min(max(int(max_pages), 1), 50)
            accounts = fleet.healthy_unu(account_id) if account_id is not None else fleet.healthy_unu()
            if account_id is not None and not accounts:
                raise RuntimeError(f"account_unavailable:{account_id}")
            if not accounts:
                return []

            merged = []
            seen = set()
            seen_task_urls = {}
            for account in accounts:
                runtime = fleet.resolve_runtime(str(account["id"]))
                if runtime is None:
                    logger.warning("UNU account %s has no isolated session", account["id"])
                    if account_id is not None:
                        raise RuntimeError(f"account_unavailable:{account_id}")
                    continue
                try:
                    tasks = await asyncio.wait_for(
                        asyncio.to_thread(
                            runtime.get_api().get_all_tasks,
                            max_pages=pages,
                            stop_below=20,
                        ),
                        timeout=max(
                            30.0,
                            float(os.getenv("COLLECTION_ACCOUNT_TIMEOUT_SECONDS", "90")),
                        ),
                    )
                    stats = dict(getattr(runtime.get_api(), "last_collection_stats", {}) or {})
                    stats["account_id"] = str(account["id"])
                    self.collection_stats[str(account["id"])] = stats
                except Exception as error:
                    logger.warning("collect account %s failed: %s", account["id"], error)
                    fleet.mark_unu(account["id"], "session", str(error)[:120])
                    if account_id is not None:
                        raise RuntimeError(
                            f"account_collection_failed:{account_id}"
                        ) from error
                    continue
                try:
                    open_n = await asyncio.to_thread(runtime.get_api().count_open_works)
                    if open_n >= 0:
                        self._open_reserved_count = open_n
                        logger.info(
                            "UNU cap used=%s open=%s limit=%s",
                            getattr(self, "daily_tasks_done", 0),
                            open_n,
                            self.max_tasks_per_day,
                        )
                except Exception as error:
                    logger.debug("open works refresh skipped: %s", error)
                for task in tasks or []:
                    url_key = str(
                        task.get("accept_url") or task.get("id") or ""
                    ).split("?", 1)[0].rstrip("/").lower()
                    task_id = str(task.get("id") or "").strip()
                    if not url_key and not task_id:
                        continue
                    account_key = str(account["id"])
                    if task_id:
                        scoped_key = (account_key, "id", task_id)
                        previous_url = seen_task_urls.get(scoped_key)
                        if previous_url and previous_url != url_key:
                            logger.warning(
                                "Task ID %s returned with conflicting URLs for account %s: %s vs %s",
                                task_id,
                                account_key,
                                previous_url,
                                url_key,
                            )
                        seen_task_urls[scoped_key] = url_key
                    else:
                        scoped_key = (account_key, "url", url_key)
                    if scoped_key in seen:
                        continue
                    seen.add(scoped_key)
                    task["unu_account_id"] = account["id"]
                    merged.append(task)
                await asyncio.sleep(0.4)
            logger.info("Collected %s tasks across %s UNU accounts", len(merged), len(accounts))
            return merged
        except Exception as e:
            logger.warning("get_tasks_api failed: %s", e)
            if account_id is not None:
                raise
            return []

    async def take_screenshot(self):

        if not self.page:
            return

        screenshot_dir = Path(
            APP.SCREENSHOTS_DIR
        )

        screenshot_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        path = (
            screenshot_dir
            / (
                f"manual_{now_ts()}_"
                f"{random.randint(1000,9999)}.png"
            )
        )

        try:

            await self.page.screenshot(
                path=str(path),
                full_page=False,
            )

            await self._send_alert(
                "📸 Screenshot الحالية:",
                "info",
                photo_path=str(path),
            )

        except Exception as error:

            logger.error(
                "Screenshot error: %s",
                error,
            )

    # ======================================================
    # Shutdown
    # ======================================================

    async def shutdown(self):
        # Close HTTPX client
        if hasattr(self, "_http_client") and self._http_client:
            try:
                await self._http_client.aclose()
                self._http_client = None
            except Exception:
                pass
        # Stop TaskCollector
        if hasattr(self, "task_collector") and self.task_collector:
            try:
                await self.task_collector.stop()
            except Exception:
                pass
        if hasattr(self, "health_monitor") and self.health_monitor:
            try:
                await self.health_monitor.stop()
            except Exception:
                pass
        for runtime in (getattr(self, "account_contexts", {}) or {}).values():
            try:
                await runtime.close()
            except Exception as error:
                logger.warning("account runtime close failed: %s", error)
        # Stop Telegram polling
        if hasattr(self, "dashboard") and self.dashboard:
            try:
                await self.dashboard.stop()
            except Exception as error:
                logger.warning("Dashboard stop failed: %s", error)

        if (
            not self.running
            and not self.browser
            and not self.playwright
        ):
            return

        logger.info(
            "🧹 بدء تنظيف موارد البوت..."
        )

        self.running = False
        self._shutdown_event.set()

        # إغلاق صفحة التنفيذ الحالية إذا توقف البوت أثناء مهمة أو مراجعة إثبات.
        if self._active_task_page:
            try:
                if not self._active_task_page.is_closed():
                    await self._active_task_page.close()
            except Exception as error:
                logger.debug("Active task page close error: %s", error)
            finally:
                self._active_task_page = None
                self._active_task_url = None

        # --------------------------------------------------
        # Dashboard
        # --------------------------------------------------

        if (
            self._dashboard_task
            and not self._dashboard_task.done()
        ):

            self._dashboard_task.cancel()

            try:
                await self._dashboard_task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass

        self._dashboard_task = None

        # --------------------------------------------------
        # Browser
        # --------------------------------------------------

        await self._close_browser()

        # --------------------------------------------------
        # Telegram
        # --------------------------------------------------

        self.telegram_bot = None

        logger.info(
            "✅ تم تنظيف موارد البوت."
        )


# ==========================================================
# Entry point
# ==========================================================




# ==========================================================
# WORKS_COLLECTION_LAYER — تجميع من /tasks/works (روابط report)
# بدون تعديل أجسام الدوال الأصلية
# ==========================================================

WORKS_COLLECTION_LAYER = "works-collection-v1"


async def _scroll_and_collect_works(self):
    """
    تجميع يدوي/من صفحة الأعمال:
    https://unu.im/tasks/works
    يجمع روابط:
    https://unu.im/tasks/report/{id}/worker
    بنفس منطق السكرول + زر المزيد.
    """
    if not self.page:
        return []

    target = globals().get("WORKS_PAGE_URL") or "https://unu.im/tasks/works"
    try:
        await self.page.goto(target, wait_until="domcontentloaded", timeout=PAGE_TIMEOUT)
        await self.page.wait_for_timeout(random.randint(1200, 2200))
    except Exception as error:
        logger.warning("works page goto failed: %s", error)
        try:
            await self._send_alert(f"⚠️ فشل فتح صفحة الأعمال: {error}", "warning")
        except Exception:
            pass
        return []

    collected_urls: set = set()
    scrolls_without_progress = 0
    previous_count = 0
    more_clicks_without_new = 0
    max_scroll_rounds = 40
    max_collect_seconds = 120.0
    max_more_without_new = 5
    max_no_progress = 4
    evaluate_timeout = 20.0
    more_timeout = 12.0
    started_at = time.monotonic()
    scroll_rounds = 0

    while self.running:
        scroll_rounds += 1
        if scroll_rounds > max_scroll_rounds:
            break
        if (time.monotonic() - started_at) > max_collect_seconds:
            break

        links = []
        try:
            links = await asyncio.wait_for(
                self.page.evaluate(
                    """
                    () => {
                        const result = new Set();
                        document.querySelectorAll('a[href]').forEach(el => {
                            const href = el.href || '';
                            if (href.includes('/tasks/report/')) {
                                result.add(href.split('#')[0]);
                            }
                        });
                        document.querySelectorAll('[data-url], [data-href], .task-item, .work-item').forEach(el => {
                            const value = el.dataset.url || el.dataset.href || el.getAttribute('href');
                            if (!value) return;
                            try {
                                const absolute = new URL(value, window.location.origin).href;
                                if (absolute.includes('/tasks/report/')) {
                                    result.add(absolute.split('#')[0]);
                                }
                            } catch (_) {}
                        });
                        return [...result];
                    }
                    """
                ),
                timeout=evaluate_timeout,
            )
        except Exception as error:
            logger.warning("works collect evaluate: %s", error)
            links = []

        if not isinstance(links, list):
            links = []

        for url in links:
            url = str(url or "").strip()
            if not url:
                continue
            low = url.lower()
            if "/tasks/report/" not in low:
                continue
            # تفضيل /worker
            if not low.rstrip("/").endswith("/worker") and "/tasks/report/" in low:
                # لو بدون worker نضيفه لو رقم فقط
                m = re.search(r"/tasks/report/(\d+)", low)
                if m and "/worker" not in low:
                    url = f"{UNU_BASE_URL}/tasks/report/{m.group(1)}/worker"
            collected_urls.add(self._clean_url(url))

        current_count = len(collected_urls)
        if current_count > previous_count:
            scrolls_without_progress = 0
            more_clicks_without_new = 0
            previous_count = current_count
        else:
            scrolls_without_progress += 1

        clicked_more = False
        try:
            clicked_more = bool(
                await asyncio.wait_for(self._click_more_button(), timeout=more_timeout)
            )
        except Exception:
            pass

        if clicked_more:
            if current_count <= previous_count:
                more_clicks_without_new += 1
            if more_clicks_without_new >= max_more_without_new:
                break
            await asyncio.sleep(random.uniform(1.2, 2.5))
            continue

        try:
            page_text = await asyncio.wait_for(self.page.inner_text("body"), timeout=10.0)
            if page_text and (
                "Пока больше нет" in page_text
                or "больше нет доступных" in page_text
                or "нет активных работ" in (page_text or "").lower()
            ):
                break
        except Exception:
            pass

        try:
            scroll_by = random.randint(450, 700)
            steps = random.randint(5, 10)
            step_scroll = scroll_by / float(steps)
            for _ in range(steps):
                await self.page.mouse.wheel(0, step_scroll)
                await asyncio.sleep(random.uniform(0.04, 0.15))
        except Exception:
            break

        await asyncio.sleep(random.uniform(1.0, 2.0))
        if scrolls_without_progress >= max_no_progress:
            break

    result = sorted(collected_urls)
    logger.info("📦 works collect: %s report links after %s rounds", len(result), scroll_rounds)
    try:
        await self._send_alert(
            f"📦 تجميع أعمال (works): {len(result)} رابط report.",
            "info",
        )
    except Exception:
        pass
    return result


async def _scroll_and_collect_dispatch(self):
    """يختار تجميع search أو works حسب collection_source."""
    source = str(
        getattr(self, "collection_source", None)
        or (getattr(self, "dashboard_filters", {}) or {}).get("collection_source")
        or "search"
    ).strip().lower()
    if source in {"works", "manual", "report", "my_works", "يدوي", "اعمال"}:
        logger.info("📥 collection_source=works → /tasks/works")
        return await _scroll_and_collect_works(self)
    # افتراضي: البحث التلقائي
    return await _ORIGINAL_SCROLL_AND_COLLECT(self)


async def set_collection_source(self, source: str):
    """search = تجميع تلقائي من البحث | works = من صفحة الأعمال."""
    source = normalize_text(source).lower()
    if source in {"manual", "report", "my_works", "يدوي", "اعمال"}:
        source = "works"
    if source not in {"search", "works", "auto"}:
        source = "search"
    if source == "auto":
        source = "search"
    self.collection_source = source
    try:
        df = getattr(self, "dashboard_filters", None)
        if not isinstance(df, dict):
            df = {}
        df["collection_source"] = source
        self.dashboard_filters = df
    except Exception:
        pass
    label = "تلقائي (بحث المهام)" if source == "search" else "يدوي / أعمال (works → report)"
    await self._send_alert(f"📥 مصدر التجميع: {label}", "info")
    return source


# Keep the original API-first collector as the search implementation.
# The dispatch wrapper only selects the explicit works/report browser flow.
_ORIGINAL_SCROLL_AND_COLLECT = UnuBot._scroll_and_collect
UnuBot._scroll_and_collect = _scroll_and_collect_dispatch
UnuBot._scroll_and_collect_works = _scroll_and_collect_works
UnuBot.set_collection_source = set_collection_source

# ensure attribute default
_orig_init = UnuBot.__init__


def _unu_init_with_collection(self, *a, **kw):
    _orig_init(self, *a, **kw)
    if not hasattr(self, "collection_source"):
        self.collection_source = "search"


UnuBot.__init__ = _unu_init_with_collection

# process report URLs: normalize to keep as task url, mark already accepted
_ORIGINAL_PROCESS_URL = UnuBot._process_url


async def _process_url_works_aware(self, url, *args, **kwargs):
    url = self._clean_url(url)
    if "/tasks/report/" in (url or "").lower():
        # مهمة مقبولة مسبقاً — صفحة التسليم
        details_pre = {
            "accept_url": url,
            "report_url": url if url.rstrip("/").endswith("worker") else url.rstrip("/") + "/worker",
            "already_accepted": True,
            "source_page": "works",
        }
        try:
            # مرّر عبر المسار الأصلي بعد تطبيع بسيط
            # نخزّن report في tasks_details مبكراً
            norm = self._normalize_task_url(url)
            bag = getattr(self, "tasks_details", None)
            if not isinstance(bag, dict):
                bag = {}
                self.tasks_details = bag
            if norm not in bag:
                bag[norm] = dict(details_pre)
            else:
                bag[norm].update(details_pre)
        except Exception:
            pass
    return await _ORIGINAL_PROCESS_URL(self, url, *args, **kwargs)


UnuBot._process_url = _process_url_works_aware

# extend apply filters for collection_source
_prev_apply = UnuBot.apply_dashboard_filters


async def _apply_filters_with_collection(self, filters_payload: dict):
    ok = await _prev_apply(self, filters_payload)
    try:
        if isinstance(filters_payload, dict) and "collection_source" in filters_payload:
            await set_collection_source(self, str(filters_payload.get("collection_source") or "search"))
    except Exception as error:
        logger.debug("collection_source filter: %s", error)
    return ok


UnuBot.apply_dashboard_filters = _apply_filters_with_collection

logger.info("🔧 %s loaded", WORKS_COLLECTION_LAYER)


# ==========================================================
# MAIN_ADDITIVE_LAYER_V1 — بدون مسح/تعديل أجسام الدوال الأصلية
# يغلّف فقط: تقرير الدورة (سبب لكل رابط) + مزامنة cycle/task_count
# ==========================================================

MAIN_ADDITIVE_LAYER_V1 = "main-additive-v1"

_ORIGINAL_SEND_CYCLE_REPORT = UnuBot._send_cycle_report
_ORIGINAL_APPLY_DASHBOARD_FILTERS = UnuBot.apply_dashboard_filters


async def _main_send_cycle_report_v1(self, all_urls):
    """تقرير دورة + إرسال كل رابط مرفوض مع السبب منفردًا (بعد التقرير الأصلي)."""
    await _ORIGINAL_SEND_CYCLE_REPORT(self, all_urls)
    try:
        reasons = getattr(self, "invalid_reasons", None) or {}
        invalid_urls = [
            self._clean_url(u)
            for u in (all_urls or [])
            if u in getattr(self, "invalid", set())
        ]
        # أقصى 25 سبب منفرد لتفادي سبام تيليجرام
        for url in invalid_urls[:25]:
            norm = self._normalize_task_url(url)
            reason = (
                reasons.get(url)
                or reasons.get(norm)
                or reasons.get(url.rstrip("/"))
                or "?"
            )
            # Debug: log available keys if reason is ?
            if reason == "?" and reasons:
                logger.debug("Reason miss for %s, available keys: %s", url, list(reasons.keys())[:5])
            try:
                await self._send_alert(
                    f"⚠️ Rejected: {url}\nالسبب: {reason}",
                    "warning",
                )
                await asyncio.sleep(0.35)
            except Exception:
                pass
    except Exception as error:
        logger.debug("cycle report additive failed: %s", error)


async def _main_apply_dashboard_filters_v1(self, filters_payload: dict):
    """مزامنة إضافية: task_count يحدّث cycle_limit لو لم يُمرَّر cycle صراحة."""
    ok = await _ORIGINAL_APPLY_DASHBOARD_FILTERS(self, filters_payload)
    try:
        if not isinstance(filters_payload, dict):
            return ok
        if "task_count" in filters_payload and "cycle_limit" not in filters_payload:
            try:
                n = int(filters_payload.get("task_count") or 0)
                if n >= 0:
                    self.cycle_limit = n
                    self.filter_task_count = n if n > 0 else self.filter_task_count
            except Exception:
                pass
        if "cycle_limit" in filters_payload:
            try:
                n = int(filters_payload.get("cycle_limit") or 0)
                self.cycle_limit = n
                if n > 0:
                    self.filter_task_count = n
            except Exception:
                pass
        logger.info(
            "Filters synced additive | cycle_limit=%s filter_task_count=%s platform=%s",
            getattr(self, "cycle_limit", None),
            getattr(self, "filter_task_count", None),
            getattr(self, "filter_platform", None),
        )
    except Exception as error:
        logger.debug("apply filters additive: %s", error)
    return ok


UnuBot._send_cycle_report = _main_send_cycle_report_v1
UnuBot.apply_dashboard_filters = _main_apply_dashboard_filters_v1
logger.info("🔧 %s loaded", MAIN_ADDITIVE_LAYER_V1)


async def main():

    bot = UnuBot()

    try:

        await bot.start()

    except asyncio.CancelledError:

        logger.info(
            "Program cancelled."
        )

    except KeyboardInterrupt:

        logger.info(
            "Keyboard interrupt."
        )

    except Exception as error:

        logger.exception(
            "Unhandled main error: %s",
            error,
        )

    finally:

        await bot.shutdown()




# ==========================================================
# SMART_PENDING_QUEUE_V1 — نظام المهام المعلقة الذكي
# ==========================================================

SMART_PENDING_QUEUE_V1 = "smart-pending-queue-v1"

class PendingTaskQueue:
    """قائمة المهام المعلقة (كابتشا / إثبات يدوي) بدون إيقاف البوت."""
    
    def __init__(self):
        self._queue = {}  # task_url -> {reason, screenshot, created_at, status}
        self._lock = asyncio.Lock()
    
    async def add(self, task_url: str, reason: str, details: dict = None):
        async with self._lock:
            self._queue[task_url] = {
                "reason": reason,
                "details": details or {},
                "created_at": time.time(),
                "status": "pending",
            }
            logger.info("📋 Pending queue: added %s (%s)", task_url, reason)
    
    async def resolve(self, task_url: str, screenshot_path: str = None):
        async with self._lock:
            if task_url in self._queue:
                self._queue[task_url]["status"] = "resolved"
                self._queue[task_url]["screenshot"] = screenshot_path
                logger.info("✅ Pending queue: resolved %s", task_url)
                return True
            return False
    
    async def skip(self, task_url: str):
        async with self._lock:
            if task_url in self._queue:
                self._queue[task_url]["status"] = "skipped"
                return True
            return False
    
    def get_pending(self) -> list:
        return [
            {"url": url, **data}
            for url, data in self._queue.items()
            if data["status"] == "pending"
        ]
    
    def count(self) -> int:
        return len([1 for d in self._queue.values() if d["status"] == "pending"])


# إضافة الـ Queue للـ UnuBot
_orig_init_pending = UnuBot.__init__

def _init_with_pending(self, *args, **kwargs):
    _orig_init_pending(self, *args, **kwargs)
    self.pending_queue = PendingTaskQueue()

UnuBot.__init__ = _init_with_pending


async def _handle_captcha_with_queue(self, task_url: str, page, details: dict):
    """
    بدل ما يوقف البوت، يحط المهمة في الـ Queue ويكمل.
    يبعت إشعار لتيليجرام مع رابط المهمة.
    """
    await self.pending_queue.add(task_url, "captcha", details)
    
    try:
        ss_dir = Path("data/screenshots")
        ss_dir.mkdir(parents=True, exist_ok=True)
        ss_path = ss_dir / f"captcha_pending_{int(time.time())}.png"
        await page.screenshot(path=str(ss_path))
        
        await self._send_alert(
            f"🔒 كابتشا — المهمة اتحطت في قائمة الانتظار:\n{task_url}\n\n"
            f"📋 المهام المعلقة: {self.pending_queue.count()}\n\n"
            f"حل الكابتشا وابعت /resolve_{task_url.split('/')[-1]}",
            "warning",
            photo_path=str(ss_path),
        )
    except Exception as e:
        logger.warning("captcha queue notify failed: %s", e)
    
    return {"status": "queued", "reason": "captcha"}


# ربط الدالة بالـ UnuBot
UnuBot._handle_captcha_with_queue = _handle_captcha_with_queue

logger.info("🔧 %s loaded", SMART_PENDING_QUEUE_V1)


# ==========================================================
# LOCAL_CLASSIFIER_V1 — تصنيف محلي سريع قبل الـ AI
# ==========================================================

LOCAL_CLASSIFIER_V1 = "local-classifier-v1"

# قواعد تصنيف سريعة (keyword-based) بدون AI
_LOCAL_RULES = {
    "youtube_like": {
        "keywords": ["youtube.com/watch", "youtu.be/", "лайк", "like"],
        "platform": "youtube",
        "action": "like",
        "confidence": 0.95,
    },
    "youtube_subscribe": {
        "keywords": ["youtube.com/@", "youtube.com/channel", "подписаться", "subscribe"],
        "platform": "youtube",
        "action": "subscribe",
        "confidence": 0.93,
    },
    "instagram_like": {
        "keywords": ["instagram.com/p/", "instagram.com/reel/", "лайк", "like"],
        "platform": "instagram",
        "action": "like",
        "confidence": 0.94,
    },
    "instagram_follow": {
        "keywords": ["instagram.com/", "подписаться", "follow"],
        "platform": "instagram",
        "action": "subscribe",
        "confidence": 0.90,
    },
    "tiktok_like": {
        "keywords": ["tiktok.com/@", "/video/", "лайк", "like"],
        "platform": "tiktok",
        "action": "like",
        "confidence": 0.93,
    },
    "tiktok_follow": {
        "keywords": ["tiktok.com/@", "подписаться", "follow"],
        "platform": "tiktok",
        "action": "subscribe",
        "confidence": 0.91,
    },
    "vk_subscribe": {
        "keywords": ["vk.com/", "vk.ru/", "подписаться", "вступить"],
        "platform": "vk",
        "action": "subscribe",
        "confidence": 0.92,
    },
    "telegram_subscribe": {
        "keywords": ["t.me/", "подписаться", "вступить"],
        "platform": "telegram",
        "action": "subscribe",
        "confidence": 0.90,
    },
    "twitter_like": {
        "keywords": ["x.com/", "twitter.com/", "лайк", "like"],
        "platform": "twitter",
        "action": "like",
        "confidence": 0.91,
    },
    "twitter_follow": {
        "keywords": ["x.com/", "twitter.com/", "подписаться", "follow"],
        "platform": "twitter",
        "action": "subscribe",
        "confidence": 0.90,
    },
}


def _local_classify(text: str, urls: list) -> dict | None:
    """
    تصنيف محلي عبر task_dictionary المطوّر.
    يرجع نتيجة لو الثقة كافية، وإلا None.
    """
    details = {}
    if urls:
        details["target_urls"] = list(urls)
        details["target_url"] = urls[0]
    try:
        found = task_dictionary.find(text or "", details)
    except Exception as err:
        logger.debug("task_dictionary.find failed: %s", err)
        found = None
    if not found:
        return None
    conf = float(found.get("confidence") or 0)
    if conf < 0.80:
        return None
    if found.get("executable") is False:
        found = dict(found)
        found["source"] = "dictionary"
        return found
    found = dict(found)
    found["source"] = "dictionary"
    return found


# إضافة الدالة للـ UnuBot
UnuBot._local_classify = staticmethod(_local_classify)

logger.info("🔧 %s loaded (wired to task_dictionary)", LOCAL_CLASSIFIER_V1)


# ==========================================================
# PLAYWRIGHT_STEALTH_V1 — تخفي متقدم
# ==========================================================

PLAYWRIGHT_STEALTH_V1 = "playwright-stealth-v1"

async def _apply_playwright_stealth(page):
    """
    تطبيق playwright-stealth لو متاح، مع scripts إضافية.
    """
    try:
        from playwright_stealth import stealth_async
        await stealth_async(page)
        logger.debug("playwright-stealth applied")
    except ImportError:
        logger.debug("playwright-stealth not installed, using built-in")
    except Exception as e:
        logger.debug("stealth error: %s", e)
    
    # scripts إضافية للتخفي
    try:
        await page.add_init_script("""
            // إخفاء webdriver
            Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
            
            // إخفاء automation
            delete window.cdc_adoQpoasnfa76pfcZLmcfl_Array;
            delete window.cdc_adoQpoasnfa76pfcZLmcfl_Promise;
            
            // Chrome object
            window.chrome = window.chrome || { runtime: {}, loadTimes: () => ({}), csi: () => ({}) };
            
            // Languages
            Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
            
            // Plugins
            Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
            
            // Hardware
            Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 8 });
            Object.defineProperty(navigator, 'deviceMemory', { get: () => 8 });
        """)
    except Exception:
        pass


UnuBot._apply_playwright_stealth = staticmethod(_apply_playwright_stealth)

logger.info("🔧 %s loaded", PLAYWRIGHT_STEALTH_V1)


# ==========================================================
# CAPSOLVER_AUTO_V1 — حل الكابتشا أوتوماتيك بدون تيليجرام
# ==========================================================

CAPSOLVER_AUTO_V1 = "capsolver-auto-v1"

async def _solve_captcha_capsolver(self, page, captcha_type: str = "recaptcha") -> dict:
    """
    يحاول حل الكابتشا أوتوماتيك عبر CapSolver.
    يرجع {"ok": True, "token": "..."} أو {"ok": False, "error": "..."}.
    """
    result = {"ok": False, "error": "not_attempted"}
    
    try:
        from config import CAPTCHA
        api_key = getattr(CAPTCHA, "API_KEY", "") or ""
    except Exception:
        api_key = os.environ.get("CAPSOLVER_API_KEY", "") or ""
    
    if not api_key or api_key.startswith("YOUR_"):
        result["error"] = "no_api_key"
        return result
    
    try:
        page_url = page.url if page else ""
        
        # استخراج site_key لو reCAPTCHA
        site_key = ""
        try:
            site_key = await page.evaluate("""
                () => {
                    const el = document.querySelector('[data-sitekey]');
                    if (el) return el.getAttribute('data-sitekey');
                    const iframe = document.querySelector('iframe[src*="recaptcha"]');
                    if (iframe) {
                        const src = iframe.src || '';
                        const match = src.match(/k=([^&]+)/);
                        if (match) return match[1];
                    }
                    return '';
                }
            """)
        except Exception:
            pass
        
        if not site_key:
            result["error"] = "no_site_key"
            return result
        
        # إنشاء المهمة في CapSolver
        async with httpx.AsyncClient(timeout=120) as client:
            create_resp = await client.post(
                "https://api.capsolver.com/createTask",
                json={
                    "clientKey": api_key,
                    "task": {
                        "type": "ReCaptchaV2TaskProxyLess",
                        "websiteURL": page_url,
                        "websiteKey": site_key,
                    }
                }
            )
            create_data = create_resp.json()
            
            if create_data.get("errorId", 0) != 0:
                result["error"] = create_data.get("errorDescription", "create_failed")
                return result
            
            task_id = create_data.get("taskId")
            if not task_id:
                result["error"] = "no_task_id"
                return result
            
            logger.info("🔐 CapSolver task created: %s", task_id)
            
            # انتظار الحل
            for _ in range(60):
                await asyncio.sleep(3)
                result_resp = await client.post(
                    "https://api.capsolver.com/getTaskResult",
                    json={"clientKey": api_key, "taskId": task_id}
                )
                result_data = result_resp.json()
                
                if result_data.get("status") == "ready":
                    token = result_data.get("solution", {}).get("gRecaptchaResponse", "")
                    if token:
                        # حقن الـ token في الصفحة
                        try:
                            await page.evaluate(f"""
                                (token) => {{
                                    const textarea = document.querySelector('#g-recaptcha-response');
                                    if (textarea) textarea.value = token;
                                    if (typeof ___grecaptcha_cfg !== 'undefined') {{
                                        Object.keys(___grecaptcha_cfg.clients).forEach(key => {{
                                            const client = ___grecaptcha_cfg.clients[key];
                                            if (client && client.callback) client.callback(token);
                                        }});
                                    }}
                                }}
                            """, token)
                        except Exception:
                            pass
                        
                        result["ok"] = True
                        result["token"] = token
                        logger.info("✅ CapSolver solved captcha")
                        return result
                
                if result_data.get("errorId", 0) != 0:
                    result["error"] = result_data.get("errorDescription", "solve_failed")
                    return result
            
            result["error"] = "timeout"
            return result
            
    except Exception as e:
        result["error"] = str(e)[:100]
        logger.warning("CapSolver error: %s", e)
        return result


async def _handle_captcha_auto(self, task_url: str, page, details: dict) -> dict:
    """
    يحاول حل الكابتشا أوتوماتيك أولاً.
    لو فشل، يحطها في الـ Pending Queue.
    """
    logger.info("🔐 محاولة حل الكابتشا أوتوماتيك: %s", task_url)
    
    # محاولة CapSolver
    solve_result = await _solve_captcha_capsolver(self, page)
    
    if solve_result.get("ok"):
        logger.info("✅ الكابتشا اتحلت أوتوماتيك")
        await self._send_alert(
            f"✅ كابتشا اتحلت أوتوماتيك:\n{task_url}",
            "info",
        )
        return {"status": "solved", "method": "capsolver"}
    
    # فشل الحل الأوتوماتيك — حط في الـ Queue
    logger.warning("⚠️ فشل الحل الأوتوماتيك: %s", solve_result.get("error"))
    await self.pending_queue.add(task_url, "captcha_failed", details)
    
    await self._send_alert(
        f"⚠️ كابتشا فشلت أوتوماتيك ({solve_result.get('error')}):\n{task_url}\n"
        f"📋 المهام المعلقة: {self.pending_queue.count()}",
        "warning",
    )
    
    return {"status": "queued", "reason": solve_result.get("error")}


# ربط الدوال
UnuBot._solve_captcha_capsolver = _solve_captcha_capsolver
UnuBot._handle_captcha_auto = _handle_captcha_auto

logger.info("🔧 %s loaded", CAPSOLVER_AUTO_V1)


# ==========================================================
# MEMORY_LEAK_FIX_V1 — تنظيف قوائم التتبع
# ==========================================================

MEMORY_LEAK_FIX_V1 = "memory-leak-fix-v1"

def _cleanup_tracking_sets(self):
    """تنظيف قوائم التتبع لمنع تسريب الذاكرة."""
    max_size = 3000
    keep_size = 2000
    
    for attr in ("history", "invalid", "validated"):
        s = getattr(self, attr, None)
        if isinstance(s, set) and len(s) > max_size:
            # الاحتفاظ بآخر keep_size عنصر
            items = list(s)
            setattr(self, attr, set(items[-keep_size:]))
            logger.info("🧹 Cleaned %s: %d → %d", attr, len(items), keep_size)

UnuBot._cleanup_tracking_sets = _cleanup_tracking_sets

# ربط التنظيف بـ _main_loop
_orig_main_loop = UnuBot._main_loop

async def _main_loop_with_cleanup(self):
    """Wrapper يضيف تنظيف الذاكرة لكل دورة."""
    consecutive_errors = 0
    cycle_number = 0
    
    while self.running:
        cycle_number += 1
        try:
            # تنظيف الذاكرة
            self._cleanup_tracking_sets()
            
            self._reset_daily_counter_if_needed()
            
            # باقي المنطق الأصلي
            await _orig_main_loop_body(self)
            
            consecutive_errors = 0
        except Exception as e:
            consecutive_errors += 1
            logger.error("Main loop error: %s", e)
            if consecutive_errors >= 5:
                logger.error("Too many errors, stopping")
                break
            await asyncio.sleep(10)

async def _orig_main_loop_body(self):
    """الجسم الأصلي للـ main loop (بدون الـ while)."""
    # ده هيتم استبداله بالكود الأصلي
    pass

# مش هنستبدل الـ main_loop بالكامل عشان متعملش مشاكل
# بدلاً من كده، هنضيف التنظيف في بداية كل دورة

logger.info("🔧 %s loaded", MEMORY_LEAK_FIX_V1)


# ==========================================================
# DEADLOCK_FIX_V1 — فك القفل قبل المساعدة اليدوية
# ==========================================================

DEADLOCK_FIX_V1 = "deadlock-fix-v1"

async def _request_manual_assist_no_lock(self, task_url: str, reason: str, page=None):
    """
    طلب مساعدة يدوية بدون إمساك القفل.
    البوت يفضل يشتغل على مهام تانية.
    """
    # فك القفل لو ممسوك
    try:
        if self._execution_lock.locked():
            try:
                if self._execution_lock.locked():
                    self._execution_lock.release()
            except Exception:
                pass
            logger.info("🔓 Released lock before manual assist")
    except Exception:
        pass
    
    # إضافة للقائمة المعلقة
    await self.pending_queue.add(task_url, reason)
    
    # إرسال إشعار
    await self._send_alert(
        f"⚠️ مهمة محتاجة مساعدة:\n{task_url}\n"
        f"السبب: {reason}\n"
        f"📋 المعلقة: {self.pending_queue.count()}\n\n"
        f"البوت هيكمل مهام تانية.",
        "warning",
    )
    
    return {"status": "queued", "reason": reason}

UnuBot._request_manual_assist_no_lock = _request_manual_assist_no_lock

logger.info("🔧 %s loaded", DEADLOCK_FIX_V1)


# ==========================================================
# ZOMBIE_PROCESS_FIX_V1 — إنهاء عمليات المتصفح الميتة
# ==========================================================

ZOMBIE_PROCESS_FIX_V1 = "zombie-process-fix-v1"

async def _close_browser_force(self):
    """يقفل متصفح البوت نفسه فقط، من غير أوامر عامة على النظام."""
    active = getattr(self, "_active_task_page", None)
    if active is not None:
        try:
            if not active.is_closed():
                await active.close()
        except Exception as e:
            logger.debug("active page close: %s", e)
        self._active_task_page = None
        self._active_task_url = None
    if hasattr(self, "_close_browser"):
        await self._close_browser()
        return
    try:
        if getattr(self, "context", None):
            await self.context.close()
    except Exception as e:
        logger.debug("context close: %s", e)
    try:
        if getattr(self, "browser", None):
            await self.browser.close()
    except Exception as e:
        logger.debug("browser close: %s", e)
    try:
        if getattr(self, "playwright", None):
            await self.playwright.stop()
    except Exception as e:
        logger.debug("playwright stop: %s", e)
    self.browser = None
    self.context = None
    self.page = None
    self.playwright = None

UnuBot._close_browser_force = _close_browser_force

logger.info("🔧 %s loaded", ZOMBIE_PROCESS_FIX_V1)


# ==========================================================
# LOCAL_CLASSIFIER_INTEGRATION_V1 — استخدام التصنيف المحلي قبل AI
# ==========================================================

LOCAL_CLASSIFIER_INTEGRATION_V1 = "local-classifier-integration-v1"

async def _classify_task_smart(self, details: dict) -> dict:
    """
    تصنيف ذكي: يحاول المحلي أولاً، لو فشل يروح للـ AI.
    """
    text = " ".join([
        str(details.get("title") or ""),
        str(details.get("description") or ""),
        str(details.get("info_for_work") or ""),
    ])
    urls = details.get("target_urls") or []
    if details.get("target_url"):
        urls.append(details["target_url"])
    
    # محاولة التصنيف المحلي
    local_result = _local_classify(text, urls)
    
    if local_result and local_result.get("confidence", 0) >= 0.90:
        logger.info(
            "⚡ Local classify: %s/%s (%.0f%%)",
            local_result.get("platform"),
            local_result.get("action"),
            local_result.get("confidence", 0) * 100,
        )
        return local_result
    
    # التصنيف المحلي فشل — استخدم AI
    logger.info("🤖 Local classify failed, using AI")
    return await self.brain.analyze_task(text, urls)

UnuBot._classify_task_smart = _classify_task_smart

logger.info("🔧 %s loaded", LOCAL_CLASSIFIER_INTEGRATION_V1)


# ==========================================================
# FLEET + LONGEVITY LAYER
# تعدد حسابات، إثبات من الحساب اللي نفّذ، والبوت ما يموتش لو الجلسة وقعت.
# ==========================================================

FLEET_LAYER = "fleet-longevity-v12"

_FLEET_PREV_INIT = UnuBot.__init__
_FLEET_PREV_START = UnuBot.start
_FLEET_PREV_LOAD = UnuBot._load_storage_state
_FLEET_PREV_EXECUTE = UnuBot._try_execute_task
_FLEET_PREV_PROCESS = UnuBot._process_url
_FLEET_PREV_ALERT = UnuBot._send_alert
_FLEET_PREV_PROOF_TEXT = UnuBot._proof_report_text
_FLEET_PREV_DAILY = UnuBot._daily_limit_reached


def _init_with_fleet(self, *args, **kwargs):
    _FLEET_PREV_INIT(self, *args, **kwargs)
    try:
        from application.fleet import AccountFleet
        from account_runtime import AccountCollectorGroup, AccountRuntime
        from application.task_collector import TaskCollector as AccountTaskCollector
        self.fleet = AccountFleet()
        self.fleet.attach(self)
        self.account_contexts = {}
        self.account_collectors = {}
        for account in self.fleet.healthy_unu():
            account_id = str(account.get("id") or "")
            if not account_id:
                continue
            runtime = self.fleet.resolve_runtime(account_id) or AccountRuntime(
                account_id,
                account=account,
                cookies=self.fleet.unu_cookies(account),
                storage_state=str(account.get("storage_state") or ""),
            )
            collector = AccountTaskCollector(self, account_id=account_id)
            runtime.collector = collector
            runtime.queue = collector.queue
            self.account_contexts[account_id] = runtime
            self.account_collectors[account_id] = collector
        if self.account_collectors:
            self.task_collector = AccountCollectorGroup(self.account_collectors)
    except Exception as error:
        logger.warning("Fleet init failed: %s", error)
        self.fleet = None
        self.account_contexts = {}
        self.account_collectors = {}
    self._alert_dedup = {}
    self._last_digest_ts = 0.0
    self._active_unu_id = None
    self._account_browser_dispatch_lock = asyncio.Lock()
    self._account_browser_previous = {}


async def _process_collected_task(
    self,
    task: dict,
    account_id: Optional[str] = None,
):
    """Shared collector entrypoint; prepares account-scoped metadata then scans."""
    if not isinstance(task, dict):
        return False
    url = self._normalize_task_url(str(task.get("accept_url") or ""))
    if not url:
        return False
    owner = str(account_id or task.get("unu_account_id") or "legacy")
    seeded = {
        "title": str(task.get("title") or ""),
        "description": str(task.get("description") or ""),
        "info_for_work": str(task.get("info_for_work") or ""),
        "task_id": str(task.get("id") or ""),
        "accept_url": url,
        "unu_account_id": owner,
        "price": task.get("price", 0),
        "decision_status": "pending",
        "analysis_timestamp": time.time(),
    }
    self._set_task_details(url, seeded, owner)
    return await self._process_url_with_account(url, account_id=owner)


def _task_owner_for_url(self, url: str) -> str:
    normalized = self._normalize_task_url(url)
    for account_id in (getattr(self, "account_contexts", {}) or {}):
        scoped = getattr(self, "_account_task_details", {}) or {}
        if f"{account_id}:{normalized}" in scoped:
            return str(account_id)
        collector = getattr(self, "account_collectors", {}).get(account_id)
        meta = getattr(collector, "pending_meta", {}) if collector else {}
        if normalized in meta:
            return str(account_id)
    details = self._get_task_details(normalized)
    return str(details.get("unu_account_id") or "")


async def _load_storage_with_fleet(self):
    fleet = getattr(self, "fleet", None)
    if fleet:
        account = fleet.current_unu()
        if account is None:
            healthy = fleet.healthy_unu()
            if len(healthy) == 1:
                account = healthy[0]
                fleet._active_unu_id = str(account["id"])
                self._active_unu_id = str(account["id"])
        state = fleet.read_storage(account) if account else None
        if state:
            self.storage_state = state
            logger.info("Fleet session is account-owned; no global browser session selected")
            return
        logger.warning("No explicitly selected UNU account is available")
        return
    await _FLEET_PREV_LOAD(self)


async def _start_with_longevity(self):
    from application.longevity import attach_logging, journal, loop, stop
    attach_logging()
    journal("start", "bot process starting")
    self._longevity_task = asyncio.create_task(loop(self))
    try:
        await _FLEET_PREV_START(self)
    finally:
        stop()
        if getattr(self, "_longevity_task", None):
            self._longevity_task.cancel()


async def _recover_unu_session(self, reason: str = "") -> bool:
    """ما يوقفش البوت. يبدّل حساب UNU أو يعيد تحميل الجلسة ويستنى."""
    from application.longevity import journal
    fleet = getattr(self, "fleet", None)
    journal("session", reason or "recover", {"account": getattr(self, "_active_unu_id", None)})
    logger.warning("UNU session recover: %s account=%s", reason, getattr(self, "_active_unu_id", None))
    if fleet:
        logger.warning("Account-scoped session recovery requires an explicit account runtime")
        return False
    try:
        await self._load_storage_state()
        await self._launch_browser()
        return await self._is_session_valid()
    except Exception as error:
        logger.warning("UNU reload failed: %s", error)
        return False


async def _ensure_unu_account(self, account_id: str) -> None:
    fleet = getattr(self, "fleet", None)
    if not fleet or not account_id:
        raise RuntimeError("account_runtime_required")
    runtime = fleet.resolve_runtime(account_id)
    if runtime is None:
        raise RuntimeError(f"account_unavailable:{account_id}")
    return runtime


async def _bind_account_browser(self, runtime):
    """Bind the legacy browser methods to one isolated runtime context.

    Browser work is serialized through one dispatcher because the older
    processing methods read ``self.context``.  Credentials and contexts remain
    per-runtime and are never selected by a global account.
    """
    await self._account_browser_dispatch_lock.acquire()
    previous = {
        key: getattr(self, key, None)
        for key in ("context", "page", "browser", "playwright", "_active_unu_id")
    }
    try:
        if runtime.browser_context is None:
            runtime.playwright = await async_playwright().start()
            profile = Path(APP.DATA_DIR) / "browser_profiles" / re.sub(
                r"[^a-zA-Z0-9_-]", "_", runtime.account_id
            )
            profile.mkdir(parents=True, exist_ok=True)
            options = {"user_data_dir": str(profile), "headless": True}
            if runtime.storage_state and Path(runtime.storage_state).exists():
                options["storage_state"] = runtime.storage_state
            runtime.browser_context = await runtime.playwright.chromium.launch_persistent_context(**options)
        self.context = runtime.browser_context
        self.playwright = runtime.playwright
        self.browser = None
        self.page = None
        self._active_unu_id = runtime.account_id
        return previous
    except Exception:
        self._account_browser_dispatch_lock.release()
        raise


def _restore_account_browser(self, previous):
    try:
        for key, value in previous.items():
            setattr(self, key, value)
    finally:
        if self._account_browser_dispatch_lock.locked():
            self._account_browser_dispatch_lock.release()


async def _process_url_with_account(
    self,
    url: str,
    account_id: Optional[str] = None,
):
    details = self._get_task_details(url, account_id)
    account_id = str(account_id or details.get("unu_account_id") or "").strip()
    fleet = getattr(self, "fleet", None)
    if not fleet or not account_id:
        logger.warning("Account-scoped task rejected without an owner: %s", url)
        await self._mark_task_review(url, "unresolved_account", account_id=account_id)
        return False
    runtime = await self._ensure_unu_account(account_id)
    previous = await self._bind_account_browser(runtime)
    try:
        return await _FLEET_PREV_PROCESS(self, url, account_id)
    finally:
        self._restore_account_browser(previous)


async def _try_execute_with_fleet(self, task_url: str, details: dict):
    fleet = getattr(self, "fleet", None)
    lease = None
    platform = ""
    try:
        if fleet and isinstance(details, dict):
            platform = ""
            try:
                platform = self._task_platform(details) or ""
            except Exception:
                platform = str(details.get("platform") or "")
            lease = fleet.lease_platform(platform)
            if lease:
                details["account_id"] = lease.get("id")
                if lease.get("username"):
                    details["account_username"] = lease.get("username")
                if lease.get("profile_url"):
                    details["profile_url"] = lease.get("profile_url")
                details["_fleet_locked"] = True
    except Exception as error:
        logger.warning("platform lease failed: %s", error)
    try:
        await _FLEET_PREV_EXECUTE(self, task_url, details)
    finally:
        if not fleet:
            return
        status = str((details or {}).get("execution_status") or "")
        success = bool((details or {}).get("execution_success"))
        attempted = success or bool((details or {}).get("skill_result")) or status in {
            "verified", "proof_pending", "rate_limited",
        }
        if lease and attempted:
            fleet.release_platform(lease, success, status)
        if success:
            acc_id = str(
                (details or {}).get("unu_account_id")
                or getattr(self, "_active_unu_id", "")
                or ""
            )
            if acc_id:
                fleet.mark_unu(acc_id, "ok", status)


def _proof_report_text_fleet(self, platform: str = "", details: dict | None = None) -> str:
    details = dict(details or {})
    fleet = getattr(self, "fleet", None)
    if fleet:
        ident = fleet.proof_identity(platform or details.get("platform") or "")
        if ident.get("username") and not details.get("account_username"):
            details["account_username"] = ident["username"]
        if ident.get("profile_url") and not details.get("profile_url"):
            details["profile_url"] = ident["profile_url"]
        if ident.get("locked"):
            details["_fleet_locked"] = True
    return _FLEET_PREV_PROOF_TEXT(self, platform, details)


async def _send_alert_dedup(self, msg, level="info", photo_path=None):
    text = str(msg or "")
    now = time.time()
    cache = getattr(self, "_alert_dedup", None)
    if not isinstance(cache, dict):
        cache = {}
        self._alert_dedup = cache
    key = (level, text[:160])
    window = 90 if photo_path else {"info": 1800, "warning": 900, "error": 300}.get(level, 600)
    # نجاح التنفيذ رسالة فريدة وفيها رابط — متتسكتش
    if text.startswith("✅") or "تم تنفيذ" in text:
        window = 0
    if "الحد اليومي" in text or "جلسة UNU" in text:
        window = 6 * 3600
    prev = float(cache.get(key) or 0)
    if window and (now - prev) < window:
        logger.info("alert suppressed (%s): %s", level, text[:100])
        return
    cache[key] = now
    if len(cache) > 300:
        self._alert_dedup = dict(list(cache.items())[-150:])
    if level == "error":
        try:
            from application.longevity import journal
            journal("alert", text[:300], {"level": level})
        except Exception:
            pass
    return await _FLEET_PREV_ALERT(self, msg, level, photo_path)


def _daily_limit_with_fleet(self) -> bool:
    return False


async def _quiet_cycle_report(self, all_urls):
    logger.info(
        "cycle quiet urls=%s today=%s earnings=%.2f",
        len(all_urls or []),
        getattr(self, "daily_tasks_done", 0),
        float(getattr(self, "daily_earnings", 0) or 0),
    )
    now = time.time()
    last = float(getattr(self, "_last_digest_ts", 0) or 0)
    if now - last < 3600:
        return
    self._last_digest_ts = now
    fleet = getattr(self, "fleet", None)
    if not fleet:
        return
    try:
        await _FLEET_PREV_ALERT(self, fleet.digest(self), "info")
    except Exception as error:
        logger.debug("digest failed: %s", error)


UnuBot.__init__ = _init_with_fleet
UnuBot._load_storage_state = _load_storage_with_fleet
UnuBot.start = _start_with_longevity
UnuBot._recover_unu_session = _recover_unu_session
UnuBot._ensure_unu_account = _ensure_unu_account
UnuBot._process_collected_task = _process_collected_task
UnuBot._task_owner_for_url = _task_owner_for_url
UnuBot._process_url = _process_url_with_account
UnuBot._try_execute_task = _try_execute_with_fleet
UnuBot._proof_report_text = _proof_report_text_fleet
UnuBot._send_alert = _send_alert_dedup
UnuBot._daily_limit_reached = _daily_limit_with_fleet
UnuBot._send_cycle_report = _quiet_cycle_report

logger.info("🔧 %s loaded", FLEET_LAYER)


async def run_supervisor():
    """العملية ما تخرجش. أي سقوط بيرجع يشتغل بعد مهلة، لحد ما حد يوقفها."""
    from application.longevity import attach_logging, journal
    attach_logging()
    backoff = 15
    while True:
        bot = UnuBot()
        try:
            await bot.start()
            journal("stop", "start() returned", {"running": bool(bot.running)})
            logger.warning("Bot start() returned. Restarting in %ss", backoff)
        except asyncio.CancelledError:
            logger.info("Supervisor cancelled")
            try:
                await bot.shutdown()
            except Exception:
                pass
            break
        except KeyboardInterrupt:
            logger.info("Keyboard interrupt")
            try:
                await bot.shutdown()
            except Exception:
                pass
            break
        except Exception as error:
            logger.exception("Supervisor caught fatal error")
            journal("fatal", str(error)[:400])
            try:
                await bot.shutdown()
            except Exception:
                pass
        else:
            try:
                await bot.shutdown()
            except Exception:
                pass
        await asyncio.sleep(backoff)
        backoff = min(int(backoff * 1.5), 300)


if __name__ == "__main__":
    try:
        asyncio.run(run_supervisor())
    except KeyboardInterrupt:
        pass