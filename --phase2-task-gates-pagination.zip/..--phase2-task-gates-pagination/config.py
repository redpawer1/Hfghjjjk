#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UNU Bot — Secure Configuration"""

import os
import random
from pathlib import Path
from typing import Optional

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

def _env(key: str, default: str = "") -> str:
    return os.getenv(key, default).strip()

def _env_bool(key: str, default: bool = False) -> bool:
    return _env(key, str(default)).lower() in {"1", "true", "yes", "on"}

def _env_int(key: str, default: int = 0) -> int:
    try:
        return int(_env(key, str(default)))
    except ValueError:
        return default


class APP:
    BASE_DIR = Path(__file__).resolve().parent
    DATA_DIR = Path(_env("DATA_DIR", str(BASE_DIR / "data")))
    # Real account sessions live outside the shareable project tree.
    SESSIONS_DIR = Path(_env("SESSIONS_DIR", "/root/sessions"))
    SCREENSHOTS_DIR = DATA_DIR / "screenshots"
    LOGS_DIR = Path(_env("LOGS_DIR", str(BASE_DIR / "logs")))
    GOLDEN_SESSION_PATH = Path(
        _env("GOLDEN_SESSION_PATH", str(SESSIONS_DIR / "unu.json"))
    )
    DATABASE_PATH = Path(_env("DATABASE_PATH", str(DATA_DIR / "unu-bot.sqlite3")))

    @classmethod
    def setup_directories(cls):
        for d in [cls.DATA_DIR, cls.SESSIONS_DIR, cls.SCREENSHOTS_DIR, cls.LOGS_DIR]:
            d.mkdir(parents=True, exist_ok=True)


class STEALTH:
    # Required by main.py
    VIEWPORT_WIDTH = 1920
    VIEWPORT_HEIGHT = 1080
    PIXEL_RATIO = 1
    
    LOCATION_PROFILES = {
        "us": {"locale": "en-US", "timezone": "America/New_York"},
        "ru": {"locale": "ru-RU", "timezone": "Europe/Moscow"},
        "eg": {"locale": "ar-EG", "timezone": "Africa/Cairo"},
    }
    
    USER_AGENTS = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    ]

    @classmethod
    def get_locale(cls, country: str = "us") -> str:
        return cls.LOCATION_PROFILES.get(country, cls.LOCATION_PROFILES["us"])["locale"]

    @classmethod
    def get_timezone(cls, country: str = "us") -> str:
        return cls.LOCATION_PROFILES.get(country, cls.LOCATION_PROFILES["us"])["timezone"]

    @classmethod
    def get_random_agent(cls) -> str:
        return random.choice(cls.USER_AGENTS)

    # Properties that return actual strings (not methods)
    @property
    def LOCALE(self) -> str:
        return self.get_locale(PROXY.get_country())

    @property
    def TIMEZONE(self) -> str:
        return self.get_timezone(PROXY.get_country())


# Singleton instance for property access
STEALTH = STEALTH()


class BOT_CONFIG:
    ADMIN_ID = _env_int("TELEGRAM_ADMIN_ID", 0)
    BOT_TOKEN = _env("TELEGRAM_BOT_TOKEN")
    TG_API_ID = _env_int("TELEGRAM_API_ID", 0)
    TG_API_HASH = _env("TELEGRAM_API_HASH")
    TG_PHONE = _env("TELEGRAM_PHONE")
    TG_STRING_SESSION = _env("TELEGRAM_STRING_SESSION")
    TG_USERNAME = _env("TELEGRAM_USERNAME")


class AI_CONFIG:
    GROQ_API_KEY = _env("GROQ_API_KEY")
    GROQ_API_KEY_2 = _env("GROQ_API_KEY_2")
    GEMINI_API_KEY = _env("GEMINI_API_KEY")
    CEREBRAS_API_KEY = _env("CEREBRAS_API_KEY")
    MISTRAL_API_KEY = _env("MISTRAL_API_KEY")
    DEEPSEEK_API_KEY = _env("DEEPSEEK_API_KEY")
    OPENROUTER_API_KEY = _env("OPENROUTER_API_KEY")
    PROVIDER = _env("AI_PROVIDER", "groq")
    MODEL = _env("AI_MODEL", "llama-3.1-8b-instant")
    TIMEOUT = _env_int("AI_TIMEOUT", 10)


class PROXY:
    ENABLED = _env_bool("PROXY_ENABLED", False)
    SERVER = _env("PROXY_SERVER")
    USERNAME = _env("PROXY_USERNAME") or None
    PASSWORD = _env("PROXY_PASSWORD") or None
    COUNTRY = _env("PROXY_COUNTRY", "us").lower()

    @classmethod
    def playwright_proxy(cls) -> Optional[dict]:
        if not cls.ENABLED or not cls.SERVER:
            return None
        return {"server": cls.SERVER}

    @classmethod
    def describe(cls) -> str:
        return f"proxy={'ON' if cls.ENABLED else 'OFF'}"

    @classmethod
    def is_enabled(cls) -> bool:
        return cls.ENABLED and bool(cls.SERVER)

    @classmethod
    def get_country(cls) -> str:
        return cls.COUNTRY


class CAPTCHA:
    API_KEY = _env("CAPTCHA_API_KEY")
    PROVIDER = _env("CAPTCHA_PROVIDER", "capsolver")


class SAFETY:
    REQUIRE_HUMAN_APPROVAL = _env_bool("REQUIRE_HUMAN_APPROVAL", True)
    MAX_TASKS_PER_DAY = _env_int("MAX_TASKS_PER_DAY", 500)


def validate_config() -> list:
    """يرجع أسماء الإعدادات الناقصة من غير ما يطبع قيمها."""
    missing = []
    if not BOT_CONFIG.BOT_TOKEN:
        missing.append("TELEGRAM_BOT_TOKEN")
    if not BOT_CONFIG.ADMIN_ID:
        missing.append("TELEGRAM_ADMIN_ID")
    if not APP.DATA_DIR:
        missing.append("DATA_DIR")
    return missing


APP.setup_directories()
