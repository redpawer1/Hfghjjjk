"""Small compatibility layer for stable skill registration.

The legacy skill manager contains additive skill definitions.  This module
keeps registration deterministic without removing any implementation.
"""

from __future__ import annotations

from typing import Any, Dict


def register_unique(skills: Dict[str, Any], name: str, instance: Any) -> Any:
    key = str(name or "").strip().lower()
    if not key:
        return instance
    existing = skills.get(key)
    if existing is None:
        skills[key] = instance
        return instance
    old_type = type(existing).__name__
    new_type = type(instance).__name__
    if old_type == "GenericWebSkill" and new_type != old_type:
        skills[key] = instance
        return instance
    return existing
