#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UNU Bot Dashboard — Fully Connected"""

import asyncio
import logging
import os
from pathlib import Path
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from telegram.request import HTTPXRequest

logger = logging.getLogger("Dashboard")
ADMIN_ID = int(os.getenv("TELEGRAM_ADMIN_ID", "0"))


class Dashboard:
    def __init__(self, token: str = None, admin_id: int = None, bot_instance=None):
        self.token = token or os.getenv("TELEGRAM_BOT_TOKEN", "")
        self.admin_id = admin_id or ADMIN_ID
        self.bot = bot_instance
        self.app = None
        self.application = None
        self._poll_task = None
        self.selected_account_id = None
    
    def _is_admin(self, update: Update) -> bool:
        uid = update.effective_user.id if update.effective_user else 0
        logger.info("User ID: %s | Admin configured: %s", uid, bool(self.admin_id))
        if not self.admin_id:
            return False
        return uid == self.admin_id

    async def _deny(self, update: Update, missing_config: bool = False):
        msg = update.effective_message
        if msg is None:
            return
        if missing_config or not self.admin_id:
            text = "الإعداد ناقص: ضع TELEGRAM_ADMIN_ID في .env ثم أعد التشغيل."
        else:
            uid = update.effective_user.id if update.effective_user else 0
            text = f"غير مصرح. الايدي بتاعك: {uid}"
        try:
            await msg.reply_text(text)
        except Exception as error:
            logger.warning("deny reply failed: %s", error)
    
    def _get_running(self) -> bool:
        if self.bot and hasattr(self.bot, 'running'):
            return self.bot.running
        return False
    
    def _get_stats(self) -> dict:
        stats = {"tasks_today": 0, "earnings_today": 0.0, "tasks_total": 0}
        if self.bot and hasattr(self.bot, 'persistence'):
            try:
                daily = self.bot.persistence.get_daily()
                stats["tasks_today"] = daily.get("tasks_done", 0)
                stats["earnings_today"] = daily.get("earnings", 0.0)
            except Exception as e:
                logger.warning("Failed to get stats: %s", e)
        return stats
    
    def _get_pending(self) -> list:
        pending = []
        if not self.bot:
            return pending
        # Check multiple possible locations
        for attr in ['pending_queue', 'pending_tasks', '_pending_urls']:
            if hasattr(self.bot, attr):
                try:
                    val = getattr(self.bot, attr)
                    if val:
                        pending = list(val)[:10]
                        break
                except Exception:
                    pass
        return pending
    
    def _get_api(self, account_id: str = None):
        """Resolve an account-bound API client; never load global cookies."""
        try:
            fleet = getattr(self.bot, "fleet", None) if self.bot else None
            selected = str(account_id or self.selected_account_id or "").strip()
            if not fleet or not selected:
                return None
            runtime = fleet.resolve_runtime(selected)
            return runtime.get_api() if runtime else None
        except Exception as e:
            logger.warning("API init failed: %s", e)
            return None
    
    
    def _persistent_kb(self) -> ReplyKeyboardMarkup:
        """لوحة أزرار ثابتة في الأسفل"""
        return ReplyKeyboardMarkup([
            [KeyboardButton("▶️ تشغيل"), KeyboardButton("⏹️ إيقاف")],
            [KeyboardButton("💰 الرصيد"), KeyboardButton("📊 الحالة")],
            [KeyboardButton("📦 المهام"), KeyboardButton("🔄 تحديث")],
        ], resize_keyboard=True, is_persistent=True)

    def _kb(self) -> InlineKeyboardMarkup:
        running = self._get_running()
        start_btn = InlineKeyboardButton("⏹️ إيقاف" if running else "▶️ تشغيل", callback_data="stop" if running else "start")
        return InlineKeyboardMarkup([
            [start_btn],
            [InlineKeyboardButton("💰 الرصيد", callback_data="balance"), InlineKeyboardButton("💸 سحب", callback_data="withdraw")],
            [InlineKeyboardButton("👤 الحسابات", callback_data="accounts"), InlineKeyboardButton("📊 الحالة", callback_data="status")],
            [InlineKeyboardButton("📦 المهام", callback_data="tasks"), InlineKeyboardButton("📋 نشطة", callback_data="works")],
            [InlineKeyboardButton("📸 لقطة", callback_data="screenshot"), InlineKeyboardButton("📋 معلقة", callback_data="pending")],
            [InlineKeyboardButton("📈 إحصائيات", callback_data="stats"), InlineKeyboardButton("🔄 تحديث", callback_data="refresh")],
            [InlineKeyboardButton("⚙️ فلاتر", callback_data="filters")],
        ])
    
    def _home_text(self) -> str:
        running = self._get_running()
        stats = self._get_stats()
        cap = getattr(self.bot, "max_tasks_per_day", 40) if self.bot else 40
        done = int(stats.get("tasks_today", 0) or 0)
        earn = float(stats.get("earnings_today", 0) or 0)
        open_n = int(getattr(self.bot, "_open_reserved_count", 0) or 0) if self.bot else 0
        queued = 0
        collector = getattr(self.bot, "task_collector", None) if self.bot else None
        if collector is not None and hasattr(collector, "pending_urls"):
            try:
                queued = len(collector.pending_urls)
            except Exception:
                queued = 0
        accounts = 0
        fleet = getattr(self.bot, "fleet", None) if self.bot else None
        if fleet is not None and hasattr(fleet, "healthy_unu"):
            try:
                accounts = len(fleet.healthy_unu())
            except Exception:
                accounts = 0
        state = "شغال" if running else "واقف"
        return (
            "UNU Bot\n"
            "\n"
            f"الحالة: {state}\n"
            f"حسابات UNU: {accounts}\n"
            f"النهاردة: {done}/{cap}\n"
            f"أرباح النهاردة: {earn:.2f} ₽\n"
            f"محجوز دلوقتي: {open_n}\n"
            f"في الطابور: {queued}\n"
            "\n"
            "اختار من الأزرار."
        )

    def _status(self) -> str:
        return self._home_text()

    async def _reply_home(self, message):
        text = self._home_text()
        try:
            await message.reply_text(text, reply_markup=self._kb())
        except Exception as error:
            logger.warning("home with buttons failed: %s", error)
            await message.reply_text(text)

    async def cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        uid = update.effective_user.id if update.effective_user else 0
        logger.info("cmd_start from %s", uid)
        if msg is None:
            return
        if not self._is_admin(update):
            await self._deny(update)
            return
        try:
            await self._reply_home(msg)
        except Exception as e:
            logger.warning("cmd_start failed: %s", e)

    async def _latest_approval_id(self) -> str:
        pending = getattr(self.bot, "_pending_proof_approvals", None) if self.bot else None
        if not isinstance(pending, dict) or not pending:
            return ""
        return str(next(iter(pending.keys())))

    async def approve_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        if not self._is_admin(update) or msg is None:
            return
        approval_id = await self._latest_approval_id()
        if not approval_id or not hasattr(self.bot, "resolve_proof_decision"):
            await msg.reply_text("مفيش إثبات مستني موافقة.")
            return
        ok = await self.bot.resolve_proof_decision(approval_id, "approve")
        await msg.reply_text("تم اعتماد الإثبات." if ok else "مفيش إثبات مفتوح.")

    async def reject_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        if not self._is_admin(update) or msg is None:
            return
        approval_id = await self._latest_approval_id()
        if not approval_id or not hasattr(self.bot, "resolve_proof_decision"):
            await msg.reply_text("مفيش مهمة مستنية رفض.")
            return
        ok = await self.bot.resolve_proof_decision(approval_id, "reject")
        await msg.reply_text("تم رفض الإثبات." if ok else "مفيش إثبات مفتوح.")

    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        if msg is None or not self._is_admin(update):
            return
        text = (msg.text or "").strip()
        if text in {"▶️ تشغيل", "تشغيل"}:
            if self.bot:
                self.bot.running = True
            await msg.reply_text("تم التشغيل.", reply_markup=self._kb())
            return
        if text in {"⏹️ إيقاف", "إيقاف"}:
            if self.bot:
                self.bot.running = False
            await msg.reply_text("تم الإيقاف.", reply_markup=self._kb())
            return
        if text in {"📊 الحالة", "🔄 تحديث", "الحالة", "تحديث"}:
            await self._reply_home(msg)
            return
        if text in {"💰 الرصيد", "الرصيد"}:
            await msg.reply_text("جاري جلب الرصيد...")
            bal = await self._api_call("get_balance_detailed")
            if not bal:
                await msg.reply_text("خطأ في الاتصال بـ UNU")
                return
            await msg.reply_text(
                f"المتاح: {float(bal.get('available', 0) or 0):.2f} ₽\n"
                f"المسحوب: {float(bal.get('withdrawn', 0) or 0):.2f} ₽"
            )
            return
        if text in {"📦 المهام", "المهام"}:
            await msg.reply_text("جاري جلب المهام...")
            result = await self._api_call("get_tasks", 0)
            tasks = (result or {}).get("tasks", []) if isinstance(result, dict) else []
            if not tasks:
                await msg.reply_text("لا توجد مهام.")
                return
            lines = []
            for task in tasks[:8]:
                lines.append(f"• {task.get('price', 0)}₽ — {str(task.get('title') or '')[:40]}")
            await msg.reply_text("\n".join(lines))

    async def _api_call(self, name: str, *args, account_id: str = None):
        api = self._get_api(account_id)
        if api is None:
            return None

        def _run():
            try:
                return getattr(api, name)(*args)
            except Exception as error:
                logger.warning("dashboard api %s failed: %s", name, error)
                return None

        try:
            return await asyncio.to_thread(_run)
        except Exception as error:
            logger.warning("dashboard api %s failed: %s", name, error)
            return None

    async def cmd_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not self._is_admin(update):
            return
        try:
            await update.effective_message.reply_text(self._home_text(), reply_markup=self._kb())
        except Exception as e:
            logger.warning("cmd_status failed: %s", e)
    
    async def callback_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        q = update.callback_query
        if not q:
            return
        # Admin check — admin_id=0 is not open access
        if not self.admin_id or (q.from_user and q.from_user.id != self.admin_id):
            try:
                await q.answer("غير مصرح أو TELEGRAM_ADMIN_ID غير مضبوط", show_alert=True)
            except Exception:
                pass
            return
        try:
            await q.answer()
        except Exception:
            pass
        
        back = InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ رجوع", callback_data="main")]])
        
        try:
            if q.data == "start":
                if self.bot:
                    self.bot.running = True
                    if hasattr(self.bot, 'start_bot'):
                        try:
                            await self.bot.start_bot()
                        except Exception as e:
                            logger.warning("start_bot failed: %s", e)
                    # Restart main loop if not running
                    if hasattr(self.bot, '_main_loop_task'):
                        task = self.bot._main_loop_task
                        if task is None or task.done():
                            import asyncio
                            self.bot._main_loop_task = asyncio.create_task(self.bot._main_loop())
                await q.edit_message_text(self._home_text(), reply_markup=self._kb())
            
            elif q.data == "stop":
                if self.bot:
                    self.bot.running = False
                    if hasattr(self.bot, "stop_bot"):
                        try:
                            await self.bot.stop_bot()
                        except Exception as e:
                            logger.warning("stop_bot failed: %s", e)
                await q.edit_message_text(self._home_text(), reply_markup=self._kb())
            
            elif q.data == "status":
                await q.edit_message_text(self._home_text(), reply_markup=back)
            
            elif q.data == "balance":
                await q.edit_message_text("💰 جاري جلب الرصيد...", reply_markup=back)
                api = self._get_api()
                if api:
                    bal = api.get_balance_detailed()
                    api.close()
                    text = f"💰 **الرصيد**\n\n"
                    text += f"المتاح: {bal.get('available', 0):.2f} ₽\n"
                    text += f"المجمد: {bal.get('frozen', 0):.2f} ₽\n"
                    text += f"الإجمالي: {bal.get('total', 0):.2f} ₽"
                    if bal.get("error"):
                        text += f"\n\n⚠️ {bal['error'][:50]}"
                else:
                    text = "💰 خطأ في الاتصال بـ UNU"
                await q.edit_message_text(text, reply_markup=back, parse_mode="Markdown")
            
            elif q.data == "withdraw":
                await q.edit_message_text("💸 جاري فحص الرصيد...", reply_markup=back)
                api = self._get_api()
                if api:
                    bal = api.get_balance_detailed()
                    frozen = api.get_frozen()
                    methods = api.get_withdrawal_methods()
                    api.close()
                    available = bal.get("available", 0)
                    frozen_amt = frozen.get("total", 0)
                    text = f"💸 **سحب**\n\n"
                    text += f"المتاح: {available:.2f} ₽\n"
                    text += f"المجمد: {frozen_amt:.2f} ₽\n"
                    text += f"الإجمالي: {available + frozen_amt:.2f} ₽\n\n"
                    if methods:
                        text += "طرق السحب:\n"
                        for m in methods[:3]:
                            text += f"• {m.get('name', '?')}\n"
                    if available >= 100:
                        text += "\n✅ يمكنك السحب"
                    else:
                        text += f"\n⚠️ الحد الأدنى 100 ₽"
                else:
                    text = "💸 خطأ في الاتصال"
                await q.edit_message_text(text, reply_markup=back, parse_mode="Markdown")
            
            elif q.data == "accounts":
                fleet = getattr(self.bot, "fleet", None) if self.bot else None
                accounts = []
                if fleet is not None and hasattr(fleet, "unu_accounts"):
                    try:
                        accounts = list(fleet.unu_accounts() or [])
                    except Exception:
                        accounts = []
                if not accounts:
                    text = "👤 لا توجد حسابات UNU متصلة حالياً."
                    markup = back
                else:
                    lines = ["👤 **حسابات UNU**", ""]
                    buttons = []
                    for account in accounts:
                        account_id = str(account.get("id") or "unknown")
                        status = fleet.account_status(account_id)
                        name = str(account.get("label") or account_id)
                        lines.append(
                            f"• {name} (`{account_id}`)\n"
                            f"  الحالة: {'متصل' if status.get('available') else 'غير متاح'}"
                        )
                    text = "\n".join(lines)
                    for account in accounts[:20]:
                        account_id = str(account.get("id") or "")
                        buttons.append([
                            InlineKeyboardButton(
                                f"اختيار {account_id}", callback_data=f"account_select:{account_id}"
                            ),
                            InlineKeyboardButton(
                                "اختبار", callback_data=f"account_test:{account_id}"
                            ),
                        ])
                        buttons.append([
                            InlineKeyboardButton("إيقاف", callback_data=f"account_pause:{account_id}"),
                            InlineKeyboardButton("فصل", callback_data=f"account_disconnect:{account_id}"),
                            InlineKeyboardButton("حذف", callback_data=f"account_remove:{account_id}"),
                        ])
                    buttons.append([InlineKeyboardButton("⬅️ رجوع", callback_data="main")])
                    markup = InlineKeyboardMarkup(buttons)
                await q.edit_message_text(text, reply_markup=markup, parse_mode="Markdown")

            elif q.data.startswith("account_select:"):
                account_id = q.data.split(":", 1)[1]
                fleet = getattr(self.bot, "fleet", None) if self.bot else None
                if not fleet or not fleet.resolve_runtime(account_id):
                    await q.edit_message_text("الحساب غير متاح أو جلسته مفقودة.", reply_markup=back)
                else:
                    self.selected_account_id = account_id
                    await q.edit_message_text(f"تم اختيار الحساب {account_id}.", reply_markup=back)

            elif q.data.startswith("account_test:"):
                account_id = q.data.split(":", 1)[1]
                fleet = getattr(self.bot, "fleet", None) if self.bot else None
                result = fleet.test_unu_account(account_id) if fleet else {"ok": False}
                text = f"اختبار {account_id}: {'نجح' if result.get('ok') else result.get('error', 'فشل')}"
                await q.edit_message_text(text, reply_markup=back)

            elif q.data.startswith("account_pause:") or q.data.startswith("account_disconnect:") or q.data.startswith("account_remove:"):
                action, account_id = q.data.split(":", 1)
                fleet = getattr(self.bot, "fleet", None) if self.bot else None
                if action == "account_pause":
                    ok = bool(fleet and fleet.update_unu_account(account_id, enabled=False))
                elif action == "account_disconnect":
                    ok = bool(fleet and fleet.disconnect_unu(account_id))
                else:
                    ok = bool(fleet and fleet.remove_unu(account_id))
                if self.selected_account_id == account_id and action != "account_pause":
                    self.selected_account_id = None
                await q.edit_message_text(
                    f"{'تم' if ok else 'تعذر'} تنفيذ العملية للحساب {account_id}.",
                    reply_markup=back,
                )
            
            elif q.data == "works":
                await q.edit_message_text("📋 جاري جلب المهام النشطة...", reply_markup=back)
                api = self._get_api()
                if api:
                    works = api.get_works("active")
                    api.close()
                    if works:
                        text = "مهام محجوزة\n\n"
                        for w in works[:8]:
                            text += f"• #{w.get('id', '?')} | {w.get('price', '?')} | {w.get('status', '')}\n"
                    else:
                        text = "لا توجد مهام محجوزة"
                else:
                    text = "📋 خطأ في الاتصال"
                await q.edit_message_text(text, reply_markup=back, parse_mode="Markdown")
            
            elif q.data == "tasks":
                await q.edit_message_text("📦 جاري جلب المهام...", reply_markup=back)
                api = self._get_api()
                if api:
                    result = api.get_tasks(page=0)
                    api.close()
                    tasks = result.get("tasks", [])
                    if tasks:
                        text = "📦 **آخر المهام**\n\n"
                        for t in tasks[:5]:
                            title = t.get("title", "?")[:35]
                            price = t.get("price", 0)
                            text += f"• {price}₽ — {title}\n"
                    else:
                        text = "📦 لا توجد مهام"
                else:
                    text = "📦 خطأ في الاتصال"
                await q.edit_message_text(text, reply_markup=back, parse_mode="Markdown")
            
            elif q.data == "screenshot":
                await q.edit_message_text("📸 جاري أخذ اللقطة...", reply_markup=back)
                if self.bot and hasattr(self.bot, 'take_screenshot'):
                    try:
                        await self.bot.take_screenshot()
                        await q.edit_message_text("📸 تم إرسال اللقطة", reply_markup=back)
                    except Exception as e:
                        await q.edit_message_text(f"📸 خطأ: {str(e)[:50]}", reply_markup=back)
                else:
                    await q.edit_message_text("📸 اللقطة غير متاحة", reply_markup=back)
            
            elif q.data == "pending":
                pending = self._get_pending()
                if pending:
                    text = "📋 **مهام معلقة**\n\n" + "\n".join(f"• {str(p)[:50]}" for p in pending[:5])
                else:
                    text = "📋 لا توجد مهام معلقة"
                await q.edit_message_text(text, reply_markup=back, parse_mode="Markdown")
            
            elif q.data == "stats":
                stats = self._get_stats()
                text = f"📈 **إحصائيات**\n\n"
                text += f"مهام اليوم: {stats.get('tasks_today', 0)}\n"
                text += f"أرباح اليوم: {stats.get('earnings_today', 0):.2f} ₽"
                await q.edit_message_text(text, reply_markup=back, parse_mode="Markdown")
            
            elif q.data == "refresh":
                await q.edit_message_text(self._home_text(), reply_markup=self._kb())
            
            elif q.data == "filters":
                price_min = getattr(self.bot, "filter_price_min", 0) if self.bot else 0
                price_max = getattr(self.bot, "filter_price_max", 999999) if self.bot else 999999
                banned = getattr(self.bot, "filter_banned_words", []) if self.bot else []
                text = f"⚙️ **الفلاتر**\n\n"
                text += f"السعر: {price_min:.0f} - {price_max:.0f} ₽\n"
                text += f"كلمات محظورة: {len(banned)}\n\n"
                text += "استخدم الأوامر:\n"
                text += "/setmin 10 — حد أدنى\n"
                text += "/setmax 100 — حد أقصى\n"
                text += "/ban كلمة — حظر كلمة\n"
                text += "/clearfilters — مسح الفلاتر"
                await q.edit_message_text(text, reply_markup=back, parse_mode="Markdown")
            
            elif q.data == "main":
                await q.edit_message_text(self._home_text(), reply_markup=self._kb())
        
        except Exception as e:
            msg = str(e)
            if "message is not modified" in msg.lower():
                logger.debug("Callback unchanged message ignored")
                return
            logger.warning("Callback error: %s", e)
            try:
                await q.edit_message_text(f"خطأ: {str(e)[:80]}", reply_markup=back)
            except Exception:
                pass
    
    async def cmd_setmin(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not self._is_admin(update):
            return
        try:
            val = float(context.args[0]) if context.args else 0
            if self.bot:
                self.bot.filter_price_min = val
                if hasattr(self.bot, "task_collector") and self.bot.task_collector:
                    self.bot.task_collector.price_min = val
            await update.message.reply_text(f"✅ الحد الأدنى: {val:.0f} ₽")
        except Exception:
            await update.message.reply_text("استخدم: /setmin 10")
    
    async def cmd_setmax(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not self._is_admin(update):
            return
        try:
            val = float(context.args[0]) if context.args else 999999
            if self.bot:
                self.bot.filter_price_max = val
                if hasattr(self.bot, "task_collector") and self.bot.task_collector:
                    self.bot.task_collector.price_max = val
            await update.message.reply_text(f"✅ الحد الأقصى: {val:.0f} ₽")
        except Exception:
            await update.message.reply_text("استخدم: /setmax 100")
    
    async def cmd_ban(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not self._is_admin(update):
            return
        if not context.args:
            await update.message.reply_text("استخدم: /ban كلمة")
            return
        word = " ".join(context.args)
        if self.bot:
            if not hasattr(self.bot, "filter_banned_words"):
                self.bot.filter_banned_words = []
            self.bot.filter_banned_words.append(word)
            if hasattr(self.bot, "task_collector") and self.bot.task_collector:
                self.bot.task_collector.banned_words.append(word)
            await update.message.reply_text(f"✅ تم حظر: {word}")
    
    async def cmd_clearfilters(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not self._is_admin(update):
            return
        if self.bot:
            self.bot.filter_price_min = 0.0
            self.bot.filter_price_max = 999999.0
            self.bot.filter_banned_words = []
        await update.message.reply_text("✅ تم مسح كل الفلاتر")

    async def cmd_account_add(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not self._is_admin(update):
            return
        if len(context.args) < 2:
            await update.effective_message.reply_text("استخدم: /account_add ACCOUNT_ID STORAGE_STATE_PATH [LABEL]")
            return
        fleet = getattr(self.bot, "fleet", None) if self.bot else None
        try:
            account = fleet.add_unu_account(
                context.args[0], context.args[1], " ".join(context.args[2:]) or context.args[0]
            )
            await update.effective_message.reply_text(f"تمت إضافة الحساب {account['id']}.")
        except Exception as error:
            await update.effective_message.reply_text(f"تعذر إضافة الحساب: {str(error)[:120]}")

    async def cmd_account_action(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not self._is_admin(update):
            return
        if len(context.args) < 2:
            await update.effective_message.reply_text("استخدم: /account_action ACTION ACCOUNT_ID")
            return
        action, account_id = context.args[0].lower(), context.args[1]
        fleet = getattr(self.bot, "fleet", None) if self.bot else None
        try:
            if action == "pause":
                fleet.update_unu_account(account_id, enabled=False)
            elif action == "resume":
                fleet.update_unu_account(account_id, enabled=True)
            elif action == "disconnect":
                fleet.disconnect_unu(account_id)
            elif action == "remove":
                fleet.remove_unu(account_id)
            elif action == "test":
                result = fleet.test_unu_account(account_id)
                await update.effective_message.reply_text(
                    f"اختبار {account_id}: {'نجح' if result.get('ok') else result.get('error', 'فشل')}"
                )
                return
            else:
                raise ValueError("action must be pause, resume, disconnect, remove, or test")
            await update.effective_message.reply_text(f"تم تنفيذ {action} للحساب {account_id}.")
        except Exception as error:
            await update.effective_message.reply_text(f"تعذر تنفيذ العملية: {str(error)[:120]}")
    
    def setup(self) -> Application:
        if not self.token:
            return None
        request = HTTPXRequest(
            connect_timeout=60,
            read_timeout=60,
            write_timeout=60,
            pool_timeout=60,
        )
        self.app = Application.builder().token(self.token).request(request).build()
        self.application = self.app
        self.app.add_handler(CommandHandler("start", self.cmd_start))
        self.app.add_handler(CommandHandler("approve", self.approve_command))
        self.app.add_handler(CommandHandler("reject", self.reject_command))
        self.app.add_handler(CommandHandler("status", self.cmd_status))
        self.app.add_handler(CommandHandler("setmin", self.cmd_setmin))
        self.app.add_handler(CommandHandler("setmax", self.cmd_setmax))
        self.app.add_handler(CommandHandler("ban", self.cmd_ban))
        self.app.add_handler(CommandHandler("clearfilters", self.cmd_clearfilters))
        self.app.add_handler(CommandHandler("account_add", self.cmd_account_add))
        self.app.add_handler(CommandHandler("account_action", self.cmd_account_action))
        self.app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.button_handler))
        self.app.add_handler(CallbackQueryHandler(self.callback_handler))
        return self.app
    
    async def start(self):
        logger.info("Starting dashboard... token=%s admin=%s", bool(self.token), self.admin_id)
        if not self.app:
            self.setup()
        if self.app:
            await self.app.initialize()
            await self.app.start()
            logger.info("Dashboard initialized, starting polling...")
            self._poll_task = asyncio.create_task(self._poll())
        else:
            logger.error("Dashboard app is None!")
    
    async def _poll(self):
        while True:
            try:
                updater = self.app.updater
                if updater and not updater.running:
                    logger.info("Dashboard polling starting")
                    await updater.start_polling(drop_pending_updates=False)
                    logger.warning("Dashboard polling stopped, restarting")
                else:
                    await asyncio.sleep(3)
                    continue
            except Exception as e:
                logger.error("Polling error: %s", e)
            await asyncio.sleep(5)
    
    async def stop(self):
        if self._poll_task and not self._poll_task.done():
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
            except Exception as error:
                logger.warning("poll stop: %s", error)
        self._poll_task = None
        app = self.app or self.application
        if app:
            try:
                if app.updater:
                    await app.updater.stop()
                await app.stop()
                await app.shutdown()
            except Exception as e:
                logger.warning("Dashboard stop error: %s", e)
            logger.info("Dashboard stopped")
    
    async def send_message(self, text: str):
        if self.app and self.admin_id:
            try:
                await self.app.bot.send_message(self.admin_id, text)
            except Exception as e:
                logger.warning("Send failed: %s", e)


SecureDashboard = Dashboard
