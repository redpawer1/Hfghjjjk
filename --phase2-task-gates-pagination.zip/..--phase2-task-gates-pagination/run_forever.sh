#!/bin/bash
# تشغيل مستمر. البوت نفسه بيرجع يشتغل لو وقع،
# والسكربت ده شبكة أمان لو العملية كلها ماتت.
# اللوج بيتقص لو كبر، عشان القرص ما يمتلئش.
set -u
cd "$(dirname "$0")"
mkdir -p data/logs data/screenshots data/sessions
PY="${PYTHON:-python3}"
if [ -x /root/unu-bot/venv/bin/python3 ]; then
  PY=/root/unu-bot/venv/bin/python3
elif [ -x ./venv/bin/python3 ]; then
  PY=./venv/bin/python3
fi
while true; do
  echo "---- start $(date -Is) ----" >> data/logs/stdout.log
  "$PY" -u main.py >> data/logs/stdout.log 2>&1
  code=$?
  echo "---- exit ${code} $(date -Is) ----" >> data/logs/stdout.log
  size=$(stat -c%s data/logs/stdout.log 2>/dev/null || echo 0)
  if [ "$size" -gt 20000000 ]; then
    tail -c 2000000 data/logs/stdout.log > data/logs/stdout.log.tmp
    mv data/logs/stdout.log.tmp data/logs/stdout.log
  fi
  sleep 15
done
