"""Account-scoped runtime state shared by collectors and verification."""

from __future__ import annotations

import asyncio
import re
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

logger = logging.getLogger("AccountRuntime")


def normalize_account_id(account_id: Optional[str]) -> str:
    value = str(account_id or "").strip()
    return value or "legacy"


def task_id_from_url(url: str) -> str:
    match = re.search(
        r"/tasks/(?:accept|report)/[^/?#]*?-(\d+)(?:[/?#]|$)",
        str(url or ""),
        re.IGNORECASE,
    )
    return match.group(1) if match else ""


@dataclass
class AccountRuntime:
    """All mutable UNU state owned by exactly one account.

    The runtime deliberately owns the API client and browser context.  Callers
    must resolve a runtime by its explicit account id; there is no fallback
    account in this class.
    """

    account_id: str
    account: Dict[str, Any] = field(default_factory=dict)
    cookies: Dict[str, str] = field(default_factory=dict, repr=False)
    api_client: Any = field(default=None, repr=False)
    http_client: Any = field(default=None, repr=False)
    browser_context: Any = field(default=None, repr=False)
    playwright: Any = field(default=None, repr=False)
    storage_state: Optional[str] = None
    collector: Any = None
    queue: Any = None
    history: set = field(default_factory=set)
    invalid: set = field(default_factory=set)
    verification_records: Dict[str, dict] = field(default_factory=dict)
    stats: Dict[str, Any] = field(default_factory=dict)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    reservation_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    browser_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    connected: bool = False
    disconnected: bool = False
    last_error: str = ""

    def __post_init__(self) -> None:
        self.account_id = normalize_account_id(self.account_id)
        self.account = dict(self.account or {})
        self.storage_state = self.storage_state or self.account.get("storage_state")
        if not self.stats:
            self.stats = {
                "collected": 0,
                "accepted": 0,
                "needs_review": 0,
                "rejected": 0,
                "api_errors": 0,
                "ai_errors": 0,
                "reservation_errors": 0,
            }

    def get_api(self, factory=None):
        """Return this account's persistent API client, never another account's."""
        if self.disconnected:
            raise RuntimeError(f"account_disconnected:{self.account_id}")
        if self.api_client is None:
            if not self.cookies:
                raise RuntimeError(f"account_session_missing:{self.account_id}")
            if factory is None:
                from unu_api import UnuAPI
                factory = UnuAPI
            self.api_client = factory(dict(self.cookies))
            try:
                self.api_client.account_id = self.account_id
            except Exception:
                pass
        self.connected = True
        return self.api_client

    def reserve_task(self, accept_url: str) -> bool:
        """Reserve through this runtime's client and its existing accept URL."""
        api = self.get_api()
        response = api.client.get(str(accept_url), follow_redirects=True)
        return "/tasks/report/" in str(getattr(response, "url", "")) or (
            int(getattr(response, "status_code", 0) or 0) == 200
        )

    async def close(self) -> None:
        self.disconnected = True
        client = self.api_client
        self.api_client = None
        if client is not None and hasattr(client, "close"):
            result = client.close()
            if asyncio.iscoroutine(result):
                await result
        http_client = self.http_client
        self.http_client = None
        if http_client is not None and hasattr(http_client, "aclose"):
            result = http_client.aclose()
            if asyncio.iscoroutine(result):
                await result
        context = self.browser_context
        self.browser_context = None
        if context is not None and hasattr(context, "close"):
            result = context.close()
            if asyncio.iscoroutine(result):
                await result
        playwright = self.playwright
        self.playwright = None
        if playwright is not None and hasattr(playwright, "stop"):
            result = playwright.stop()
            if asyncio.iscoroutine(result):
                await result
        self.connected = False


class AccountCollectorGroup:
    """Compatibility facade over independent account collectors."""

    def __init__(self, collectors: Dict[str, Any]):
        self.collectors = dict(collectors)

    @property
    def pending_urls(self) -> set:
        result = set()
        for collector in self.collectors.values():
            result.update(getattr(collector, "pending_urls", set()) or set())
        return result

    @property
    def stats(self) -> dict:
        merged: Dict[str, int] = {}
        for collector in self.collectors.values():
            for key, value in (getattr(collector, "stats", {}) or {}).items():
                merged[key] = merged.get(key, 0) + int(value or 0)
        return merged

    @property
    def running(self) -> bool:
        """Expose group activity using the same interface as one collector."""
        return any(
            bool(getattr(collector, "running", False))
            for collector in self.collectors.values()
        )

    async def start(self):
        for collector in self.collectors.values():
            account_id = getattr(collector, "account_id", "unknown")
            try:
                await asyncio.wait_for(collector.start(), timeout=25)
            except asyncio.TimeoutError:
                logger.error(
                    "Collector startup timed out for account=%s; continuing other accounts",
                    account_id,
                )
            except Exception:
                logger.exception(
                    "Collector startup failed for account=%s; continuing other accounts",
                    account_id,
                )

    async def stop(self):
        for collector in self.collectors.values():
            await collector.stop()

    def get_pending(self, limit: int = 0) -> list:
        result = []
        remaining = int(limit or 0)
        for collector in self.collectors.values():
            if remaining == 0 and limit:
                break
            take = remaining if limit else 0
            batch = collector.get_pending(limit=take)
            result.extend(batch)
            if limit:
                remaining -= len(batch)
        return result

