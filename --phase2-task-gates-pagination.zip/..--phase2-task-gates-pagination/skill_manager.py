#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
UNU BOT — Ultimate Skill Manager (Pro Edition) - (Stealth & Anti-Ban Upgraded)

Telegram:
    - تنفيذ الاشتراك بواسطة Telethon API.
    - التحقق من العضوية بواسطة Telegram API.
    - Screenshot للإثبات من Telegram Web فقط إذا كانت جلسة Telegram Web
      متاحة داخل BrowserContext.

IMPORTANT:
    لا يتم أخذ Screenshot من صفحة UNU كإثبات لتنفيذ مهمة Telegram.
"""

import asyncio
import json
import logging
import os
import random
import re
import time
from pathlib import Path
from typing import Optional, Tuple, Any, Dict

from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import (
    FloodWaitError,
    UserAlreadyParticipantError,
)

from telethon.tl.functions.channels import (
    JoinChannelRequest,
    GetParticipantRequest,
)

from telethon.tl.functions.messages import (
    ImportChatInviteRequest,
    StartBotRequest,
)

from telethon.tl.types import (
    ChannelParticipant,
    ChannelParticipantSelf,
)
from skill_registry import register_unique
from platform_policy import EXECUTION_PLATFORMS, canonical_platform

logger = logging.getLogger("SkillManager")


# ==========================================================
# Canonical Actions & Capabilities
# ==========================================================

SUPPORTED_ACTIONS = {
    "subscribe",
    "like",
    "comment",
    "view",
    "share",
    "register",
    "review",
    "start_bot",
    "repost",
    "vote"
}


SKILL_CAPABILITIES = {
    "telegram": {
        "subscribe",
        "start_bot",
        "view",
        "like",
        "comment",
    },

    "vk": {
        "subscribe",
        "like",
        "repost",
    },

    "tiktok": {
        "like",
        "subscribe",
        "view",
        "comment",
        "repost",
        "share",
    },

    "facebook": {
        "like",
        "subscribe",
        "share",
    },

    "review": {
        "review",
    },

    # --- Platforms Added for UNU ---
    "youtube": {
        "subscribe",
        "like",
        "view",
        "comment",
    },

    "instagram": {
        "subscribe",
        "like",
        "comment",
        "share",
        "repost",
        "view",
    },

    "rutube": {
        "subscribe",
        "like",
        "view",
    },

    "avito": {
        "view",
        "like", # Added to favorites
    },

    "twitter": {
        "subscribe",
        "like",
        "repost",
        "comment",
        "share",
    },

    "discord": {
        "subscribe",
    },

    "reddit": {
        "subscribe",
        "like", # Upvote
        "vote",
    },

    "max": {
        "subscribe",
        "like",
        "view",
        "comment",
    },

    # منصات إضافية تعمل عبر GenericWebSkill.
    "linkedin": {"subscribe", "like", "comment", "share", "view"},
    "pinterest": {"subscribe", "like", "share", "view"},
    "snapchat": {"subscribe", "view"},
    "threads": {"subscribe", "like", "comment", "repost", "view"},
    "twitch": {"subscribe", "like", "view"},
    "kick": {"subscribe", "like", "view"},
    "steam": {"subscribe", "like", "review", "view"},
    "github": {"subscribe", "like", "comment", "view"},
    "gitlab": {"subscribe", "like", "comment", "view"},
    "medium": {"subscribe", "like", "comment", "view"},
    "quora": {"subscribe", "like", "comment", "share", "view"},
    "tumblr": {"subscribe", "like", "repost", "comment", "view"},
    "dailymotion": {"subscribe", "like", "view"},
    "soundcloud": {"subscribe", "like", "view"},
    "bandcamp": {"subscribe", "like", "view"},
    "tripadvisor": {"like", "review", "view"},
    "google_play": {"review", "view"},
    "app_store": {"review", "view"},
    "yandex": {"review", "view"},
    "google_maps": {"review", "view", "like"},
    "website": {"register", "view", "like", "comment", "review"},
}


# ==========================================================
# Base Skill
# ==========================================================

class BaseSkill:

    async def _human_delay(
        self,
        min_sec: float = 0.25,
        max_sec: float = 0.7
    ):
        # سقف السرعة: الضغط يتأخر أقل من ثانية، والمشاهدة سقفها 8 ثواني مش 30.
        lo = float(min_sec or 0.2)
        hi = float(max_sec or 0.6)
        if hi >= 8:
            lo, hi = 5.0, 8.0
        else:
            lo = min(lo, 0.35)
            hi = min(max(hi, lo + 0.1), 1.15)
        await asyncio.sleep(random.uniform(lo, hi))

    async def _human_delay_heavy(self, lo: float = 0.35, hi: float = 0.8):
        """تأخير قصير قبل اللايك/الاشتراك. السرعة أولى، والجلسة لسه بشرية."""
        await asyncio.sleep(random.uniform(min(lo, 0.4), min(hi, 0.9)))

    async def _type_like_human(
        self,
        page,
        selector: str,
        text: str
    ):
        await page.click(selector)

        for char in text:
            await page.keyboard.press(char)
            await asyncio.sleep(
                random.uniform(0.05, 0.2)
            )

    async def _scroll_to_bottom_and_up(self, page):
        """تقوم بالتمرير لأسفل لضمان تحميل العناصر (Lazy Load) ثم تصعد قليلاً"""
        try:
            await page.evaluate("window.scrollTo(0, document.body.scrollHeight/2)")
            await self._human_delay(1, 2)
            await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            await self._human_delay(1, 2)
            await page.evaluate("window.scrollTo(0, 0)")
            await self._human_delay(1, 2)
        except Exception:
            pass

    async def _apply_stealth_and_human_behavior(self, page):
        """نظام تخفي أقصى ضد Instagram / TikTok / Rutube / كشف الروبوت."""
        if not page:
            return
        try:
            await page.add_init_script("""
                // webdriver
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined,
                    configurable: true
                });
                try {
                    const proto = Navigator.prototype;
                    if (proto) {
                        Object.defineProperty(proto, 'webdriver', { get: () => undefined, configurable: true });
                    }
                } catch (e) {}

                // chrome automation leftovers
                try {
                    delete window.cdc_adoQpoasnfa76pfcZLmcfl_Array;
                    delete window.cdc_adoQpoasnfa76pfcZLmcfl_Promise;
                    delete window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol;
                    delete window.$cdc_asdjflasutopfhvcZLmcfl_;
                    delete window.$chrome_asyncScriptInfo;
                } catch (e) {}

                window.chrome = window.chrome || {
                    runtime: {},
                    loadTimes: function(){ return {}; },
                    csi: function(){ return {}; },
                    app: { isInstalled: false }
                };

                Object.defineProperty(navigator, 'languages', {
                    get: () => ['ru-RU', 'ru', 'en-US', 'en']
                });
                Object.defineProperty(navigator, 'language', {
                    get: () => 'ru-RU'
                });
                Object.defineProperty(navigator, 'plugins', {
                    get: () => [1, 2, 3, 4, 5]
                });
                Object.defineProperty(navigator, 'platform', {
                    get: () => 'Win32'
                });
                Object.defineProperty(navigator, 'hardwareConcurrency', {
                    get: () => 8
                });
                Object.defineProperty(navigator, 'deviceMemory', {
                    get: () => 8
                });
                Object.defineProperty(navigator, 'maxTouchPoints', {
                    get: () => 0
                });

                // permissions
                try {
                    const originalQuery = window.navigator.permissions && window.navigator.permissions.query;
                    if (originalQuery) {
                        window.navigator.permissions.query = (parameters) => (
                            parameters && parameters.name === 'notifications'
                                ? Promise.resolve({ state: Notification.permission })
                                : originalQuery(parameters)
                        );
                    }
                } catch (e) {}

                // WebGL vendor noise
                try {
                    const getParameter = WebGLRenderingContext.prototype.getParameter;
                    WebGLRenderingContext.prototype.getParameter = function(parameter) {
                        if (parameter === 37445) return 'Intel Inc.';
                        if (parameter === 37446) return 'Intel Iris OpenGL Engine';
                        return getParameter.call(this, parameter);
                    };
                } catch (e) {}

                // canvas slight noise
                try {
                    const toDataURL = HTMLCanvasElement.prototype.toDataURL;
                    HTMLCanvasElement.prototype.toDataURL = function() {
                        const context = this.getContext('2d');
                        if (context) {
                            const shift = Math.floor(Math.random() * 3);
                            const imageData = context.getImageData(0, 0, Math.min(this.width || 1, 8), 1);
                            if (imageData && imageData.data && imageData.data.length) {
                                imageData.data[0] = imageData.data[0] + shift;
                                context.putImageData(imageData, 0, 0);
                            }
                        }
                        return toDataURL.apply(this, arguments);
                    };
                } catch (e) {}
            """)
            # حركات ماوس متعددة أكثر بشرية
            for _ in range(random.randint(3, 6)):
                x = random.randint(60, 1200)
                y = random.randint(60, 750)
                await page.mouse.move(x, y, steps=random.randint(10, 25))
                await asyncio.sleep(random.uniform(0.12, 0.45))
            try:
                await page.mouse.wheel(0, random.randint(150, 520))
                await asyncio.sleep(random.uniform(0.2, 0.5))
                await page.mouse.wheel(0, -random.randint(40, 180))
            except Exception:
                pass
            await asyncio.sleep(random.uniform(0.5, 1.3))
            # طبقة تخفي إضافية ضد فحوصات السلوك (Yandex/IG/YT)
            try:
                await page.add_init_script("""
                    try {
                        Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
                        if (!window.chrome) {
                            window.chrome = { runtime: {}, loadTimes: function(){}, csi: function(){}, app: {} };
                        }
                        Object.defineProperty(navigator, 'languages', { get: () => ['ru-RU','ru','en-US','en'] });
                        Object.defineProperty(navigator, 'language', { get: () => 'ru-RU' });
                        Object.defineProperty(navigator, 'platform', { get: () => 'Win32' });
                        Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 8 });
                        Object.defineProperty(navigator, 'deviceMemory', { get: () => 8 });
                        Object.defineProperty(navigator, 'maxTouchPoints', { get: () => 0 });
                        // plugins length غير صفر
                        try {
                            Object.defineProperty(navigator, 'plugins', {
                                get: () => [1, 2, 3, 4, 5],
                            });
                        } catch (e) {}
                        // permissions query
                        try {
                            const originalQuery = window.navigator.permissions && window.navigator.permissions.query;
                            if (originalQuery) {
                                window.navigator.permissions.query = (parameters) => (
                                    parameters && parameters.name === 'notifications'
                                        ? Promise.resolve({ state: Notification.permission })
                                        : originalQuery(parameters)
                                );
                            }
                        } catch (e) {}
                        // WebGL vendor
                        try {
                            const getParameter = WebGLRenderingContext.prototype.getParameter;
                            WebGLRenderingContext.prototype.getParameter = function(parameter) {
                                if (parameter === 37445) return 'Intel Inc.';
                                if (parameter === 37446) return 'Intel Iris OpenGL Engine';
                                return getParameter.call(this, parameter);
                            };
                        } catch (e) {}
                    } catch (e) {}
                """)
            except Exception:
                pass
            # تأخير بشري أطول قبل أي فعل
            await asyncio.sleep(random.uniform(0.8, 2.2))
            # حركة ماوس بطيئة إضافية
            try:
                for _ in range(random.randint(2, 4)):
                    await page.mouse.move(
                        random.randint(100, 1100),
                        random.randint(100, 700),
                        steps=random.randint(15, 30),
                    )
                    await asyncio.sleep(random.uniform(0.2, 0.55))
            except Exception:
                pass
        except Exception as e:
            logger.debug(f"Stealth apply failed: {e}")

    async def _dismiss_common_blockers(self, page):
        """إغلاق موسّع للنوافذ: كوكي / إعلانات / روبوت / عمر / إشعارات / روتوب."""
        if not page:
            return
        blocker_selectors = [
            # TikTok / generic close
            'div[data-e2e="modal-close-inner-button"]',
            'div[data-e2e="modal-close"]',
            'div[aria-label="Close"]',
            'div[aria-label="إغلاق"]',
            'div[aria-label="Закрыть"]',
            'button[aria-label="Close"]',
            'button[aria-label="Закрыть"]',
            'button[aria-label="Close dialog"]',
            # Instagram / Facebook
            'button:has-text("Not now")',
            'button:has-text("Not Now")',
            'button:has-text("Не сейчас")',
            'button:has-text("Закрыть")',
            'button:has-text("Close")',
            'button:has-text("Понятно")',
            'button:has-text("Продолжить")',
            # cookie banners
            'button:has-text("Принять cookie")',
            'button:has-text("Согласен")',
            'button:has-text("Accept cookies")',

            'button:has-text("Позже")',
            'button:has-text("Dismiss")',
            'button:has-text("Skip")',
            'button:has-text("Maybe later")',
            # Cookie / consent
            'button:has-text("Accept All")',
            'button:has-text("Accept all")',
            'button:has-text("Accept")',
            'button:has-text("Agree")',
            'button:has-text("I agree")',
            'button:has-text("Allow all")',
            'button:has-text("Allow All")',
            'button:has-text("Принять")',
            'button:has-text("Принять все")',
            'button:has-text("Согласен")',
            'button:has-text("Согласиться")',
            'button:has-text("Хорошо")',
            'button:has-text("Понятно")',
            'button:has-text("Ok")',
            'button:has-text("OK")',
            'button:has-text("Продолжить")',
            'button:has-text("Continue")',
            'button:has-text("Got it")',
            # Age / content gates
            'button:has-text("I am 18")',
            'button:has-text("Yes, I am")',
            'button:has-text("Мне есть 18")',
            'button:has-text("Мне есть 16")',
            'button:has-text("Войти")',
            # Rutube / Russian media overlays
            'button:has-text("Закрыть")',
            'button:has-text("Пропустить")',
            'button:has-text("Скрыть")',
            'button:has-text("Больше не показывать")',
            'button:has-text("Не сейчас")',
            '[class*="popup"] button[class*="close"]',
            '[class*="modal"] button[class*="close"]',
            '[class*="banner"] button[class*="close"]',
            # Robot soft continue (not hard captcha solve)
            'button:has-text("I am not a robot")',
            'button:has-text("Verify")',
            # Generic close classes
            'button[class*="close"]',
            'button[class*="Close"]',
            '[role="button"][aria-label*="close" i]',
            '[role="button"][aria-label*="закрыть" i]',
            'div[role="button"][aria-label*="Close"]',
        ]
        for selector in blocker_selectors:
            try:
                btn = page.locator(selector).first
                if await btn.is_visible(timeout=500):
                    await btn.click(timeout=2000)
                    await asyncio.sleep(random.uniform(0.3, 0.7))
            except Exception:
                continue
        # إغلاق أيقونات X الشائعة
        try:
            close_icons = page.locator(
                'svg[aria-label="Close"], svg[aria-label="Закрыть"], '
                '[data-testid="close"], [data-testid="modal-close"], '
                '[data-testid="x-button"], button[aria-label="Dismiss"]'
            )
            count = await close_icons.count()
            for i in range(min(count, 4)):
                try:
                    el = close_icons.nth(i)
                    if await el.is_visible(timeout=350):
                        await el.click(timeout=1500)
                        await asyncio.sleep(0.35)
                except Exception:
                    continue
        except Exception:
            pass
        # Escape كمحاولة أخيرة لإغلاق modal
        try:
            await page.keyboard.press("Escape")
            await asyncio.sleep(0.25)
        except Exception:
            pass

    async def _get_page_body_text(self, page) -> str:
        if not page:
            return ""
        try:
            return (await page.inner_text("body")).strip().lower()
        except Exception:
            return ""

    async def _capture_fixed_profile_proof(
        self,
        page,
        platform: str,
        prefix: str | None = None,
    ) -> Optional[str]:
        """
        إثبات ثابت: يفتح رابط حساب المنصة المحفوظ ويأخذ Screenshot منه.
        لا يغيّر منطق التنفيذ؛ طبقة إضافية بعد نجاح الفعل.
        """
        if not page:
            return None
        plat = str(platform or "").strip().lower()
        if plat == "x":
            plat = "twitter"
        profiles = _sm_load_proof_profiles() if "_sm_load_proof_profiles" in globals() else dict(globals().get("PROOF_PROFILE_URLS") or {})
        url = (profiles.get(plat) or "").strip()
        if not url:
            return None
        try:
            await page.goto(url, timeout=45_000, wait_until="domcontentloaded")
            await self._human_delay(2.0, 4.0)
            try:
                await self._dismiss_common_blockers(page)
            except Exception:
                pass
            await self._human_delay(1.0, 2.0)
            # scroll خفيف لإظهار الهوية
            try:
                await page.mouse.wheel(0, random.randint(120, 320))
            except Exception:
                pass
            await self._human_delay(0.8, 1.5)
            name = prefix or f"{plat}_profile_proof"
            if hasattr(self, "_capture_screenshot"):
                return await self._capture_screenshot(page, name)
            # fallback عام
            ss_dir = Path("data/screenshots")
            ss_dir.mkdir(parents=True, exist_ok=True)
            ss_path = ss_dir / f"{name}_{int(time.time())}_{random.randint(1000,9999)}.png"
            await page.screenshot(path=str(ss_path), full_page=False)
            return str(ss_path)
        except Exception as error:
            logger.warning("fixed profile proof failed [%s]: %s", plat, error)
            return None

    async def _session_health_check(self, page, platform: str = "generic") -> Dict:
        """
        فحص صحة الجلسة/الصفحة قبل التنفيذ.
        statuses:
          ready | login_required | captcha | automation_block | region_block |
          content_restricted | ip_blocked | http_404 | page_error | missing_page
        """
        result = {
            "status": "missing_page",
            "platform": platform,
            "logged_in": False,
            "reason": "",
        }
        if not page:
            result["reason"] = "no_page"
            return result

        url = ""
        try:
            url = (page.url or "").lower()
        except Exception:
            url = ""
        if (not url) or url.startswith("about:") or url.startswith("chrome:") or url == "about:blank":
            return {
                "status": "ready",
                "platform": platform,
                "logged_in": None,
                "reason": "blank_tab_skip_until_navigation",
            }

        body = await self._get_page_body_text(page)

        # --- CAPTCHA / robot ---
        captcha_markers = [
            "captcha",
            "recaptcha",
            "hcaptcha",
            "h-captcha",
            "cf-challenge",
            "verify you are human",
            "verify that you are human",
            "security check",
            "robot check",
            "проверяем, что вы не робот",
            "я не робот",
            "я человек",
            "подозрительный трафик",
            "почему это могло произойти",
            "about this page",
            "об этой странице",
            "i am human",
            "i'm not a robot",
            "имеем дело именно с вами",
            "а не с ботом",
            "разверните картинку",
            "поведение вашего браузера",
            "поведение похоже на поведение автоматизированных",
            "пройдите проверку",
        ]
        if any(m in body for m in captcha_markers):
            result["status"] = "captcha"
            result["reason"] = "captcha_or_robot_check"
            return result

        # --- IP / network block (Yandex etc.) ---
        ip_markers = [
            "доступ ограничен: проблема с ip",
            "проблема с ip",
            "access denied",
            "your access to this site has been limited",
            "ip has been blocked",
            "too many requests",
            "слишком много запросов",
        ]
        if any(m in body for m in ip_markers):
            result["status"] = "ip_blocked"
            result["reason"] = "ip_or_network_restriction"
            return result

        # --- Region / geo block (TikTok: video unavailable in your country) ---
        region_markers = [
            "видео недоступно",
            "недоступно в вашей стране",
            "недоступно в вашей стране или регионе",
            "this video is unavailable in your country",
            "not available in your country",
            "not available in your region",
            "content is not available in your country",
            "недоступно в вашем регионе",
        ]
        if any(m in body for m in region_markers):
            result["status"] = "region_block"
            result["reason"] = "geo_or_region_unavailable"
            return result

        # --- Content restricted / sensitive (Instagram) ---
        content_markers = [
            "этот контент может быть неуместным",
            "контент недоступен для определенных аудиторий",
            "content unavailable",
            "this content may be inappropriate",
            "sensitive content",
            "content isn't available",
            "к сожалению, воспроизвести это видео не удается",
            "не удается воспроизвести видео",
        ]
        # video playback failure alone is soft; mark content_restricted only with stronger phrases
        hard_content = [
            "этот контент может быть неуместным",
            "контент недоступен для определенных аудиторий",
            "this content may be inappropriate",
            "content isn't available",
            "sensitive content",
        ]
        if any(m in body for m in hard_content):
            result["status"] = "content_restricted"
            result["reason"] = "sensitive_or_audience_restriction"
            return result

        # soft video playback issue (still may allow like if controls exist)
        if any(m in body for m in (
            "к сожалению, воспроизвести это видео не удается",
            "не удается воспроизвести видео",
            "обновите страницу и повторите попытку",
        )):
            result["video_playback_failed"] = True

        # --- Automation ---
        automation_markers = [
            "we suspect automated behavior",
            "automated behavior",
            "suspicious activity",
            "try again later",
            "подозрительная активность",
            "подтвердите, что вы человек",
            "зарегистрировали подозрительный трафик",
            "ваши действия признаны автоматическими",
            "действия признаны автоматическими",
            "recognized as automated",
            "actions are automated",
            "bot detected",
            "access denied",
            "qrerror/403",
            "ошибки: eb",
        ]
        if any(m in body for m in automation_markers):
            result["status"] = "automation_block"
            result["reason"] = "platform_automation_warning"
            return result

        # --- 404 ---
        if any(x in body for x in (
            "такой страницы не существует",
            "page not found",
            "404 not found",
            "страница не найдена",
            "الصفحة غير موجودة",
        )) or "/404" in url:
            result["status"] = "http_404"
            result["reason"] = "page_not_found"
            return result

        # --- Login walls ---
        login_markers = {
            "instagram": [
                "log in", "login", "sign up", "sign in", "вход", "تسجيل الدخول",
                "создать аккаунт", "войти",
            ],
            "tiktok": [
                "log in", "login", "sign up", "войти", "регистрация", "تسجيل الدخول",
            ],
            "telegram": [
                "log in to telegram by qr code",
                "log in by phone number",
                "log in", "qr code", "войти", "تسجيل الدخول",
                "open telegram on your phone",
                "point your phone at this screen",
            ],
            "rutube": ["войти", "регистрация", "log in", "login"],
            "generic": ["log in", "login", "sign in", "войти", "تسجيل الدخول"],
        }
        markers = login_markers.get(platform, login_markers["generic"])
        url_login = any(x in url for x in ("/login", "/signin", "/accounts/login", "auth", "oauth"))
        body_login = any(m in body for m in markers)

        logged_in_signals = {
            "instagram": ["home", "profile", "messages", "создать", "профиль", "сообщения", "добавьте комментарий"],
            "tiktok": ["for you", "following", "profile", "upload", "для вас", "рекомендации"],
            "telegram": ["saved messages", "contacts", "chats", "меню", "настройки", "archived chats"],
            "rutube": ["подписки", "профиль", "уведомления"],
            "generic": [],
        }
        signals = logged_in_signals.get(platform, [])
        has_signal = any(s in body for s in signals) if signals else True

        # TikTok: big pink "Войти" with empty video often means logged out
        if platform == "tiktok" and ("войти" in body and not has_signal):
            result["status"] = "login_required"
            result["logged_in"] = False
            result["reason"] = "tiktok_login_wall"
            return result

        # Telegram QR login screen
        if platform == "telegram" and any(m in body for m in (
            "log in to telegram by qr code",
            "log in by phone number",
            "point your phone at this screen",
            "open telegram on your phone",
        )):
            result["status"] = "login_required"
            result["logged_in"] = False
            result["reason"] = "telegram_qr_or_phone_login"
            return result

        if url_login or (body_login and not has_signal):
            result["status"] = "login_required"
            result["logged_in"] = False
            result["reason"] = "login_wall_detected"
            return result

        if any(x in body for x in (
            "something went wrong",
            "page isn't available",
            "content unavailable",
        )):
            result["status"] = "page_error"
            result["reason"] = "page_unavailable"
            return result

        result["status"] = "ready"
        result["logged_in"] = True
        result["reason"] = "session_ok"
        return result

    async def _smart_click_with_retry(
        self,
        page,
        selectors: list,
        platform: str = "generic",
        refresh_on_miss: bool = True,
    ) -> Dict:
        """
        ضغط ذكي:
        - يحاول السليكتورات
        - لو مش ظاهر يعمل refresh مرة واحدة
        - لو login/captcha يرجّع فشل نظيف
        """
        outcome = {
            "clicked": False,
            "status": "control_not_found",
            "selector": None,
            "health": None,
        }
        if not page:
            outcome["status"] = "missing_page"
            return outcome

        async def _try_click() -> bool:
            for selector in selectors:
                try:
                    btn = page.locator(selector).first
                    if not await btn.count():
                        continue
                    if not await btn.is_visible(timeout=1800):
                        continue
                    try:
                        await btn.scroll_into_view_if_needed(timeout=2500)
                    except Exception:
                        pass
                    box = await btn.bounding_box()
                    if box:
                        await page.mouse.move(
                            box["x"] + box["width"] / 2,
                            box["y"] + box["height"] / 2,
                            steps=random.randint(8, 18),
                        )
                        await asyncio.sleep(random.uniform(0.15, 0.45))
                    await btn.click(timeout=5000, delay=random.randint(40, 130))
                    outcome["clicked"] = True
                    outcome["status"] = "clicked"
                    outcome["selector"] = selector
                    return True
                except Exception:
                    continue
            return False

        health = await self._session_health_check(page, platform)
        outcome["health"] = health
        if health["status"] in {
                "login_required", "captcha", "automation_block", "page_error",
                "region_block", "content_restricted", "ip_blocked", "http_404",
            }:
            outcome["status"] = health["status"]
            return outcome

        if await _try_click():
            return outcome

        if refresh_on_miss:
            try:
                await page.reload(wait_until="domcontentloaded", timeout=45_000)
                await self._human_delay(2, 4)
                await self._dismiss_common_blockers(page)
            except Exception:
                pass
            health = await self._session_health_check(page, platform)
            outcome["health"] = health
            if health["status"] in {
                "login_required", "captcha", "automation_block", "page_error",
                "region_block", "content_restricted", "ip_blocked", "http_404",
            }:
                outcome["status"] = health["status"]
                return outcome
            if await _try_click():
                return outcome

        outcome["status"] = "control_not_found"
        return outcome

    async def _score_proof_page(self, page, platform: str = "generic", action: str = "") -> Dict:
        """
        تقييم جودة صفحة الإثبات قبل الإرسال للمراجعة.
        score 0..100
        """
        score = 50
        reasons = []
        body = await self._get_page_body_text(page)
        url = ""
        try:
            url = (page.url or "").lower()
        except Exception:
            pass

        # عقوبات قوية
        if any(x in body for x in ("log in", "login", "sign in", "войти", "تسجيل الدخول", "qr code")):
            score -= 40
            reasons.append("looks_like_login")
        if any(x in body for x in ("start bot", "join channel", "view in telegram", "preview channel")):
            score -= 25
            reasons.append("telegram_preview_still_visible")
        if any(x in body for x in ("captcha", "проверяем, что вы не робот", "robot")):
            score -= 45
            reasons.append("captcha_visible")
        if any(x in body for x in ("we suspect automated behavior", "automated behavior")):
            score -= 50
            reasons.append("automation_warning")

        if any(x in body for x in ("видео недоступно", "недоступно в вашей стране", "not available in your country")):
            score -= 40
            reasons.append("region_block")
        if any(x in body for x in ("этот контент может быть неуместным", "content may be inappropriate", "sensitive content")):
            score -= 35
            reasons.append("content_restricted")
        if any(x in body for x in ("проблема с ip", "доступ ограничен", "подозрительный трафик")):
            score -= 45
            reasons.append("ip_or_captcha_block")
        if any(x in body for x in ("log in to telegram by qr code", "log in by phone number", "point your phone")):
            score -= 50
            reasons.append("telegram_login_screen")
        if any(x in body for x in ("такой страницы не существует", "page not found")):
            score -= 50
            reasons.append("http_404")

        # مكافآت حسب الإجراء
        action = (action or "").lower()
        if action in {"subscribe", "start_bot"}:
            positives = [
                "subscribed", "following", "joined", "подписан", "вы подписаны",
                "members", "подписчик", "open chat", "send message", "message",
            ]
            if any(p in body for p in positives):
                score += 25
                reasons.append("membership_signal_found")
        if action == "like":
            positives = ["unlike", "liked", "нравится", "убрать отметку", "remove like"]
            if any(p in body for p in positives):
                score += 20
                reasons.append("like_state_signal")
        if action == "comment":
            if any(p in body for p in ("comment", "коммент", "تعليق", "posted")):
                score += 15
                reasons.append("comment_context")

        if "web.telegram.org" in url and "login" not in body:
            score += 10
            reasons.append("telegram_web_context")

        score = max(0, min(100, score))
        return {
            "score": score,
            "acceptable": score >= 55,
            "reasons": reasons,
            "platform": platform,
            "action": action,
        }

    async def _format_playwright_cookies(self, source_cookies: list, default_domain: str) -> list:
        """Helper to format cookies for playwright context safely."""
        converted = []
        for item in source_cookies:
            if not item.get("name") or "value" not in item:
                continue
            cookie = {
                "name": str(item["name"]),
                "value": str(item["value"]),
                "domain": str(item.get("domain", default_domain)),
                "path": str(item.get("path", "/")),
                "httpOnly": bool(item.get("httpOnly", False)),
                "secure": bool(item.get("secure", True)),
            }
            expiration = item.get("expirationDate", item.get("expires"))
            if expiration:
                cookie["expires"] = float(expiration)
            
            same_site = str(item.get("sameSite", "")).lower()
            if same_site in {"none", "no_restriction"}:
                cookie["sameSite"] = "None"
            elif same_site == "strict":
                cookie["sameSite"] = "Strict"
            else:
                cookie["sameSite"] = "Lax"
                
            converted.append(cookie)
        return converted

    async def execute_task(
        self,
        action: str,
        target_url: str,
        page=None,
        **kwargs
    ) -> tuple:
        raise NotImplementedError


# ==========================================================
# Telegram Skill
# ==========================================================

class TelegramSkill(BaseSkill):

    def __init__(self):
        self.client: Optional[TelegramClient] = None
        self.is_ready = False
        # API ينفذ الاشتراك، لكن Screenshot الموثوقة تحتاج Browser Profile
        # مسجل الدخول إلى Telegram Web.
        self.browser_account_required = os.getenv(
            "TELEGRAM_WEB_ACCOUNT_REQUIRED", "1"
        ).strip().lower() not in {"0", "false", "no"}
        self.browser_account_ready = False

    # ------------------------------------------------------
    # Initialize
    # ------------------------------------------------------

    async def initialize(self, config: dict):

        try:
            api_id = config.get("api_id")
            api_hash = config.get("api_hash")
            session_string = config.get("session_string")

            if not api_id or not api_hash:
                logger.error(
                    "❌ Telegram API credentials غير موجودة."
                )
                return

            if not session_string:
                logger.error(
                    "❌ Telegram StringSession غير موجودة."
                )
                return

            logger.info(
                "📱 جاري تهيئة Telegram عبر StringSession..."
            )

            self.client = TelegramClient(
                StringSession(session_string),
                api_id,
                api_hash,
            )

            await self.client.connect()

            if not await self.client.is_user_authorized():

                logger.error(
                    "❌ Telegram session غير مصرح بها."
                )

                self.is_ready = False
                return

            self.is_ready = True

            me = await self.client.get_me()

            logger.info(
                "✅ Telegram API جاهز — user=%s",
                getattr(me, "username", None)
                or getattr(me, "id", "unknown")
            )

        except Exception as e:

            logger.exception(
                "❌ فشل تهيئة Telegram: %s",
                e
            )

            self.is_ready = False

    # ------------------------------------------------------
    # URL helpers
    # ------------------------------------------------------

    def _extract_chat_hash(
        self,
        url: str
    ) -> Optional[str]:

        match = re.search(
            r"(?:t\.me|telegram\.me)/(?:\+|joinchat/)([\w-]+)",
            str(url)
        )

        return match.group(1) if match else None

    def _extract_username(
        self,
        url: str
    ) -> Optional[str]:

        if not url:
            return None

        if "+" in url or "joinchat" in url:
            return None

        match = re.search(
            r"(?:t\.me|telegram\.me)/([\w_]+)",
            str(url)
        )

        return match.group(1) if match else None

    def _extract_post_id(
        self,
        url: str
    ) -> Tuple[Optional[str], Optional[str]]:

        match = re.search(
            r"(?:t\.me|telegram\.me)/([\w_]+)/(\d+)",
            str(url)
        )

        if match:
            return match.group(1), match.group(2)

        return None, None

    # ------------------------------------------------------
    # Screenshot
    # ------------------------------------------------------

    async def _capture_screenshot(
        self,
        page,
        prefix: str = "telegram"
    ) -> Optional[str]:

        if not page:
            return None

        try:

            screenshot_dir = Path(
                "data/screenshots"
            )

            screenshot_dir.mkdir(
                parents=True,
                exist_ok=True
            )

            timestamp = int(time.time())

            ss_path = (
                screenshot_dir
                / f"{prefix}_{timestamp}_{random.randint(1000, 9999)}.png"
            )

            await page.screenshot(
                path=str(ss_path),
                full_page=True
            )

            logger.info(
                "📸 Telegram screenshot: %s",
                ss_path
            )

            return str(ss_path)

        except Exception as e:

            logger.error(
                "❌ Telegram screenshot failed: %s",
                e
            )

            return None

    # ------------------------------------------------------
    # Verify membership through Telegram API
    # ------------------------------------------------------

    async def _verify_membership(
        self,
        target_url: str
    ) -> bool:

        if not self.client:
            return False

        try:

            username = self._extract_username(
                target_url
            )

            if not username:
                return True

            entity = await self.client.get_entity(
                username
            )

            me = await self.client.get_me()

            try:

                result = await self.client(
                    GetParticipantRequest(
                        channel=entity,
                        participant=me,
                    )
                )

                participant = getattr(
                    result,
                    "participant",
                    None
                )

                if isinstance(
                    participant,
                    (ChannelParticipantSelf, ChannelParticipant)
                ):
                    return True

                return participant is not None

            except Exception as e:

                text = str(e).lower()

                if (
                    "notparticipant" in text
                    or "participant_id_invalid" in text
                    or "user not participant" in text
                ):
                    return False

                logger.warning(
                    "⚠️ تعذر التحقق الدقيق من العضوية: %s",
                    e
                )

                return True

        except Exception as e:

            logger.warning(
                "⚠️ Telegram membership verification failed: %s",
                e
            )

            return False

    # ------------------------------------------------------
    # Telegram Web proof (UPGRADED)
    # ------------------------------------------------------

    # ✅ NEW: Static cookies to use if no external file is found
    TELEGRAM_WEB_COOKIES = [
    {
        "domain": ".telegram.org",
        "expirationDate": 1819342978.707436,
        "hostOnly": False,
        "httpOnly": True,
        "name": "stel_acid",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "Y4Pfmi-2hR1yo2zd7J3pBcTFbtpKEt1vUuBG8LYXF27h3RUyPdOSs6f-JpEBX00W"
    }
]

    async def _load_telegram_web_cookies(self, context) -> bool:
        """تحميل Cookies اختيارية قبل فتح Telegram Web دون تسجيلها في الـlog."""
        # First, try to load from an external file if configured
        cookies_path = os.getenv("TELEGRAM_WEB_COOKIES_FILE", "").strip()
        if cookies_path:
            try:
                with Path(cookies_path).expanduser().open("r", encoding="utf-8") as handle:
                    raw_cookies = json.load(handle)
                if isinstance(raw_cookies, dict):
                    raw_cookies = raw_cookies.get("cookies", [])
                if not isinstance(raw_cookies, list) or not raw_cookies:
                    return False

                cookies = []
                for item in raw_cookies:
                    if not item.get("name") or "value" not in item:
                        continue
                    cookie = {
                        "name": str(item["name"]),
                        "value": str(item["value"]),
                        "domain": str(item.get("domain", ".telegram.org")),
                        "path": str(item.get("path", "/")),
                        "httpOnly": bool(item.get("httpOnly", False)),
                        "secure": bool(item.get("secure", True)),
                        "sameSite": (
                            "None" if str(item.get("sameSite", "")).lower() in {"none", "no_restriction"}
                            else "Strict" if str(item.get("sameSite", "")).lower() == "strict"
                            else "Lax"
                        ),
                    }
                    expiration = item.get("expirationDate", item.get("expires"))
                    if expiration:
                        cookie["expires"] = float(expiration)
                    cookies.append(cookie)
                if cookies:
                    await context.add_cookies(cookies)
                    logger.info("✅ Telegram Web Cookies loaded from file (%s cookies).", len(cookies))
                    return True
            except Exception as error:
                logger.warning("Telegram Web Cookies file could not be loaded: %s", type(error).__name__)

        # Fallback to the static cookies defined in this class
        if self.TELEGRAM_WEB_COOKIES:
            try:
                formatted = await self._format_playwright_cookies(self.TELEGRAM_WEB_COOKIES, ".telegram.org")
                if formatted:
                    await context.add_cookies(formatted)
                    logger.info("✅ Telegram Web Cookies loaded from class (static).")
                    return True
            except Exception as error:
                logger.warning("Telegram Web static cookies failed: %s", type(error).__name__)

        return False

    async def _click_telegram_preview_actions(self, telegram_page) -> bool:
        """ضغط أزرار صفحات المعاينة: START BOT / JOIN CHANNEL / VIEW IN TELEGRAM."""
        action_selectors = [
            # Bots
            'button:has-text("START BOT")',
            'button:has-text("Start Bot")',
            'button:has-text("START")',
            'a:has-text("START BOT")',
            'a:has-text("Start Bot")',
            # Channels / groups
            'button:has-text("JOIN CHANNEL")',
            'button:has-text("Join Channel")',
            'button:has-text("JOIN GROUP")',
            'button:has-text("Join Group")',
            'button:has-text("JOIN")',
            'button:has-text("Join")',
            'a:has-text("JOIN CHANNEL")',
            'a:has-text("Join Channel")',
            # Preview bridge
            'button:has-text("VIEW IN TELEGRAM")',
            'button:has-text("View in Telegram")',
            'a:has-text("VIEW IN TELEGRAM")',
            'a:has-text("View in Telegram")',
            # Russian UI
            'button:has-text("ЗАПУСТИТЬ БОТА")',
            'button:has-text("Запустить бота")',
            'button:has-text("ПРИСОЕДИНИТЬСЯ")',
            'button:has-text("Присоединиться")',
            'button:has-text("ВСТУПИТЬ")',
            'button:has-text("Вступить")',
            'button:has-text("ОТКРЫТЬ В TELEGRAM")',
            'button:has-text("Открыть в Telegram")',
        ]
        clicked = False
        for selector in action_selectors:
            try:
                btn = telegram_page.locator(selector).first
                if not await btn.count():
                    continue
                if not await btn.is_visible(timeout=1500):
                    continue
                await btn.scroll_into_view_if_needed()
                box = await btn.bounding_box()
                if box:
                    await telegram_page.mouse.move(
                        box["x"] + box["width"] / 2,
                        box["y"] + box["height"] / 2,
                        steps=random.randint(6, 14),
                    )
                    await asyncio.sleep(random.uniform(0.2, 0.5))
                await btn.click(timeout=5000, delay=random.randint(40, 120))
                clicked = True
                logger.info("✅ تم الضغط على زر معاينة تيليجرام: %s", selector)
                await asyncio.sleep(random.uniform(2.5, 4.5))
                break
            except Exception:
                continue
        return clicked

    async def _telegram_web_proof(
        self,
        target_url: str,
        page=None
    ) -> Optional[str]:

        if not page:
            logger.warning(
                "⚠️ لا توجد Browser Page لإثبات Telegram."
            )
            return None

        telegram_page = None

        try:

            context = page.context

            await self._load_telegram_web_cookies(context)

            telegram_page = await context.new_page()

            telegram_page.set_default_timeout(
                25_000
            )

            username = self._extract_username(
                target_url
            )

            post_username, post_id = (
                self._extract_post_id(target_url)
            )

            chat_hash = self._extract_chat_hash(target_url)

            # تجربة نسخة K كافتراضي
            version = "k"
            if post_username and post_id:
                web_url = f"https://web.telegram.org/{version}/#@{post_username}/{post_id}"
            elif username:
                web_url = f"https://web.telegram.org/{version}/#@{username}"
            elif chat_hash:
                # روابط الدعوة الخاصة
                web_url = f"https://web.telegram.org/{version}/#+{chat_hash}"
            else:
                # fallback: افتح الرابط الأصلي مباشرة (t.me preview)
                web_url = str(target_url)

            logger.info("🌐 فتح Telegram Web للإثبات: %s", web_url)

            await telegram_page.goto(
                web_url,
                timeout=35_000,
                wait_until="domcontentloaded"
            )

            await self._apply_stealth_and_human_behavior(telegram_page)
            await asyncio.sleep(random.uniform(3.5, 6.0))

            body_text = ""
            try:
                body_text = (await telegram_page.inner_text("body")).lower()
            except Exception:
                pass

            login_markers = ["log in", "login", "qr code", "تسجيل الدخول", "войти"]

            # إذا كانت نسخة K غير مسجلة دخول، نحاول مع نسخة A قبل الفشل
            if any(marker in body_text for marker in login_markers):
                logger.warning("⚠️ Telegram Web (K) غير مسجل دخول. محاولة التبديل لنسخة (A)...")
                version = "a"
                if post_username and post_id:
                    web_url = f"https://web.telegram.org/{version}/#@{post_username}/{post_id}"
                elif username:
                    web_url = f"https://web.telegram.org/{version}/#@{username}"
                elif chat_hash:
                    web_url = f"https://web.telegram.org/{version}/#+{chat_hash}"
                else:
                    web_url = str(target_url)

                await telegram_page.goto(web_url, timeout=35_000, wait_until="domcontentloaded")
                await asyncio.sleep(random.uniform(3.5, 6.0))

                try:
                    body_text = (await telegram_page.inner_text("body")).lower()
                except Exception:
                    pass

                if any(marker in body_text for marker in login_markers):
                    logger.warning("⚠️ Telegram Web (A) أيضاً غير مسجل دخول.")
                    self.browser_account_ready = False
                    return None

            self.browser_account_ready = True
            await self._dismiss_common_blockers(telegram_page)
            await asyncio.sleep(random.uniform(1.5, 3.0))

            health = await self._session_health_check(telegram_page, "telegram")
            if health["status"] in {
                "login_required", "captcha", "automation_block",
                "region_block", "content_restricted", "ip_blocked", "http_404",
            }:
                logger.warning("⚠️ Telegram Web session health: %s", health["status"])
                self.browser_account_ready = False
                return None

            # أهم إصلاح: الضغط الفعلي على أزرار المعاينة
            await self._click_telegram_preview_actions(telegram_page)
            await self._dismiss_common_blockers(telegram_page)
            await asyncio.sleep(random.uniform(2.0, 4.0))

            # لو لسه ظاهر زر START/JOIN نحاول مرة ثانية
            try:
                body_after = (await telegram_page.inner_text("body")).lower()
            except Exception:
                body_after = ""
            if any(x in body_after for x in ("start bot", "join channel", "view in telegram", "присоединиться", "запустить бота")):
                await self._click_telegram_preview_actions(telegram_page)
                await asyncio.sleep(random.uniform(2.0, 3.5))

            proof = await self._score_proof_page(telegram_page, "telegram", "subscribe")
            logger.info("📊 Telegram proof score=%s reasons=%s", proof.get("score"), proof.get("reasons"))
            if not proof.get("acceptable", True):
                logger.warning("⚠️ Telegram proof quality low — still capturing for review.")

            screenshot_path = (
                await self._capture_screenshot(
                    telegram_page,
                    "telegram_web_subscribed"
                )
            )

            return screenshot_path

        except Exception as e:

            logger.warning(
                "⚠️ فشل Telegram Web proof: %s",
                e
            )

            return None

        finally:
            if telegram_page:
                try:
                    await telegram_page.close()
                except Exception:
                    pass

    # ------------------------------------------------------
    # Subscribe
    # ------------------------------------------------------

    async def _subscribe(
        self,
        target_url: str,
        page=None
    ) -> Tuple[bool, Dict]:

        if not self.client:
            return False, {}

        try:

            username = None

            chat_hash = self._extract_chat_hash(
                target_url
            )

            if chat_hash:
                try:
                    await self.client(
                        ImportChatInviteRequest(
                            chat_hash
                        )
                    )
                    logger.info("✅ تم الانضمام إلى Telegram باستخدام Invite API.")
                except UserAlreadyParticipantError:
                    logger.info("ℹ️ الحساب موجود بالفعل في القناة.")
                username = (await self._get_my_username())

            else:
                username = self._extract_username(
                    target_url
                )
                if not username:
                    logger.error("❌ لم يتم استخراج Telegram username.")
                    return False, {}

                entity = await self.client.get_entity(
                    username
                )
                try:
                    await self.client(
                        JoinChannelRequest(entity)
                    )
                    logger.info("✅ تم الاشتراك في Telegram: @%s", username)
                except UserAlreadyParticipantError:
                    logger.info("ℹ️ الحساب مشترك بالفعل: @%s", username)

            verified = await self._verify_membership(
                target_url
            )

            if not verified:
                logger.error("❌ فشل التحقق من العضوية بعد التنفيذ.")
                return False, {}

            my_username = (await self._get_my_username())

            screenshot_path = None
            if page:
                screenshot_path = (
                    await self._telegram_web_proof(
                        target_url,
                        page=page
                    )
                )

            if screenshot_path:
                logger.info("✅ تم الحصول على Screenshot من Telegram Web.")
            else:
                # الاشتراك عبر Telethon نجح — الإثبات النصي = يوزر تيليجرام
                # (الكثير من مهام UNU تطلب اليوزر/الاسم وليس السكرين فقط)
                logger.warning(
                    "⚠️ API نجح بدون Screenshot من Telegram Web — "
                    "نكمل بالإثبات النصي (username) بدل فشل المهمة بعد accept."
                )
                # لا نرجع False هنا: منع «accept بدون إكمال» بعد اشتراك ناجح

            return True, {
                "username": my_username,
                "telegram_verified": True,
                "screenshot_path": screenshot_path,
                "proof_source": (
                    "telegram_web"
                    if screenshot_path
                    else "telegram_api"
                ),
            }

        except FloodWaitError as e:
            logger.error("🚨 Telegram FloodWait: %s seconds", e.seconds)
            return False, {}
        except Exception as e:
            logger.exception("❌ Telegram subscribe error: %s", e)
            return False, {}

    # ------------------------------------------------------
    # Current account username
    # ------------------------------------------------------

    async def _get_my_username(self) -> Optional[str]:
        try:
            me = await self.client.get_me()
            if getattr(me, "username", None):
                return me.username
            if getattr(me, "id", None):
                return str(me.id)
        except Exception:
            pass
        return None

    # ------------------------------------------------------
    # View
    # ------------------------------------------------------

    async def _view_posts(
        self,
        url: str,
        page
    ) -> Tuple[bool, Dict]:

        if not page:
            return False, {}

        try:
            username, post_id = self._extract_post_id(url)
            view_url = url
            if username and post_id:
                view_url = f"https://t.me/{username}/{post_id}"

            await page.goto(
                view_url,
                timeout=30_000,
                wait_until="domcontentloaded"
            )

            await self._apply_stealth_and_human_behavior(page)
            await self._dismiss_common_blockers(page)
            await self._human_delay(5, 10)

            screenshot_path = (
                await self._capture_screenshot(
                    page,
                    "telegram_view"
                )
            )

            return True, {
                "screenshot_path": screenshot_path
            }
        except Exception as e:
            logger.error("❌ Telegram view failed: %s", e)
            return False, {}

    # ------------------------------------------------------
    # Execute
    # ------------------------------------------------------

    async def execute_task(
        self,
        action: str,
        target_url: str,
        page=None,
        **kwargs
    ) -> Tuple[bool, Dict]:

        if not self.is_ready:
            logger.warning("⚠️ Telegram skill غير جاهزة.")
            return False, {}

        logger.info("🎯 Telegram action=%s url=%s", action, target_url)
        await self._human_delay()

        try:
            if action == "subscribe":
                return await self._subscribe(target_url, page=page)

            elif action == "start_bot" or action in {"start", "open_bot"}:
                # سياسة التشغيل: بوتات تيليجرام ممنوعة بالكامل
                logger.warning("🛑 Telegram bot tasks are blocked by policy: %s", target_url)
                return False, {
                    "status": "telegram_bot_blocked",
                    "reason": "telegram_bots_not_allowed",
                    "platform": "telegram",
                    "action": action,
                }

            elif action == "view":
                if page:
                    return await self._view_posts(target_url, page)
                return False, {}

            elif action == "like":
                if not page:
                    return False, {}
                try:
                    await page.goto(target_url, timeout=30_000, wait_until="domcontentloaded")
                    await self._apply_stealth_and_human_behavior(page)
                    await self._dismiss_common_blockers(page)
                    await self._human_delay(2, 4)

                    like_selectors = [
                        'button[aria-label="Like"]',
                        'button[aria-label="إعجاب"]',
                        'div[class*="reaction"]',
                        'svg[class*="like"]',
                    ]

                    for selector in like_selectors:
                        try:
                            btn = page.locator(selector).first
                            if await btn.is_visible():
                                await btn.click()
                                await self._human_delay(1, 2)
                                screenshot_path = await self._capture_screenshot(page, "telegram_like")
                                return True, {"screenshot_path": screenshot_path}
                        except Exception:
                            continue
                    return False, {}
                except Exception as e:
                    logger.error("❌ Telegram like failed: %s", e)
                    return False, {}

            elif action == "comment":
                if not page:
                    return False, {}
                try:
                    await page.goto(target_url, timeout=30_000, wait_until="domcontentloaded")
                    await self._apply_stealth_and_human_behavior(page)
                    await self._dismiss_common_blockers(page)
                    await self._human_delay(2, 4)

                    comment_selectors = [
                        'textarea[placeholder*="comment"]',
                        'textarea[placeholder*="تعليق"]',
                        'div[contenteditable="true"]',
                        'input[type="text"]',
                    ]

                    for selector in comment_selectors:
                        try:
                            input_field = page.locator(selector).first
                            if await input_field.is_visible():
                                comment_text = "👍 Отлично! 👍"
                                await input_field.click()
                                await self._human_delay(0.5, 1)
                                await input_field.type(comment_text, delay=random.randint(30, 80))
                                await self._human_delay(1, 2)

                                send_btn = page.locator(
                                    'button:has-text("Send"), button:has-text("إرسال")'
                                ).first
                                if await send_btn.is_visible():
                                    await send_btn.click()
                                    await self._human_delay(1, 2)
                                    screenshot_path = await self._capture_screenshot(page, "telegram_comment")
                                    return True, {"screenshot_path": screenshot_path}
                        except Exception:
                            continue
                    return False, {}
                except Exception as e:
                    logger.error("❌ Telegram comment failed: %s", e)
                    return False, {}

            return False, {}

        except FloodWaitError as e:
            logger.error("🚨 Telegram FloodWait: %s seconds", e.seconds)
            return False, {}
        except Exception as e:
            logger.exception("❌ Telegram execution error: %s", e)
            return False, {}


# ==========================================================
# VK Skill
# ==========================================================

class VKSkill(BaseSkill):
    """VK browser skill: Cookies/Profile only, no VK API dependency."""

    # Cookies updated from user provided JSON
    VK_COOKIES = [
    {
        "domain": ".m.vk.ru",
        "expirationDate": 1790743302.694262,
        "hostOnly": False,
        "httpOnly": False,
        "name": "domain_sid",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "lvLBhATSL9vnA7Whkmtng%3A1790138502693",
        "id": 1
    },
    {
        "domain": ".m.vk.ru",
        "expirationDate": 1790142097.859055,
        "hostOnly": False,
        "httpOnly": True,
        "name": "httoken",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "B2hShl-UJ0VlLUHRhpaU2s-VnQhYPDgS_bSZVkqYOwf4PKLcaCplSFVoPULdzViE1Q-Gl8YRmd45cpaociiX0gAkVr5pjfI6aSKcQoFVjcmxq6zEIUtiLNzpTCwCYc8TG1Zf",
        "id": 2
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1821674501,
        "hostOnly": False,
        "httpOnly": False,
        "name": "remixcolor_scheme_mode",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "auto",
        "id": 3
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1790224911,
        "hostOnly": False,
        "httpOnly": False,
        "name": "remixcurr_audio",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "undefined",
        "id": 4
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1821674501,
        "hostOnly": False,
        "httpOnly": False,
        "name": "remixdark_color_scheme",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "1",
        "id": 5
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1820025748.408464,
        "hostOnly": False,
        "httpOnly": True,
        "name": "remixdmgr",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "d62b485eba4012b2a60e92698f71ac4380d52213857aa05d6ce49d0eb9b12712",
        "id": 6
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1820213056,
        "hostOnly": False,
        "httpOnly": False,
        "name": "remixdt",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "0",
        "id": 7
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1791002502,
        "hostOnly": False,
        "httpOnly": False,
        "name": "remixff",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "10111111111111",
        "id": 8
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1790152691,
        "hostOnly": False,
        "httpOnly": False,
        "name": "remixgp",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "fdcd2aca8f4a3dfd14bc54c41b57670b",
        "id": 9
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1820401794.516693,
        "hostOnly": False,
        "httpOnly": False,
        "name": "remixlang",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "3",
        "id": 10
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1820636091.237017,
        "hostOnly": False,
        "httpOnly": True,
        "name": "remixlgck",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "30040c46874f373442",
        "id": 11
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1796453049,
        "hostOnly": False,
        "httpOnly": False,
        "name": "remixmdevice",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "384/832/2.8125/!!!!!!!!!!!/384",
        "id": 12
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1790139376,
        "hostOnly": False,
        "httpOnly": False,
        "name": "remixmsts",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "%7B%22data%22%3A%5B%5B1790138512%2C%22entries_requests%22%2C1%2C%22audio%22%2C%22mvk%22%5D%2C%5B1790138512%2C%22entries_requests%22%2C1%2C%22audio_player_bottom%22%2C%22mvk%22%5D%2C%5B1790138512%2C%22unique_adblock_users%22%2C1043297158%2C%22mvk%22%2C%22False%22%2CNone%2C%22feed%22%5D%5D%2C%22uniqueId%22%3A605819768.3959%7D",
        "id": 13
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1820357291.50379,
        "hostOnly": False,
        "httpOnly": False,
        "name": "remixrefkey",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "31b1a56ecb2f273f5f",
        "id": 14
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1821162385.857955,
        "hostOnly": False,
        "httpOnly": True,
        "name": "remixsid",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "1_83AkaWjhsJO17kcPR6wEjx4Y3uzNni-4stS7YGQB7fl-Q0GFqjCtqmGmm_-qb5PNGQ_-qyJtii_p4EO2oxlOJQ",
        "id": 15
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1820213053.697067,
        "hostOnly": False,
        "httpOnly": False,
        "name": "remixstid",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "1122134027_jpoQ1wRDT5vxzXs4tH0Si3zvCqwH9eCUdxefnoTIEt0",
        "id": 16
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1820213053.697633,
        "hostOnly": False,
        "httpOnly": False,
        "name": "remixstlid",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "9077813819768798879_MDLlQT0UU0cujRg9vqFq7CwBQ7qRjaMnerll1655agP",
        "id": 17
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1820337756.561126,
        "hostOnly": False,
        "httpOnly": True,
        "name": "remixsuc",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "1%3A",
        "id": 18
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1822098007.04305,
        "hostOnly": False,
        "httpOnly": False,
        "name": "remixua",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "17%7C614%7C172%7C2472894652",
        "id": 19
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1819781033.238745,
        "hostOnly": False,
        "httpOnly": True,
        "name": "remixuacck",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "72ac0b5b726850b200",
        "id": 20
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1820517243.224411,
        "hostOnly": False,
        "httpOnly": True,
        "name": "remixuas",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "Zjk4ZjIzMGNhZjMzMWNkMWRmMjA0MDIz",
        "id": 21
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1818909700,
        "hostOnly": False,
        "httpOnly": False,
        "name": "tmr_lvid",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "475c6ae13c43da359c091a256b2f2cd5",
        "id": 22
    },
    {
        "domain": ".vk.ru",
        "expirationDate": 1818909700,
        "hostOnly": False,
        "httpOnly": False,
        "name": "tmr_lvidTS",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "1788581732736",
        "id": 23
    },
    {
        "domain": "m.vk.ru",
        "expirationDate": 1821565297.857849,
        "hostOnly": True,
        "httpOnly": True,
        "name": "remixnsid",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "vk1.a.AMn742n2TOwlRWcj0FGGJ1fqUGfi_tAqO0YNNv7XjWAQz73ytTpIxvYAcGq3q_YHif24bwDg6_LBiaTBGwyBMYIAVXNySgHdBKbdk8FSt68-psmR_CwFJir-0cPY4HwltjEsaPEHHrQu294oVXWx8aGkcgqcjP17sbpzplRdVHhb-IHV-E0ljkvI3_2tvmnn",
        "id": 24
    },
    {
        "domain": "m.vk.ru",
        "expirationDate": 1790224903,
        "hostOnly": True,
        "httpOnly": False,
        "name": "tmr_detect",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "0%7C1790138503515",
        "id": 25
    }
]

    ACTIONS = {
        "subscribe", "join", "follow", "like", "comment",
        "view", "share", "repost", "review",
    }

    def __init__(self):
        self.is_ready = False
        self.browser_session_ready = False
        self.last_status = None

    async def initialize(self, config: dict):
        self.is_ready = True
        logger.info("✅ VK Browser/Cookies skill جاهزة بدون VK API.")

    @classmethod
    def _playwright_cookies(cls):
        external_path = os.getenv("VK_COOKIES_FILE", "/root/sessions/vk.json").strip()
        if external_path and Path(str(external_path)).expanduser().exists():
            try:
                with Path(external_path).expanduser().open("r", encoding="utf-8") as handle:
                    external_cookies = json.load(handle)
                if isinstance(external_cookies, dict):
                    external_cookies = external_cookies.get("cookies", [])
                if isinstance(external_cookies, list) and external_cookies:
                    source_cookies = external_cookies
                else:
                    logger.warning("VK_COOKIES_FILE is empty; using built-in fallback.")
                    source_cookies = cls.VK_COOKIES
            except Exception as error:
                logger.warning("Could not load VK_COOKIES_FILE: %s", error)
                source_cookies = cls.VK_COOKIES
        else:
            source_cookies = cls.VK_COOKIES

        converted = []
        for item in source_cookies:
            if not item.get("name") or "value" not in item:
                continue
            cookie = {
                "name": str(item["name"]),
                "value": str(item["value"]),
                "domain": str(item.get("domain", ".vk.ru")),
                "path": str(item.get("path", "/")),
                "httpOnly": bool(item.get("httpOnly", False)),
                "secure": bool(item.get("secure", False)),
            }
            expiration = item.get("expirationDate")
            if expiration:
                cookie["expires"] = float(expiration)
            same_site = str(item.get("sameSite", "")).lower()
            cookie["sameSite"] = (
                "None" if same_site in {"none", "no_restriction"}
                else "Strict" if same_site == "strict"
                else "Lax"
            )
            converted.append(cookie)
        return converted

    @staticmethod
    def _browser_url(target_url: str) -> str:
        if "vk.com" in target_url:
            return target_url.replace("vk.com", "vk.ru")
        if target_url.startswith("http://"):
            return "https://" + target_url[7:]
        return target_url

    async def _load_cookies(self, page) -> bool:
        try:
            cookies = self._playwright_cookies()
            if not cookies:
                return False
            await page.context.add_cookies(cookies)
            self.browser_session_ready = True
            logger.info("✅ تم تحميل Cookies VK داخل Browser context.")
            return True
        except Exception as error:
            logger.warning("⚠️ فشل تحميل Cookies VK: %s", error)
            return False

    async def _capture_screenshot(self, page, prefix="vk") -> Optional[str]:
        if not page:
            return None
        try:
            screenshot_dir = Path("data/screenshots/vk")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            path = screenshot_dir / (
                f"{prefix}_{int(time.time())}_"
                f"{random.randint(1000, 9999)}.png"
            )
            await page.screenshot(path=str(path), full_page=False)
            return str(path)
        except Exception as error:
            logger.warning("VK screenshot failed: %s", error)
            return None

    async def _body(self, page) -> str:
        try:
            return (await page.locator("body").inner_text()).lower()
        except Exception:
            return ""

    async def _session_status(self, page) -> str:
        current_url = (page.url or "").lower()
        body = await self._body(page)
        if any(x in current_url for x in ("/login", "/signin", "/auth")):
            return "login_required"
        if any(x in body for x in ("войти", "войдите", "log in", "sign in")):
            return "login_required"
        if any(x in body for x in ("captcha", "капча", "робот", "robot")):
            return "captcha_detected"
        return "ready"

    async def _first_visible(self, page, selectors):
        for selector in selectors:
            try:
                item = page.locator(selector).first
                if await item.count() and await item.is_visible() and await item.is_enabled():
                    return item
            except Exception:
                continue
        return None

    async def _already_subscribed(self, page) -> bool:
        selectors = [
            'button:has-text("Вы подписаны")',
            'button:has-text("Вы вступили")',
            'button:has-text("В группе")',
            '[aria-label*="Вы подписаны"]',
            '[data-testid*="joined"]',
        ]
        if await self._first_visible(page, selectors):
            return True
        body = await self._body(page)
        return any(x in body for x in ("вы подписаны", "вы вступили", "в группе"))

    async def _already_liked(self, page) -> bool:
        selectors = [
            '[aria-pressed="true"]',
            'button[aria-label*="Убрать отметку"]',
            'button[aria-label*="Unlike"]',
            '[data-reaction-target="like"].active',
            '.like_btn.active',
        ]
        return bool(await self._first_visible(page, selectors))

    async def _verify_action(self, page, action: str) -> bool:
        if action in ('subscribe', 'join', 'follow'):
            return await self._already_subscribed(page)
        if action == "like":
            return await self._already_liked(page)
        if action in ('comment', 'review'):
            body = await self._body(page)
            return any(x in body for x in ("комментарий добавлен", "комментарий опубликован", "comment posted"))
        if action in ('view', 'share', 'repost'):
            body = await self._body(page)
            if action == "view":
                return True
            return any(
                x in body
                for x in (
                    "запись скопирована",
                    "репост",
                    "поделились",
                    "опубликовано",
                    "shared",
                    "reposted",
                )
            )
        return False

    async def _click_first(self, page, selectors):
        button = await self._first_visible(page, selectors)
        if not button:
            return False
        try:
            await button.scroll_into_view_if_needed()
            await button.click(timeout=10_000)
            await self._human_delay(2, 4)
            return True
        except Exception as error:
            logger.debug("VK click failed: %s", error)
            return False

    async def _comment(self, page, text: str) -> bool:
        if not text.strip():
            return False
        areas = [
            'textarea[name="comment"]',
            'textarea[name="text"]',
            'textarea[placeholder*="коммент"]',
            'textarea[placeholder*="Комментар"]',
            'textarea[placeholder*="comment"]',
            '[contenteditable="true"]',
        ]
        area = await self._first_visible(page, areas)
        if not area:
            await self._click_first(page, [
                'button:has-text("Написать")',
                '#post_field',
                '[placeholder*="Что у вас нового"]',
                '[placeholder*="Что нового"]',
            ])
            area = await self._first_visible(page, areas)
        if not area:
            return False
        try:
            await area.scroll_into_view_if_needed()
            await area.click()
            try:
                await area.fill(text)
            except Exception:
                await area.press("Control+A")
                await area.press("Backspace")
                await area.type(text, delay=random.randint(25, 75))
            await self._human_delay(0.5, 1.2)
            submit = await self._first_visible(page, [
                'button[type="submit"]',
                'button:has-text("Отправить")',
                'button:has-text("Опубликовать")',
                'button:has-text("Send")',
                'button:has-text("Post")',
            ])
            if not submit:
                return False
            await submit.click(timeout=10_000)
            await self._human_delay(2, 4)
            return True
        except Exception as error:
            logger.warning("VK comment failed: %s", error)
            return False

    async def execute_task(
        self,
        action: str,
        target_url: str,
        page=None,
        comment_text: str = "",
        **kwargs
    ) -> Tuple[bool, Dict]:
        action = str(action or "").strip().lower()
        if action == "follow": action = "subscribe"
        if action == "join": action = "subscribe"

        if not page:
            return False, {"status": "missing_browser_page", "action": action}
        if not target_url:
            return False, {"status": "missing_target_url", "action": action}
        if action not in self.ACTIONS:
            return False, {"status": "unsupported_action", "action": action}

        try:
            await self._load_cookies(page)
            await self._apply_stealth_and_human_behavior(page)

            browser_url = self._browser_url(target_url)
            await page.goto(browser_url, timeout=45_000, wait_until="domcontentloaded")
            await self._dismiss_common_blockers(page)
            await self._human_delay(3, 6)

            session_status = await self._session_status(page)
            self.last_status = session_status
            if session_status != "ready":
                return False, {"status": session_status, "action": action}

            if action == "view":
                await self._scroll_to_bottom_and_up(page)
                await self._human_delay(8, 18)
            elif action == "subscribe":
                if not await self._already_subscribed(page):
                    clicked = await self._click_first(page, [
                        'button:has-text("Подписаться")',
                        'button:has-text("Вступить в группу")',
                        'button:has-text("Вступить")',
                        'button:has-text("Follow")',
                        'button:has-text("Join")',
                        'button.vkuiButton:has-text("Подписаться")',
                        'button.vkuiButton:has-text("Вступить")',
                        '#join_button',
                        '[data-testid="group-subscribe-button"]',
                        '[data-task-click="Join"]',
                    ])
                    if not clicked: return False, {"status": "subscribe_control_not_found", "action": action}
                    await self._human_delay(2, 5)
                if not await self._already_subscribed(page):
                    return False, {"status": "subscription_not_verified", "action": action}
            elif action == "like":
                if not await self._already_liked(page):
                    clicked = await self._click_first(page, [
                        'button[aria-label="Нравится"]',
                        'button[aria-label="Like"]',
                        '[data-testid="post-bottom-like"]',
                        '[data-reaction-target="like"]',
                        '.like_btn',
                    ])
                    if not clicked: return False, {"status": "like_control_not_found", "action": action}
                    await self._human_delay(2, 5)
                if not await self._already_liked(page):
                    return False, {"status": "like_not_verified", "action": action}
            elif action in ('comment', 'review'):
                text = str(comment_text or kwargs.get("review_text") or kwargs.get("text") or "")
                if not await self._comment(page, text):
                    return False, {"status": "comment_control_not_found_or_failed", "action": action}
                if not await self._verify_action(page, action):
                    return False, {"status": "comment_not_verified", "action": action}
            elif action in ('share', 'repost'):
                clicked = await self._click_first(page, [
                    'button[aria-label*="Поделиться"]',
                    'button[aria-label*="Share"]',
                    'button[aria-label*="Репост"]',
                    'button[aria-label*="Repost"]',
                    '[data-testid*="share"]',
                    '[data-testid*="repost"]',
                ])
                if not clicked:
                    return False, {"status": "share_control_not_found", "action": action}
                if not await self._verify_action(page, action):
                    return False, {"status": "share_not_verified", "action": action}

            screenshot_path = await self._capture_screenshot(page, f"vk_{action}_verified")
            if not screenshot_path:
                return False, {"status": "proof_screenshot_failed", "action": action}

            return True, {
                "status": "done",
                "platform": "vk",
                "action": action,
                "proof_path": screenshot_path,
                "screenshot_path": screenshot_path,
                "execution_method": "browser_cookies",
                "verified": True,
            }

        except Exception as error:
            logger.exception("VK browser skill failed: %s", error)
            return False, {"status": "vk_browser_error", "action": action, "error": str(error)[:500]}


# ==========================================================
# TikTok Skill
# ==========================================================

class TikTokSkill(BaseSkill):

    TIKTOK_COOKIES = [
    {
        "domain": ".tiktok.com",
        "expirationDate": 1821291060.860144,
        "hostOnly": False,
        "httpOnly": False,
        "name": "_ttp",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "3Ha8g2HJKzRGjdLDFsZXOPl4eKJ",
        "id": 1
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1793778423.984326,
        "hostOnly": False,
        "httpOnly": True,
        "name": "cmpl_token",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "AgQQAPObF-RO0rirMaXYZd0v8Oym_I-SP5anYKVEBw",
        "id": 2
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1820130423.983749,
        "hostOnly": False,
        "httpOnly": True,
        "name": "d_ticket",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "1509bbfe40c05e5b5062969bc273f94802174",
        "id": 3
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1791002960.340561,
        "hostOnly": False,
        "httpOnly": False,
        "name": "msToken",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "IJsqC_RtGgdsCnBKFUV95uoFtGLel3ApMqfG3G9GNayCZKTa8UdDhLh-U1phsOmncqXKPkkyfEA3GOlccYo6Q_sFz6BxOlLoX6PrHQuiXV60w1YW1W9za5T7sDIUUk91ETWV6hJ9uTv1xC217YJGaPmQrEXH3WjWyNmi7v0EHAYC",
        "id": 4
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1793778423.984056,
        "hostOnly": False,
        "httpOnly": True,
        "name": "multi_sids",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "7536174752505201686%3A73a2d54894cc098c57c9e9451c8f4ef6",
        "id": 5
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1821674965.153487,
        "hostOnly": False,
        "httpOnly": True,
        "name": "odin_tt",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "1ed94756582a0fefd96a1d941086a8e3fdedbd25179fc26076fdd224b1913d85111593df03fdb362ef7deadc8d9e9ff150b3f650530cba285202cf6dd10d6cfc05f53c6a2e8750b69c2573a475313ed8",
        "id": 6
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1804146423.984988,
        "hostOnly": False,
        "httpOnly": True,
        "name": "sessionid",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "73a2d54894cc098c57c9e9451c8f4ef6",
        "id": 7
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1804146423.985081,
        "hostOnly": False,
        "httpOnly": True,
        "name": "sessionid_ss",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "73a2d54894cc098c57c9e9451c8f4ef6",
        "id": 8
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1819698423.984429,
        "hostOnly": False,
        "httpOnly": True,
        "name": "sid_guard",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "73a2d54894cc098c57c9e9451c8f4ef6%7C1788594423%7C15552000%7CThu%2C+04-Mar-2027+07%3A47%3A03+GMT",
        "id": 9
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1804146423.984897,
        "hostOnly": False,
        "httpOnly": True,
        "name": "sid_tt",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "73a2d54894cc098c57c9e9451c8f4ef6",
        "id": 10
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1804146423.985391,
        "hostOnly": False,
        "httpOnly": True,
        "name": "sid_ucp_v1",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "1.0.1-KGRhODg5MTYzNjRlOTQ2MTBmZjQxMmQwMWYwMjBlNGVlODQ1N2ZmYTAKIgiWiNyCpeD3ymgQ95Hv1AYYswsgDDDLvtfEBjgEQOoHSAQQBRoEbm8xYSIgNzNhMmQ1NDg5NGNjMDk4YzU3YzllOTQ1MWM4ZjRlZjYyTgogvDQnsroR97VlPR7jC-pUGm9kX1wpPFzkyyDFSw6fsiESIAJWrPAerdlOS951bpSNWieKO5bewBE7w7epBgh_PDWKGAIiBnRpa3Rvaw",
        "id": 11
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1804146423.985531,
        "hostOnly": False,
        "httpOnly": True,
        "name": "ssid_ucp_v1",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "1.0.1-KGRhODg5MTYzNjRlOTQ2MTBmZjQxMmQwMWYwMjBlNGVlODQ1N2ZmYTAKIgiWiNyCpeD3ymgQ95Hv1AYYswsgDDDLvtfEBjgEQOoHSAQQBRoEbm8xYSIgNzNhMmQ1NDg5NGNjMDk4YzU3YzllOTQ1MWM4ZjRlZjYyTgogvDQnsroR97VlPR7jC-pUGm9kX1wpPFzkyyDFSw6fsiESIAJWrPAerdlOS951bpSNWieKO5bewBE7w7epBgh_PDWKGAIiBnRpa3Rvaw",
        "id": 12
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1804146428.887094,
        "hostOnly": False,
        "httpOnly": True,
        "name": "store-country-code",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "fr",
        "id": 13
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1804146428.887136,
        "hostOnly": False,
        "httpOnly": True,
        "name": "store-country-code-src",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "uid",
        "id": 14
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1804146428.887042,
        "hostOnly": False,
        "httpOnly": True,
        "name": "store-country-sign",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "MEIEDH1VWEyckbnq62Y6bAQgAQ9mtEawg2TaFu_5WYAa0Ox5nLw6DXiXApEvU4MRoRgEEGZAtZU4GWG43ALS2zsC6TM",
        "id": 15
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1804146428.88693,
        "hostOnly": False,
        "httpOnly": True,
        "name": "store-idc",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "no1a",
        "id": 16
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1805690940.260157,
        "hostOnly": False,
        "httpOnly": True,
        "name": "tt_chain_token",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "jc/D6zb1aO1G8UVaFCowsQ==",
        "id": 17
    },
    {
        "domain": ".tiktok.com",
        "hostOnly": False,
        "httpOnly": True,
        "name": "tt_csrf_token",
        "path": "/",
        "sameSite": "lax",
        "secure": True,
        "session": True,
        "storeId": "0",
        "value": "RGaQrqPV-m_Sb3reTCAC2PFePWQgmzsG7Kf4",
        "id": 18
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1804146423.985238,
        "hostOnly": False,
        "httpOnly": True,
        "name": "tt_session_tlb_tag",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "sttt%7C2%7Cc6LVSJTMCYxXyelFHI9O9v_________rLIsC6Ql3lUIjOUr7IozBrOwHW2vtpF-l08hpVkbi5TQ%3D",
        "id": 19
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1804146428.887173,
        "hostOnly": False,
        "httpOnly": True,
        "name": "tt-target-idc",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "eu-ttp2",
        "id": 20
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1820130425.299368,
        "hostOnly": False,
        "httpOnly": True,
        "name": "tt-target-idc-sign",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "e7-kh6lBBNkNJIUgGgfVAKVA9DipletU202Pt2vsI0J5dHR9BhI7xw7Gh_6LFo_e9w3DdejEyL8Hiaj0Tnvb_k69n7XPZjCvDcBrCOS5FxO06Ck_uNT0W-0cfmY_gPtUsn9hvrCys1lyb3wKQ2zhyOdS8ieVR4MUUn5vKg1GicxIMzvj_2EQ8EEXh0zLjKfQNl0y-PefMagNHM1n_yydnoPYJPuY2KqZz0qeaR90KPh0SVlB8KVQ9_chGgo1PlDY0nxZ5Gx0utE-eWB40IIdWAf0sDyDPH72POaX_nxIyBwqeR9Gmvi-r5nZrPe98HgrJGgxkzbElA2jMc6POX-V-foZTQEW5ruxFS_GUxJubnFXUUBAtYhb_MyNAwquPNywJGr4IKLQICcBjqhME43EQXavWpfHke4_g5xc23q1IxZWQLawtaNCw8ak4jrNS6CV0vQ1YXrAAtdxz4nzdw5xxOTY71dI2BONTOA-wqODe7mpKw93UVc6ba407sEFue3C",
        "id": 21
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1821674964.385353,
        "hostOnly": False,
        "httpOnly": True,
        "name": "ttwid",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "1%7CoBP-43qV_LaSteCHZW6brYm93a1Wr0nUG5H-OwhW05A%7C1790138964%7Cc4368eec48d5f9434bb7e81bc51196175092547462e779f0c04a6ae8a5ce614b",
        "id": 22
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1804146423.984608,
        "hostOnly": False,
        "httpOnly": True,
        "name": "uid_tt",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "7ecf7ef30abaec012b270a4a3e406f469b76dd166abaf82ea3cdd9966d92efb6",
        "id": 23
    },
    {
        "domain": ".tiktok.com",
        "expirationDate": 1804146423.984792,
        "hostOnly": False,
        "httpOnly": True,
        "name": "uid_tt_ss",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "7ecf7ef30abaec012b270a4a3e406f469b76dd166abaf82ea3cdd9966d92efb6",
        "id": 24
    },
    {
        "domain": ".www.tiktok.com",
        "expirationDate": 1814350455,
        "hostOnly": False,
        "httpOnly": False,
        "name": "delay_guest_mode_vid",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "5",
        "id": 25
    },
    {
        "domain": ".www.tiktok.com",
        "hostOnly": False,
        "httpOnly": False,
        "name": "passport_fe_beating_status",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": True,
        "storeId": "0",
        "value": "True",
        "id": 26
    },
    {
        "domain": ".www.tiktok.com",
        "expirationDate": 1790743760,
        "hostOnly": False,
        "httpOnly": False,
        "name": "perf_feed_cache",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "{%22expireTimestamp%22:1790740800000%2C%22itemIds%22:[%227683551499196091669%22%2C%227687571096488480018%22%2C%227668294112335957268%22]}",
        "id": 27
    },
    {
        "domain": ".www.tiktok.com",
        "expirationDate": 1816058942,
        "hostOnly": False,
        "httpOnly": False,
        "name": "tiktok_webapp_theme",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "dark",
        "id": 28
    },
    {
        "domain": ".www.tiktok.com",
        "expirationDate": 1816058942,
        "hostOnly": False,
        "httpOnly": False,
        "name": "tiktok_webapp_theme_source",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "auto",
        "id": 29
    },
    {
        "domain": "www.tiktok.com",
        "expirationDate": 1796370424,
        "hostOnly": True,
        "httpOnly": False,
        "name": "last_login_method",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "handle",
        "id": 30
    },
    {
        "domain": "www.tiktok.com",
        "expirationDate": 1797914966,
        "hostOnly": True,
        "httpOnly": False,
        "name": "msToken",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "tu7RtCC1HPNg4KILdX_uxy2ecOEvaDCwy8ala6ZReU8QyAxrXSQEDpGDAOnGrJl5FMVAaubI2N1ghfNFgkr6f_zuPtUJW-Ou_arl9n3ymV2rlanMxPDRKTL47dK8KuhAoWueNMtEmx8aOgj_KFH9twQdwTICbfMLrlvYcbcwdJfc",
        "id": 31
    },
    {
        "domain": "www.tiktok.com",
        "expirationDate": 1790225361.550222,
        "hostOnly": True,
        "httpOnly": False,
        "name": "tt_ticket_guard_has_set_public_key",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "1",
        "id": 32
    }
]

    async def _load_cookies(self, page) -> bool:
        try:
            formatted = await self._format_playwright_cookies(self.TIKTOK_COOKIES, ".tiktok.com")
            if not formatted: return False
            await page.context.add_cookies(formatted)
            logger.info("✅ TikTok Cookies loaded successfully.")
            return True
        except Exception as error:
            logger.warning("⚠️ Failed to load TikTok cookies: %s", error)
            return False

    async def _capture_screenshot(
        self,
        page,
        prefix="tiktok"
    ) -> Optional[str]:

        if not page:
            return None

        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = (screenshot_dir / f"{prefix}_{int(time.time())}_{random.randint(1000,9999)}.png")
            await page.screenshot(path=str(ss_path))
            return str(ss_path)
        except Exception:
            return None

    async def execute_task(
        self,
        action: str,
        target_url: str,
        page=None,
        comment_text: str = "Great video! 👏",
        **kwargs
    ) -> Tuple[bool, Dict]:

        if not page:
            return False, {"status": "missing_page", "platform": "tiktok"}

        try:
            await self._load_cookies(page)
            await self._apply_stealth_and_human_behavior(page)

            await page.goto(
                target_url,
                timeout=55_000,
                wait_until="domcontentloaded"
            )

            await self._human_delay(4, 8)
            await self._dismiss_common_blockers(page)

            health = await self._session_health_check(page, "tiktok")
            if health["status"] in {
                "login_required", "captcha", "automation_block", "page_error",
                "region_block", "content_restricted", "ip_blocked", "http_404",
            }:
                ss = await self._capture_screenshot(page, f"tiktok_{health['status']}")
                logger.error("❌ TikTok session health failed: %s", health["status"])
                return False, {
                    "status": health["status"],
                    "reason": health.get("reason"),
                    "screenshot_path": ss,
                    "platform": "tiktok",
                    "session_health": health,
                }

            # محاولة تشغيل الفيديو لو واقف (مشكلة "Не удается воспроизвести")
            try:
                play_btn = page.locator(
                    'button[aria-label*="Play"], [data-e2e="video-play"], .play-button, video'
                ).first
                if await play_btn.count():
                    await play_btn.click(timeout=2500)
                    await asyncio.sleep(random.uniform(1.5, 3.0))
            except Exception:
                pass

            await self._dismiss_common_blockers(page)

            if action == "like":
                selectors = [
                    'span[data-e2e="like-icon"]',
                    'button[data-e2e="like-icon"]',
                    'button[data-e2e="like"]',
                    '[data-e2e="like-action"]',
                    'span[data-e2e="browse-like-icon"]',
                    'div[data-e2e="like-icon"]',
                    '[data-e2e="browse-like-icon"]',
                    '[data-e2e="video-like-icon"]',
                    'button[aria-label*="like" i]',
                    'button[aria-label*="Like"]',
                    'span[data-e2e="like-icon"] path',
                    'div[class*="LikeAction"]',
                    'button:has(span[data-e2e="like-icon"])',
                ]
                click = await self._smart_click_with_retry(page, selectors, platform="tiktok", refresh_on_miss=True)
                if click["status"] in {"login_required", "captcha", "automation_block"}:
                    ss = await self._capture_screenshot(page, f"tiktok_{click['status']}")
                    return False, {"status": click["status"], "screenshot_path": ss, "platform": "tiktok", "click": click}
                if not click["clicked"]:
                    return False, {"status": "control_not_found", "platform": "tiktok", "action": action, "click": click}
                await self._human_delay(2, 4)
                screenshot_path = await self._capture_screenshot(page, "tiktok_like")
                proof = await self._score_proof_page(page, "tiktok", "like")
                return proof.get("acceptable", True), {
                    "screenshot_path": screenshot_path,
                    "status": "done" if proof.get("acceptable", True) else "proof_low_quality",
                    "proof_score": proof,
                }

            elif action == "subscribe":
                # BUGFIX: "Подписки" في الشريط الجانبي ≠ مشترك في الحساب
                async def _tt_already_following() -> bool:
                    checks = [
                        '[data-e2e="follow-button"]:has-text("Following")',
                        '[data-e2e="follow-button"]:has-text("Вы подписаны")',
                        '[data-e2e="follow-button"]:has-text("Unfollow")',
                        '[data-e2e="follow-button"]:has-text("Отписаться")',
                        'button[data-e2e="follow-button"]:has-text("Following")',
                        'button[data-e2e="follow-button"]:has-text("Вы подписаны")',
                        'button:has-text("Вы подписаны")',
                        'button:has-text("Following")',
                    ]
                    for sel in checks:
                        try:
                            loc = page.locator(sel).first
                            if await loc.count() and await loc.is_visible(timeout=800):
                                txt = (await loc.inner_text()).strip().lower()
                                if txt in {"подписки", "subscriptions", "сообщения"}:
                                    continue
                                return True
                        except Exception:
                            continue
                    return False

                if await _tt_already_following():
                    screenshot_path = await self._capture_screenshot(page, "tiktok_already_sub")
                    proof = await self._score_proof_page(page, "tiktok", "subscribe")
                    return True, {
                        "screenshot_path": screenshot_path,
                        "status": "already_following",
                        "proof_score": proof,
                    }

                selectors = [
                    '[data-e2e="follow-button"]',
                    'button[data-e2e="follow-button"]',
                    'button[data-e2e="browse-follow"]',
                    '[data-e2e="browse-follow"]',
                    '[data-e2e="follow-button"] button',
                    'button[data-e2e="user-follow"]',
                    '[data-e2e="user-follow"]',
                    'button:has-text("Подписаться")',
                    'button:has-text("Follow")',
                    'button:has-text("متابعة")',
                    '[role="button"]:has-text("Подписаться")',
                    '[role="button"]:has-text("Follow")',
                    'button:has-text("Follow back")',
                    'button:has-text("Подписаться на")',
                    # فيديو / بروفايل
                    'div[class*="DivFollowButton"] button',
                    'button[class*="FollowButton"]',
                    'button[class*="follow"]',
                ]

                # دوس مباشر على الزر الوردي Подписаться
                clicked_direct = False
                try:
                    pink = page.locator(
                        'button:has-text("Подписаться"), [data-e2e="follow-button"]'
                    ).first
                    if await pink.count() and await pink.is_visible(timeout=2500):
                        await pink.scroll_into_view_if_needed()
                        box = await pink.bounding_box()
                        if box:
                            await page.mouse.move(
                                box["x"] + box["width"] / 2,
                                box["y"] + box["height"] / 2,
                                steps=random.randint(6, 14),
                            )
                            await asyncio.sleep(random.uniform(0.15, 0.45))
                        await pink.click(timeout=5000, delay=random.randint(40, 120))
                        clicked_direct = True
                        await self._human_delay(2, 4)
                except Exception as e:
                    logger.debug("TikTok direct follow click: %s", e)

                if not clicked_direct or not await _tt_already_following():
                    click = await self._smart_click_with_retry(
                        page, selectors, platform="tiktok", refresh_on_miss=True
                    )
                    if click.get("status") in {"login_required", "captcha", "automation_block"}:
                        ss = await self._capture_screenshot(page, f"tiktok_{click['status']}")
                        return False, {
                            "status": click["status"],
                            "screenshot_path": ss,
                            "platform": "tiktok",
                            "click": click,
                        }
                    if not click.get("clicked") and not clicked_direct:
                        return False, {
                            "status": "control_not_found",
                            "platform": "tiktok",
                            "action": action,
                            "click": click,
                        }
                    await self._human_delay(2, 5)
                else:
                    click = {"clicked": True, "status": "direct"}

                # تأكيد: الزر الوردي اختفى أو بقى Following
                still_need_follow = False
                try:
                    still = page.locator('button:has-text("Подписаться")').first
                    if await still.count() and await still.is_visible(timeout=1500):
                        still_need_follow = True
                except Exception:
                    pass

                screenshot_path = await self._capture_screenshot(page, "tiktok_subscribe")
                proof = await self._score_proof_page(page, "tiktok", "subscribe")

                if still_need_follow and not await _tt_already_following():
                    logger.error(
                        "TikTok: click ran but Подписаться still visible (not subscribed)"
                    )
                    return False, {
                        "status": "subscribe_not_confirmed",
                        "screenshot_path": screenshot_path,
                        "platform": "tiktok",
                        "proof_score": proof,
                        "click": click,
                    }

                return True, {
                    "screenshot_path": screenshot_path,
                    "status": "done",
                    "proof_score": proof,
                    "click": click,
                }

            elif action == "repost":
                try:
                    share_selectors = [
                        'span[data-e2e="share-icon"]',
                        'button[aria-label="Share"]',
                        'span[data-e2e="share-text"]',
                        '[data-e2e="browse-share"]',
                    ]
                    share_click = await self._smart_click_with_retry(page, share_selectors, platform="tiktok", refresh_on_miss=False)
                    if share_click["clicked"]:
                        await self._human_delay(1, 2)
                        repost_selectors = [
                            'span:has-text("Repost")',
                            'span:has-text("إعادة النشر")',
                            'div[class*="repost"]',
                            'div[data-e2e="share-repost"]',
                        ]
                        repost_click = await self._smart_click_with_retry(page, repost_selectors, platform="tiktok", refresh_on_miss=False)
                        if repost_click["clicked"]:
                            await self._human_delay(1, 2)
                            screenshot_path = await self._capture_screenshot(page, "tiktok_repost")
                            proof = await self._score_proof_page(page, "tiktok", "repost")
                            return True, {"screenshot_path": screenshot_path, "status": "done", "proof_score": proof}
                except Exception:
                    pass

            elif action == "comment":
                try:
                    comment_icon_selectors = [
                        'span[data-e2e="comment-icon"]',
                        'button[data-e2e="comment-icon"]',
                        '[data-e2e="browse-comment-icon"]',
                    ]
                    icon_click = await self._smart_click_with_retry(page, comment_icon_selectors, platform="tiktok", refresh_on_miss=False)
                    if icon_click["clicked"]:
                        await self._human_delay(1, 2)
                        input_field = page.locator(
                            'div[data-e2e="comment-input"], input[placeholder*="comment" i], input[placeholder*="تعليق"], div[contenteditable="true"]'
                        ).first
                        if await input_field.is_visible(timeout=3000):
                            await input_field.click()
                            await asyncio.sleep(random.uniform(0.2, 0.5))
                            try:
                                await input_field.type(comment_text, delay=random.randint(40, 110))
                            except Exception:
                                await page.keyboard.type(comment_text, delay=random.randint(40, 110))
                            post_selectors = [
                                'div[data-e2e="comment-post"]',
                                'button:has-text("Post")',
                                'button:has-text("نشر")',
                            ]
                            post_click = await self._smart_click_with_retry(page, post_selectors, platform="tiktok", refresh_on_miss=False)
                            if post_click["clicked"]:
                                await self._human_delay(2, 3)
                                screenshot_path = await self._capture_screenshot(page, "tiktok_comment")
                                proof = await self._score_proof_page(page, "tiktok", "comment")
                                return True, {"screenshot_path": screenshot_path, "status": "done", "proof_score": proof}
                except Exception as comment_error:
                    logger.warning("TikTok comment failed: %s", type(comment_error).__name__)

            elif action == "view":
                try:
                    await page.mouse.wheel(0, random.randint(300, 700))
                except Exception:
                    pass
                await self._human_delay(8, 16)
                screenshot_path = await self._capture_screenshot(page, "tiktok_view")
                proof = await self._score_proof_page(page, "tiktok", "view")
                return True, {"screenshot_path": screenshot_path, "status": "done", "proof_score": proof}

            return False, {"status": "execution_failed", "platform": "tiktok", "action": action}

        except Exception as e:
            logger.error("❌ TikTok error: %s", e)

        return False, {"status": "execution_failed", "platform": "tiktok"}


# ==========================================================
# Facebook Skill
# ==========================================================

class FacebookSkill(BaseSkill):

    async def _capture_screenshot(self, page, prefix="facebook") -> Optional[str]:
        if not page: return None
        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = screenshot_dir / f"{prefix}_{int(time.time())}_{random.randint(1000,9999)}.png"
            await page.screenshot(path=str(ss_path))
            return str(ss_path)
        except Exception: return None

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs) -> Tuple[bool, Dict]:
        if not page: return False, {}
        try:
            await self._apply_stealth_and_human_behavior(page)

            await page.goto(target_url, timeout=45_000, wait_until="domcontentloaded")
            await self._dismiss_common_blockers(page)
            await self._human_delay(3, 6)
            await self._scroll_to_bottom_and_up(page)

            if action == "like":
                selectors = [
                    'div[aria-label="Like"]',
                    'div[aria-label="أعجبني"]',
                    'div[aria-label="Нравится"]',
                    'div[aria-label="Love"]',
                    'div[class*="like"]',
                    'span:has-text("Like")',
                    'span:has-text("أعجبني")',
                ]
                for selector in selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible():
                            await btn.click()
                            await self._human_delay(1, 2)
                            screenshot_path = await self._capture_screenshot(page, "fb_like")
                            return True, {"screenshot_path": screenshot_path}
                    except Exception: continue

            elif action == "subscribe":
                selectors = [
                    'div[aria-label="Join Group"]',
                    'div[aria-label="انضمام للمجموعة"]',
                    'div[aria-label="Вступить в группу"]',
                    'div[aria-label="Follow"]',
                    'div[aria-label="متابعة"]',
                    'div[aria-label="Подписаться"]',
                    'button[class*="follow"]',
                    'span:has-text("Join Group")',
                    'span:has-text("Follow")',
                ]
                for selector in selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible():
                            await btn.click()
                            await self._human_delay(1, 2)
                            screenshot_path = await self._capture_screenshot(page, "fb_subscribe")
                            return True, {"screenshot_path": screenshot_path}
                    except Exception: continue

        except Exception as e:
            logger.error("❌ Facebook error: %s", e)
        return False, {}


# ==========================================================
# Review Skill
# ==========================================================

class ReviewSkill(BaseSkill):

    async def _capture_screenshot(self, page, prefix="review") -> Optional[str]:
        if not page: return None
        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = screenshot_dir / f"{prefix}_{int(time.time())}_{random.randint(1000,9999)}.png"
            await page.screenshot(path=str(ss_path))
            return str(ss_path)
        except Exception: return None

    async def execute_task(self, action: str, target_url: str, page=None, review_text="Отличное приложение, рекомендую!", **kwargs) -> Tuple[bool, Dict]:
        if not page: return False, {}
        try:
            await self._apply_stealth_and_human_behavior(page)

            await page.goto(target_url, timeout=45_000, wait_until="domcontentloaded")
            await self._dismiss_common_blockers(page)
            await self._human_delay(4, 8)

            if "play.google.com" in target_url:
                selectors = [
                    'button:has-text("Написать отзыв")',
                    'button:has-text("Write a review")',
                    'button:has-text("كتابة مراجعة")',
                    'div[class*="review"]',
                ]
                for selector in selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible():
                            await btn.click()
                            await self._human_delay()

                            star_selector = (
                                'div[aria-label="Оценить на 5 звезд"], '
                                'div[aria-label="Rate 5 stars"], '
                                'div[aria-label="تقييم 5 نجوم"]'
                            )
                            star_btn = page.locator(star_selector).first
                            if await star_btn.is_visible(): await star_btn.click()

                            await self._type_like_human(page, "textarea", review_text)
                            await self._human_delay()

                            submit_btn = page.locator(
                                'button:has-text("Опубликовать"), button:has-text("Publish"), button:has-text("نشر")'
                            ).first
                            if await submit_btn.is_visible():
                                await submit_btn.click()
                                await self._human_delay(1, 2)
                                screenshot_path = await self._capture_screenshot(page, "googleplay_review")
                                return True, {"screenshot_path": screenshot_path}
                    except Exception: continue

            elif "yandex.ru/maps" in target_url or "maps.google.com" in target_url:
                await page.mouse.wheel(0, 1000)
                await self._human_delay(3, 6)
                review_tab = page.locator(
                    'a:has-text("Отзывы"), button:has-text("Отзывы"), button:has-text("Reviews"), button:has-text("المراجعات")'
                ).first
                if await review_tab.is_visible():
                    await review_tab.click()
                    await self._human_delay(1, 2)
                    screenshot_path = await self._capture_screenshot(page, "maps_review")
                    return True, {"screenshot_path": screenshot_path}

        except Exception as e:
            logger.error("❌ Review error: %s", e)
        return False, {}


# ==========================================================
# NEW SKILLS ADDED FOR UNU.IM
# ==========================================================

class YouTubeSkill(BaseSkill):
    # ✅ NEW: Added static cookies for YouTube
    YOUTUBE_COOKIES = [
    {
        "domain": ".youtube.com",
        "expirationDate": 1824698751.293292,
        "hostOnly": False,
        "httpOnly": False,
        "name": "__Secure-1PAPISID",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "ekd1b218jcDF2dY5/AgAyHd7rzx7k6pKlG",
        "id": 1
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1824698751.294852,
        "hostOnly": False,
        "httpOnly": True,
        "name": "__Secure-1PSID",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "g.a000CQl2e772r8NbRemCjDnJMUmi7iE81lOks5XI1ODXfDIk-RvmXz7Xge0BkPnMZmVu7VEdBAACgYKAVUSARMSFQHGX2MiuXtRB0FnnBmz31U3mF-3exoVAUF8yKrCu4EbanraVSPUx1MxW5j-0076",
        "id": 2
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1821674756.708357,
        "hostOnly": False,
        "httpOnly": True,
        "name": "__Secure-1PSIDCC",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "AKEyXzVU9SJvz5P7AoY-cxUAkwG8DklEklvKdlOyZnmGkCfT0jnzmMjG74oMdfX9pMfV8SszoQ",
        "id": 3
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1821674751.291392,
        "hostOnly": False,
        "httpOnly": True,
        "name": "__Secure-1PSIDTS",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "sidts-CjUBXMw41fVKhyvsBeY02NTlWnSFkoaA67RidtRuPqL76LojP98p0cFlUFsngBlK3r3clZsmhhAA",
        "id": 4
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1824698751.29353,
        "hostOnly": False,
        "httpOnly": False,
        "name": "__Secure-3PAPISID",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "ekd1b218jcDF2dY5/AgAyHd7rzx7k6pKlG",
        "id": 5
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1824698751.295154,
        "hostOnly": False,
        "httpOnly": True,
        "name": "__Secure-3PSID",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "g.a000CQl2e772r8NbRemCjDnJMUmi7iE81lOks5XI1ODXfDIk-RvmoNknZZKo7mjqynzZslGfoAACgYKAV4SARMSFQHGX2Mi9PIcdHMX4gruNqFPJAhCghoVAUF8yKq1dWXNpY4nGyQAXIAvRxTf0076",
        "id": 6
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1821674756.708456,
        "hostOnly": False,
        "httpOnly": True,
        "name": "__Secure-3PSIDCC",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "AKEyXzVMGL1ItOvt7jAx0P8PsEEaJxQ0Dvc50iwEpMtrgE02fyP92WRNc9iXFyUMtQq4VndFyKc",
        "id": 7
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1821674751.291914,
        "hostOnly": False,
        "httpOnly": True,
        "name": "__Secure-3PSIDTS",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "sidts-CjUBXMw41fVKhyvsBeY02NTlWnSFkoaA67RidtRuPqL76LojP98p0cFlUFsngBlK3r3clZsmhhAA",
        "id": 8
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1824698751.292792,
        "hostOnly": False,
        "httpOnly": False,
        "name": "APISID",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "JYi6Lxk9W9BsCOXk/A3nts7aTIP9_SYvBp",
        "id": 9
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1824698751.292277,
        "hostOnly": False,
        "httpOnly": True,
        "name": "HSID",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "AJEGA2mEoFxoByjrD",
        "id": 10
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1824698752.666398,
        "hostOnly": False,
        "httpOnly": True,
        "name": "LOGIN_INFO",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "AFmmF2swRAIgKdXNlZdpp9jYGNyqr-CXiK00CbEScCdRdr8krV0-_kQCIHLdp3-QUk7AtKxyAKERMvjg2q_u02JaKZEmGF_Vv_0M:QUQ3MjNmd0VNOW0wcFcycHZJdllFdV9ONURJZVQzdWdtclFYWGUyZ28yMkZIWmhfS1BLeVkzYWZ1eUM2dFZpcDlaM3ZZMG9CXzZFMVY4a3FWZ0tpVHVoZl82bmxPbVByenU3U1J4eTk2bHlFQlVCUEN6TG1QdDIxaF9XRnQxaThzby1XZW9ncjlfaTJMNXBlZ0FabEtyOFMyNkh3N0ZvQm13",
        "id": 11
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1824698754.368093,
        "hostOnly": False,
        "httpOnly": False,
        "name": "PREF",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "f6=40000000&tz=Africa.Cairo&f4=4000000&f7=100",
        "id": 12
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1824698751.293044,
        "hostOnly": False,
        "httpOnly": False,
        "name": "SAPISID",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "ekd1b218jcDF2dY5/AgAyHd7rzx7k6pKlG",
        "id": 13
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1824698751.293837,
        "hostOnly": False,
        "httpOnly": False,
        "name": "SID",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "g.a000CQl2e772r8NbRemCjDnJMUmi7iE81lOks5XI1ODXfDIk-RvmsdtmmrgWIk0sf7W4wDawZQACgYKAb4SARMSFQHGX2MiY2G1wEJutfTIPBY1WZAZhRoVAUF8yKr604bESdlUqJXoixd9JnBB0076",
        "id": 14
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1821674756.708169,
        "hostOnly": False,
        "httpOnly": False,
        "name": "SIDCC",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "AKEyXzUdEEiTjaZ9L4Mg_dxD7NLAfdQ3S27q3TjdXaYv7QYZvEhUalzI6I4xACgKPl9xWYIH",
        "id": 15
    },
    {
        "domain": ".youtube.com",
        "expirationDate": 1824698751.292558,
        "hostOnly": False,
        "httpOnly": True,
        "name": "SSID",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "AV6VwUHh9LCCD-92R",
        "id": 16
    }
]

    async def _capture_screenshot(self, page, prefix="youtube") -> Optional[str]:
        if not page: return None
        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = screenshot_dir / f"{prefix}_{int(time.time())}_{random.randint(1000,9999)}.png"
            await page.screenshot(path=str(ss_path))
            return str(ss_path)
        except Exception: return None

    async def _load_cookies(self, page) -> bool:
        try:
            cookies_src = list(self.YOUTUBE_COOKIES or [])
            try:
                path = Path("/root/sessions/youtube.json")
                if path.exists():
                    raw = json.loads(path.read_text(encoding="utf-8"))
                    external = raw if isinstance(raw, list) else (raw.get("cookies") or [])
                    if external:
                        cookies_src = list(external)
                        logger.info("YouTube: using external cookies file (%s)", len(external))
            except Exception as _ext_err:
                logger.debug("youtube external cookies: %s", _ext_err)
            formatted = await self._format_playwright_cookies(cookies_src, ".youtube.com")
            if not formatted: return False
            await page.context.add_cookies(formatted)
            logger.info("✅ YouTube Cookies loaded successfully (%s).", len(formatted))
            return True
        except Exception as error:
            logger.warning("⚠️ Failed to load YouTube cookies: %s", error)
            return False

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs) -> Tuple[bool, Dict]:
        if not page: return False, {}
        try:
            await self._load_cookies(page)
            await self._apply_stealth_and_human_behavior(page)
            await page.goto(target_url, timeout=45_000, wait_until="domcontentloaded")
            await self._dismiss_common_blockers(page)
            await self._human_delay(4, 7)
            await self._scroll_to_bottom_and_up(page)

            if action == "subscribe":
                selectors = ['ytd-subscribe-button-renderer button', '#subscribe-button button', 'button:has-text("Subscribe")', 'button:has-text("Подписаться")']
                for selector in selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible():
                            await btn.click()
                            await self._human_delay(1, 2)
                            ss = await self._capture_screenshot(page, "yt_sub")
                            return True, {"screenshot_path": ss}
                    except Exception: continue

            elif action == "like":
                selectors = ['like-button-view-model button', 'ytd-toggle-button-renderer button', '[aria-label*="Like"]', '[aria-label*="Нравится"]']
                for selector in selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible():
                            await btn.click()
                            await self._human_delay(1, 2)
                            ss = await self._capture_screenshot(page, "yt_like")
                            return True, {"screenshot_path": ss}
                    except Exception: continue

            elif action == "view":
                await self._human_delay(15, 30) # Watch video
                ss = await self._capture_screenshot(page, "yt_view")
                return True, {"screenshot_path": ss}

        except Exception as e: logger.error("❌ YouTube error: %s", e)
        return False, {}

class InstagramSkill(BaseSkill):
    
    INSTAGRAM_COOKIES = [
    {
        "domain": ".instagram.com",
        "expirationDate": 1824698592.936575,
        "hostOnly": False,
        "httpOnly": False,
        "name": "csrftoken",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "0pdhxHOu5YMQQl7MEn20I82QTZjTkAZw",
        "id": 1
    },
    {
        "domain": ".instagram.com",
        "expirationDate": 1822990761.919851,
        "hostOnly": False,
        "httpOnly": True,
        "name": "datr",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "qUmZarUI1wEIftM6sLBJ9cim",
        "id": 2
    },
    {
        "domain": ".instagram.com",
        "expirationDate": 1790743386,
        "hostOnly": False,
        "httpOnly": False,
        "name": "dpr",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "2.8125",
        "id": 3
    },
    {
        "domain": ".instagram.com",
        "expirationDate": 1797914592.937058,
        "hostOnly": False,
        "httpOnly": False,
        "name": "ds_user_id",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "31051270271",
        "id": 4
    },
    {
        "domain": ".instagram.com",
        "expirationDate": 1819966761.919915,
        "hostOnly": False,
        "httpOnly": True,
        "name": "ig_did",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "557C5E77-40DF-4ADF-BB5F-745ADE558C1B",
        "id": 5
    },
    {
        "domain": ".instagram.com",
        "expirationDate": 1822990765,
        "hostOnly": False,
        "httpOnly": False,
        "name": "mid",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "aplJqQABAAF5W9YisdMIjfThWphZ",
        "id": 6
    },
    {
        "domain": ".instagram.com",
        "expirationDate": 1823236378.358323,
        "hostOnly": False,
        "httpOnly": True,
        "name": "ps_l",
        "path": "/",
        "sameSite": "lax",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "1",
        "id": 7
    },
    {
        "domain": ".instagram.com",
        "expirationDate": 1823236378.358522,
        "hostOnly": False,
        "httpOnly": True,
        "name": "ps_n",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "1",
        "id": 8
    },
    {
        "domain": ".instagram.com",
        "hostOnly": False,
        "httpOnly": True,
        "name": "rur",
        "path": "/",
        "sameSite": "lax",
        "secure": True,
        "session": True,
        "storeId": "0",
        "value": "NCG%2C17841431148141408%2C1791348193%3A01fffdf8b69ff0f1eb8591dfd964b11d6f58abefbf2309750270dd9772403f47d1bbe22b",
        "id": 9
    },
    {
        "domain": ".instagram.com",
        "expirationDate": 1821674592.937832,
        "hostOnly": False,
        "httpOnly": True,
        "name": "sessionid",
        "path": "/",
        "sameSite": "unspecified",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "31051270271%3AZwK108Vg6hYhBm%3A23%3AAYkqsWSc1hJ5nDop7ZeHN5nCVnYHsA5e7Lel6L53AA",
        "id": 10
    },
    {
        "domain": ".instagram.com",
        "expirationDate": 1790743386,
        "hostOnly": False,
        "httpOnly": False,
        "name": "wd",
        "path": "/",
        "sameSite": "lax",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "384x733",
        "id": 11
    }
]

    async def _load_cookies(self, page) -> bool:
        try:
            formatted = await self._format_playwright_cookies(self.INSTAGRAM_COOKIES, ".instagram.com")
            if not formatted: return False
            await page.context.add_cookies(formatted)
            logger.info("✅ Instagram Cookies loaded successfully.")
            return True
        except Exception as error:
            logger.warning("⚠️ Failed to load Instagram cookies: %s", error)
            return False

    async def _capture_screenshot(self, page, prefix="instagram") -> Optional[str]:
        if not page: return None
        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = screenshot_dir / f"{prefix}_{int(time.time())}_{random.randint(1000,9999)}.png"
            await page.screenshot(path=str(ss_path))
            return str(ss_path)
        except Exception: return None

    async def execute_task(self, action: str, target_url: str, page=None, comment_text: str = "Amazing! 🔥", **kwargs) -> Tuple[bool, Dict]:
        if not page:
            return False, {"status": "missing_page", "platform": "instagram"}
        try:
            await self._load_cookies(page)
            await self._apply_stealth_and_human_behavior(page)
            await page.goto(target_url, timeout=55_000, wait_until="domcontentloaded")
            await self._dismiss_common_blockers(page)
            await self._human_delay(5, 9)

            health = await self._session_health_check(page, "instagram")
            if health["status"] in {
                "login_required", "captcha", "automation_block", "page_error",
                "region_block", "content_restricted", "ip_blocked", "http_404",
            }:
                ss = await self._capture_screenshot(page, f"ig_{health['status']}")
                logger.error("❌ Instagram session health failed: %s", health["status"])
                return False, {
                    "status": health["status"],
                    "reason": health.get("reason"),
                    "screenshot_path": ss,
                    "platform": "instagram",
                    "session_health": health,
                }

            await self._dismiss_common_blockers(page)

            if action == "subscribe":
                selectors = [
                    'button:has-text("متابعة")',
                    'button:has-text("Follow")',
                    'button:has-text("Подписаться")',
                    'div[role="button"]:has-text("Follow")',
                    'div[role="button"]:has-text("متابعة")',
                    'button:has-text("Follow back")',
                ]
                click = await self._smart_click_with_retry(page, selectors, platform="instagram", refresh_on_miss=True)
                if click["status"] in {"login_required", "captcha", "automation_block"}:
                    ss = await self._capture_screenshot(page, f"ig_{click['status']}")
                    return False, {"status": click["status"], "screenshot_path": ss, "platform": "instagram", "click": click}
                if not click["clicked"]:
                    return False, {"status": "control_not_found", "platform": "instagram", "action": action, "click": click}
                await self._human_delay(2, 4)
                ss = await self._capture_screenshot(page, "ig_sub")
                proof = await self._score_proof_page(page, "instagram", "subscribe")
                return proof.get("acceptable", True), {
                    "screenshot_path": ss,
                    "status": "done" if proof.get("acceptable", True) else "proof_low_quality",
                    "proof_score": proof,
                }

            elif action == "like":
                # Already liked?
                try:
                    unlike = page.locator('svg[aria-label="Unlike"], svg[aria-label="إلغاء الإعجاب"], [aria-label="Unlike"]').first
                    if await unlike.count() and await unlike.is_visible(timeout=1200):
                        ss = await self._capture_screenshot(page, "ig_like_already")
                        proof = await self._score_proof_page(page, "instagram", "like")
                        return True, {"screenshot_path": ss, "status": "already_liked", "proof_score": proof}
                except Exception:
                    pass
                # لايك المنشور/الريل فقط — مش لايك الكومنت
                selectors = [
                    'article section:first-of-type span[role="button"] svg[aria-label="Like"]',
                    'article section:first-of-type span[role="button"] svg[aria-label="Нравится"]',
                    'article section:first-of-type span[role="button"] svg[aria-label="إعجاب"]',
                    'main article section svg[aria-label="Like"]',
                    'main article section svg[aria-label="Нравится"]',
                    'article:first-of-type svg[aria-label="Like"]',
                    'article:first-of-type svg[aria-label="Нравится"]',
                    'article svg[aria-label="Like"]',
                    'article svg[aria-label="Нравится"]',
                    # Reels
                    'section svg[aria-label="Like"]',
                    'section svg[aria-label="Нравится"]',
                    'div[role="presentation"] svg[aria-label="Like"]',
                    'div[role="button"] svg[aria-label="Like"]',
                    '[aria-label="Like"]',
                    '[aria-label="Нравится"]',
                    '[aria-label="إعجاب"]',
                    'svg[aria-label="Like"]',
                    'svg[aria-label="Нравится"]',
                ]
                clicked_manual = False
                try:
                    article = page.locator("article").first
                    if await article.count():
                        post_like = article.locator(
                            'section >> nth=0 >> svg[aria-label="Like"], '
                            'section >> nth=0 >> svg[aria-label="Нравится"], '
                            'section >> nth=0 >> svg[aria-label="إعجاب"]'
                        ).first
                        if await post_like.count() and await post_like.is_visible(timeout=2000):
                            box = await post_like.bounding_box()
                            if box:
                                await page.mouse.move(
                                    box["x"] + box["width"] / 2,
                                    box["y"] + box["height"] / 2,
                                    steps=random.randint(8, 18),
                                )
                                await asyncio.sleep(random.uniform(0.25, 0.6))
                            await post_like.click(timeout=4000)
                            clicked_manual = True
                except Exception:
                    clicked_manual = False
                if clicked_manual:
                    click = {"clicked": True, "status": "done_post_like"}
                else:
                    click = await self._smart_click_with_retry(page, selectors, platform="instagram", refresh_on_miss=True)
                if click["status"] in {"login_required", "captcha", "automation_block"}:
                    ss = await self._capture_screenshot(page, f"ig_{click['status']}")
                    return False, {"status": click["status"], "screenshot_path": ss, "platform": "instagram", "click": click}
                if not click["clicked"]:
                    return False, {"status": "control_not_found", "platform": "instagram", "action": action, "click": click}
                await self._human_delay(2, 4)
                ss = await self._capture_screenshot(page, "ig_like")
                proof = await self._score_proof_page(page, "instagram", "like")
                return proof.get("acceptable", True), {
                    "screenshot_path": ss,
                    "status": "done" if proof.get("acceptable", True) else "proof_low_quality",
                    "proof_score": proof,
                }

            elif action == "comment":
                comment_text = str(
                    kwargs.get("comment_text")
                    or kwargs.get("text")
                    or kwargs.get("review_text")
                    or "🔥"
                ).strip() or "🔥"
                try:
                    try:
                        cicon = page.locator(
                            'article section:first-of-type svg[aria-label="Comment"], '
                            'article section:first-of-type svg[aria-label="Комментировать"], '
                            'article section:first-of-type svg[aria-label="تعليق"]'
                        ).first
                        if await cicon.count() and await cicon.is_visible(timeout=1500):
                            await cicon.click(timeout=3000)
                            await self._human_delay(0.8, 1.5)
                    except Exception:
                        pass
                    comment_field = page.locator(
                        'article textarea[placeholder*="comment" i], '
                        'article textarea[placeholder*="تعليق"], '
                        'article textarea[placeholder*="коммент"], '
                        'article textarea[placeholder*="Добавьте комментарий"], '
                        'form textarea, '
                        'textarea[placeholder*="comment" i], '
                        'textarea[placeholder*="коммент"], '
                        'textarea[placeholder*="تعليق"]'
                    ).first
                    if await comment_field.is_visible(timeout=5000):
                        await comment_field.scroll_into_view_if_needed()
                        await comment_field.click()
                        await asyncio.sleep(random.uniform(0.4, 0.9))
                        try:
                            await comment_field.fill("")
                        except Exception:
                            pass
                        await comment_field.type(comment_text[:400], delay=random.randint(50, 130))
                        await self._human_delay(0.6, 1.2)
                        post_selectors = [
                            'article form [role="button"]:has-text("Post")',
                            'article form [role="button"]:has-text("Опубликовать")',
                            'article form [role="button"]:has-text("نشر")',
                            'button:has-text("Post")',
                            'button:has-text("نشر")',
                            'button:has-text("Опубликовать")',
                            'div[role="button"]:has-text("Post")',
                            'div[role="button"]:has-text("Опубликовать")',
                        ]
                        post_click = await self._smart_click_with_retry(
                            page, post_selectors, platform="instagram", refresh_on_miss=False
                        )
                        if not post_click.get("clicked"):
                            try:
                                await comment_field.press("Enter")
                                post_click = {"clicked": True, "status": "enter_submit"}
                            except Exception:
                                pass
                        if post_click.get("clicked"):
                            await self._human_delay(2, 4)
                            ss = await self._capture_screenshot(page, "ig_comment")
                            proof = await self._score_proof_page(page, "instagram", "comment")
                            return True, {
                                "screenshot_path": ss,
                                "status": "done",
                                "proof_score": proof,
                                "comment_text": comment_text[:200],
                            }
                    ss = await self._capture_screenshot(page, "ig_comment_fail")
                    return False, {"status": "comment_field_not_found", "screenshot_path": ss, "platform": "instagram"}
                except Exception as error:
                    logger.warning("IG comment error: %s", error)
                    return False, {"status": "comment_error", "error": str(error)[:300], "platform": "instagram"}

            elif action in {"share", "repost"}:
                try:
                    share_selectors = [
                        'article section:first-of-type svg[aria-label="Share Post"]',
                        'article section:first-of-type svg[aria-label="Share"]',
                        'article section:first-of-type svg[aria-label="Поделиться"]',
                        'article section:first-of-type svg[aria-label="مشاركة"]',
                        'article svg[aria-label="Share Post"]',
                        'article svg[aria-label="Share"]',
                        'article svg[aria-label="Поделиться"]',
                    ]
                    click = await self._smart_click_with_retry(
                        page, share_selectors, platform="instagram", refresh_on_miss=True
                    )
                    await self._human_delay(1.0, 2.0)
                    try:
                        copy_btn = page.locator(
                            'button:has-text("Copy link"), button:has-text("Копировать ссылку"), '
                            'button:has-text("نسخ الرابط"), span:has-text("Copy link")'
                        ).first
                        if await copy_btn.count() and await copy_btn.is_visible(timeout=2000):
                            await copy_btn.click(timeout=3000)
                    except Exception:
                        pass
                    ss = await self._capture_screenshot(page, "ig_share")
                    if click.get("clicked"):
                        return True, {"screenshot_path": ss, "status": "done", "action": action}
                    return False, {"status": "share_control_not_found", "screenshot_path": ss, "platform": "instagram"}
                except Exception as error:
                    return False, {"status": "share_error", "error": str(error)[:300], "platform": "instagram"}

            return False, {"status": "unsupported_or_failed", "platform": "instagram", "action": action}

        except Exception as e:
            logger.error("❌ Instagram error: %s", e)
        return False, {"status": "execution_failed", "platform": "instagram"}

class RutubeSkill(BaseSkill):
    # ✅ NEW: Added static cookies for Rutube
    RUTUBE_COOKIES = [
        {"name": "wdpThemeId", "value": "dark2021", "domain": "rutube.ru", "hostOnly": True, "path": "/", "secure": False, "httpOnly": False, "sameSite": "strict", "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1823154102.587, "storeId": None},
        {"name": "_ym_uid", "value": "1788585974743787432", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": False, "httpOnly": False, "sameSite": None, "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1820121974, "storeId": None},
        {"name": "oxxfgh", "value": "L!e41b57f8-4f0a-8629-add7-1974ee5588c3%230%231800000%235000%231800000%2322820", "domain": "rutube.ru", "hostOnly": True, "path": "/", "secure": True, "httpOnly": False, "sameSite": None, "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1788587939, "storeId": None},
        {"name": "session_id", "value": "79330669491788585947_1788594104132", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": True, "httpOnly": False, "sameSite": "no_restriction", "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1788595978, "storeId": None},
        {"name": "uwyii", "value": "68df1b09-eeab-cec7-9f45-b7668f4423a4", "domain": "rutube.ru", "hostOnly": True, "path": "/", "secure": True, "httpOnly": False, "sameSite": None, "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1823145974.849, "storeId": None},
        {"name": "spid", "value": "1788586382993_0fae3b58dd3c73bdee566340c36a081c_mqko6gu8xld7qrh1", "domain": "rutube.ru", "hostOnly": True, "path": "/", "secure": True, "httpOnly": False, "sameSite": "no_restriction", "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1823146382.959, "storeId": None},
        {"name": "uxs_uid", "value": "4972a5e0-a8ea-11f1-b3c6-ed59c888e3f5", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": False, "httpOnly": False, "sameSite": None, "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1823145963, "storeId": None},
        {"name": "csrftoken", "value": "eIqPXjIaYTTF1kqicFfa1v44J7rBGwPi", "domain": "rutube.ru", "hostOnly": True, "path": "/", "secure": True, "httpOnly": False, "sameSite": "no_restriction", "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1820035737.611, "storeId": None},
        {"name": "refreshToken", "value": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJydXBhc3NfaWQiOjUxMjY3OTEyLCJleHAiOjE4MjAxMjIxMzcsInJlcXVlc3RfaWQiOiI0Y2MwNTk4MC1jOTkzLTQwMWMtOWNiYi0xMWZhZWRmMjgzYTIifQ.Sv0l3Jw4ExE0Anv6LrIUepizKrAbvAoZMWg7HI5liX0", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": True, "httpOnly": True, "sameSite": "no_restriction", "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1820122137.611, "storeId": None},
        {"name": "_ym_isad", "value": "2", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": False, "httpOnly": False, "sameSite": None, "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1788657975, "storeId": None},
        {"name": "_cookieTabId", "value": "119ac847-9e7d-6cce-4f29-f708ee7a746e", "domain": "rutube.ru", "hostOnly": True, "path": "/", "secure": True, "httpOnly": False, "sameSite": None, "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1788586143, "storeId": None},
        {"name": "_ym_d", "value": "1788585974", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": False, "httpOnly": False, "sameSite": None, "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1820121974, "storeId": None},
        {"name": "_ym_visorc", "value": "b", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": False, "httpOnly": False, "sameSite": None, "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1788595905, "storeId": None},
        {"name": "ajs_anonymous_id", "value": "686b8235-8699-423e-b9cf-471b91dbc923", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": False, "httpOnly": False, "sameSite": "lax", "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1820122137, "storeId": None},
        {"name": "canary1", "value": "{\"tags_predicto\":{\"active\":\"A\",\"term\":[{\"id\":44,\"label\":\"A\",\"percent\":100},{\"id\":45,\"label\":\"B\",\"percent\":100}]},\"new_player\":{\"active\":\"A\",\"term\":[{\"id\":50,\"label\":\"A\",\"percent\":100},{\"id\":51,\"label\":\"B\",\"percent\":100}]},\"ds_player\":{\"active\":\"A\",\"term\":[{\"id\":87,\"label\":\"A\",\"percent\":100},{\"id\":88,\"label\":\"B\",\"percent\":100}]},\"current_stage_ds\":{\"active\":\"A\",\"term\":[{\"id\":120,\"label\":\"A\",\"percent\":100},{\"id\":121,\"label\":\"B\",\"percent\":100}]}}", "domain": "rutube.ru", "hostOnly": True, "path": "/", "secure": False, "httpOnly": False, "sameSite": None, "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1801432800, "storeId": None},
        {"name": "cid", "value": "79330669491788585947", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": True, "httpOnly": False, "sameSite": "no_restriction", "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1823154181, "storeId": None},
        {"name": "jwt", "value": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJydXBhc3NfaWQiOjUxMjY3OTEyLCJlbWFpbF9jb25maXJtZWQiOnsidHlwZW9mIjoiYm9vbCIsInZhbHVlIjp0cnVlfSwiaGFzX3Bob25lIjp7InR5cGVvZiI6ImJvb2wiLCJ2YWx1ZSI6ZmFsc2V9LCJleHAiOjE3ODk3OTU3MzcsIm9yaWdfaWF0IjoxNzg4NTg2MTM3LCJyZXF1ZXN0X2lkIjoiNGNjMDU5ODAtYzk5My00MDFjLTljYmItMTFmYWVkZjI4M2EyIiwidXNlcl9pZCI6NTYwMjQ0MDMsImRhdGEiOnsidXNlcl9pbmZvIjp7ImlkIjo1NjAyNDQwM319LCJ1c2VybmFtZSI6Im15bWFud2VyMjAyMDEyMzQ1QGdtYWlsLmNvbSIsImVtYWlsIjoibXltYW53ZXIyMDIwMTIzNDVAZ21haWwuY29tIiwibmFtZSI6IiIsInBhcmVudCI6bnVsbCwidHlwZSI6ImFjY291bnQiLCJjb250ZXh0IjpudWxsLCJ0cnVzdCI6W10sInN1YnMiOltdfQ.wxXdivWiNzWnGT7T37j7BnSOMeMmG_yjco5PbGhZS7k", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": True, "httpOnly": True, "sameSite": "no_restriction", "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1789795737.611, "storeId": None},
        {"name": "mdd", "value": "0", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": False, "httpOnly": False, "sameSite": None, "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1788672537, "storeId": None},
        {"name": "psid2", "value": "65kjfjmba09zck00mobi8c0m8yzqcnvu", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": True, "httpOnly": False, "sameSite": "no_restriction", "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1791013303.161, "storeId": None},
        {"name": "qrator_msid2", "value": "v2.0.1788585940.542.54e948bdF8tcoqiC|AaoG0IxNFk4OQSaw|SqPf9d7/zjCo5qRuRhl6BeqiDk4CNJ9yNl6BAxGmWd2kWJx3HLTJYrVXVMVPWLq1IpLvdFpIxj0v95i7p+RhOw==-OM9msSu0fAEmAtZFA+fQlXqakeY=", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": False, "httpOnly": True, "sameSite": None, "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1788586941.166, "storeId": None},
        {"name": "source_social", "value": "gid", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": True, "httpOnly": False, "sameSite": "no_restriction", "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1820122137.611, "storeId": None},
        {"name": "uuid", "value": "af970f69-8aba-443f-b369-5731c91801a1", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": True, "httpOnly": False, "sameSite": "no_restriction", "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1823154104, "storeId": None},
        {"name": "uwyiert", "value": "1511474f-6751-1809-02eb-5dde5a963d3e", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": False, "httpOnly": False, "sameSite": None, "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1823146138.223, "storeId": None},
        {"name": "visitorID", "value": "56024403", "domain": ".rutube.ru", "hostOnly": False, "path": "/", "secure": True, "httpOnly": False, "sameSite": "no_restriction", "session": False, "firstPartyDomain": "", "partitionKey": None, "expirationDate": 1820122137.611, "storeId": None}
    ]

    async def _capture_screenshot(self, page, prefix="rutube") -> Optional[str]:
        if not page: return None
        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = screenshot_dir / f"{prefix}_{int(time.time())}_{random.randint(1000,9999)}.png"
            await page.screenshot(path=str(ss_path))
            return str(ss_path)
        except Exception: return None

    async def _load_cookies(self, page) -> bool:
        """يحمل كوكيز Rutube من /root/sessions/rutube.json أولاً ثم المضمّنة."""
        try:
            cookies_src = list(self.RUTUBE_COOKIES or [])
            try:
                path = Path("/root/sessions/rutube.json")
                if path.exists():
                    raw = json.loads(path.read_text(encoding="utf-8"))
                    external = raw if isinstance(raw, list) else (raw.get("cookies") or [])
                    if external:
                        cookies_src = list(external)
                        logger.info("Rutube: using external cookies file (%s)", len(external))
            except Exception as _ext_err:
                logger.debug("rutube external cookies: %s", _ext_err)
            formatted = await self._format_playwright_cookies(cookies_src, ".rutube.ru")
            if not formatted:
                return False
            await page.context.add_cookies(formatted)
            logger.info("✅ Rutube Cookies loaded successfully (%s).", len(formatted))
            return True
        except Exception as error:
            logger.warning("⚠️ Failed to load Rutube cookies: %s", error)
            return False

    async def _dismiss_rutube_overlays(self, page):
        """إغلاق مكثف لنوافذ روتوب الإعلانية والكوكي والاختيارات."""
        if not page:
            return
        # جولات متعددة لأن روتوب بيفتح طبقات فوق بعض
        for _ in range(3):
            await self._dismiss_common_blockers(page)
            extra = [
                'button:has-text("Закрыть")',
                'button:has-text("Пропустить")',
                'button:has-text("Скрыть")',
                'button:has-text("Больше не показывать")',
                'button:has-text("Не сейчас")',
                'button:has-text("Понятно")',
                'button:has-text("Принять")',
                'button:has-text("Принять все")',
                'button:has-text("Ok")',
                'button:has-text("OK")',
                'button:has-text("Хорошо")',
                '[class*="modal"] button[class*="close"]',
                '[class*="popup"] button[class*="close"]',
                'div[role="dialog"] button',
            ]
            for selector in extra:
                try:
                    btn = page.locator(selector).first
                    if await btn.count() and await btn.is_visible(timeout=500):
                        await btn.click(timeout=1500)
                        await asyncio.sleep(random.uniform(0.3, 0.7))
                except Exception:
                    continue
            await asyncio.sleep(0.4)

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs) -> Tuple[bool, Dict]:
        if not page:
            return False, {"status": "missing_page", "platform": "rutube"}
        try:
            await self._load_cookies(page)
            await self._apply_stealth_and_human_behavior(page)
            await page.goto(target_url, timeout=50_000, wait_until="domcontentloaded")
            await self._dismiss_rutube_overlays(page)
            await self._human_delay(4, 7)
            await self._dismiss_rutube_overlays(page)

            health = await self._session_health_check(page, "rutube")
            if health["status"] in {
                "login_required", "captcha", "automation_block", "page_error",
                "region_block", "content_restricted", "ip_blocked", "http_404",
            }:
                ss = await self._capture_screenshot(page, f"rutube_{health['status']}")
                return False, {
                    "status": health["status"],
                    "reason": health.get("reason"),
                    "screenshot_path": ss,
                    "platform": "rutube",
                    "session_health": health,
                }

            if action == "subscribe":
                # إغلاق طبقات تانية قبل الاشتراك
                await self._dismiss_rutube_overlays(page)
                await self._human_delay(1, 2)
                selectors = [
                    'button:has-text("Подписаться")',
                    'button:has-text("Subscribe")',
                    'a:has-text("Подписаться")',
                    '[data-testid*="subscribe" i]',
                    '[data-testid*="follow" i]',
                    'button[class*="subscribe" i]',
                    'button[class*="Subscribe"]',
                    '[class*="subscribe-button" i]',
                    '[class*="SubscribeButton"]',
                    'button:has-text("подписаться")',
                    # قناة / فيديو
                    '.wdp-button:has-text("Подписаться")',
                    'div[class*="subscribe"] button',
                ]
                # لو بالفعل مشترك
                try:
                    body_txt = (await page.inner_text("body"))[:4000]
                    if any(x in body_txt for x in ("Вы подписаны", "Отписаться", "Subscribed", "Unsubscribe")):
                        ss = await self._capture_screenshot(page, "rutube_already_sub")
                        return True, {
                            "status": "already_subscribed",
                            "screenshot_path": ss,
                            "platform": "rutube",
                            "action": action,
                        }
                except Exception:
                    pass
                click = await self._smart_click_with_retry(
                    page, selectors, platform="rutube", refresh_on_miss=True
                )
                await self._dismiss_rutube_overlays(page)
                if not click.get("clicked"):
                    # محاولة ثانية بعد scroll للأعلى حيث زر القناة
                    try:
                        await page.evaluate("window.scrollTo(0, 0)")
                        await self._human_delay(1, 2)
                        await self._dismiss_rutube_overlays(page)
                        click = await self._smart_click_with_retry(
                            page, selectors, platform="rutube", refresh_on_miss=False
                        )
                    except Exception:
                        pass
                if not click.get("clicked"):
                    return False, {
                        "status": click.get("status") or "control_not_found",
                        "platform": "rutube",
                        "action": action,
                        "click": click,
                    }
                await self._human_delay(2, 4)
                ss = await self._capture_screenshot(page, "rutube_sub")
                proof = await self._score_proof_page(page, "rutube", "subscribe")
                return proof.get("acceptable", True), {
                    "screenshot_path": ss,
                    "status": "done",
                    "proof_score": proof,
                    "platform": "rutube",
                    "action": action,
                }

            elif action == "like":
                await self._dismiss_rutube_overlays(page)
                # تشغيل الفيديو أحيانًا يظهر زر اللايك
                for play_sel in (
                    'button[aria-label*="Play" i]',
                    'button[aria-label*="Воспроиз"]',
                    '.wdp-player-play-button',
                    'button[class*="play" i]',
                ):
                    try:
                        loc = page.locator(play_sel).first
                        if await loc.count() and await loc.is_visible():
                            await loc.click(timeout=2500)
                            await self._human_delay(1, 2)
                            break
                    except Exception:
                        continue
                selectors = [
                    'button[aria-label="Лайк"]',
                    'button[aria-label*="Лайк" i]',
                    'button[aria-label*="Like" i]',
                    'button[aria-label*="нравится" i]',
                    '.wdp-button-like',
                    'button:has-text("Нравится")',
                    'button:has-text("Like")',
                    '[class*="like"] button',
                    'button[class*="like" i]',
                    '[data-testid*="like" i]',
                    '.wdp-video-like button',
                    'button svg[class*="like" i]',
                ]
                click = await self._smart_click_with_retry(
                    page, selectors, platform="rutube", refresh_on_miss=True
                )
                await self._dismiss_rutube_overlays(page)
                if not click.get("clicked"):
                    return False, {
                        "status": click.get("status") or "control_not_found",
                        "platform": "rutube",
                        "action": action,
                        "click": click,
                    }
                await self._human_delay(2, 4)
                ss = await self._capture_screenshot(page, "rutube_like")
                proof = await self._score_proof_page(page, "rutube", "like")
                return True, {
                    "screenshot_path": ss,
                    "status": "done",
                    "proof_score": proof,
                    "platform": "rutube",
                    "action": action,
                }

            elif action == "view":
                # مشاهدة على رابط الفيديو المطلوب — سكرين من صفحة الهدف فقط
                await self._dismiss_rutube_overlays(page)
                play_selectors = [
                    'button[aria-label*="Play"]',
                    'button[aria-label*="Воспроиз"]',
                    'button[aria-label*="play" i]',
                    '.wdp-player-play-button',
                    '[class*="play-button"]',
                    'button.play',
                ]
                for sel in play_selectors:
                    try:
                        loc = page.locator(sel).first
                        if await loc.count() and await loc.is_visible():
                            await loc.click(timeout=3000)
                            break
                    except Exception:
                        continue
                try:
                    await page.mouse.wheel(0, random.randint(120, 400))
                except Exception:
                    pass
                await self._human_delay(10, 18)
                cur = ""
                try:
                    cur = (page.url or "").lower()
                except Exception:
                    cur = ""
                # لو الصفحة مش فيديو نرجع للهدف
                if target_url and ("/video/" in str(target_url).lower() or "/shorts/" in str(target_url).lower()):
                    if "/video/" not in cur and "/shorts/" not in cur:
                        try:
                            await page.goto(target_url, timeout=50_000, wait_until="domcontentloaded")
                            await self._dismiss_rutube_overlays(page)
                            await self._human_delay(5, 9)
                        except Exception:
                            pass
                ss = await self._capture_screenshot(page, "rutube_view")
                return True, {
                    "screenshot_path": ss,
                    "proof_path": ss,
                    "status": "done",
                    "proof_source": "action_target",
                    "page_url": cur,
                }

        except Exception as e:
            logger.error("❌ Rutube error: %s", e)
        return False, {"status": "execution_failed", "platform": "rutube"}

class AvitoSkill(BaseSkill):
    async def _capture_screenshot(self, page, prefix="avito") -> Optional[str]:
        if not page: return None
        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = screenshot_dir / f"{prefix}_{int(time.time())}_{random.randint(1000,9999)}.png"
            await page.screenshot(path=str(ss_path))
            return str(ss_path)
        except Exception: return None

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs) -> Tuple[bool, Dict]:
        if not page: return False, {}
        try:
            await self._apply_stealth_and_human_behavior(page)
            await page.goto(target_url, timeout=45_000, wait_until="domcontentloaded")
            await self._dismiss_common_blockers(page)
            await self._human_delay(4, 7)
            await self._scroll_to_bottom_and_up(page)

            if action == "like": # Add to favorites
                selectors = ['button[data-marker="item-view/favorite-button"]', 'button:has-text("В избранное")']
                for selector in selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible():
                            await btn.click()
                            await self._human_delay(1, 2)
                            ss = await self._capture_screenshot(page, "avito_fav")
                            return True, {"screenshot_path": ss}
                    except Exception: continue

            elif action == "view":
                await self._human_delay(10, 15)
                ss = await self._capture_screenshot(page, "avito_view")
                return True, {"screenshot_path": ss}

            elif action in ("apply", "message"):
                # Apply to vacancies / send message
                apply_selectors = [
                    'button:has-text("Откликнуться")',
                    'button:has-text("Написать")',
                    'button[data-marker="item-contact-bar/button"]',
                    'a:has-text("Откликнуться")',
                ]
                for selector in apply_selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible(timeout=3000):
                            await btn.click()
                            await self._human_delay(2, 4)
                            # Fill message if textarea appears
                            textarea = page.locator('textarea').first
                            if await textarea.is_visible(timeout=2000):
                                await textarea.fill("Здравствуйте! Интересует вакансия.")
                                await self._human_delay(1, 2)
                                send_btn = page.locator('button:has-text("Отправить")').first
                                if await send_btn.is_visible(timeout=2000):
                                    await send_btn.click()
                                    await self._human_delay(2, 3)
                            ss = await self._capture_screenshot(page, "avito_apply")
                            return True, {"screenshot_path": ss, "action": action}
                    except Exception:
                        continue
                # Fallback: just screenshot
                ss = await self._capture_screenshot(page, "avito_apply_fallback")
                return True, {"screenshot_path": ss, "partial": True}

        except Exception as e: logger.error("❌ Avito error: %s", e)
        return False, {}

class OzonApiSkill(BaseSkill):
    async def _capture_screenshot(self, page, prefix="ozon") -> Optional[str]:
        if not page: return None
        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = screenshot_dir / f"{prefix}_{int(time.time())}_{random.randint(1000,9999)}.png"
            await page.screenshot(path=str(ss_path))
            return str(ss_path)
        except Exception: return None

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs) -> Tuple[bool, Dict]:
        if not page: return False, {}
        try:
            await self._apply_stealth_and_human_behavior(page)
            await page.goto(target_url if target_url.startswith("http") else "https://www.ozon.ru", timeout=45_000, wait_until="domcontentloaded")
            await self._dismiss_common_blockers(page)
            await self._human_delay(3, 5)
            
            # Search if needed
            search_query = kwargs.get("search_query", "")
            if search_query:
                search_input = page.locator('input[placeholder*="Искать"]').first
                if await search_input.is_visible(timeout=3000):
                    await search_input.fill(search_query)
                    await page.keyboard.press("Enter")
                    await self._human_delay(3, 5)
            
            # Scroll through product
            await self._scroll_to_bottom_and_up(page)
            await self._human_delay(2, 4)
            
            if action in ("like", "review"):
                # Find and like a review
                like_selectors = [
                    'button[data-widget="webReviewLike"]',
                    'button:has-text("Полезно")',
                    '[class*="like"]',
                ]
                for selector in like_selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible(timeout=2000):
                            await btn.click()
                            await self._human_delay(1, 2)
                            break
                    except Exception:
                        continue
            
            ss = await self._capture_screenshot(page, f"ozon_{action}")
            return True, {"screenshot_path": ss, "action": action}

        except Exception as e:
            logger.error("❌ Ozon error: %s", e)
        return False, {}


class MaxChannelsSkill(BaseSkill):
    """مهارة MAX للقنوات المتعددة."""
    
    async def _capture_screenshot(self, page, prefix="max") -> Optional[str]:
        if not page: return None
        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = screenshot_dir / f"{prefix}_{int(time.time())}_{random.randint(1000,9999)}.png"
            await page.screenshot(path=str(ss_path))
            return str(ss_path)
        except Exception: return None

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs) -> Tuple[bool, Dict]:
        if not page: return False, {}
        try:
            # استخراج كل القنوات من النص
            channels = kwargs.get("channels", [])
            if not channels and target_url:
                channels = [target_url]
            
            subscribed = 0
            for ch in channels[:15]:  # حد أقصى 15 قناة
                try:
                    await page.goto(ch, timeout=30_000, wait_until="domcontentloaded")
                    await self._human_delay(2, 4)
                    # اضغط زر الاشتراك
                    sub_selectors = [
                        'button:has-text("Подписаться")',
                        'button:has-text("Subscribe")',
                        '[data-testid="subscribe"]',
                        '.subscribe-btn',
                    ]
                    for sel in sub_selectors:
                        try:
                            btn = page.locator(sel).first
                            if await btn.is_visible(timeout=2000):
                                await btn.click()
                                await self._human_delay(1, 2)
                                subscribed += 1
                                break
                        except Exception:
                            continue
                except Exception as e:
                    logger.debug("MAX channel error: %s", e)
                    continue
            
            ss = await self._capture_screenshot(page, "max_channels")
            return subscribed > 0, {
                "screenshot_path": ss,
                "subscribed_count": subscribed,
                "total_channels": len(channels),
            }
        except Exception as e:
            logger.error("❌ MAX error: %s", e)
        return False, {}


class TwitterSkill(BaseSkill):
    
    X_COOKIES = [
        {"domain": ".x.com", "expirationDate": 1788441388.429764, "hostOnly": False, "httpOnly": True, "name": "__cf_bm", "path": "/", "sameSite": "no_restriction", "secure": True, "session": False, "storeId": "0", "value": "L4mtnoHdJfW6hh3PKW6wYhUcYrnJ2apIQgHxsI1IZSg-1788439588.2940278-1.0.1.1-DT4AkA34LLX.nJ2K0cuB9aG1mVUKNa7l4hSJOMzU1j..bdNsBEZ8owfx5r4W0gAO0irsZcQ1Xi5NLRsQxx4HL0xuoUhw5Da85MJL.QaPeOJsaSPI7Yf7XVuIENu.1dct", "id": 1},
        {"domain": ".x.com", "expirationDate": 1822999587, "hostOnly": False, "httpOnly": False, "name": "__cuid", "path": "/", "sameSite": "unspecified", "secure": False, "session": False, "storeId": "0", "value": "67f9fa03-41af-4b1d-a3db-7d71ec2ffbc7", "id": 2},
        {"domain": ".x.com", "expirationDate": 1819971338.804101, "hostOnly": False, "httpOnly": True, "name": "auth_token", "path": "/", "sameSite": "no_restriction", "secure": True, "session": False, "storeId": "0", "value": "a0d77d7ad9f5d8de4c91ddda25dc24fb5a292649", "id": 3},
        {"domain": ".x.com", "expirationDate": 1822995339.166211, "hostOnly": False, "httpOnly": False, "name": "ct0", "path": "/", "sameSite": "lax", "secure": True, "session": False, "storeId": "0", "value": "60c907fe83dd9eb46e229fb938e323b026965096c50fb9a43f9b27f72a638fb193d4b3cefceb4b64cc50b9af6314039515ed53bcb5e6dfc06f2ec55c74929bd7ddf188f90547d562f2fea1474dc04e31", "id": 4},
        {"domain": ".x.com", "expirationDate": 1788444283.738298, "hostOnly": False, "httpOnly": False, "name": "gt", "path": "/", "sameSite": "lax", "secure": True, "session": False, "storeId": "0", "value": "2095475573740978275", "id": 5},
        {"domain": ".x.com", "expirationDate": 1822995283.738361, "hostOnly": False, "httpOnly": False, "name": "guest_id", "path": "/", "sameSite": "no_restriction", "secure": True, "session": False, "storeId": "0", "value": "v1%3A178843528314479810", "id": 6},
        {"domain": ".x.com", "expirationDate": 1822999588.496309, "hostOnly": False, "httpOnly": False, "name": "guest_id_ads", "path": "/", "sameSite": "no_restriction", "secure": True, "session": False, "storeId": "0", "value": "v1%3A178843528314479810", "id": 7},
        {"domain": ".x.com", "expirationDate": 1822999588.496406, "hostOnly": False, "httpOnly": False, "name": "guest_id_marketing", "path": "/", "sameSite": "no_restriction", "secure": True, "session": False, "storeId": "0", "value": "v1%3A178843528314479810", "id": 8},
        {"domain": ".x.com", "expirationDate": 1822995287.55839, "hostOnly": False, "httpOnly": False, "name": "personalization_id", "path": "/", "sameSite": "no_restriction", "secure": True, "session": False, "storeId": "0", "value": "\"v1_XEjdSRALtFEMwmNlCfm/cQ==\"", "id": 9},
        {"domain": ".x.com", "expirationDate": 1819975588.626477, "hostOnly": False, "httpOnly": False, "name": "twid", "path": "/", "sameSite": "no_restriction", "secure": True, "session": False, "storeId": "0", "value": "u%3D2095475678120460289", "id": 10},
        {"domain": "x.com", "expirationDate": 1822999587, "hostOnly": True, "httpOnly": False, "name": "__cuid", "path": "/", "sameSite": "unspecified", "secure": False, "session": False, "storeId": "0", "value": "67f9fa03-41af-4b1d-a3db-7d71ec2ffbc7", "id": 11},
        {"domain": "x.com", "expirationDate": 1803987307, "hostOnly": True, "httpOnly": False, "name": "g_state", "path": "/", "sameSite": "no_restriction", "secure": True, "session": False, "storeId": "0", "value": "{\"i_l\":0,\"i_ll\":1788435295416,\"i_e\":{\"enable_itp_optimization\":24},\"i_et\":1788435295416}", "id": 12},
        {"domain": "x.com", "hostOnly": True, "httpOnly": False, "name": "lang", "path": "/", "sameSite": "unspecified", "secure": False, "session": True, "storeId": "0", "value": "en", "id": 13}
    ]

    async def _load_cookies(self, page) -> bool:
        try:
            cookies_src = list(self.X_COOKIES or [])
            try:
                for cand in ("/root/sessions/x.json", "/root/sessions/twitter.json"):
                    path = Path(cand)
                    if path.exists():
                        raw = json.loads(path.read_text(encoding="utf-8"))
                        external = raw if isinstance(raw, list) else (raw.get("cookies") or [])
                        if external:
                            cookies_src = list(external)
                            logger.info("X/Twitter: using external cookies file %s (%s)", cand, len(external))
                            break
            except Exception as _ext_err:
                logger.debug("x external cookies: %s", _ext_err)
            formatted = await self._format_playwright_cookies(cookies_src, ".x.com")
            if not formatted: return False
            await page.context.add_cookies(formatted)
            logger.info("✅ X (Twitter) Cookies loaded successfully (%s).", len(formatted))
            return True
        except Exception as error:
            logger.warning("⚠️ Failed to load X cookies: %s", error)
            return False

    async def _capture_screenshot(self, page, prefix="twitter") -> Optional[str]:
        if not page: return None
        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = screenshot_dir / f"{prefix}_{int(time.time())}_{random.randint(1000,9999)}.png"
            await page.screenshot(path=str(ss_path))
            return str(ss_path)
        except Exception: return None

    async def execute_task(self, action: str, target_url: str, page=None, comment_text: str = "Amazing content!", **kwargs) -> Tuple[bool, Dict]:
        if not page: return False, {}
        try:
            await self._load_cookies(page)
            await self._apply_stealth_and_human_behavior(page)
            await page.goto(target_url, timeout=45_000, wait_until="domcontentloaded")
            await self._dismiss_common_blockers(page)
            await self._human_delay(4, 7)

            if action == "subscribe":
                # Adapted based on Screenshot_20260903_143739
                selectors = ['[data-testid="placementTracking"] button', 'button:has-text("Follow")']
                for selector in selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible():
                            await btn.click()
                            await self._human_delay(1, 2)
                            ss = await self._capture_screenshot(page, "x_sub")
                            return True, {"screenshot_path": ss}
                    except Exception: continue

            elif action == "like":
                # Adapted based on Screenshot_20260903_143729
                selectors = ['[data-testid="like"]']
                for selector in selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible():
                            await btn.click()
                            await self._human_delay(1, 2)
                            ss = await self._capture_screenshot(page, "x_like")
                            return True, {"screenshot_path": ss}
                    except Exception: continue

            elif action == "repost":
                # Adapted based on Screenshot_20260903_143729
                selectors = ['[data-testid="retweet"]']
                for selector in selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible():
                            await btn.click()
                            await self._human_delay(1, 2)
                            confirm = page.locator('[data-testid="retweetConfirm"]').first
                            if await confirm.is_visible():
                                await confirm.click()
                                await self._human_delay(1, 2)
                            ss = await self._capture_screenshot(page, "x_repost")
                            return True, {"screenshot_path": ss}
                    except Exception: continue
            
            elif action == "comment":
                try:
                    reply_btn = page.locator('[data-testid="reply"]').first
                    if await reply_btn.is_visible():
                        await reply_btn.click()
                        await self._human_delay(1, 2)
                        input_field = page.locator('.public-DraftEditor-content').first
                        if await input_field.is_visible():
                            await input_field.click()
                            await self._type_like_human(page, str(input_field), comment_text)
                            tweet_btn = page.locator('[data-testid="tweetButton"]').first
                            if await tweet_btn.is_visible():
                                await tweet_btn.click()
                                await self._human_delay(2, 3)
                                ss = await self._capture_screenshot(page, "x_comment")
                                return True, {"screenshot_path": ss}
                except Exception:
                    pass

        except Exception as e: logger.error("❌ Twitter error: %s", e)
        return False, {}

class DiscordSkill(BaseSkill):
    async def _capture_screenshot(self, page, prefix="discord") -> Optional[str]:
        if not page: return None
        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = screenshot_dir / f"{prefix}_{int(time.time())}_{random.randint(1000,9999)}.png"
            await page.screenshot(path=str(ss_path))
            return str(ss_path)
        except Exception: return None

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs) -> Tuple[bool, Dict]:
        if not page: return False, {}
        try:
            await self._apply_stealth_and_human_behavior(page)
            await page.goto(target_url, timeout=45_000, wait_until="domcontentloaded")
            await self._dismiss_common_blockers(page)
            await self._human_delay(4, 7)

            if action == "subscribe":
                selectors = ['button:has-text("Accept Invite")', 'button:has-text("Принять приглашение")']
                for selector in selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible():
                            await btn.click()
                            await self._human_delay(3, 5)
                            ss = await self._capture_screenshot(page, "discord_sub")
                            return True, {"screenshot_path": ss}
                    except Exception: continue

        except Exception as e: logger.error("❌ Discord error: %s", e)
        return False, {}

class RedditSkill(BaseSkill):
    async def _capture_screenshot(self, page, prefix="reddit") -> Optional[str]:
        if not page: return None
        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = screenshot_dir / f"{prefix}_{int(time.time())}_{random.randint(1000,9999)}.png"
            await page.screenshot(path=str(ss_path))
            return str(ss_path)
        except Exception: return None

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs) -> Tuple[bool, Dict]:
        if not page: return False, {}
        try:
            await self._apply_stealth_and_human_behavior(page)
            await page.goto(target_url, timeout=45_000, wait_until="domcontentloaded")
            await self._dismiss_common_blockers(page)
            await self._human_delay(4, 7)

            if action == "subscribe":
                selectors = ['button:has-text("Join")', 'button:has-text("Присоединиться")']
                for selector in selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible():
                            await btn.click()
                            await self._human_delay(1, 2)
                            ss = await self._capture_screenshot(page, "reddit_sub")
                            return True, {"screenshot_path": ss}
                    except Exception: continue

            elif action == "like":
                selectors = ['button[aria-label="Upvote"]', '[data-click-id="upvote"]']
                for selector in selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible():
                            await btn.click()
                            await self._human_delay(1, 2)
                            ss = await self._capture_screenshot(page, "reddit_like")
                            return True, {"screenshot_path": ss}
                    except Exception: continue

        except Exception as e: logger.error("❌ Reddit error: %s", e)
        return False, {}

# ==========================================================
# NEW SKILL: Max (Russian streaming service)
# ==========================================================
class MaxSkill(BaseSkill):
    async def _load_external_max_cookies(self, page) -> bool:
        """يحمل كوكيز Max من /root/sessions/max.json إن وُجدت (أحدث من المضمّنة)."""
        try:
            path = Path("/root/sessions/max.json")
            if not path.exists():
                return False
            raw = json.loads(path.read_text(encoding="utf-8"))
            cookies = raw if isinstance(raw, list) else raw.get("cookies") or []
            if not cookies:
                return False
            formatted = await self._format_playwright_cookies(cookies, ".max.ru")
            if not formatted:
                return False
            await page.context.add_cookies(formatted)
            logger.info("✅ Max external cookies loaded from %s", path)
            return True
        except Exception as error:
            logger.warning("Max external cookies failed: %s", error)
            return False


    # ✅ NEW: Added static cookies for Max
    MAX_COOKIES = [
    {
        "domain": ".max.ru",
        "expirationDate": 1818910085,
        "hostOnly": False,
        "httpOnly": False,
        "name": "tmr_lvid",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "2f9cf1d65d974828324ad4671e17a13d"
    },
    {
        "domain": ".max.ru",
        "expirationDate": 1818910085,
        "hostOnly": False,
        "httpOnly": False,
        "name": "tmr_lvidTS",
        "path": "/",
        "sameSite": "unspecified",
        "secure": False,
        "session": False,
        "storeId": "0",
        "value": "1787741193464"
    },
    {
        "domain": ".max.ru",
        "expirationDate": 1819277193,
        "hostOnly": False,
        "httpOnly": False,
        "name": "_ym_uid",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "1787741194828590225"
    },
    {
        "domain": ".max.ru",
        "expirationDate": 1819277193,
        "hostOnly": False,
        "httpOnly": False,
        "name": "_ym_d",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "1787741194"
    },
    {
        "domain": ".max.ru",
        "expirationDate": 1790210706,
        "hostOnly": False,
        "httpOnly": False,
        "name": "_ym_isad",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "2"
    },
    {
        "domain": ".max.ru",
        "expirationDate": 1790225292,
        "hostOnly": False,
        "httpOnly": False,
        "name": "mdd",
        "path": "/",
        "sameSite": "no_restriction",
        "secure": True,
        "session": False,
        "storeId": "0",
        "value": "0"
    }
]

    def __init__(self):
        self.is_ready = True

    async def _load_cookies(self, page) -> bool:
        try:
            # أولوية للكوكيز الخارجية الأحدث
            if await self._load_external_max_cookies(page):
                return True
            formatted = await self._format_playwright_cookies(self.MAX_COOKIES, ".max.ru")
            if not formatted: return False
            await page.context.add_cookies(formatted)
            logger.info("✅ Max Cookies loaded successfully.")
            return True
        except Exception as error:
            logger.warning("⚠️ Failed to load Max cookies: %s", error)
            return False

    async def _capture_screenshot(self, page, prefix="max") -> Optional[str]:
        if not page: return None
        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = screenshot_dir / f"{prefix}_{int(time.time())}_{random.randint(1000,9999)}.png"
            await page.screenshot(path=str(ss_path))
            return str(ss_path)
        except Exception: return None

    async def execute_task(self, action: str, target_url: str, page=None, comment_text="Отлично!", **kwargs) -> Tuple[bool, Dict]:
        if not page:
            return False, {"status": "missing_page", "platform": "max"}
        try:
            await self._load_cookies(page)
            await self._apply_stealth_and_human_behavior(page)
            await page.goto(target_url, timeout=50_000, wait_until="domcontentloaded")
            await self._dismiss_common_blockers(page)
            await self._human_delay(4, 7)

            # Generic actions for Max (likely similar to a video site)
            if action == "view":
                await self._human_delay(10, 20)
                ss = await self._capture_screenshot(page, "max_view")
                return True, {"screenshot_path": ss}

            if action == "like":
                selectors = [
                    'button[aria-label*="Нравится"]',
                    'button[aria-label*="Like"]',
                    'button[class*="like"]',
                ]
                for selector in selectors:
                    try:
                        btn = page.locator(selector).first
                        if await btn.is_visible():
                            await btn.click()
                            await self._human_delay(1, 2)
                            ss = await self._capture_screenshot(page, "max_like")
                            return True, {"screenshot_path": ss}
                    except Exception: continue

            if action == "subscribe":
                await self._human_delay_heavy(1.5, 3.2)
                selectors = [
                    'button:has-text("Подписаться")',
                    'button:has-text("Subscribe")',
                    'button:has-text("Follow")',
                    'button:has-text("Присоединиться")',
                    'button[class*="subscribe"]',
                    'a:has-text("Подписаться")',
                    '[role="button"]:has-text("Подписаться")',
                ]
                click = await self._smart_click_with_retry(
                    page, selectors, platform="max", refresh_on_miss=True
                )
                if click.get("status") in {"login_required", "captcha", "automation_block"}:
                    ss = await self._capture_screenshot(page, f"max_{click['status']}")
                    return False, {
                        "status": click["status"],
                        "screenshot_path": ss,
                        "platform": "max",
                        "click": click,
                    }
                if not click.get("clicked"):
                    return False, {
                        "status": "control_not_found",
                        "platform": "max",
                        "action": action,
                        "click": click,
                    }
                await self._human_delay_heavy(1.2, 2.5)
                ss = await self._capture_screenshot(page, "max_sub")
                proof = await self._score_proof_page(page, "max", "subscribe")
                return True, {
                    "screenshot_path": ss,
                    "status": "done",
                    "proof_score": proof,
                    "click": click,
                }

            return False, {"status": "execution_failed", "platform": "max", "action": action}
        except Exception as e:
            logger.error("❌ Max error: %s", e)
            return False, {"status": "execution_failed", "platform": "max"}


# ==========================================================
# Generic Web Skill
# ==========================================================

class GenericWebSkill(BaseSkill):
    """مهارة عامة للمنصات التي تستخدم واجهات HTML متقاربة."""

    ACTION_SELECTORS = {
        "subscribe": [
            'button:has-text("Follow")',
            'button:has-text("Subscribe")',
            'button:has-text("Подписаться")',
            'button:has-text("Вступить")',
            'button:has-text("Join")',
            'button:has-text("متابعة")',
            'button:has-text("اشتراك")',
            '[aria-label*="Follow"]',
            '[aria-label*="Subscribe"]',
            '[aria-label*="Подпис"]',
            '[data-testid*="follow"]',
            '[data-testid*="subscribe"]',
        ],
        "like": [
            'button[aria-label*="Like"]',
            'button[aria-label*="Нравится"]',
            'button[aria-label*="إعجاب"]',
            '[data-testid*="like"]',
            '[data-testid*="Like"]',
            '[data-click-id="like"]',
            '[data-reaction-target="like"]',
            'button:has-text("Like")',
            'button:has-text("Нравится")',
            'button:has-text("أعجبني")',
        ],
        "share": [
            'button[aria-label*="Share"]',
            'button[aria-label*="Поделиться"]',
            '[data-testid*="share"]',
            '[data-testid*="Share"]',
            'button:has-text("Share")',
            'button:has-text("Поделиться")',
            'button:has-text("مشاركة")',
        ],
        "repost": [
            'button[aria-label*="Repost"]',
            'button[aria-label*="Retweet"]',
            '[data-testid="retweet"]',
            '[data-testid*="repost"]',
            'button:has-text("Repost")',
            'button:has-text("Retweet")',
            'button:has-text("Репост")',
        ],
        "vote": [
            'button[aria-label*="Upvote"]',
            'button[aria-label*="Vote"]',
            '[data-testid*="upvote"]',
            '[data-testid*="vote"]',
            'button:has-text("Vote")',
        ],
        "register": [
            'a:has-text("Sign up")',
            'button:has-text("Sign up")',
            'a:has-text("Register")',
            'button:has-text("Register")',
            'a:has-text("Регистрация")',
            'button:has-text("Регистрация")',
            'button:has-text("إنشاء حساب")',
        ],
        "start_bot": [
            'button:has-text("Start")',
            'button:has-text("START")',
            'button:has-text("Запустить")',
            'button:has-text("ابدأ")',
            '[data-testid*="start"]',
        ],
    }

    COMMENT_SELECTORS = [
        'textarea[name="comment"]',
        'textarea[name="text"]',
        'textarea[placeholder*="comment"]',
        'textarea[placeholder*="Comment"]',
        'textarea[placeholder*="коммент"]',
        'textarea[placeholder*="Комментар"]',
        'textarea[placeholder*="تعليق"]',
        '[contenteditable="true"]',
        'input[type="text"][name="comment"]',
    ]

    SUBMIT_SELECTORS = [
        'button[type="submit"]',
        'button:has-text("Post")',
        'button:has-text("Publish")',
        'button:has-text("Send")',
        'button:has-text("Отправить")',
        'button:has-text("Опубликовать")',
        'button:has-text("نشر")',
        'button:has-text("إرسال")',
    ]

    def __init__(self, platform: str = "generic"):
        self.platform = platform

    async def _capture_screenshot(self, page, prefix="generic") -> Optional[str]:
        if not page:
            return None
        try:
            screenshot_dir = Path("data/screenshots")
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            ss_path = screenshot_dir / (
                f"{prefix}_{int(time.time())}_{random.randint(1000, 9999)}.png"
            )
            await page.screenshot(path=str(ss_path), full_page=False)
            return str(ss_path)
        except Exception as error:
            logger.warning("Generic screenshot failed [%s]: %s", self.platform, error)
            return None

    async def _first_visible(self, page, selectors):
        for selector in selectors:
            try:
                candidate = page.locator(selector).first
                if await candidate.count() and await candidate.is_visible() and await candidate.is_enabled():
                    return candidate
            except Exception as error:
                logger.debug("Selector failed [%s/%s]: %s", self.platform, selector, error)
        return None

    async def _login_wall(self, page) -> bool:
        try:
            current_url = (page.url or "").lower()
            body = (await page.locator("body").inner_text())[:5000].lower()
            markers = (
                "/login", "/signin", "log in", "sign in", "войти",
                "авторизац", "تسجيل الدخول", "captcha", "капча",
            )
            return any(marker in current_url or marker in body for marker in markers)
        except Exception:
            return False

    async def _button_state_text(self, button) -> str:
        try:
            values = [
                await button.inner_text(),
                await button.get_attribute("aria-label"),
                await button.get_attribute("data-state"),
                await button.get_attribute("data-status"),
            ]
            return " ".join(str(value or "") for value in values).lower()
        except Exception:
            return ""

    async def _verify_generic_action(self, page, action: str, button=None, comment_text: str = "") -> bool:
        try:
            state_text = await self._button_state_text(button) if button else ""
            body = (await page.locator("body").inner_text()).lower()

            if action in {"subscribe", "join", "follow"}:
                markers = (
                    "following", "subscribed", "joined", "unfollow",
                    "unsubscribe", "подписан", "подписаны", "в группе",
                    "вы вступили", "отписаться", "متابَع", "مشترك",
                )
                return any(marker in state_text or marker in body for marker in markers)

            if action == "like":
                markers = (
                    "unlike", "liked", "remove like", "active", "selected",
                    "понравилось", "убрать отметку", "нравится", "أعجبني",
                )
                return any(marker in state_text for marker in markers) or any(
                    marker in body for marker in ("liked", "понравилось", "أعجبني")
                )

            if action in {"comment", "review"}:
                normalized_comment = str(comment_text or "").strip().lower()
                return bool(normalized_comment) and normalized_comment in body

            if action in {"share", "repost"}:
                return any(
                    marker in body
                    for marker in (
                        "shared", "reposted", "post shared", "поделились",
                        "репост опубликован", "опубликовано", "تمت المشاركة",
                    )
                )

            if action == "register":
                return not await self._login_wall(page)

            if action == "vote":
                return bool(button) and (
                    await button.get_attribute("aria-pressed") == "true"
                    or await button.get_attribute("aria-checked") == "true"
                )

            if action == "view":
                return bool(body.strip())

            return False
        except Exception as error:
            logger.debug("Generic postcondition failed [%s/%s]: %s", self.platform, action, error)
            return False

    async def _click_action(self, page, action: str):
        button = await self._first_visible(
            page,
            self.ACTION_SELECTORS.get(action, []),
        )
        if not button:
            return False, None

        try:
            await button.scroll_into_view_if_needed()
            await button.click(timeout=10_000)
            await self._human_delay(1.0, 2.5)
            return True, button
        except Exception as error:
            logger.warning("Generic click failed [%s/%s]: %s", self.platform, action, error)
            return False, None

    async def _comment(self, page, text: str):
        if not text:
            return False
        area = await self._first_visible(page, self.COMMENT_SELECTORS)
        if not area:
            return False
        try:
            await area.scroll_into_view_if_needed()
            await area.click()
            try:
                await area.fill(text)
            except Exception:
                await area.press("Control+A")
                await area.press("Backspace")
                await area.type(text, delay=random.randint(25, 70))
            await self._human_delay(0.5, 1.2)
            submit = await self._first_visible(page, self.SUBMIT_SELECTORS)
            if not submit:
                return False
            await submit.click(timeout=10_000)
            await self._human_delay(1.0, 2.5)
            return True
        except Exception as error:
            logger.warning("Generic comment failed [%s]: %s", self.platform, error)
            return False

    async def execute_task(
        self,
        action: str,
        target_url: str,
        page=None,
        **kwargs
    ) -> Tuple[bool, Dict]:
        if not page or not target_url:
            return False, {"status": "missing_page_or_url"}

        action = str(action or "").strip().lower()
        allowed = {
            "subscribe", "like", "comment", "view", "share",
            "register", "review", "repost", "vote", "start_bot",
        }
        if action not in allowed:
            return False, {"status": "unsupported_action", "action": action}

        try:
            await self._apply_stealth_and_human_behavior(page)
            await page.goto(target_url, timeout=45_000, wait_until="domcontentloaded")
            await self._dismiss_common_blockers(page)
            await self._human_delay(3.0, 6.0)

            if await self._login_wall(page):
                return False, {"status": "login_required", "platform": self.platform}

            if action == "view":
                await self._scroll_to_bottom_and_up(page)
                await self._human_delay(8.0, 18.0)
                if not await self._verify_generic_action(page, action):
                    return False, {"status": "view_not_verified", "action": action}
                proof = await self._capture_screenshot(page, f"{self.platform}_view")
                if not proof:
                    return False, {"status": "proof_screenshot_failed", "action": action}
                return True, {"status": "done", "changed": False, "verified": True, "screenshot_path": proof, "proof_path": proof}

            action_button = None
            if action == "comment":
                comment_text = kwargs.get("comment_text") or kwargs.get("review_text") or kwargs.get("text")
                comment_text = str(comment_text or "")
                ok = await self._comment(page, comment_text)
            elif action == "review":
                review_text = kwargs.get("review_text") or kwargs.get("comment_text") or kwargs.get("text")
                review_text = str(review_text or "")
                comment_text = review_text
                ok = await self._comment(page, review_text)
            else:
                ok, action_button = await self._click_action(page, action)
                comment_text = ""

            if not ok:
                return False, {"status": "control_not_found_or_execution_failed", "action": action}

            if not await self._verify_generic_action(page, action, action_button, comment_text):
                return False, {"status": "action_not_verified", "action": action}

            proof = await self._capture_screenshot(page, f"{self.platform}_{action}")
            if not proof:
                return False, {"status": "proof_screenshot_failed", "action": action}
            return True, {
                "status": "done",
                "changed": True,
                "action": action,
                "screenshot_path": proof,
                "proof_path": proof,
                "platform": self.platform,
            }

        except Exception as error:
            logger.exception("Generic skill error [%s/%s]: %s", self.platform, action, error)
            return False, {"status": "error", "action": action, "error": str(error)[:500]}


# ==========================================================
# Skill Manager
# ==========================================================

class SkillManager:

    def __init__(self):

        self.skills = {}

        self.register_skill("telegram", TelegramSkill())
        self.register_skill("vk", VKSkill())
        self.register_skill("tiktok", TikTokSkill())
        self.register_skill("facebook", FacebookSkill())
        self.register_skill("review", ReviewSkill())

        # Register new skills for UNU
        self.register_skill("youtube", YouTubeSkill())
        self.register_skill("instagram", InstagramSkill())
        self.register_skill("rutube", RutubeSkill())
        self.register_skill("avito", AvitoSkill())
        self.register_skill("ozon", OzonApiSkill())
        self.register_skill("twitter", TwitterSkill())
        self.register_skill("discord", DiscordSkill())
        self.register_skill("reddit", RedditSkill())
        self.register_skill("max", MaxSkill())  # ✅ NEW
        self.register_skill("google_maps", ReviewSkill())  # خرائط جوجل منفصلة عن ياندكس

        # منصات إضافية تستخدم المهارة العامة مع selectors مشتركة.
        generic_platforms = [
            "linkedin", "pinterest", "snapchat", "threads", "twitch",
            "kick", "steam", "github", "gitlab", "medium", "quora",
            "tumblr", "dailymotion", "soundcloud", "bandcamp",
            "tripadvisor", "google_play", "app_store", "yandex", "website",
        ]
        for platform_name in generic_platforms:
            self.register_skill(
                platform_name,
                GenericWebSkill(platform_name),
            )

    def register_skill(
        self,
        name: str,
        skill_instance
    ):

        key = str(name or "").lower()
        existing = self.skills.get(key)
        new_type = type(skill_instance).__name__
        if existing is not None:
            old_type = type(existing).__name__
            if new_type == old_type or new_type == "GenericWebSkill":
                return existing
            if old_type != "GenericWebSkill":
                logger.info("skill %s kept %s, skipped %s", key, old_type, new_type)
                return existing
        registered = register_unique(self.skills, key, skill_instance)
        if registered is not skill_instance:
            logger.info(
                "skill %s kept %s, skipped %s",
                key,
                type(registered).__name__,
                new_type,
            )
            return registered

        logger.info(
            "⚙️ تم تفعيل مهارة المنصة: %s",
            name.upper()
        )
        return registered

    def get_skill(self, name: str):

        return self.skills.get(
            str(name or "").lower()
        )

    @staticmethod
    def _normalize_action(action: str) -> str:
        text = str(action or "").strip().lower()
        aliases = {
            "اشتراك": "subscribe",
            "اشتراك/متابعة": "subscribe",
            "متابعة": "subscribe",
            "подписаться": "subscribe",
            "вступить": "subscribe",
            "إعجاب": "like",
            "لايك": "like",
            "лайк": "like",
            "تعليق": "comment",
            "комментарий": "comment",
            "مشاهدة": "view",
            "تصفح/مشاهدة": "view",
            "просмотр": "view",
            "مشاركة": "share",
            "поделиться": "share",
            "إعادة نشر": "repost",
            "репост": "repost",
            "تسجيل": "register",
            "регистрация": "register",
            "مراجعة": "review",
            "تقييم": "review",
            "отзыв": "review",
            "تشغيل بوت": "start_bot",
            "запустить бота": "start_bot",
        }
        if text in aliases:
            return aliases[text]
        return text

    def supports_action(
        self,
        platform: str,
        action: str
    ) -> bool:

        platform = (
            str(platform or "")
            .strip()
            .lower()
        )

        action = self._normalize_action(action)

        # تيك توك: share = repost عمليًا
        if str(platform or "").strip().lower() in {"tiktok", "tt"} and action == "share":
            action = "repost"

        if str(platform or "").strip().lower() in {"twitter", "x", "x.com"} and action in {"share", "retweet"}:
            action = "repost"

        platform_aliases = {
            "x": "twitter",
            "x.com": "twitter",
            "google maps": "google_maps",
            "google play": "google_play",
            "play market": "google_play",
            "app store": "app_store",
        }
        platform = platform_aliases.get(platform, platform)

        if platform in {"google_play", "app_store", "yandex"} and action == "review":
            platform = "review"

        capabilities = (
            SKILL_CAPABILITIES
            .get(platform, set())
        )

        return action in capabilities

    async def route_task(
        self,
        platform: str,
        action: str,
        target_url: str,
        page=None,
        **kwargs
    ) -> Tuple[bool, Dict]:

        platform = (
            str(platform or "")
            .strip()
            .lower()
        )

        action = self._normalize_action(action)

        platform_aliases = {
            "x": "twitter",
            "x.com": "twitter",
            "google maps": "google_maps",
            "google play": "google_play",
            "play market": "google_play",
            "app store": "app_store",
        }
        platform = platform_aliases.get(platform, platform)

        if platform in {"google_play", "app_store", "yandex"} and action == "review":
            platform = "review"

        if action not in SUPPORTED_ACTIONS:

            logger.warning(
                "⚠️ Action غير مدعوم: %s",
                action
            )

            return False, {}

        if not self.supports_action(
            platform,
            action
        ):

            logger.warning(
                "⚠️ المنصة '%s' لا تدعم action '%s'",
                platform,
                action
            )

            return False, {}

        skill = self.get_skill(
            platform
        )

        if not skill:

            logger.warning(
                "⚠️ لا توجد Skill للمنصة: %s",
                platform
            )

            return False, {}

        # مهام متعددة الروابط (مثل 5 جروبات VK): نفّذ الاشتراك على كل رابط
        multi = kwargs.get("all_target_urls") or kwargs.get("target_urls") or []
        if not isinstance(multi, (list, tuple)):
            multi = []
        urls = []
        for u in multi:
            u = str(u or "").strip()
            if u.startswith("http") and u not in urls:
                urls.append(u)
        if target_url and str(target_url).startswith("http") and str(target_url) not in urls:
            urls.insert(0, str(target_url))
        if not urls and target_url:
            urls = [str(target_url)]

        if len(urls) <= 1 or action not in {
            "subscribe", "like", "follow", "join", "view",
        }:
            return await skill.execute_task(
                action=action,
                target_url=target_url or (urls[0] if urls else ""),
                page=page,
                **kwargs
            )

        logger.info(
            "Multi-target %s/%s on %s links",
            platform,
            action,
            len(urls),
        )
        results = []
        any_ok = False
        last_meta = {}
        for i, u in enumerate(urls):
            try:
                logger.info("Multi-target [%s/%s]: %s", i + 1, len(urls), u)
                ok, meta = await skill.execute_task(
                    action=action,
                    target_url=u,
                    page=page,
                    **{k: v for k, v in kwargs.items() if k not in {"all_target_urls", "target_urls"}},
                )
                # بعض المهارات ترجع bool فقط
                if isinstance(ok, tuple):
                    success, meta = ok[0], (ok[1] if len(ok) > 1 else {})
                else:
                    success, meta = bool(ok), (meta if isinstance(meta, dict) else {})
                if not isinstance(meta, dict):
                    meta = {}
                meta = dict(meta)
                meta["target_url"] = u
                meta["multi_index"] = i + 1
                results.append({"ok": success, **meta})
                if success:
                    any_ok = True
                else:
                    # login_required يوقف الباقي
                    stt = str(meta.get("status") or "").lower()
                    if "login" in stt or stt in {"captcha", "session_or_control_failed"}:
                        last_meta = meta
                        break
                last_meta = meta
            except Exception as e:
                logger.exception("Multi-target item failed: %s", e)
                results.append({"ok": False, "target_url": u, "error": str(e)[:200]})
                last_meta = {"status": "failed", "error": str(e)[:200]}

        last_meta = dict(last_meta or {})
        last_meta["multi_results"] = results
        last_meta["multi_total"] = len(urls)
        last_meta["multi_ok"] = sum(1 for r in results if r.get("ok"))
        return any_ok, last_meta

# ==========================================================
# UNU BOT — NON-DESTRUCTIVE SKILL HARDENING LAYER
# ==========================================================
# IMPORTANT:
# This layer is intentionally appended to the original file.
# Existing classes, functions, cookies, sessions, credentials,
# selectors and data are NOT removed or rewritten in-place.
# The layer adds reliability/verification helpers and wraps the
# existing execute_task/route_task methods while preserving their
# public signatures and return contract.
# ==========================================================

SM_HARDENING_VERSION = "2026.09.production.1"
SM_BROWSER_UI_LANGUAGE = "en-US"
SM_BROWSER_LOCALE = "en-US"
SM_MAX_ACTION_ATTEMPTS = 2
SM_ACTION_SETTLE_SECONDS = (1.2, 2.8)
SM_NAVIGATION_TIMEOUT = 45_000
SM_SELECTOR_TIMEOUT = 4_500


def _sm_result_dict(value) -> Dict:
    """Normalize skill result metadata without changing the original contract."""
    if isinstance(value, dict):
        return dict(value)
    return {}


async def _sm_body_text(page) -> str:
    if not page:
        return ""
    try:
        return (await page.locator("body").inner_text(timeout=3_000)).strip().lower()
    except Exception:
        return ""


async def _sm_wait_dom(page, milliseconds: int = 700):
    if not page:
        return
    try:
        await page.wait_for_load_state("domcontentloaded", timeout=8_000)
    except Exception:
        pass
    try:
        await page.wait_for_timeout(max(0, int(milliseconds)))
    except Exception:
        await asyncio.sleep(max(0.0, milliseconds / 1000.0))


async def _sm_first_actionable(page, selectors, timeout: int = SM_SELECTOR_TIMEOUT):
    """Return the first visible+enabled control from an ordered selector list."""
    if not page:
        return None
    for selector in selectors:
        try:
            loc = page.locator(selector).first
            if not await loc.count():
                continue
            if not await loc.is_visible(timeout=min(timeout, 1500)):
                continue
            if not await loc.is_enabled(timeout=min(timeout, 1500)):
                continue
            return loc
        except Exception:
            continue
    return None


async def _sm_safe_click(page, selectors, settle=True) -> bool:
    """Click only a visible/enabled DOM control; no force-click or overlay bypass."""
    control = await _sm_first_actionable(page, selectors)
    if not control:
        return False
    try:
        await control.scroll_into_view_if_needed(timeout=3_000)
    except Exception:
        pass
    try:
        await control.click(timeout=SM_SELECTOR_TIMEOUT)
        if settle:
            await asyncio.sleep(random.uniform(*SM_ACTION_SETTLE_SECONDS))
        return True
    except Exception:
        return False


async def _sm_screenshot(page, prefix: str) -> Optional[str]:
    if not page:
        return None
    try:
        root = Path("data/screenshots")
        root.mkdir(parents=True, exist_ok=True)
        safe_prefix = re.sub(r"[^a-zA-Z0-9_.-]+", "_", str(prefix))[:80]
        path = root / f"{safe_prefix}_{int(time.time())}_{random.randint(1000, 9999)}.png"
        await page.screenshot(path=str(path), full_page=False)
        if path.exists() and path.stat().st_size > 0:
            return str(path)
    except Exception as error:
        logger.warning("Hardened screenshot failed: %s", type(error).__name__)
    return None


async def _sm_page_health(page) -> str:
    """Classify obvious page states so a skill fails closed instead of clicking blindly."""
    if not page:
        return "missing_page"
    try:
        url = (page.url or "").lower()
    except Exception:
        url = ""
    body = await _sm_body_text(page)

    if any(x in url for x in ("/login", "/signin", "/auth", "accounts.google.com/servicelogin")):
        return "login_required"
    if any(x in body for x in (
        "captcha", "verify you are human", "verify that you are human",
        "security check", "robot check", "access denied"
    )):
        return "challenge_or_block"
    if any(x in body for x in ("something went wrong", "page isn't available", "content unavailable")):
        return "page_error"
    return "ready"


async def _sm_already_active(page, action: str) -> bool:
    """Conservative post-condition detection for common English UI states."""
    action = str(action or "").lower()
    if action in {"subscribe", "follow", "join"}:
        selectors = [
            'button:has-text("Subscribed")',
            'button:has-text("Following")',
            'button:has-text("Joined")',
            '[aria-label*="Subscribed"]',
            '[aria-label*="Following"]',
            '[aria-label*="Joined"]',
            '[data-testid*="subscribed"]',
            '[data-testid*="following"]',
        ]
    elif action == "like":
        selectors = [
            'button[aria-pressed="true"]',
            '[aria-label*="Unlike"]',
            '[data-e2e*="like"].active',
            '[data-testid*="like"][aria-pressed="true"]',
        ]
    elif action in {"share", "repost"}:
        # Share/repost controls are not universally stateful; no broad body-text
        # match is used because it creates false positives.
        return False
    else:
        return False

    return bool(await _sm_first_actionable(page, selectors, timeout=2_000))


SM_ENGLISH_SELECTORS = {
    "subscribe": [
        'button:has-text("Subscribe")',
        'button:has-text("Follow")',
        'button:has-text("Join")',
        '[role="button"]:has-text("Subscribe")',
        '[role="button"]:has-text("Follow")',
        '[aria-label*="Subscribe"]',
        '[aria-label*="Follow"]',
        '[data-testid*="subscribe"]',
        '[data-testid*="follow"]',
        '[data-e2e*="follow"]',
    ],
    "like": [
        'button:has-text("Like")',
        '[role="button"]:has-text("Like")',
        'button[aria-label="Like"]',
        '[aria-label*="Like"]',
        '[data-testid*="like"]',
        '[data-e2e*="like"]',
    ],
    "share": [
        'button:has-text("Share")',
        '[role="button"]:has-text("Share")',
        'button[aria-label="Share"]',
        '[aria-label*="Share"]',
        '[data-testid*="share"]',
        '[data-e2e*="share"]',
    ],
    "repost": [
        'button:has-text("Repost")',
        '[role="button"]:has-text("Repost")',
        'button[aria-label="Repost"]',
        '[aria-label*="Repost"]',
        '[data-testid*="repost"]',
        '[data-e2e*="repost"]',
    ],
}


async def _sm_generic_browser_fallback(skill, action: str, target_url: str, page=None, **kwargs):
    """Conservative fallback for simple idempotent browser actions.

    It deliberately does not auto-submit comments/reviews/registrations because
    those actions are non-idempotent and can create duplicate content/accounts.
    """
    action = str(action or "").strip().lower()
    if not page or not target_url:
        return False, {"status": "missing_page_or_target", "action": action}

    if action in {"comment", "review", "register"}:
        return False, {"status": "fallback_disabled_for_non_idempotent_action", "action": action}

    try:
        await page.goto(
            str(target_url),
            timeout=SM_NAVIGATION_TIMEOUT,
            wait_until="domcontentloaded",
        )
        await _sm_wait_dom(page, 900)
        health = await _sm_page_health(page)
        if health != "ready":
            return False, {"status": health, "action": action}

        if action == "view":
            # Viewing is satisfied by actually loading the target and allowing
            # the page to settle; no arbitrary hidden/force interaction.
            try:
                await page.mouse.wheel(0, 700)
                await asyncio.sleep(random.uniform(1.5, 3.0))
            except Exception:
                pass
            screenshot = await _sm_screenshot(page, f"{getattr(skill, '__class__', type(skill)).__name__.lower()}_view")
            if not screenshot:
                return False, {"status": "proof_screenshot_failed", "action": action}
            return True, {
                "status": "done",
                "action": action,
                "screenshot_path": screenshot,
                "proof_path": screenshot,
                "verified": True,
                "execution_method": "browser",
                "hardening": SM_HARDENING_VERSION,
            }

        if action in {"subscribe", "like"} and await _sm_already_active(page, action):
            screenshot = await _sm_screenshot(page, f"{action}_already_active")
            if screenshot:
                return True, {
                    "status": "already_active",
                    "action": action,
                    "screenshot_path": screenshot,
                    "proof_path": screenshot,
                    "verified": True,
                    "hardening": SM_HARDENING_VERSION,
                }

        selectors = SM_ENGLISH_SELECTORS.get(action, [])
        clicked = await _sm_safe_click(page, selectors)
        if not clicked:
            return False, {"status": f"{action}_control_not_found", "action": action}

        # Re-read DOM after the state-changing click.
        await _sm_wait_dom(page, 900)
        verified = True
        if action in {"subscribe", "like"}:
            verified = await _sm_already_active(page, action)

        if not verified:
            return False, {"status": f"{action}_postcondition_failed", "action": action}

        screenshot = await _sm_screenshot(page, f"{action}_verified")
        if not screenshot:
            return False, {"status": "proof_screenshot_failed", "action": action}

        return True, {
            "status": "done",
            "action": action,
            "screenshot_path": screenshot,
            "proof_path": screenshot,
            "verified": True,
            "execution_method": "browser",
            "hardening": SM_HARDENING_VERSION,
        }
    except Exception as error:
        logger.warning("Hardened browser fallback failed: %s", type(error).__name__)
        return False, {"status": "browser_fallback_error", "action": action}


# ----------------------------------------------------------
# Preserve original execute_task methods and add a safe
# second-chance path only after the original method reports
# failure. Existing cookies/sessions remain untouched.
# ----------------------------------------------------------

_SM_BROWSER_SKILLS = (
    VKSkill, TikTokSkill, FacebookSkill, YouTubeSkill,
    InstagramSkill, RutubeSkill, AvitoSkill, TwitterSkill,
    DiscordSkill, RedditSkill, MaxSkill, GenericWebSkill,
)


def _sm_wrap_browser_skill(cls):
    original = cls.execute_task
    if getattr(original, "__sm_hardened__", False):
        return

    async def wrapped(self, action: str, target_url: str, page=None, **kwargs):
        try:
            result = await original(self, action, target_url, page=page, **kwargs)
        except Exception as error:
            logger.exception("Original %s.execute_task raised: %s", cls.__name__, type(error).__name__)
            result = (False, {"status": "original_skill_exception", "action": str(action or "").lower()})

        if isinstance(result, tuple) and len(result) >= 2:
            success, data = result[0], _sm_result_dict(result[1])
        else:
            success, data = bool(result), {}

        if success:
            data.setdefault("hardening", SM_HARDENING_VERSION)
            return True, data

        fallback_success, fallback_data = await _sm_generic_browser_fallback(
            self, action, target_url, page=page, **kwargs
        )
        if fallback_success:
            fallback_data.setdefault("original_result", data)
            return True, fallback_data

        # Preserve original failure information instead of replacing it.
        data.setdefault("hardening", SM_HARDENING_VERSION)
        data.setdefault("fallback_status", fallback_data.get("status"))
        return False, data

    wrapped.__name__ = original.__name__
    wrapped.__qualname__ = original.__qualname__
    wrapped.__doc__ = original.__doc__
    wrapped.__sm_hardened__ = True
    cls.execute_task = wrapped


for _sm_cls in _SM_BROWSER_SKILLS:
    _sm_wrap_browser_skill(_sm_cls)


# ----------------------------------------------------------
# Harden action normalization without removing the original
# aliases. English aliases are added as an additive layer.
# ----------------------------------------------------------

_SM_ORIGINAL_NORMALIZE_ACTION = SkillManager._normalize_action


def _sm_normalize_action(action: str) -> str:
    text = str(action or "").strip().lower()
    english_aliases = {
        "follow": "subscribe",
        "following": "subscribe",
        "join": "subscribe",
        "joined": "subscribe",
        "sub": "subscribe",
        "fav": "like",
        "favorite": "like",
        "favourite": "like",
        "upvote": "vote",
        "retweet": "repost",
        "boost": "repost",
        "watch": "view",
        "visit": "view",
        "write review": "review",
    }
    if text in english_aliases:
        return english_aliases[text]
    return _SM_ORIGINAL_NORMALIZE_ACTION(action)


SkillManager._normalize_action = staticmethod(_sm_normalize_action)


# ----------------------------------------------------------
# Additive route hardening. Same public signature; no existing
# Skill or credential data is changed.
# ----------------------------------------------------------

_SM_ORIGINAL_ROUTE_TASK = SkillManager.route_task


async def _sm_hardened_route_task(
    self,
    platform: str,
    action: str,
    target_url: str,
    page=None,
    **kwargs
) -> Tuple[bool, Dict]:
    normalized_platform = str(platform or "").strip().lower()
    normalized_action = self._normalize_action(action)

    platform_aliases = {
        "x": "twitter",
        "x.com": "twitter",
        "google maps": "google_maps",
        "google play": "google_play",
        "play market": "google_play",
        "app store": "app_store",
        "yt": "youtube",
        "ig": "instagram",
        "fb": "facebook",
        "tt": "tiktok",
        "max": "max",
    }
    normalized_platform = platform_aliases.get(normalized_platform, normalized_platform)

    if normalized_platform in {"google_play", "app_store", "yandex"} and normalized_action == "review":
        normalized_platform = "review"

    if normalized_action not in SUPPORTED_ACTIONS:
        logger.warning("Unsupported canonical action: %s", normalized_action)
        return False, {
            "status": "unsupported_action",
            "platform": normalized_platform,
            "action": normalized_action,
        }

    if not self.supports_action(normalized_platform, normalized_action):
        logger.warning(
            "Skill capability mismatch: platform=%s action=%s",
            normalized_platform,
            normalized_action,
        )
        return False, {
            "status": "unsupported_skill_action",
            "platform": normalized_platform,
            "action": normalized_action,
        }

    skill = self.get_skill(normalized_platform)
    if not skill:
        return False, {
            "status": "skill_not_registered",
            "platform": normalized_platform,
            "action": normalized_action,
        }

    try:
        result = await skill.execute_task(
            action=normalized_action,
            target_url=target_url,
            page=page,
            **kwargs,
        )
    except Exception as error:
        logger.exception(
            "Skill execution crashed: platform=%s action=%s error=%s",
            normalized_platform,
            normalized_action,
            type(error).__name__,
        )
        return False, {
            "status": "skill_exception",
            "platform": normalized_platform,
            "action": normalized_action,
            "error": str(error)[:500],
        }

    if isinstance(result, tuple) and len(result) >= 2:
        success = bool(result[0])
        data = _sm_result_dict(result[1])
    else:
        success = bool(result)
        data = {}

    data.setdefault("platform", normalized_platform)
    data.setdefault("action", normalized_action)
    data.setdefault("hardening", SM_HARDENING_VERSION)
    return success, data


SkillManager.route_task = _sm_hardened_route_task


# ----------------------------------------------------------
# Capability helper exposed additively for callers/tests.
# ----------------------------------------------------------


def _sm_supports_action_strict(self, platform: str, action: str) -> bool:
    normalized_platform = canonical_platform(platform)
    normalized_action = self._normalize_action(action)
    aliases = {
        "x": "twitter",
        "x.com": "twitter",
        "yt": "youtube",
        "ig": "instagram",
        "fb": "facebook",
        "tt": "tiktok",
        "max": "max",
        "google maps": "google_maps",
        "google play": "google_play",
        "play market": "google_play",
        "app store": "app_store",
    }
    normalized_platform = aliases.get(normalized_platform, normalized_platform)
    _exec_ok = EXECUTION_PLATFORMS
    if normalized_platform not in _exec_ok:
        return False
    if normalized_platform in {"google_play", "app_store", "yandex"} and normalized_action == "review":
        normalized_platform = "review"
    return normalized_action in SKILL_CAPABILITIES.get(normalized_platform, set())


SkillManager.supports_action = _sm_supports_action_strict


logger.info(
    "🚀 Skill hardening layer loaded: %s | original cookies/sessions preserved | English-first DOM controls",
    SM_HARDENING_VERSION,
)


# ==========================================================
# UNU BOT — PRODUCTION HARDENING LAYER v2
# ==========================================================
# Additive only. Does not delete original functions/keys.
# Covers:
#   - comment / review / register fallback (idempotent-safe)
#   - idempotency keys
#   - existing-comment detection
#   - cookie expiry monitor + external cookie reload
#   - smart retry loop + 2/4/8 exponential backoff
#   - HTTP 404/500/502/503/504 health markers
#   - unified result normalizer
#   - multi-account + accounts.json
#   - dynamic selectors.json + update_selector()
#   - per-platform hourly rate limit + semaphore
#   - detailed stack traces
#   - close() for skills + SkillManager.close()
# ==========================================================

import hashlib
import traceback
from collections import defaultdict, deque
from datetime import datetime, timezone

SM_PROD_VERSION = "2026.09.production.2"
SM_IDEMPOTENCY_DIR = Path("data/idempotency")
SM_SELECTORS_FILE = Path(os.getenv("SM_SELECTORS_FILE", "data/selectors.json"))
SM_ACCOUNTS_FILE = Path(os.getenv("SM_ACCOUNTS_FILE", "data/accounts.json"))
# المنصات المسموح بتنفيذها فقط (مواءمة مع main.ALLOWED_EXECUTION_PLATFORMS)

# روابط حسابات ثابتة لإثبات المهام (سكرين من البروفايل نفسه)
PROOF_PROFILE_URLS = {
    "instagram": "https://www.instagram.com/virexohq1?stkn=MWdwZTgxb2d4NXlocA==",
    "tiktok": "https://www.tiktok.com/@virexohq?is_from_webapp=1&sender_device=pc",
    "max": "https://max.ru/u/f9LHodD0cOIeVY5jPgXZClogFIlVV5c_1_pbg6D9kyFdLQeUZwQvmtOj8m8",
    "rutube": "https://rutube.ru/channel/56024403/",
    "youtube": "https://www.youtube.com/@AjaebWalaken",
    "vk": "https://m.vk.ru/id1043297158",
    "telegram": "",
    "twitter": "",
    "x": "",
}

def _sm_load_proof_profiles() -> dict:
    """تحميل proof_profiles.json مع الإبقاء على القيم الافتراضية."""
    profiles = dict(PROOF_PROFILE_URLS)
    try:
        path = Path(os.getenv("PROOF_PROFILES_FILE", "data/proof_profiles.json"))
        if path.exists():
            raw = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                for k, v in raw.items():
                    if v:
                        profiles[str(k).lower()] = str(v)
    except Exception as error:
        logger.warning("proof_profiles load failed: %s", error)
    return profiles

SM_EXECUTION_PLATFORMS = {
    "telegram",
    "vk",
    "max",
    "instagram",
    "tiktok",
    "youtube",
    "rutube",
    "twitter",
    "x",
    "ozon",
    "wildberries",
}

SM_COOKIE_FILES = {
    "instagram": os.getenv("INSTAGRAM_COOKIES_FILE", "/root/sessions/instagram.json"),
    "tiktok": os.getenv("TIKTOK_COOKIES_FILE", "/root/sessions/tiktok.json"),
    "telegram": os.getenv("TELEGRAM_WEB_COOKIES_FILE", "/root/sessions/telegram_web.json"),
    "facebook": os.getenv("FACEBOOK_COOKIES_FILE", "/root/sessions/facebook.json"),
    "youtube": os.getenv("YOUTUBE_COOKIES_FILE", "/root/sessions/youtube.json"),
    "vk": os.getenv("VK_COOKIES_FILE", "/root/sessions/vk.json"),
    "max": os.getenv("MAX_COOKIES_FILE", "/root/sessions/max.json"),
    "yandex": os.getenv("YANDEX_COOKIES_FILE", "/root/sessions/yandex.json"),
    "google_maps": os.getenv("GOOGLE_MAPS_COOKIES_FILE", "/root/sessions/google_maps.json"),
    "rutube": os.getenv("RUTUBE_COOKIES_FILE", "/root/sessions/rutube.json"),
    "twitter": os.getenv("TWITTER_COOKIES_FILE", "/root/sessions/twitter.json"),
    "x": os.getenv("X_COOKIES_FILE", "/root/sessions/x.json"),
}
SM_HOURLY_LIMITS = {
    "instagram": int(os.getenv("SM_LIMIT_INSTAGRAM", "25")),
    "tiktok": int(os.getenv("SM_LIMIT_TIKTOK", "30")),
    "telegram": int(os.getenv("SM_LIMIT_TELEGRAM", "60")),
    "youtube": int(os.getenv("SM_LIMIT_YOUTUBE", "20")),
    "facebook": int(os.getenv("SM_LIMIT_FACEBOOK", "20")),
    "rutube": int(os.getenv("SM_LIMIT_RUTUBE", "25")),
    "max": int(os.getenv("SM_LIMIT_MAX", "20")),
    "default": int(os.getenv("SM_LIMIT_DEFAULT", "40")),
}
SM_PLATFORM_CONCURRENCY = {
    "instagram": int(os.getenv("SM_CONC_INSTAGRAM", "1")),
    "tiktok": int(os.getenv("SM_CONC_TIKTOK", "1")),
    "telegram": int(os.getenv("SM_CONC_TELEGRAM", "2")),
    "youtube": int(os.getenv("SM_CONC_YOUTUBE", "2")),
    "max": int(os.getenv("SM_CONC_MAX", "1")),
    "default": int(os.getenv("SM_CONC_DEFAULT", "2")),
}
SM_BACKOFF_SECONDS = (0.4, 0.9)
SM_MAX_WRAPPER_ATTEMPTS = 2

# Runtime state (process-local)
_SM_HOURLY_HITS: Dict[str, deque] = defaultdict(deque)
_SM_PLATFORM_SEMAPHORES: Dict[str, asyncio.Semaphore] = {}
_SM_DYNAMIC_SELECTORS: Dict[str, Dict[str, list]] = {}
_SM_ACCOUNTS_CACHE: Dict[str, list] = {}
_SM_ACCOUNT_CURSOR: Dict[str, int] = defaultdict(int)
_SM_COOKIE_MTIME: Dict[str, float] = {}


def _sm_now_ts() -> float:
    return time.time()


def _sm_utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sm_stack_trace(error: BaseException = None, limit: int = 12) -> str:
    if error is not None:
        return "".join(traceback.format_exception(type(error), error, error.__traceback__))[:4000]
    return "".join(traceback.format_stack(limit=limit))[-4000:]


def _sm_normalize_result(success: bool, data: Dict = None, **extra) -> Tuple[bool, Dict]:
    """Unified result normalizer for all skills/route_task paths."""
    payload = dict(data or {})
    # لا نجاح صوري: submitted بدون تحقق / partial
    try:
        st_status = str(payload.get("status") or "").lower()
        if st_status in {
            "submitted_unverified",
            "partial_failure",
            "register_incomplete",
            "comment_unverified",
        }:
            success = False
            payload["verified"] = False
        if payload.get("verified") is False and st_status in {"submitted_unverified"}:
            success = False
    except Exception:
        pass
    payload.setdefault("status", "done" if success else "failed")
    payload.setdefault("success", bool(success))
    payload.setdefault("verified", bool(success and payload.get("verified", success)))
    payload.setdefault("timestamp", _sm_utc_iso())
    payload.setdefault("prod_layer", SM_PROD_VERSION)
    for key, value in extra.items():
        if value is not None and key not in payload:
            payload[key] = value
    # normalize proof aliases
    if payload.get("screenshot_path") and not payload.get("proof_path"):
        payload["proof_path"] = payload["screenshot_path"]
    if payload.get("proof_path") and not payload.get("screenshot_path"):
        payload["screenshot_path"] = payload["proof_path"]
    return bool(success), payload


def _sm_idempotency_key(platform: str, action: str, target_url: str, extra: str = "") -> str:
    raw = f"{platform}|{action}|{target_url}|{extra}".encode("utf-8", errors="ignore")
    return hashlib.sha256(raw).hexdigest()


def _sm_idempotency_path(key: str) -> Path:
    SM_IDEMPOTENCY_DIR.mkdir(parents=True, exist_ok=True)
    return SM_IDEMPOTENCY_DIR / f"{key}.json"


def _sm_idempotency_seen(key: str) -> Optional[Dict]:
    path = _sm_idempotency_path(key)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _sm_idempotency_store(key: str, payload: Dict) -> None:
    try:
        path = _sm_idempotency_path(key)
        data = dict(payload or {})
        data["stored_at"] = _sm_utc_iso()
        data["key"] = key
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as error:
        logger.warning("Idempotency store failed: %s", type(error).__name__)


def _sm_get_semaphore(platform: str) -> asyncio.Semaphore:
    platform = str(platform or "default").lower()
    if platform not in _SM_PLATFORM_SEMAPHORES:
        limit = SM_PLATFORM_CONCURRENCY.get(platform, SM_PLATFORM_CONCURRENCY["default"])
        _SM_PLATFORM_SEMAPHORES[platform] = asyncio.Semaphore(max(1, int(limit)))
    return _SM_PLATFORM_SEMAPHORES[platform]


def _sm_rate_limit_allow(platform: str) -> Tuple[bool, Dict]:
    platform = str(platform or "default").lower()
    limit = SM_HOURLY_LIMITS.get(platform, SM_HOURLY_LIMITS["default"])
    now = _sm_now_ts()
    window = _SM_HOURLY_HITS[platform]
    while window and (now - window[0]) > 3600:
        window.popleft()
    info = {
        "platform": platform,
        "hourly_limit": limit,
        "hourly_used": len(window),
        "hourly_remaining": max(0, limit - len(window)),
    }
    if len(window) >= limit:
        info["status"] = "rate_limited"
        return False, info
    window.append(now)
    info["status"] = "allowed"
    info["hourly_used"] = len(window)
    info["hourly_remaining"] = max(0, limit - len(window))
    return True, info


def _sm_load_selectors_file() -> Dict[str, Dict[str, list]]:
    global _SM_DYNAMIC_SELECTORS
    if _SM_DYNAMIC_SELECTORS:
        return _SM_DYNAMIC_SELECTORS
    try:
        if SM_SELECTORS_FILE.exists():
            raw = json.loads(SM_SELECTORS_FILE.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                _SM_DYNAMIC_SELECTORS = raw
                logger.info("Loaded dynamic selectors from %s", SM_SELECTORS_FILE)
    except Exception as error:
        logger.warning("selectors.json load failed: %s", type(error).__name__)
        _SM_DYNAMIC_SELECTORS = {}
    return _SM_DYNAMIC_SELECTORS


def update_selector(platform: str, action: str, selectors: list, persist: bool = True) -> bool:
    """Public helper to update runtime selectors and optionally persist to selectors.json."""
    platform = str(platform or "").strip().lower()
    action = str(action or "").strip().lower()
    if not platform or not action or not isinstance(selectors, list):
        return False
    data = _sm_load_selectors_file()
    data.setdefault(platform, {})
    data[platform][action] = [str(s) for s in selectors if s]
    _SM_DYNAMIC_SELECTORS = data
    if persist:
        try:
            SM_SELECTORS_FILE.parent.mkdir(parents=True, exist_ok=True)
            SM_SELECTORS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            return True
        except Exception as error:
            logger.warning("update_selector persist failed: %s", type(error).__name__)
            return False
    return True


def _sm_get_selectors(platform: str, action: str, defaults: list = None) -> list:
    data = _sm_load_selectors_file()
    platform = str(platform or "").lower()
    action = str(action or "").lower()
    dynamic = data.get(platform, {}).get(action) if isinstance(data.get(platform), dict) else None
    if isinstance(dynamic, list) and dynamic:
        return list(dynamic)
    if defaults:
        return list(defaults)
    return list(SM_ENGLISH_SELECTORS.get(action, []))


def _sm_load_accounts() -> Dict[str, list]:
    global _SM_ACCOUNTS_CACHE
    if _SM_ACCOUNTS_CACHE:
        return _SM_ACCOUNTS_CACHE
    try:
        if SM_ACCOUNTS_FILE.exists():
            raw = json.loads(SM_ACCOUNTS_FILE.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                _SM_ACCOUNTS_CACHE = raw
            elif isinstance(raw, list):
                # flat list with platform field
                grouped = defaultdict(list)
                for item in raw:
                    if isinstance(item, dict):
                        grouped[str(item.get("platform", "generic")).lower()].append(item)
                _SM_ACCOUNTS_CACHE = dict(grouped)
            logger.info("Loaded accounts.json platforms=%s", list(_SM_ACCOUNTS_CACHE.keys()))
    except Exception as error:
        logger.warning("accounts.json load failed: %s", type(error).__name__)
        _SM_ACCOUNTS_CACHE = {}
    return _SM_ACCOUNTS_CACHE


def _sm_next_account(platform: str) -> Optional[Dict]:
    accounts = _sm_load_accounts().get(str(platform or "").lower(), [])
    if not accounts:
        return None
    idx = _SM_ACCOUNT_CURSOR[platform] % len(accounts)
    _SM_ACCOUNT_CURSOR[platform] = idx + 1
    return accounts[idx]


async def _sm_cookie_expiry_monitor(cookies: list, platform: str = "generic") -> Dict:
    """Inspect cookie list for expiry health."""
    now = _sm_now_ts()
    total = 0
    expired = 0
    expiring_soon = 0
    missing_session = True
    details = []
    session_names = {"sessionid", "sessionid_ss", "sid_tt", "auth_token", "li_at", "xs"}
    for item in cookies or []:
        if not isinstance(item, dict) or not item.get("name"):
            continue
        total += 1
        name = str(item.get("name"))
        if name.lower() in session_names:
            missing_session = False
        exp = item.get("expirationDate", item.get("expires"))
        if exp is None:
            continue
        try:
            exp_f = float(exp)
        except Exception:
            continue
        # support ms timestamps
        if exp_f > 10_000_000_000:
            exp_f = exp_f / 1000.0
        remain = exp_f - now
        if remain <= 0:
            expired += 1
            details.append({"name": name, "state": "expired"})
        elif remain < 3 * 24 * 3600:
            expiring_soon += 1
            details.append({"name": name, "state": "expiring_soon", "hours_left": round(remain / 3600, 1)})
    status = "ok"
    if total == 0:
        status = "no_cookies"
    elif missing_session:
        status = "missing_session_cookie"
    elif expired > 0:
        status = "expired_cookies"
    elif expiring_soon > 0:
        status = "expiring_soon"
    return {
        "platform": platform,
        "status": status,
        "total": total,
        "expired": expired,
        "expiring_soon": expiring_soon,
        "missing_session": missing_session,
        "details": details[:20],
    }


async def _sm_external_cookie_reload(page, platform: str) -> Dict:
    """Reload cookies from the fleet-selected file, else the canonical session file."""
    platform = str(platform or "").lower()
    forced = os.environ.get(f"FLEET_COOKIE_{platform.upper()}", "").strip()
    if forced:
        path = Path(forced).expanduser()
        SM_COOKIE_FILES[platform] = str(path)
    else:
        path = Path(SM_COOKIE_FILES.get(platform, f"/root/sessions/{platform}.json")).expanduser()
    result = {"platform": platform, "reloaded": False, "path": str(path), "status": "missing_file"}
    if not path.exists():
        return result
    try:
        mtime = path.stat().st_mtime
        previous = _SM_COOKIE_MTIME.get(platform)
        raw = json.loads(path.read_text(encoding="utf-8"))
        cookies = raw.get("cookies", raw) if isinstance(raw, dict) else raw
        if not isinstance(cookies, list) or not cookies:
            result["status"] = "empty_file"
            return result
        health = await _sm_cookie_expiry_monitor(cookies, platform)
        result["cookie_health"] = health
        if health["status"] in {"expired_cookies", "missing_session_cookie", "no_cookies"}:
            result["status"] = health["status"]
            return result
        if page is None:
            result["status"] = "no_page"
            return result
        # only reload if file changed or never loaded
        if previous is not None and mtime <= previous and health["status"] == "ok":
            result["status"] = "up_to_date"
            return result
        formatted = []
        default_domain = {
            "instagram": ".instagram.com",
            "tiktok": ".tiktok.com",
            "telegram": ".telegram.org",
            "facebook": ".facebook.com",
            "youtube": ".youtube.com",
        }.get(platform, "")
        # reuse BaseSkill formatter if available via instance later; inline safe format here
        for item in cookies:
            if not item.get("name") or "value" not in item:
                continue
            cookie = {
                "name": str(item["name"]),
                "value": str(item["value"]),
                "domain": str(item.get("domain", default_domain)),
                "path": str(item.get("path", "/")),
                "httpOnly": bool(item.get("httpOnly", False)),
                "secure": bool(item.get("secure", True)),
            }
            expiration = item.get("expirationDate", item.get("expires"))
            if expiration:
                try:
                    exp_f = float(expiration)
                    if exp_f > 10_000_000_000:
                        exp_f = exp_f / 1000.0
                    cookie["expires"] = exp_f
                except Exception:
                    pass
            same_site = str(item.get("sameSite", "")).lower()
            if same_site in {"none", "no_restriction"}:
                cookie["sameSite"] = "None"
            elif same_site == "strict":
                cookie["sameSite"] = "Strict"
            else:
                cookie["sameSite"] = "Lax"
            formatted.append(cookie)
        if formatted:
            await page.context.add_cookies(formatted)
            _SM_COOKIE_MTIME[platform] = mtime
            result["reloaded"] = True
            result["status"] = "reloaded"
            result["count"] = len(formatted)
            logger.info("External cookies reloaded for %s count=%s", platform, len(formatted))
        else:
            result["status"] = "nothing_to_load"
    except Exception as error:
        result["status"] = "reload_error"
        result["error"] = str(error)[:300]
        result["stack"] = _sm_stack_trace(error)
        logger.warning("External cookie reload failed for %s: %s", platform, type(error).__name__)
    return result


async def _sm_page_health_v2(page) -> str:
    """Extended health: login/captcha/IP/region/content/404/5xx."""
    if not page:
        return "missing_page"
    try:
        url = (page.url or "").lower()
    except Exception:
        url = ""
    body = await _sm_body_text(page)

    if any(x in url for x in ("/login", "/signin", "/auth", "accounts.google.com/servicelogin")):
        return "login_required"
    if any(x in body for x in (
        "log in to telegram by qr code",
        "log in by phone number",
        "point your phone at this screen",
        "open telegram on your phone",
    )):
        return "login_required"
    if any(code in url for code in ("/404", "error=404")):
        return "http_404"
    if any(code in body for code in (
        "404 not found", "page not found", "страница не найдена",
        "такой страницы не существует", "الصفحة غير موجودة",
    )):
        return "http_404"
    if any(code in body for code in (
        "500 internal server error", "internal server error", "502 bad gateway",
        "503 service unavailable", "504 gateway timeout", "bad gateway",
        "service unavailable", "gateway timeout",
    )):
        if "502" in body or "bad gateway" in body:
            return "http_502"
        if "503" in body or "service unavailable" in body:
            return "http_503"
        if "504" in body or "gateway timeout" in body:
            return "http_504"
        return "http_500"
    if any(x in body for x in (
        "доступ ограничен: проблема с ip",
        "проблема с ip",
        "слишком много запросов",
        "too many requests",
        "ip has been blocked",
    )):
        return "ip_blocked"
    if any(x in body for x in (
        "видео недоступно",
        "недоступно в вашей стране",
        "недоступно в вашей стране или регионе",
        "not available in your country",
        "not available in your region",
    )):
        return "region_block"
    if any(x in body for x in (
        "этот контент может быть неуместным",
        "контент недоступен для определенных аудиторий",
        "this content may be inappropriate",
        "sensitive content",
    )):
        return "content_restricted"
    if any(x in body for x in (
        "captcha", "verify you are human", "verify that you are human",
        "security check", "robot check",
        "проверяем, что вы не робот", "я не робот", "я человек",
        "подозрительный трафик", "recaptcha", "hcaptcha", "h-captcha",
        "i am human",
    )):
        return "challenge_or_block"
    if any(x in body for x in (
        "we suspect automated behavior", "automated behavior", "suspicious activity",
        "зарегистрировали подозрительный трафик",
        "ваши действия признаны автоматическими",
        "действия признаны автоматическими",
        "recognized as automated",
        "qrerror/403",
    )):
        return "automation_block"
    if any(x in body for x in (
        "доступ ограничен: проблема с ip",
        "проблема с ip",
        "отключить vpn",
        "режим «в самолёте»",
        "подключиться к другой сети",
    )):
        return "ip_blocked"
    if any(x in body for x in ("something went wrong", "page isn't available", "content unavailable")):
        return "page_error"
    return "ready"


async def _sm_comment_already_exists(page, comment_text: str) -> bool:
    """Best-effort check whether the same comment text is already visible on the page."""
    if not page or not comment_text:
        return False
    needle = str(comment_text).strip().lower()
    if len(needle) < 3:
        return False
    body = await _sm_body_text(page)
    # exact or near-exact presence
    if needle in body:
        return True
    # shortened match (first 40 chars) to tolerate truncation in UI
    short = needle[:40]
    if len(short) >= 12 and short in body:
        return True
    return False


async def _sm_fallback_comment(skill, target_url: str, page=None, comment_text: str = "", **kwargs):
    """Idempotent-safe comment fallback: skip if comment already present."""
    action = "comment"
    if not page or not target_url:
        return _sm_normalize_result(False, {"status": "missing_page_or_target", "action": action})
    text = str(comment_text or kwargs.get("text") or "Nice!").strip()
    key = _sm_idempotency_key("web", action, target_url, text)
    seen = _sm_idempotency_seen(key)
    if seen and seen.get("success"):
        return _sm_normalize_result(True, {
            "status": "idempotent_replay",
            "action": action,
            "idempotency_key": key,
            "previous": seen,
        })
    try:
        await page.goto(str(target_url), timeout=SM_NAVIGATION_TIMEOUT, wait_until="domcontentloaded")
        await _sm_wait_dom(page, 900)
        health = await _sm_page_health_v2(page)
        if health != "ready":
            return _sm_normalize_result(False, {"status": health, "action": action, "idempotency_key": key})
        if await _sm_comment_already_exists(page, text):
            screenshot = await _sm_screenshot(page, "comment_already_exists")
            payload = {
                "status": "already_commented",
                "action": action,
                "screenshot_path": screenshot,
                "proof_path": screenshot,
                "verified": True,
                "idempotency_key": key,
            }
            _sm_idempotency_store(key, payload)
            return _sm_normalize_result(True, payload)
        # generic comment UI attempt
        field_selectors = [
            'textarea[placeholder*="comment" i]',
            'textarea[placeholder*="تعليق"]',
            'textarea[placeholder*="коммент"]',
            'div[contenteditable="true"]',
            'input[placeholder*="comment" i]',
        ]
        field = await _sm_first_actionable(page, field_selectors)
        if not field:
            return _sm_normalize_result(False, {"status": "comment_field_not_found", "action": action, "idempotency_key": key})
        await field.click()
        await asyncio.sleep(random.uniform(0.2, 0.5))
        try:
            await field.type(text, delay=random.randint(35, 100))
        except Exception:
            await page.keyboard.type(text, delay=random.randint(35, 100))
        post_selectors = [
            'button:has-text("Post")',
            'button:has-text("نشر")',
            'button:has-text("Опубликовать")',
            'button:has-text("Send")',
            'div[data-e2e="comment-post"]',
        ]
        posted = await _sm_safe_click(page, post_selectors)
        if not posted:
            return _sm_normalize_result(False, {"status": "comment_post_not_found", "action": action, "idempotency_key": key})
        await _sm_wait_dom(page, 1200)
        exists = await _sm_comment_already_exists(page, text)
        screenshot = await _sm_screenshot(page, "comment_fallback")
        payload = {
            "status": "done" if exists else "submitted_unverified",
            "action": action,
            "screenshot_path": screenshot,
            "proof_path": screenshot,
            "verified": bool(exists),
            "idempotency_key": key,
            "execution_method": "fallback_comment",
        }
        if exists:
            _sm_idempotency_store(key, payload)
            return _sm_normalize_result(True, payload)
        # submitted_unverified ≠ success: الزر اتضغط لكن مفيش إثبات إن التعليق ظاهر
        _sm_idempotency_store(key, payload)
        return _sm_normalize_result(False, payload)
    except Exception as error:
        return _sm_normalize_result(False, {
            "status": "comment_fallback_error",
            "action": action,
            "error": str(error)[:400],
            "stack": _sm_stack_trace(error),
            "idempotency_key": key,
        })


async def _sm_fallback_review(skill, target_url: str, page=None, review_text: str = "", rating: int = 5, **kwargs):
    action = "review"
    if not page or not target_url:
        return _sm_normalize_result(False, {"status": "missing_page_or_target", "action": action})
    text = str(review_text or kwargs.get("text") or kwargs.get("comment_text") or "Good").strip()
    key = _sm_idempotency_key("web", action, target_url, f"{rating}|{text}")
    seen = _sm_idempotency_seen(key)
    if seen and seen.get("success"):
        return _sm_normalize_result(True, {"status": "idempotent_replay", "action": action, "idempotency_key": key, "previous": seen})
    try:
        await page.goto(str(target_url), timeout=SM_NAVIGATION_TIMEOUT, wait_until="domcontentloaded")
        await _sm_wait_dom(page, 900)
        health = await _sm_page_health_v2(page)
        if health != "ready":
            return _sm_normalize_result(False, {"status": health, "action": action, "idempotency_key": key})
        # rating stars (best effort)
        star_selectors = [
            f'[aria-label="{rating} star"]',
            f'button[aria-label*="{rating}"]',
            f'[data-rating="{rating}"]',
            'div[role="radio"]',
        ]
        await _sm_safe_click(page, star_selectors)
        field_selectors = [
            'textarea[placeholder*="review" i]',
            'textarea[placeholder*="отзыв" i]',
            'textarea[placeholder*="مراجعة"]',
            'textarea',
        ]
        field = await _sm_first_actionable(page, field_selectors)
        if field:
            await field.click()
            try:
                await field.type(text, delay=random.randint(35, 100))
            except Exception:
                await page.keyboard.type(text, delay=random.randint(35, 100))
        submit_selectors = [
            'button:has-text("Submit")',
            'button:has-text("Post")',
            'button:has-text("Send")',
            'button:has-text("Отправить")',
            'button:has-text("إرسال")',
            'button[type="submit"]',
        ]
        submitted = await _sm_safe_click(page, submit_selectors)
        screenshot = await _sm_screenshot(page, "review_fallback")
        payload = {
            "status": "done" if submitted else "review_submit_not_found",
            "action": action,
            "screenshot_path": screenshot,
            "proof_path": screenshot,
            "verified": bool(submitted),
            "idempotency_key": key,
            "execution_method": "fallback_review",
        }
        if submitted:
            _sm_idempotency_store(key, payload)
            return _sm_normalize_result(True, payload)
        return _sm_normalize_result(False, payload)
    except Exception as error:
        return _sm_normalize_result(False, {
            "status": "review_fallback_error",
            "action": action,
            "error": str(error)[:400],
            "stack": _sm_stack_trace(error),
            "idempotency_key": key,
        })


async def _sm_fallback_register(skill, target_url: str, page=None, **kwargs):
    """Register fallback is intentionally conservative: detect form + idempotency only.
    Does not invent personal data. Uses kwargs email/password/username when provided.
    """
    action = "register"
    if not page or not target_url:
        return _sm_normalize_result(False, {"status": "missing_page_or_target", "action": action})
    email = str(kwargs.get("email") or "").strip()
    password = str(kwargs.get("password") or "").strip()
    username = str(kwargs.get("username") or "").strip()
    key = _sm_idempotency_key("web", action, target_url, f"{email}|{username}")
    seen = _sm_idempotency_seen(key)
    if seen and seen.get("success"):
        return _sm_normalize_result(True, {"status": "idempotent_replay", "action": action, "idempotency_key": key, "previous": seen})
    if not email or not password:
        return _sm_normalize_result(False, {
            "status": "register_requires_email_password",
            "action": action,
            "idempotency_key": key,
        })
    try:
        await page.goto(str(target_url), timeout=SM_NAVIGATION_TIMEOUT, wait_until="domcontentloaded")
        await _sm_wait_dom(page, 900)
        health = await _sm_page_health_v2(page)
        if health not in {"ready", "login_required"}:
            return _sm_normalize_result(False, {"status": health, "action": action, "idempotency_key": key})
        # fill common fields when present
        filled = 0
        mapping = [
            (['input[type="email"]', 'input[name*="email" i]', 'input[placeholder*="email" i]'], email),
            (['input[type="password"]', 'input[name*="password" i]'], password),
            (['input[name*="user" i]', 'input[placeholder*="username" i]', 'input[name*="login" i]'], username or email.split("@")[0]),
        ]
        for selectors, value in mapping:
            if not value:
                continue
            field = await _sm_first_actionable(page, selectors)
            if not field:
                continue
            try:
                await field.click()
                await field.fill("")
                await field.type(value, delay=random.randint(25, 70))
                filled += 1
            except Exception:
                continue
        submit_selectors = [
            'button[type="submit"]',
            'button:has-text("Sign up")',
            'button:has-text("Register")',
            'button:has-text("Create account")',
            'button:has-text("Зарегистрироваться")',
            'button:has-text("Регистрация")',
        ]
        submitted = await _sm_safe_click(page, submit_selectors)
        screenshot = await _sm_screenshot(page, "register_fallback")
        payload = {
            "status": "done" if submitted and filled >= 2 else "register_incomplete",
            "action": action,
            "filled_fields": filled,
            "screenshot_path": screenshot,
            "proof_path": screenshot,
            "verified": bool(submitted and filled >= 2),
            "idempotency_key": key,
            "execution_method": "fallback_register",
        }
        if payload["verified"]:
            _sm_idempotency_store(key, payload)
            return _sm_normalize_result(True, payload)
        return _sm_normalize_result(False, payload)
    except Exception as error:
        return _sm_normalize_result(False, {
            "status": "register_fallback_error",
            "action": action,
            "error": str(error)[:400],
            "stack": _sm_stack_trace(error),
            "idempotency_key": key,
        })


async def _sm_generic_browser_fallback_v2(skill, action: str, target_url: str, page=None, **kwargs):
    """Enhanced fallback with comment/review/register support + backoff-ready status codes."""
    action = str(action or "").strip().lower()
    if action == "comment":
        return await _sm_fallback_comment(skill, target_url, page=page, **kwargs)
    if action == "review":
        return await _sm_fallback_review(skill, target_url, page=page, **kwargs)
    if action == "register":
        return await _sm_fallback_register(skill, target_url, page=page, **kwargs)

    # reuse original fallback for idempotent actions, but with v2 health
    if not page or not target_url:
        return _sm_normalize_result(False, {"status": "missing_page_or_target", "action": action})
    try:
        await page.goto(str(target_url), timeout=SM_NAVIGATION_TIMEOUT, wait_until="domcontentloaded")
        await _sm_wait_dom(page, 900)
        health = await _sm_page_health_v2(page)
        if health != "ready":
            return _sm_normalize_result(False, {"status": health, "action": action})
        if action == "view":
            try:
                await page.mouse.wheel(0, 700)
                await asyncio.sleep(random.uniform(1.5, 3.0))
            except Exception:
                pass
            screenshot = await _sm_screenshot(page, f"{getattr(skill, '__class__', type(skill)).__name__.lower()}_view")
            if not screenshot:
                return _sm_normalize_result(False, {"status": "proof_screenshot_failed", "action": action})
            return _sm_normalize_result(True, {
                "status": "done",
                "action": action,
                "screenshot_path": screenshot,
                "proof_path": screenshot,
                "verified": True,
                "execution_method": "browser",
            })
        key = _sm_idempotency_key(getattr(skill, "__class__", type(skill)).__name__.lower(), action, target_url)
        seen = _sm_idempotency_seen(key)
        if seen and seen.get("success") and action in {"subscribe", "like"}:
            return _sm_normalize_result(True, {
                "status": "idempotent_replay",
                "action": action,
                "idempotency_key": key,
                "previous": seen,
            })
        if action in {"subscribe", "like"} and await _sm_already_active(page, action):
            screenshot = await _sm_screenshot(page, f"{action}_already_active")
            payload = {
                "status": "already_active",
                "action": action,
                "screenshot_path": screenshot,
                "proof_path": screenshot,
                "verified": True,
                "idempotency_key": key,
            }
            _sm_idempotency_store(key, payload)
            return _sm_normalize_result(True, payload)
        platform_name = getattr(skill, "__class__", type(skill)).__name__.replace("Skill", "").lower()
        selectors = _sm_get_selectors(platform_name, action, SM_ENGLISH_SELECTORS.get(action, []))
        clicked = await _sm_safe_click(page, selectors)
        if not clicked:
            return _sm_normalize_result(False, {"status": f"{action}_control_not_found", "action": action})
        await _sm_wait_dom(page, 900)
        verified = True
        if action in {"subscribe", "like"}:
            verified = await _sm_already_active(page, action)
        if not verified:
            return _sm_normalize_result(False, {"status": f"{action}_postcondition_failed", "action": action, "idempotency_key": key})
        screenshot = await _sm_screenshot(page, f"{action}_verified")
        if not screenshot:
            return _sm_normalize_result(False, {"status": "proof_screenshot_failed", "action": action})
        payload = {
            "status": "done",
            "action": action,
            "screenshot_path": screenshot,
            "proof_path": screenshot,
            "verified": True,
            "execution_method": "browser",
            "idempotency_key": key,
        }
        _sm_idempotency_store(key, payload)
        return _sm_normalize_result(True, payload)
    except Exception as error:
        return _sm_normalize_result(False, {
            "status": "browser_fallback_error",
            "action": action,
            "error": str(error)[:400],
            "stack": _sm_stack_trace(error),
        })


def _sm_wrap_browser_skill_v2(cls):
    """Re-wrap with retry loop + exponential backoff + rate limit + semaphore."""
    current = cls.execute_task
    if getattr(current, "__sm_prod_v2__", False):
        return

    # unwrap one level if previous hardening wrapper exists, keep calling current chain
    async def wrapped(self, action: str, target_url: str, page=None, **kwargs):
        platform = cls.__name__.replace("Skill", "").lower()
        action_n = str(action or "").strip().lower()
        account = _sm_next_account(platform)
        if account:
            kwargs.setdefault("account", account)
            kwargs.setdefault("account_id", account.get("id") or account.get("username"))

        # external cookie reload (best effort)
        if page is not None and platform in SM_COOKIE_FILES:
            try:
                reload_info = await _sm_external_cookie_reload(page, platform)
                kwargs.setdefault("cookie_reload", reload_info)
            except Exception:
                pass

        allowed, rate_info = _sm_rate_limit_allow(platform)
        if not allowed:
            return _sm_normalize_result(False, {
                "status": "rate_limited",
                "platform": platform,
                "action": action_n,
                "rate_limit": rate_info,
            })

        sem = _sm_get_semaphore(platform)
        await sem.acquire()
        last_data = {"status": "no_attempt", "platform": platform, "action": action_n}
        try:
            for attempt in range(1, SM_MAX_WRAPPER_ATTEMPTS + 1):
                try:
                    result = await current(self, action, target_url, page=page, **kwargs)
                except Exception as error:
                    logger.exception(
                        "Skill %s attempt %s raised: %s",
                        cls.__name__, attempt, type(error).__name__
                    )
                    result = (False, {
                        "status": "original_skill_exception",
                        "action": action_n,
                        "error": str(error)[:400],
                        "stack": _sm_stack_trace(error),
                        "attempt": attempt,
                    })

                if isinstance(result, tuple) and len(result) >= 2:
                    success, data = bool(result[0]), _sm_result_dict(result[1])
                else:
                    success, data = bool(result), {}

                data.setdefault("attempt", attempt)
                data.setdefault("platform", platform)
                data.setdefault("action", action_n)
                data.setdefault("rate_limit", rate_info)
                data.setdefault("prod_layer", SM_PROD_VERSION)

                if success:
                    return _sm_normalize_result(True, data)

                # fallback path with v2 (includes comment/review/register)
                fb_success, fb_data = await _sm_generic_browser_fallback_v2(
                    self, action, target_url, page=page, **kwargs
                )
                fb_data.setdefault("attempt", attempt)
                fb_data.setdefault("original_result", data)
                if fb_success:
                    return _sm_normalize_result(True, fb_data)

                last_data = data
                last_data["fallback_status"] = fb_data.get("status")
                last_data["fallback"] = fb_data

                # stop early on non-retryable statuses
                non_retryable = {
                    "login_required", "captcha", "challenge_or_block", "automation_block",
                    "automation_detected", "rate_limited", "unsupported_action",
                    "register_requires_email_password",
                    "region_block", "content_restricted", "ip_blocked",
                    "http_404", "http_500", "http_502", "http_503", "http_504",
                    "telegram_qr_or_phone_login", "tiktok_login_wall",
                }
                status = str(data.get("status") or fb_data.get("status") or "")
                if status in non_retryable or status.startswith("http_40"):
                    last_data["status"] = status
                    break

                if attempt < SM_MAX_WRAPPER_ATTEMPTS:
                    delay = SM_BACKOFF_SECONDS[min(attempt - 1, len(SM_BACKOFF_SECONDS) - 1)]
                    # jitter
                    delay = delay + random.uniform(0, 0.8)
                    last_data["backoff_seconds"] = delay
                    await asyncio.sleep(delay)

            last_data.setdefault("status", "failed_after_retries")
            last_data.setdefault("stack", _sm_stack_trace())
            return _sm_normalize_result(False, last_data)
        finally:
            sem.release()

    wrapped.__name__ = getattr(current, "__name__", "execute_task")
    wrapped.__qualname__ = getattr(current, "__qualname__", "execute_task")
    wrapped.__doc__ = getattr(current, "__doc__", None)
    wrapped.__sm_prod_v2__ = True
    wrapped.__sm_hardened__ = True
    cls.execute_task = wrapped


for _sm_cls in _SM_BROWSER_SKILLS:
    _sm_wrap_browser_skill_v2(_sm_cls)


# ----------------------------------------------------------
# close() helpers for skills + SkillManager
# ----------------------------------------------------------

async def _sm_skill_close(self):
    """Best-effort resource cleanup for any skill instance."""
    errors = []
    # Telethon client
    client = getattr(self, "client", None)
    if client is not None:
        try:
            if getattr(client, "is_connected", lambda: False)():
                await client.disconnect()
        except Exception as error:
            errors.append(f"client:{type(error).__name__}")
        try:
            self.client = None
        except Exception:
            pass
    # generic session flags
    for attr in ("is_ready", "browser_account_ready"):
        if hasattr(self, attr):
            try:
                setattr(self, attr, False)
            except Exception:
                pass
    return {"closed": True, "errors": errors, "skill": self.__class__.__name__}


# Attach close() to BaseSkill if missing
if not hasattr(BaseSkill, "close"):
    BaseSkill.close = _sm_skill_close

for _sm_cls in (
    TelegramSkill, VKSkill, TikTokSkill, FacebookSkill, ReviewSkill,
    YouTubeSkill, InstagramSkill, RutubeSkill, AvitoSkill, TwitterSkill,
    DiscordSkill, RedditSkill, MaxSkill, GenericWebSkill,
):
    if not hasattr(_sm_cls, "close"):
        _sm_cls.close = _sm_skill_close


async def _sm_manager_close(self):
    """Close all registered skills and clear runtime caches."""
    report = {"skills": {}, "prod_layer": SM_PROD_VERSION}
    skills = getattr(self, "skills", {}) or {}
    for name, skill in list(skills.items()):
        try:
            if hasattr(skill, "close"):
                report["skills"][name] = await skill.close()
            else:
                report["skills"][name] = {"closed": False, "reason": "no_close_method"}
        except Exception as error:
            report["skills"][name] = {
                "closed": False,
                "error": str(error)[:300],
                "stack": _sm_stack_trace(error),
            }
    # clear process caches
    try:
        _SM_HOURLY_HITS.clear()
        _SM_DYNAMIC_SELECTORS.clear()
        _SM_ACCOUNTS_CACHE.clear()
        _SM_COOKIE_MTIME.clear()
    except Exception:
        pass
    report["closed"] = True
    logger.info("SkillManager.close() completed")
    return report


if not hasattr(SkillManager, "close"):
    SkillManager.close = _sm_manager_close


# ----------------------------------------------------------
# Enhanced route_task: rate limit + normalized output + stack
# ----------------------------------------------------------

_SM_ROUTE_PREV = SkillManager.route_task


async def _sm_route_task_v2(
    self,
    platform: str,
    action: str,
    target_url: str,
    page=None,
    **kwargs
) -> Tuple[bool, Dict]:
    normalized_platform = canonical_platform(platform)
    normalized_action = self._normalize_action(action)
    platform_aliases = {
        "x": "twitter",
        "x.com": "twitter",
        "yt": "youtube",
        "ig": "instagram",
        "fb": "facebook",
        "tt": "tiktok",
        "max": "max",
        "google maps": "google_maps",
        "google play": "google_play",
        "play market": "google_play",
        "app store": "app_store",
    }
    normalized_platform = platform_aliases.get(normalized_platform, normalized_platform)
    if normalized_platform in {"google_play", "app_store", "yandex"} and normalized_action == "review":
        normalized_platform = "review"

    # حراسة مزدوجة: منصات غير مسموحة تُرفض فورًا من الـSkill layer
    allowed = EXECUTION_PLATFORMS
    if normalized_platform not in allowed and normalized_platform != "review":
        logger.warning(
            "SM route rejected unsupported platform: %s / %s",
            normalized_platform,
            normalized_action,
        )
        return False, {
            "status": "platform_not_allowed",
            "platform": normalized_platform,
            "action": normalized_action,
            "reason": "only_telegram_vk_max_ig_tt_yt_rutube",
        }

    # idempotency short-circuit for safe actions
    if normalized_action in {"subscribe", "like", "view", "comment", "review", "register"}:
        key = _sm_idempotency_key(normalized_platform, normalized_action, str(target_url or ""), str(kwargs.get("comment_text") or kwargs.get("text") or ""))
        seen = _sm_idempotency_seen(key)
        if seen and seen.get("success") and normalized_action in {"subscribe", "like", "view"}:
            return _sm_normalize_result(True, {
                "status": "idempotent_replay",
                "platform": normalized_platform,
                "action": normalized_action,
                "idempotency_key": key,
                "previous": seen,
            })

    try:
        success, data = await _SM_ROUTE_PREV(
            self,
            platform=normalized_platform,
            action=normalized_action,
            target_url=target_url,
            page=page,
            **kwargs,
        )
    except Exception as error:
        logger.exception("route_task_v2 crashed: %s", type(error).__name__)
        return _sm_normalize_result(False, {
            "status": "route_exception",
            "platform": normalized_platform,
            "action": normalized_action,
            "error": str(error)[:500],
            "stack": _sm_stack_trace(error),
        })

    success, data = _sm_normalize_result(success, _sm_result_dict(data), platform=normalized_platform, action=normalized_action)
    # بروفايل الحساب اختياري فقط — لا يستبدل سكرين التنفيذ على الهدف
    # الإثبات الأساسي = ما التقطه الـSkill بعد الفعل على رابط المهمة
    if success and page is not None:
        try:
            data = dict(data or {})
            # احتفظ بسكرين التنفيذ الأصلي
            action_ss = data.get("proof_path") or data.get("screenshot_path")
            if action_ss:
                data["action_proof_path"] = action_ss
                data["proof_path"] = action_ss
                data["screenshot_path"] = action_ss
                data["proof_source"] = data.get("proof_source") or "action_target"
            # لا نفتح بروفايل الحساب كإثبات أساسي (كان يسبب سكرين قناة فاضية)
        except Exception as proof_error:
            logger.warning("proof normalize failed: %s", proof_error)
    # persist idempotency on success for safe actions
    if success and normalized_action in {"subscribe", "like", "view", "comment"}:
        key = data.get("idempotency_key") or _sm_idempotency_key(
            normalized_platform, normalized_action, str(target_url or ""), str(kwargs.get("comment_text") or "")
        )
        data["idempotency_key"] = key
        _sm_idempotency_store(key, {"success": True, **{k: data.get(k) for k in ("status", "screenshot_path", "proof_path", "platform", "action")}})
    return success, data


SkillManager.route_task = _sm_route_task_v2


# expose helpers on SkillManager for external use
SkillManager.update_selector = staticmethod(update_selector)
SkillManager.cookie_expiry_monitor = staticmethod(_sm_cookie_expiry_monitor)
SkillManager.external_cookie_reload = staticmethod(_sm_external_cookie_reload)
SkillManager.idempotency_key = staticmethod(_sm_idempotency_key)
SkillManager.normalize_result = staticmethod(_sm_normalize_result)
SkillManager.load_accounts = staticmethod(_sm_load_accounts)
SkillManager.next_account = staticmethod(_sm_next_account)


logger.info(
    "🚀 Production hardening v2 loaded: %s | comment/review/register fallback + idempotency + cookies + rate limits + close()",
    SM_PROD_VERSION,
)



# =====================================================================
# SM_API_LAYER_V3 — External API skills (ADDITIVE ONLY)
# Libraries: instagrapi | vk_api/vksdk | twikit | TikTok helpers |
#            Ozon Seller API | MAX Bot API | Avito API
# Does NOT delete or rewrite existing skill method bodies.
# Wraps execute_task: try API first → original browser skill.
# =====================================================================

SM_API_LAYER_VERSION = "api-layer-v3"
logger.info("🔌 Loading %s …", SM_API_LAYER_VERSION)

import urllib.parse
import urllib.request


def _sm_api_env(*names: str, default: str = "") -> str:
    for n in names:
        v = (os.getenv(n) or "").strip()
        if v:
            return v
    return default


def _sm_api_proxy() -> str:
    return _sm_api_env("IG_PROXY", "TT_PROXY", "VK_PROXY", "HTTPS_PROXY", "HTTP_PROXY", "ALL_PROXY")


def _sm_cookie_value(cookies: list, name: str) -> str:
    for c in cookies or []:
        if str(c.get("name") or "") == name and c.get("value") is not None:
            return str(c.get("value"))
    return ""


def _sm_load_json_cookies(path: str) -> list:
    try:
        fp = Path(path)
        if not fp.exists():
            return []
        raw = json.loads(fp.read_text(encoding="utf-8"))
        if isinstance(raw, list):
            return raw
        if isinstance(raw, dict):
            return list(raw.get("cookies") or [])
    except Exception:
        pass
    return []


# ---------------------------------------------------------------------
# Instagram — instagrapi
# ---------------------------------------------------------------------
_IG_API_CLIENT = None


def _sm_ig_get_client():
    global _IG_API_CLIENT
    if _IG_API_CLIENT is not None:
        return _IG_API_CLIENT
    try:
        from instagrapi import Client
    except ImportError:
        logger.warning("instagrapi not installed")
        return None
    sid = _sm_api_env("IG_SESSIONID", "INSTAGRAM_SESSIONID")
    if not sid:
        # from skill cookies if available
        try:
            sid = _sm_cookie_value(getattr(InstagramSkill, "INSTAGRAM_COOKIES", []), "sessionid")
        except Exception:
            sid = ""
    if not sid:
        cookies = _sm_load_json_cookies(_sm_api_env("IG_COOKIES_PATH", default="/root/sessions/instagram.json"))
        sid = _sm_cookie_value(cookies, "sessionid")
    cl = Client()
    proxy = _sm_api_proxy()
    if proxy:
        try:
            cl.set_proxy(proxy)
        except Exception as e:
            logger.warning("IG proxy: %s", e)
    settings = Path(_sm_api_env("IG_SETTINGS_PATH", default="data/sessions/instagram_settings.json"))
    try:
        if settings.exists():
            cl.load_settings(str(settings))
    except Exception:
        pass
    try:
        if sid:
            cl.login_by_sessionid(sid)
        else:
            user = _sm_api_env("IG_USERNAME")
            password = _sm_api_env("IG_PASSWORD")
            if not (user and password):
                return None
            cl.login(user, password)
        try:
            settings.parent.mkdir(parents=True, exist_ok=True)
            cl.dump_settings(str(settings))
        except Exception:
            pass
        _IG_API_CLIENT = cl
        logger.info("✅ instagrapi client ready")
        return cl
    except Exception as e:
        logger.warning("instagrapi login failed: %s", e)
        return None


def _sm_ig_username(url: str) -> str:
    m = re.search(r"instagram\.com/([A-Za-z0-9._]+)", url or "")
    if not m:
        return ""
    name = m.group(1)
    if name.lower() in {"p", "reel", "reels", "stories", "tv", "explore", "accounts", "direct"}:
        return ""
    return name


def _sm_ig_is_media(url: str) -> bool:
    u = (url or "").lower()
    return any(x in u for x in ("/p/", "/reel/", "/reels/", "/tv/"))


async def _sm_ig_api_action(action: str, target_url: str, comment_text: str = "🔥") -> Tuple[bool, Dict]:
    if _sm_api_env("IG_USE_API", default="1").lower() in {"0", "false", "no"}:
        return False, {"status": "api_disabled", "engine": "instagrapi"}

    def _run():
        cl = _sm_ig_get_client()
        if cl is None:
            return False, {"status": "api_unavailable", "engine": "instagrapi"}
        act = (action or "").lower().strip()
        url = (target_url or "").strip()
        meta = {"platform": "instagram", "engine": "instagrapi", "url": url}
        try:
            if act in {"subscribe", "follow", "join"}:
                username = _sm_ig_username(url)
                if not username:
                    return False, {**meta, "status": "no_username"}
                uid = cl.user_id_from_username(username)
                try:
                    fr = cl.user_friendship_v1(uid)
                    if getattr(fr, "following", False):
                        return True, {**meta, "status": "already_subscribed", "username": username}
                except Exception:
                    pass
                cl.user_follow(uid)
                return True, {**meta, "status": "done", "action": "subscribe", "username": username}
            if act == "like":
                if not _sm_ig_is_media(url):
                    return False, {**meta, "status": "not_media_url"}
                pk = cl.media_pk_from_url(url)
                cl.media_like(pk)
                return True, {**meta, "status": "done", "action": "like", "media_pk": str(pk)}
            if act == "comment":
                if not _sm_ig_is_media(url):
                    return False, {**meta, "status": "not_media_url"}
                pk = cl.media_pk_from_url(url)
                text = (comment_text or "🔥").strip() or "🔥"
                cl.media_comment(pk, text)
                return True, {**meta, "status": "done", "action": "comment", "media_pk": str(pk)}
            if act == "view":
                if _sm_ig_is_media(url):
                    pk = cl.media_pk_from_url(url)
                    return True, {**meta, "status": "done", "action": "view", "media_pk": str(pk)}
                username = _sm_ig_username(url)
                if username:
                    uid = cl.user_id_from_username(username)
                    return True, {**meta, "status": "done", "action": "view", "user_id": str(uid)}
            return False, {**meta, "status": "api_unsupported_action", "action": act}
        except Exception as e:
            err = str(e)[:300]
            st = "api_error"
            low = err.lower()
            if "login_required" in low:
                st = "login_required"
                globals()["_IG_API_CLIENT"] = None
            elif "challenge" in low:
                st = "challenge_required"
            elif "feedback" in low:
                st = "feedback_required"
            return False, {**meta, "status": st, "error": err}

    return await asyncio.to_thread(_run)


# ---------------------------------------------------------------------
# VK — vk_api (already in project) + optional vksdk
# ---------------------------------------------------------------------
_VK_API_SESSION = None


def _sm_vk_get_api():
    global _VK_API_SESSION
    if _VK_API_SESSION is not None:
        return _VK_API_SESSION
    token = _sm_api_env("VK_TOKEN", "VK_ACCESS_TOKEN", "VK_USER_TOKEN")
    login = _sm_api_env("VK_LOGIN", "VK_PHONE")
    password = _sm_api_env("VK_PASSWORD")
    try:
        import vk_api
    except ImportError:
        logger.warning("vk_api not installed")
        return None
    try:
        if token:
            session = vk_api.VkApi(token=token)
        elif login and password:
            session = vk_api.VkApi(login=login, password=password)
            session.auth()
        else:
            # try remixsid cookie → limited
            logger.warning("VK API: need VK_TOKEN or VK_LOGIN/VK_PASSWORD")
            return None
        api = session.get_api()
        _VK_API_SESSION = api
        logger.info("✅ vk_api client ready")
        return api
    except Exception as e:
        logger.warning("vk_api init failed: %s", e)
        return None


def _sm_vk_parse_target(url: str) -> Dict[str, Any]:
    """Parse VK wall post or group/user screen name."""
    u = (url or "").strip()
    out: Dict[str, Any] = {"raw": u}
    m = re.search(r"wall(-?\d+)_(\d+)", u)
    if m:
        out["owner_id"] = int(m.group(1))
        out["post_id"] = int(m.group(2))
        out["type"] = "wall"
        return out
    m = re.search(r"(?:vk\.(?:com|ru)|m\.vk\.(?:com|ru))/([A-Za-z0-9._]+)", u)
    if m:
        out["screen_name"] = m.group(1)
        out["type"] = "page"
    return out


async def _sm_vk_api_action(action: str, target_url: str, comment_text: str = "👍") -> Tuple[bool, Dict]:
    if _sm_api_env("VK_USE_API", default="1").lower() in {"0", "false", "no"}:
        return False, {"status": "api_disabled", "engine": "vk_api"}

    def _run():
        api = _sm_vk_get_api()
        if api is None:
            return False, {"status": "api_unavailable", "engine": "vk_api"}
        act = (action or "").lower().strip()
        info = _sm_vk_parse_target(target_url)
        meta = {"platform": "vk", "engine": "vk_api", "url": target_url, "parsed": info}
        try:
            if act in {"subscribe", "follow", "join"}:
                screen = info.get("screen_name")
                if not screen:
                    return False, {**meta, "status": "no_screen_name"}
                # resolve
                resolved = api.utils.resolveScreenName(screen_name=screen)
                obj_type = resolved.get("type")
                obj_id = int(resolved.get("object_id") or 0)
                if obj_type in {"group", "page"}:
                    api.groups.join(group_id=obj_id)
                    return True, {**meta, "status": "done", "action": "subscribe", "group_id": obj_id}
                if obj_type == "user":
                    api.friends.add(user_id=obj_id)
                    return True, {**meta, "status": "done", "action": "subscribe", "user_id": obj_id}
                return False, {**meta, "status": "unsupported_vk_object", "type": obj_type}
            if act == "like" and info.get("type") == "wall":
                api.likes.add(type="post", owner_id=info["owner_id"], item_id=info["post_id"])
                return True, {**meta, "status": "done", "action": "like"}
            if act == "comment" and info.get("type") == "wall":
                text = (comment_text or "👍").strip() or "👍"
                api.wall.createComment(owner_id=info["owner_id"], post_id=info["post_id"], message=text)
                return True, {**meta, "status": "done", "action": "comment"}
            if act == "repost" and info.get("type") == "wall":
                obj = f"wall{info['owner_id']}_{info['post_id']}"
                api.wall.repost(object=obj)
                return True, {**meta, "status": "done", "action": "repost"}
            return False, {**meta, "status": "api_unsupported_action", "action": act}
        except Exception as e:
            return False, {**meta, "status": "api_error", "error": str(e)[:300]}

    return await asyncio.to_thread(_run)


# ---------------------------------------------------------------------
# Twitter/X — twikit
# ---------------------------------------------------------------------
_TWIKIT_CLIENT = None


def _sm_twikit_client():
    global _TWIKIT_CLIENT
    if _TWIKIT_CLIENT is not None:
        return _TWIKIT_CLIENT
    try:
        from twikit import Client as TwikitClient
    except ImportError:
        logger.warning("twikit not installed")
        return None
    try:
        cl = TwikitClient("en-US")
        cookies_file = _sm_api_env("TWITTER_COOKIES_PATH", "X_COOKIES_PATH", default="/root/sessions/twitter_twikit.json")
        auth_info = Path(cookies_file)
        user = _sm_api_env("TWITTER_USERNAME", "X_USERNAME")
        email = _sm_api_env("TWITTER_EMAIL", "X_EMAIL")
        password = _sm_api_env("TWITTER_PASSWORD", "X_PASSWORD")
        # load cookies if present
        if auth_info.exists():
            try:
                cl.load_cookies(str(auth_info))
                _TWIKIT_CLIENT = cl
                logger.info("✅ twikit cookies loaded")
                return cl
            except Exception as e:
                logger.warning("twikit load_cookies: %s", e)
        if user and password:
            # login is async in newer twikit — handle sync wrapper outside
            _TWIKIT_CLIENT = (cl, user, email, password, str(auth_info))
            return _TWIKIT_CLIENT
        return None
    except Exception as e:
        logger.warning("twikit init: %s", e)
        return None


async def _sm_twitter_api_action(action: str, target_url: str, comment_text: str = "Nice!") -> Tuple[bool, Dict]:
    if _sm_api_env("TWITTER_USE_API", "X_USE_API", default="1").lower() in {"0", "false", "no"}:
        return False, {"status": "api_disabled", "engine": "twikit"}
    try:
        from twikit import Client as TwikitClient
    except ImportError:
        return False, {"status": "api_unavailable", "engine": "twikit"}

    act = (action or "").lower().strip()
    url = (target_url or "").strip()
    meta = {"platform": "twitter", "engine": "twikit", "url": url}

    try:
        cl = TwikitClient("en-US")
        cookies_file = _sm_api_env("TWITTER_COOKIES_PATH", default="/root/sessions/twitter_twikit.json")
        if Path(cookies_file).exists():
            cl.load_cookies(cookies_file)
        else:
            user = _sm_api_env("TWITTER_USERNAME", "X_USERNAME")
            email = _sm_api_env("TWITTER_EMAIL", "X_EMAIL")
            password = _sm_api_env("TWITTER_PASSWORD", "X_PASSWORD")
            if not (user and password):
                return False, {**meta, "status": "api_unavailable", "reason": "no_cookies_or_login"}
            await cl.login(auth_info_1=user, auth_info_2=email or user, password=password)
            try:
                Path(cookies_file).parent.mkdir(parents=True, exist_ok=True)
                cl.save_cookies(cookies_file)
            except Exception:
                pass

        # tweet id
        m = re.search(r"/status/(\d+)", url)
        tweet_id = m.group(1) if m else ""
        # username
        m2 = re.search(r"(?:x|twitter)\.com/([A-Za-z0-9_]+)", url)
        screen = m2.group(1) if m2 else ""
        if screen.lower() in {"home", "explore", "i", "search", "settings"}:
            screen = ""

        if act in {"subscribe", "follow"} and screen:
            user = await cl.get_user_by_screen_name(screen)
            await user.follow()
            return True, {**meta, "status": "done", "action": "subscribe", "username": screen}
        if act == "like" and tweet_id:
            tweet = await cl.get_tweet_by_id(tweet_id)
            await tweet.favorite()
            return True, {**meta, "status": "done", "action": "like", "tweet_id": tweet_id}
        if act == "repost" and tweet_id:
            tweet = await cl.get_tweet_by_id(tweet_id)
            await tweet.retweet()
            return True, {**meta, "status": "done", "action": "repost", "tweet_id": tweet_id}
        if act == "comment" and tweet_id:
            text = (comment_text or "Nice!").strip() or "Nice!"
            await cl.create_tweet(text=text, reply_to=tweet_id)
            return True, {**meta, "status": "done", "action": "comment", "tweet_id": tweet_id}
        return False, {**meta, "status": "api_unsupported_action", "action": act}
    except Exception as e:
        return False, {**meta, "status": "api_error", "error": str(e)[:300]}


# ---------------------------------------------------------------------
# TikTok — optional unofficial helpers (TiktokAutoUploader / session)
# ---------------------------------------------------------------------
async def _sm_tiktok_api_action(action: str, target_url: str, comment_text: str = "🔥") -> Tuple[bool, Dict]:
    """Best-effort TikTok API path. Falls back quickly if package/session missing."""
    if _sm_api_env("TT_USE_API", default="1").lower() in {"0", "false", "no"}:
        return False, {"status": "api_disabled", "engine": "tiktok_api"}
    meta = {"platform": "tiktok", "engine": "tiktok_api", "url": target_url}
    act = (action or "").lower().strip()

    # Try tiktok_uploader / TiktokAutoUploader style session if installed
    try:
        # Placeholder soft path: many packages differ; document env session
        sessionid = _sm_api_env("TIKTOK_SESSIONID", "TT_SESSIONID")
        if not sessionid:
            cookies = _sm_load_json_cookies(_sm_api_env("TIKTOK_COOKIES_PATH", default="/root/sessions/tiktok.json"))
            sessionid = _sm_cookie_value(cookies, "sessionid")
        if not sessionid:
            return False, {**meta, "status": "api_unavailable", "reason": "no_sessionid"}

        # Minimal private API-ish requests (fragile; browser remains primary)
        import httpx

        def _run():
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121.0.0.0 Safari/537.36",
                "Referer": "https://www.tiktok.com/",
                "Cookie": f"sessionid={sessionid}",
            }
            proxy = _sm_api_proxy() or None
            # Without stable private endpoints, we only probe session validity
            with httpx.Client(timeout=20, proxy=proxy, headers=headers, follow_redirects=True) as client:
                r = client.get("https://www.tiktok.com/")
                if r.status_code >= 400:
                    return False, {**meta, "status": "api_session_invalid", "http": r.status_code}
            # Full like/follow needs official/private signed APIs — mark for browser
            return False, {**meta, "status": "api_partial_session_ok_use_browser", "action": act}

        return await asyncio.to_thread(_run)
    except Exception as e:
        return False, {**meta, "status": "api_error", "error": str(e)[:300]}


# ---------------------------------------------------------------------
# Ozon Seller API
# ---------------------------------------------------------------------
async def _sm_ozon_api_action(action: str, target_url: str, **kwargs) -> Tuple[bool, Dict]:
    if _sm_api_env("OZON_USE_API", default="1").lower() in {"0", "false", "no"}:
        return False, {"status": "api_disabled", "engine": "ozon_seller"}
    client_id = _sm_api_env("OZON_CLIENT_ID", "OZON_CLIENTID")
    api_key = _sm_api_env("OZON_API_KEY", "OZON_APIKEY")
    meta = {"platform": "ozon", "engine": "ozon_seller", "url": target_url}
    if not (client_id and api_key):
        return False, {**meta, "status": "api_unavailable", "reason": "missing_OZON_CLIENT_ID_or_OZON_API_KEY"}

    def _run():
        import httpx
        headers = {
            "Client-Id": client_id,
            "Api-Key": api_key,
            "Content-Type": "application/json",
        }
        base = _sm_api_env("OZON_API_BASE", default="https://api-seller.ozon.ru")
        try:
            with httpx.Client(timeout=30, headers=headers) as client:
                # Health / roles probe
                r = client.post(f"{base}/v1/roles", json={})
                if r.status_code in (200, 201):
                    return True, {**meta, "status": "done", "action": action or "view", "http": r.status_code, "note": "seller_api_reachable"}
                return False, {**meta, "status": "api_error", "http": r.status_code, "body": r.text[:200]}
        except Exception as e:
            return False, {**meta, "status": "api_error", "error": str(e)[:300]}

    return await asyncio.to_thread(_run)


# ---------------------------------------------------------------------
# MAX Bot API (HTTP)
# ---------------------------------------------------------------------
async def _sm_max_api_action(action: str, target_url: str, comment_text: str = "") -> Tuple[bool, Dict]:
    if _sm_api_env("MAX_USE_API", default="1").lower() in {"0", "false", "no"}:
        return False, {"status": "api_disabled", "engine": "max_bot_api"}
    token = _sm_api_env("MAX_BOT_TOKEN", "MAX_TOKEN", "MAX_API_TOKEN")
    base = _sm_api_env("MAX_API_BASE", default="https://botapi.max.ru")
    meta = {"platform": "max", "engine": "max_bot_api", "url": target_url}
    if not token:
        return False, {**meta, "status": "api_unavailable", "reason": "missing_MAX_BOT_TOKEN"}

    def _run():
        import httpx
        headers = {"Authorization": token, "Content-Type": "application/json"}
        try:
            with httpx.Client(timeout=25, headers=headers) as client:
                # Probe me/getMe style endpoints (MAX API shapes vary)
                for path in ("/me", "/bot/me", "/v1/me"):
                    try:
                        r = client.get(f"{base}{path}")
                        if r.status_code == 200:
                            return True, {**meta, "status": "done", "action": action or "view", "probe": path}
                    except Exception:
                        continue
                # channel join often not available to bots — soft fail to browser
                return False, {**meta, "status": "api_partial_use_browser", "action": action}
        except Exception as e:
            return False, {**meta, "status": "api_error", "error": str(e)[:300]}

    return await asyncio.to_thread(_run)


# ---------------------------------------------------------------------
# Avito API
# ---------------------------------------------------------------------
async def _sm_avito_api_action(action: str, target_url: str, **kwargs) -> Tuple[bool, Dict]:
    if _sm_api_env("AVITO_USE_API", default="1").lower() in {"0", "false", "no"}:
        return False, {"status": "api_disabled", "engine": "avito_api"}
    client_id = _sm_api_env("AVITO_CLIENT_ID")
    client_secret = _sm_api_env("AVITO_CLIENT_SECRET")
    token = _sm_api_env("AVITO_ACCESS_TOKEN")
    meta = {"platform": "avito", "engine": "avito_api", "url": target_url}

    def _run():
        import httpx
        try:
            with httpx.Client(timeout=30) as client:
                access = token
                if not access and client_id and client_secret:
                    r = client.post(
                        "https://api.avito.ru/token",
                        data={
                            "grant_type": "client_credentials",
                            "client_id": client_id,
                            "client_secret": client_secret,
                        },
                    )
                    if r.status_code == 200:
                        access = (r.json() or {}).get("access_token") or ""
                if not access:
                    return False, {**meta, "status": "api_unavailable", "reason": "missing_token"}
                headers = {"Authorization": f"Bearer {access}"}
                # self probe
                r2 = client.get("https://api.avito.ru/core/v1/accounts/self", headers=headers)
                if r2.status_code == 200:
                    return True, {**meta, "status": "done", "action": action or "view", "account": (r2.json() or {})}
                return False, {**meta, "status": "api_error", "http": r2.status_code, "body": r2.text[:200]}
        except Exception as e:
            return False, {**meta, "status": "api_error", "error": str(e)[:300]}

    return await asyncio.to_thread(_run)


# ---------------------------------------------------------------------
# Ozon Skill (new platform registration — additive)
# ---------------------------------------------------------------------
class OzonSkill(BaseSkill):
    """Ozon Seller API skill — additive platform."""

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs) -> Tuple[bool, Dict]:
        ok, data = await _sm_ozon_api_action(action, target_url, **kwargs)
        if ok:
            return True, data
        # soft browser fallback if page given
        if page is not None and target_url:
            try:
                await page.goto(target_url, timeout=45000, wait_until="domcontentloaded")
                await self._human_delay(2, 4)
                ss = None
                if hasattr(self, "_capture_screenshot"):
                    ss = await self._capture_screenshot(page, "ozon_view")
                return True, {"status": "done", "action": action or "view", "screenshot_path": ss, "engine": "browser_fallback"}
            except Exception as e:
                return False, {"status": "execution_failed", "error": str(e)[:300], "api": data}
        return False, data


# Register Ozon without touching SkillManager.__init__ body: patch after class defined
try:
    _sm_orig_register = SkillManager.register_skill

    def _sm_register_skill_with_ozon(self, name: str, skill_instance):
        return _sm_orig_register(self, name, skill_instance)

    # After any SkillManager is constructed, ensure ozon exists
    _sm_orig_init = SkillManager.__init__

    def _sm_init_with_api_platforms(self, *args, **kwargs):
        _sm_orig_init(self, *args, **kwargs)
        try:
            if "ozon" not in self.skills:
                self.register_skill("ozon", OzonSkill())
                logger.info("⚙️ تم تفعيل مهارة المنصة: OZON (API layer)")
            extras = globals().get("SkillManager")
            mapping = getattr(extras, "_V8_EXTRA", None) or {}
            for key, cls in mapping.items():
                if key not in self.skills and callable(cls):
                    try:
                        self.register_skill(key, cls())
                    except Exception:
                        pass
        except Exception as e:
            logger.warning("Ozon register failed: %s", e)

    SkillManager.__init__ = _sm_init_with_api_platforms
except Exception as e:
    logger.warning("Ozon SkillManager patch failed: %s", e)


# ---------------------------------------------------------------------
# Wrap existing skills: API first → original execute_task (unchanged body)
# ---------------------------------------------------------------------

def _sm_wrap_api_first(cls, api_coro_factory, platform_name: str):
    """Replace cls.execute_task with wrapper that calls API then original."""
    original = cls.execute_task
    if getattr(original, "_sm_api_v3_wrapped", False):
        return

    async def wrapped(self, action: str, target_url: str, page=None, **kwargs):
        kwargs = dict(kwargs or {})
        comment_text = kwargs.pop("comment_text", None) or kwargs.pop("text", None) or "🔥"
        kwargs.pop("comment_text", None)
        try:
            ok, data = await api_coro_factory(
                action, target_url, comment_text=comment_text, **kwargs
            )
            if ok:
                logger.info("✅ %s API success: %s %s", platform_name, action, data.get("status"))
                # optional screenshot proof if page present
                if page is not None and not data.get("screenshot_path"):
                    try:
                        await page.goto(target_url, timeout=40000, wait_until="domcontentloaded")
                        await asyncio.sleep(random.uniform(1.5, 3.0))
                        if hasattr(self, "_capture_screenshot"):
                            data["screenshot_path"] = await self._capture_screenshot(page, f"{platform_name}_api_{action}")
                    except Exception:
                        pass
                return True, data
            logger.info(
                "↪️ %s API skip/fail (%s) → original skill",
                platform_name,
                (data or {}).get("status"),
            )
        except Exception as e:
            logger.warning("%s API wrapper error: %s → original", platform_name, e)
        return await original(
            self, action, target_url, page=page, comment_text=comment_text, **kwargs
        )

    wrapped._sm_api_v3_wrapped = True
    wrapped.__name__ = getattr(original, "__name__", "execute_task")
    wrapped.__qualname__ = getattr(original, "__qualname__", "execute_task")
    wrapped.__doc__ = (getattr(original, "__doc__", None) or "") + " [api-layer-v3 wrapper]"
    cls.execute_task = wrapped


# Factories matching signature (action, url, comment_text=..., **kwargs)
async def _fac_ig(action, target_url, comment_text="🔥", **kwargs):
    return await _sm_ig_api_action(action, target_url, comment_text=comment_text)


async def _fac_vk(action, target_url, comment_text="👍", **kwargs):
    return await _sm_vk_api_action(action, target_url, comment_text=comment_text)


async def _fac_tw(action, target_url, comment_text="Nice!", **kwargs):
    return await _sm_twitter_api_action(action, target_url, comment_text=comment_text)


async def _fac_tt(action, target_url, comment_text="🔥", **kwargs):
    return await _sm_tiktok_api_action(action, target_url, comment_text=comment_text)


async def _fac_max(action, target_url, comment_text="", **kwargs):
    return await _sm_max_api_action(action, target_url, comment_text=comment_text)


async def _fac_avito(action, target_url, comment_text="", **kwargs):
    return await _sm_avito_api_action(action, target_url, **kwargs)


try:
    _sm_wrap_api_first(InstagramSkill, _fac_ig, "instagram")
    _sm_wrap_api_first(VKSkill, _fac_vk, "vk")
    _sm_wrap_api_first(TwitterSkill, _fac_tw, "twitter")
    _sm_wrap_api_first(TikTokSkill, _fac_tt, "tiktok")
    _sm_wrap_api_first(MaxSkill, _fac_max, "max")
    _sm_wrap_api_first(AvitoSkill, _fac_avito, "avito")
    logger.info(
        "🚀 %s active: instagrapi | vk_api | twikit | tiktok_session | ozon | max | avito",
        SM_API_LAYER_VERSION,
    )
except Exception as e:
    logger.exception("API layer wrap failed: %s", e)


# Capabilities hint (additive — does not remove existing)
try:
    SKILL_CAPABILITIES.setdefault("ozon", {"view", "register"})
except Exception:
    pass



# ==========================================================
# SKILL_SESSIONS_AUDIT_V1 + UNIFIED EXTERNAL COOKIES LOADER
# Additive only — لا يمس أجسام الدوال الأصلية
# ==========================================================

SKILL_SESSIONS_AUDIT_V1 = "skill-sessions-audit-v1"

# مسارات الكوكيز الخارجية الموصى بها (ملف لكل منصة)
SKILL_EXTERNAL_COOKIE_PATHS = {
    "telegram": [
        "/root/sessions/telegram.json",
        "/root/sessions/telegram_web.json",
        os.getenv("TELEGRAM_WEB_COOKIES_FILE", "") or "",
    ],
    "vk": [
        "/root/sessions/vk.json",
        os.getenv("VK_COOKIES_FILE", "") or "",
    ],
    "tiktok": [
        "/root/sessions/tiktok.json",
        os.getenv("TIKTOK_COOKIES_FILE", "") or "",
    ],
    "instagram": [
        "/root/sessions/instagram.json",
        os.getenv("INSTAGRAM_COOKIES_FILE", "") or "",
    ],
    "youtube": [
        "/root/sessions/youtube.json",
        os.getenv("YOUTUBE_COOKIES_FILE", "") or "",
    ],
    "rutube": [
        "/root/sessions/rutube.json",
        os.getenv("RUTUBE_COOKIES_FILE", "") or "",
    ],
    "max": [
        "/root/sessions/max.json",
        os.getenv("MAX_COOKIES_FILE", "") or "",
    ],
    "twitter": [
        "/root/sessions/twitter.json",
        "/root/sessions/x.json",
        os.getenv("TWITTER_COOKIES_FILE", "") or "",
        os.getenv("X_COOKIES_FILE", "") or "",
    ],
    "x": [
        "/root/sessions/x.json",
        "/root/sessions/twitter.json",
        os.getenv("X_COOKIES_FILE", "") or "",
    ],
    "facebook": [
        "/root/sessions/facebook.json",
        os.getenv("FACEBOOK_COOKIES_FILE", "") or "",
    ],
    "avito": [
        "/root/sessions/avito.json",
        os.getenv("AVITO_COOKIES_FILE", "") or "",
    ],
    "google_maps": [
        "/root/sessions/google_maps.json",
        os.getenv("GOOGLE_MAPS_COOKIES_FILE", "") or "",
    ],
    "yandex": [
        "/root/sessions/yandex.json",
        os.getenv("YANDEX_COOKIES_FILE", "") or "",
    ],
    "ok": ["/root/sessions/ok.json"],
    "likee": ["/root/sessions/likee.json"],
    "linkedin": ["/root/sessions/linkedin.json"],
    "discord": ["/root/sessions/discord.json"],
    "reddit": ["/root/sessions/reddit.json"],
}


def _skill_load_cookie_file(path: str) -> list:
    path = (path or "").strip()
    if not path:
        return []
    try:
        pth = Path(path).expanduser()
        if not pth.is_file():
            return []
        raw = json.loads(pth.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            raw = raw.get("cookies") or raw.get("Cookie") or []
        if not isinstance(raw, list):
            return []
        return [c for c in raw if isinstance(c, dict) and c.get("name")]
    except Exception as error:
        logger.warning("cookie file load failed %s: %s", path, error)
        return []


def _skill_first_external_cookies(platform: str) -> tuple:
    """يرجع (path, cookies_list) لأول ملف موجود."""
    paths = SKILL_EXTERNAL_COOKIE_PATHS.get(platform) or []
    for path in paths:
        cookies = _skill_load_cookie_file(path)
        if cookies:
            return path, cookies
    return "", []


def skill_sessions_inventory() -> dict:
    """
    تقرير شامل: إيه الجلسات/الكوكيز الموجودة جوّا الكود وإيه الناقص.
    لا يطبع أسرار — أعداد + أسماء فقط.
    """
    report = {
        "layer": SKILL_SESSIONS_AUDIT_V1,
        "platforms": {},
        "telethon": {},
        "missing_files": [],
        "recommendations": [],
    }

    # --- Telethon (API session string من config) ---
    try:
        from config import BOT_CONFIG  # type: ignore
        sess = getattr(BOT_CONFIG, "TELEGRAM_SESSION", None) or getattr(BOT_CONFIG, "SESSION_STRING", None) or ""
        api_id = getattr(BOT_CONFIG, "API_ID", None) or getattr(BOT_CONFIG, "TELEGRAM_API_ID", None)
        api_hash = getattr(BOT_CONFIG, "API_HASH", None) or getattr(BOT_CONFIG, "TELEGRAM_API_HASH", None)
        report["telethon"] = {
            "session_string_present": bool(sess and len(str(sess)) > 20),
            "api_id_present": bool(api_id),
            "api_hash_present": bool(api_hash),
            "note": "TelegramSkill يعتمد على Telethon StringSession + كوكيز Web منفصلة للإثبات",
        }
        if not sess:
            report["recommendations"].append("أضف TELEGRAM_SESSION / StringSession في config — بدونها اشتراك القنوات/الجروبات عبر API يفشل")
        if not api_id or not api_hash:
            report["recommendations"].append("أضف API_ID + API_HASH من my.telegram.org")
    except Exception as error:
        report["telethon"] = {"error": str(error)[:120]}

    # --- Embedded class cookies ---
    embedded_map = {
        "telegram_web": ("TelegramSkill", "TELEGRAM_WEB_COOKIES"),
        "vk": ("VKSkill", "VK_COOKIES"),
        "tiktok": ("TikTokSkill", "TIKTOK_COOKIES"),
        "youtube": ("YouTubeSkill", "YOUTUBE_COOKIES"),
        "instagram": ("InstagramSkill", "INSTAGRAM_COOKIES"),
        "rutube": ("RutubeSkill", "RUTUBE_COOKIES"),
        "max": ("MaxSkill", "MAX_COOKIES"),
    }
    for key, (cls_name, attr) in embedded_map.items():
        cls = globals().get(cls_name)
        names = []
        count = 0
        if cls is not None:
            raw = getattr(cls, attr, None) or []
            if isinstance(raw, list):
                count = len(raw)
                names = [str(c.get("name")) for c in raw if isinstance(c, dict)][:15]
        path, external = _skill_first_external_cookies(key if key != "telegram_web" else "telegram")
        report["platforms"][key] = {
            "embedded_count": count,
            "embedded_names_sample": names,
            "external_file": path or None,
            "external_count": len(external),
            "status": (
                "ok_embedded" if count >= 3
                else "weak_embedded" if count > 0
                else "missing_embedded"
            ),
        }
        if count == 0 and not external:
            report["missing_files"].append(f"/root/sessions/{key.replace('telegram_web','telegram')}.json")
            report["recommendations"].append(
                f"{key}: لا يوجد كوكيز كافية — صدّر من المتصفح إلى /root/sessions/ وحدّث الملف"
            )

    # platforms without embedded block
    for plat in ("twitter", "facebook", "avito", "google_maps", "yandex", "ok", "likee", "linkedin", "discord", "reddit"):
        path, external = _skill_first_external_cookies(plat)
        report["platforms"][plat] = {
            "embedded_count": 0,
            "external_file": path or None,
            "external_count": len(external),
            "status": "ok_external" if external else "missing",
        }
        if not external:
            report["missing_files"].append(f"/root/sessions/{plat}.json")
            report["recommendations"].append(
                f"{plat}: مفيش كوكيز جوّا الكود ولا ملف خارجي — أنشئ /root/sessions/{plat}.json"
            )

    # critical cookie names expected
    report["critical_cookie_names"] = {
        "instagram": ["sessionid", "ds_user_id", "csrftoken"],
        "tiktok": ["sessionid", "sid_tt", "uid_tt", "tt_chain_token"],
        "vk": ["remixsid", "remixstlid", "remixnsid"],
        "youtube": ["SID", "HSID", "SSID", "__Secure-1PSID"],
        "twitter": ["auth_token", "ct0"],
        "telegram_web": ["stel_ssid", "stel_token", "stel_acid"],
        "max": ["token", "access_token", "auth"],
        "rutube": ["session_id", "jwt", "csrf"],
    }

    return report


async def skill_inject_external_cookies(context, platform: str, default_domain: str = "") -> dict:
    """حقن كوكيز من ملف خارجي في BrowserContext — بدون لمس دوال المهارة."""
    result = {"ok": False, "path": "", "count": 0, "platform": platform}
    path, cookies = _skill_first_external_cookies(platform)
    if not cookies or context is None:
        return result
    domain = default_domain or {
        "telegram": ".telegram.org",
        "vk": ".vk.com",
        "tiktok": ".tiktok.com",
        "instagram": ".instagram.com",
        "youtube": ".youtube.com",
        "rutube": ".rutube.ru",
        "max": ".max.ru",
        "twitter": ".x.com",
        "x": ".x.com",
        "facebook": ".facebook.com",
        "avito": ".avito.ru",
        "yandex": ".yandex.ru",
        "google_maps": ".google.com",
        "ok": ".ok.ru",
        "likee": ".likee.video",
        "linkedin": ".linkedin.com",
    }.get(platform, "")
    try:
        # استخدم formatter من BaseSkill لو متاح
        formatter = getattr(BaseSkill, "_format_playwright_cookies", None)
        if formatter:
            # static unbound — نحتاج instance وهمي
            class _Tmp(BaseSkill):
                def __init__(self):
                    pass
            tmp = _Tmp()
            formatted = await tmp._format_playwright_cookies(cookies, domain)
        else:
            formatted = []
            for item in cookies:
                c = {
                    "name": item.get("name"),
                    "value": str(item.get("value") or ""),
                    "domain": item.get("domain") or domain,
                    "path": item.get("path") or "/",
                    "secure": bool(item.get("secure", True)),
                    "httpOnly": bool(item.get("httpOnly", False)),
                }
                if item.get("expirationDate") or item.get("expires"):
                    try:
                        c["expires"] = float(item.get("expirationDate") or item.get("expires"))
                    except Exception:
                        pass
                formatted.append(c)
        if formatted:
            await context.add_cookies(formatted)
            result.update({"ok": True, "path": path, "count": len(formatted)})
            logger.info("✅ external cookies injected platform=%s count=%s file=%s", platform, len(formatted), path)
    except Exception as error:
        logger.warning("inject external cookies failed: %s", error)
        result["error"] = str(error)[:160]
    return result


# اربط على SkillManager كـ methods إضافية
def _sm_sessions_inventory(self) -> dict:
    return skill_sessions_inventory()


async def _sm_inject_cookies(self, context, platform: str, default_domain: str = "") -> dict:
    return await skill_inject_external_cookies(context, platform, default_domain)


SkillManager.sessions_inventory = _sm_sessions_inventory
SkillManager.inject_external_cookies = _sm_inject_cookies

# لوج مختصر عند الاستيراد
try:
    _inv = skill_sessions_inventory()
    _miss = [k for k, v in _inv.get("platforms", {}).items() if v.get("status") in ("missing", "missing_embedded", "weak_embedded")]
    logger.info(
        "🔧 %s | platforms_checked=%s weak_or_missing=%s",
        SKILL_SESSIONS_AUDIT_V1,
        len(_inv.get("platforms") or {}),
        _miss[:12],
    )
except Exception as _e:
    logger.debug("sessions inventory boot: %s", _e)



# ==========================================================
# SKILL_COOKIE_EXPORT_GUIDE_V2 — أدوات + دليل تصدير الجلسات
# Additive only
# ==========================================================

SKILL_COOKIE_EXPORT_GUIDE_V2 = "skill-cookie-export-guide-v2"

# نطاقات Playwright الموصى بها لكل منصة عند الحقن
SKILL_PLATFORM_DOMAINS = {
    "telegram": [".telegram.org", "web.telegram.org", ".web.telegram.org"],
    "vk": [".vk.com", ".vk.ru", "m.vk.com", "m.vk.ru", ".vk.me"],
    "tiktok": [".tiktok.com", "www.tiktok.com"],
    "instagram": [".instagram.com", "www.instagram.com"],
    "youtube": [".youtube.com", ".google.com", "accounts.google.com"],
    "rutube": [".rutube.ru", "rutube.ru"],
    "max": [".max.ru", "max.ru", "web.max.ru"],
    "twitter": [".x.com", ".twitter.com", "x.com", "twitter.com"],
    "x": [".x.com", ".twitter.com"],
    "facebook": [".facebook.com", "www.facebook.com"],
    "avito": [".avito.ru", "www.avito.ru", "m.avito.ru"],
    "google_maps": [".google.com", "maps.google.com", ".google.ru"],
    "yandex": [".yandex.ru", ".yandex.com", "maps.yandex.ru"],
    "ok": [".ok.ru", "ok.ru"],
    "likee": [".likee.video", "likee.com"],
    "linkedin": [".linkedin.com"],
    "discord": [".discord.com"],
    "reddit": [".reddit.com"],
}


def skill_cookie_export_guide() -> dict:
    """
    دليل عملي: منين وبإيه تجيب كل جلسة/كوكيز ناقصة.
    يُرجع dict جاهز للطباعة أو إرسال تيليجرام.
    """
    return {
        "title": "دليل تصدير الجلسات والكوكيز — UNU Skill Manager",
        "general_steps_ar": [
            "1) افتح Chrome/Edge على نفس الحساب اللي هتنفّذ بيه المهام.",
            "2) سجّل دخول يدوي للمنصة (VK / TikTok / Instagram / …) وتأكد إن الصفحة شغّالة.",
            "3) ثبّت إضافة تصدير كوكيز مثل: Cookie-Editor أو EditThisCookie أو Get cookies.txt LOCALLY.",
            "4) صدّر الكوكيز بصيغة JSON (مصفوفة objects فيها name/value/domain/path/…).",
            "5) احفظ الملف في المسار: /root/sessions/<platform>.json",
            "6) على السيرفر/GitHub Actions: ارفع الملف كـ Secret أو commit في /root/sessions/ (يفضّل Secret).",
            "7) أعد تشغيل البوت — الطبقة SKILL_SESSIONS_AUDIT هتحقن الملف تلقائيًا إن وُجد.",
        ],
        "platforms": {
            "telegram_api": {
                "what": "Telethon StringSession + API_ID + API_HASH",
                "how": [
                    "ادخل https://my.telegram.org → API development tools → خذ api_id و api_hash",
                    "شغّل سكربت توليد جلسة مرة واحدة محليًا (Telethon client.start) واحفظ StringSession",
                    "ضع القيم في config / env: TELEGRAM_API_ID, TELEGRAM_API_HASH, TELEGRAM_SESSION",
                ],
                "file": "config أو env — مش ملف cookies",
            },
            "telegram_web": {
                "what": "كوكيز web.telegram.org للإثبات بالسكرين",
                "url": "https://web.telegram.org/k/",
                "critical": ["stel_ssid", "stel_token", "stel_acid", "stel_dsn"],
                "file": "/root/sessions/telegram.json",
                "how": [
                    "افتح web.telegram.org وسجّل بنفس رقم الحساب",
                    "بعد ما الشات يفتح بالكامل صدّر كل كوكيز نطاق .telegram.org",
                    "احفظ JSON في /root/sessions/telegram.json",
                ],
            },
            "vk": {
                "url": "https://m.vk.ru/ أو https://vk.com",
                "critical": ["remixsid", "remixnsid", "remixstid", "remixlu"],
                "file": "/root/sessions/vk.json",
                "how": [
                    "سجّل دخول VK من نفس بروكسي/دولة الحساب إن أمكن",
                    "تأكد إن الخلاصة (feed) بتفتح من غير صفحة login",
                    "صدّر كوكيز .vk.com و .vk.ru كلها",
                ],
            },
            "tiktok": {
                "url": "https://www.tiktok.com",
                "critical": ["sessionid", "sid_tt", "uid_tt", "tt_chain_token", "msToken"],
                "file": "/root/sessions/tiktok.json",
                "how": [
                    "سجّل دخول TikTok Web (مش التطبيق فقط)",
                    "افتح بروفايلك وفيديو واحد للتأكد",
                    "صدّر كوكيز .tiktok.com — خصوصًا sessionid",
                    "تنبيه: GitHub datacenter IP غالبًا يبوّظ الفيديو؛ بروكسي سكني أفضل",
                ],
            },
            "instagram": {
                "url": "https://www.instagram.com",
                "critical": ["sessionid", "ds_user_id", "csrftoken", "mid", "ig_did"],
                "file": "/root/sessions/instagram.json",
                "how": [
                    "سجّل دخول Instagram Web",
                    "صدّر كوكيز .instagram.com",
                    "اختياري instagrapi: نفس sessionid يكفي لـ API",
                ],
            },
            "youtube": {
                "url": "https://www.youtube.com",
                "critical": ["SID", "HSID", "SSID", "__Secure-1PSID", "__Secure-3PSID", "LOGIN_INFO"],
                "file": "/root/sessions/youtube.json",
                "how": [
                    "سجّل دخول Google/YouTube",
                    "صدّر كوكيز .youtube.com و .google.com المرتبطة",
                ],
            },
            "rutube": {
                "url": "https://rutube.ru",
                "critical": ["session_id", "jwt", "csrftoken", "spid"],
                "file": "/root/sessions/rutube.json",
                "how": ["سجّل دخول Rutube Web وصدّر .rutube.ru"],
            },
            "max": {
                "url": "https://max.ru أو web.max.ru",
                "critical": ["أي cookie auth حقيقي — مش _ym_uid فقط"],
                "file": "/root/sessions/max.json",
                "how": [
                    "سجّل دخول Max Web بالكامل",
                    "لو بعد التصدير لسه login_required → الجلسة مش مكتملة؛ أعد التصدير بعد استخدام الشات",
                ],
            },
            "twitter_x": {
                "url": "https://x.com",
                "critical": ["auth_token", "ct0"],
                "file": "/root/sessions/twitter.json أو /root/sessions/x.json",
                "how": [
                    "سجّل دخول X",
                    "صدّر .x.com — لازم auth_token + ct0 معًا",
                ],
            },
            "facebook": {
                "url": "https://www.facebook.com",
                "critical": ["c_user", "xs", "fr", "datr"],
                "file": "/root/sessions/facebook.json",
            },
            "avito": {
                "url": "https://www.avito.ru",
                "critical": ["sessid", "auth", "u", "buyer_location_id"],
                "file": "/root/sessions/avito.json",
            },
            "google_maps": {
                "url": "https://maps.google.com",
                "critical": ["SID", "HSID", "__Secure-1PSID"],
                "file": "/root/sessions/google_maps.json",
            },
            "yandex": {
                "url": "https://yandex.ru",
                "critical": ["Session_id", "sessionid2", "yandexuid"],
                "file": "/root/sessions/yandex.json",
            },
            "ok": {
                "url": "https://ok.ru",
                "critical": ["authid", "session_data"],
                "file": "/root/sessions/ok.json",
            },
            "likee": {
                "url": "https://likee.video",
                "file": "/root/sessions/likee.json",
            },
            "linkedin": {
                "url": "https://www.linkedin.com",
                "critical": ["li_at", "JSESSIONID"],
                "file": "/root/sessions/linkedin.json",
            },
        },
        "github_actions_tips": [
            "لا ترفع كوكيز في repo عام — استخدم GitHub Secrets أو artifact مشفّر",
            "مثال: Secret اسمه VK_COOKIES_JSON ومحتواه نص الملف كامل، وفي workflow اكتبه إلى /root/sessions/vk.json قبل التشغيل",
            "بروكسي روسي سكني يرفع نجاح VK/TikTok عن IP جيت هب",
        ],
        "validation": [
            "بعد الحفظ شغّل: SkillManager().sessions_inventory()",
            "أو من الكود: from skill_manager import skill_sessions_inventory; print(skill_sessions_inventory())",
            "status=ok_external أو ok_embedded يعني جاهز شكليًا — النجاح الحقيقي يتأكد بتنفيذ لايك/فولو تجريبي",
        ],
    }


def skill_sessions_inventory_text() -> str:
    """نص عربي مختصر جاهز للإرسال على تيليجرام."""
    inv = skill_sessions_inventory()
    guide = skill_cookie_export_guide()
    lines = ["📋 تقرير الجلسات والكوكيز", ""]
    for plat, info in (inv.get("platforms") or {}).items():
        st = info.get("status")
        emb = info.get("embedded_count", 0)
        ext = info.get("external_count", 0)
        fpath = info.get("external_file") or "-"
        mark = "✅" if st in ("ok_embedded", "ok_external") else ("⚠️" if "weak" in str(st) else "❌")
        lines.append(f"{mark} {plat}: embedded={emb} external={ext} file={fpath}")
    tel = inv.get("telethon") or {}
    lines.append("")
    lines.append(
        f"Telethon session={'✅' if tel.get('session_string_present') else '❌'} "
        f"api_id={'✅' if tel.get('api_id_present') else '❌'} "
        f"api_hash={'✅' if tel.get('api_hash_present') else '❌'}"
    )
    miss = inv.get("missing_files") or []
    if miss:
        lines.append("")
        lines.append("📁 ملفات ناقصة:")
        for m in miss[:30]:
            lines.append(f"  - {m}")
    rec = inv.get("recommendations") or []
    if rec:
        lines.append("")
        lines.append("💡 توصيات:")
        for r in rec[:20]:
            lines.append(f"  • {r}")
    lines.append("")
    lines.append("📖 خطوات عامة:")
    for step in (guide.get("general_steps_ar") or [])[:8]:
        lines.append(f"  {step}")
    return "\n".join(lines)


async def skill_ensure_platform_cookies(context, platform: str) -> dict:
    """
    يحاول بالترتيب:
    1) ملف خارجي data/cookies
    2) (لا يمس الكوكيز المدمجة — المهارة الأصلية تحقنها لوحدها)
    """
    platform = (platform or "").lower().strip()
    if platform == "twitter":
        platform = "x" if not _skill_first_external_cookies("twitter")[1] else "twitter"
    result = await skill_inject_external_cookies(
        context,
        platform,
        default_domain=(SKILL_PLATFORM_DOMAINS.get(platform) or [""])[0],
    )
    # جرّب alias x/twitter
    if not result.get("ok") and platform in {"x", "twitter"}:
        alt = "twitter" if platform == "x" else "x"
        result = await skill_inject_external_cookies(
            context, alt, default_domain=".x.com"
        )
    return result


def _sm_cookie_guide(self) -> dict:
    return skill_cookie_export_guide()


def _sm_inventory_text(self) -> str:
    return skill_sessions_inventory_text()


async def _sm_ensure_cookies(self, context, platform: str) -> dict:
    return await skill_ensure_platform_cookies(context, platform)


SkillManager.cookie_export_guide = _sm_cookie_guide
SkillManager.sessions_inventory_text = _sm_inventory_text
SkillManager.ensure_platform_cookies = _sm_ensure_cookies

logger.info("🔧 %s loaded", SKILL_COOKIE_EXPORT_GUIDE_V2)



# ==========================================================
# EXECUTION_ENGINE_V3 — محرك تنفيذ متعدد الاستراتيجيات
# لايك / فولو / كومنت / ريبوست / مشاهدة — بدون مسح دوال
# يغلّف execute_task للمهارات ويضيف محاولات احترافية
# ==========================================================

EXECUTION_ENGINE_V3 = "execution-engine-v3"

# --- مكتبات محددات متعددة لكل منصة/فعل ---
EXEC_SELECTORS = {
    "tiktok": {
        "subscribe": [
            '[data-e2e="follow-button"]',
            'button[data-e2e="follow-button"]',
            'button:has-text("Follow")',
            'button:has-text("Подписаться")',
            'button:has-text("متابعة")',
            'button:has-text("Follow back")',
            '[data-e2e="user-follow"]',
        ],
        "subscribe_done": [
            'button:has-text("Following")',
            'button:has-text("Подписки")',
            'button:has-text("Friends")',
            'button:has-text("متابَع")',
            '[data-e2e="follow-button"]:has-text("Following")',
        ],
        "like": [
            '[data-e2e="like-icon"]',
            '[data-e2e="browse-like-icon"]',
            'span[data-e2e="like-icon"]',
            'button[aria-label*="Like"]',
            'button[aria-label*="Нравится"]',
        ],
        "comment": [
            '[data-e2e="comment-icon"]',
            '[data-e2e="comment-input"]',
            'div[contenteditable="true"]',
            'div[data-e2e="comment-text"]',
        ],
        "repost": [
            '[data-e2e="share-icon"]',
            '[data-e2e="share-btn"]',
            'button:has-text("Repost")',
            'span:has-text("Repost")',
            'div:has-text("Репост")',
        ],
    },
    "instagram": {
        "subscribe": [
            'button:has-text("Follow")',
            'button:has-text("Подписаться")',
            'button:has-text("متابعة")',
            'button._acan._acap._acas',
            'div[role="button"]:has-text("Follow")',
        ],
        "subscribe_done": [
            'button:has-text("Following")',
            'button:has-text("Requested")',
            'button:has-text("Подписки")',
        ],
        "like": [
            'svg[aria-label="Like"]',
            'svg[aria-label="Нравится"]',
            'svg[aria-label="أعجبني"]',
            'span:has(svg[aria-label="Like"])',
            'div[role="button"] svg[aria-label="Like"]',
        ],
        "like_done": [
            'svg[aria-label="Unlike"]',
            'svg[aria-label="Не нравится"]',
            'svg[aria-label="إلغاء الإعجاب"]',
        ],
        "comment": [
            'textarea[aria-label*="comment"]',
            'textarea[placeholder*="comment"]',
            'textarea[placeholder*="Комментарий"]',
            'form textarea',
        ],
    },
    "vk": {
        "subscribe": [
            'button:has-text("Подписаться")',
            'button:has-text("Follow")',
            '.FlatButton:has-text("Подписаться")',
            '#subscribe_button',
            'a.FlatButton--primary:has-text("Подписаться")',
            '.vkuiButton:has-text("Подписаться")',
        ],
        "subscribe_done": [
            'button:has-text("Вы подписаны")',
            'button:has-text("Подписан")',
            'button:has-text("Following")',
            '.FlatButton:has-text("Вы подписаны")',
        ],
        "like": [
            '.PostButtonReactions',
            'button[data-task-click*="like"]',
            '.like_btn',
            '.PostButtonReactions__icon',
            'div[data-testid="like_button"]',
            'button:has-text("Нравится")',
        ],
        "comment": [
            '.reply_field',
            'div[contenteditable="true"].reply_field',
            'div.rich_text[contenteditable]',
            'textarea[placeholder*="комментари"]',
        ],
        "repost": [
            '.share',
            'button:has-text("Поделиться")',
            '.PostBottomAction--share',
            'div[data-testid="share_button"]',
        ],
    },
    "youtube": {
        "subscribe": [
            'button[aria-label*="Subscribe"]',
            'yt-button-shape:has-text("Subscribe")',
            'button:has-text("Subscribe")',
            'button:has-text("Подписаться")',
            '#subscribe-button button',
        ],
        "like": [
            'button[aria-label*="like this video"]',
            'button[title*="I like this"]',
            'like-button-view-model button',
            '#top-level-buttons-computed button[aria-pressed="false"]',
        ],
    },
    "twitter": {
        "subscribe": [
            '[data-testid="placementTracking"] [data-testid*="follow"]',
            'button[data-testid$="-follow"]',
            'div[role="button"]:has-text("Follow")',
            'button:has-text("Follow")',
        ],
        "like": [
            'button[data-testid="like"]',
            'div[data-testid="like"]',
            'button[aria-label*="Like"]',
        ],
        "repost": [
            'button[data-testid="retweet"]',
            'div[data-testid="retweet"]',
            'button[data-testid="retweetConfirm"]',
        ],
        "comment": [
            'button[data-testid="reply"]',
            'div[data-testid="tweetTextarea_0"]',
            'div[role="textbox"]',
        ],
    },
    "rutube": {
        "subscribe": [
            'button:has-text("Подписаться")',
            'button:has-text("Subscribe")',
            '.subscribe-button',
            'button[class*="subscribe"]',
        ],
        "like": [
            'button[class*="like"]',
            'button:has-text("Нравится")',
            '[data-testid="like"]',
        ],
    },
}


async def _exec_human_click(page, locator, timeout: float = 4000) -> bool:
    try:
        await locator.wait_for(state="visible", timeout=timeout)
        box = await locator.bounding_box()
        if box:
            x = box["x"] + box["width"] * random.uniform(0.3, 0.7)
            y = box["y"] + box["height"] * random.uniform(0.3, 0.7)
            await page.mouse.move(x, y, steps=random.randint(8, 18))
            await asyncio.sleep(random.uniform(0.08, 0.25))
            await page.mouse.down()
            await asyncio.sleep(random.uniform(0.04, 0.12))
            await page.mouse.up()
            return True
        await locator.click(timeout=timeout, delay=random.randint(40, 120))
        return True
    except Exception:
        try:
            await locator.click(timeout=timeout, force=True)
            return True
        except Exception:
            return False


async def _exec_try_selectors(page, selectors: list, timeout: float = 3500) -> tuple:
    """يجرب قائمة محددات بالترتيب. يرجع (ok, selector_used)."""
    for sel in selectors or []:
        try:
            loc = page.locator(sel).first
            if await loc.count() == 0:
                continue
            if not await loc.is_visible():
                try:
                    await loc.scroll_into_view_if_needed(timeout=1500)
                except Exception:
                    pass
            if await _exec_human_click(page, loc, timeout=timeout):
                return True, sel
        except Exception:
            continue
    return False, ""


async def _exec_js_click_text(page, texts: list) -> bool:
    """ضغط عبر JS على زر يحتوي نص معيّن."""
    try:
        return bool(
            await page.evaluate(
                """(texts) => {
                    const lower = texts.map(t => String(t).toLowerCase());
                    const nodes = Array.from(document.querySelectorAll('button, a, div[role="button"], span[role="button"]'));
                    for (const el of nodes) {
                        const t = (el.innerText || el.textContent || '').trim().toLowerCase();
                        if (!t || t.length > 40) continue;
                        if (lower.some(x => t === x || t.includes(x))) {
                            el.click();
                            return true;
                        }
                    }
                    return false;
                }""",
                list(texts),
            )
        )
    except Exception:
        return False


async def _exec_dismiss_noise(page) -> None:
    """إغلاق بوب-أب/كوكيز/تسجيل سريع بدون كسر الصفحة."""
    noise = [
        'button:has-text("Accept")',
        'button:has-text("Accept all")',
        'button:has-text("Принять")',
        'button:has-text("Согласен")',
        'button:has-text("Not now")',
        'button:has-text("Не сейчас")',
        'button:has-text("Close")',
        'button:has-text("Закрыть")',
        'button[aria-label="Close"]',
        'div[role="dialog"] button:has-text("OK")',
    ]
    for sel in noise:
        try:
            loc = page.locator(sel).first
            if await loc.count() and await loc.is_visible():
                await loc.click(timeout=1200)
                await asyncio.sleep(0.3)
        except Exception:
            pass


async def _exec_multi_strategy_action(
    page,
    platform: str,
    action: str,
    *,
    comment_text: str = "",
    max_rounds: int = 3,
) -> dict:
    """
    محرك تنفيذ متعدد:
    round = dismiss → selectors → JS text → (like: dblclick video) → verify done selectors
    """
    platform = (platform or "").lower()
    action = (action or "").lower()
    if action in {"follow", "join"}:
        action = "subscribe"
    if action in {"share"} and platform in {"twitter", "x", "vk", "tiktok"}:
        action = "repost"

    meta = {
        "engine": EXECUTION_ENGINE_V3,
        "platform": platform,
        "action": action,
        "ok": False,
        "methods_ok": [],
        "methods_fail": [],
        "status": "pending",
    }
    if page is None:
        meta["status"] = "no_page"
        return meta

    plat_map = EXEC_SELECTORS.get(platform) or EXEC_SELECTORS.get(
        "twitter" if platform == "x" else platform
    ) or {}
    sels = list(plat_map.get(action) or [])
    done_sels = list(plat_map.get(f"{action}_done") or [])

    for rnd in range(1, max_rounds + 1):
        meta["methods_ok"].append(f"round_{rnd}")
        try:
            await _exec_dismiss_noise(page)
        except Exception:
            pass
        await asyncio.sleep(random.uniform(0.35, 0.9))

        # 1) CSS / data-e2e selectors
        ok, used = await _exec_try_selectors(page, sels)
        if ok:
            meta["methods_ok"].append(f"selector:{used[:60]}")
            await asyncio.sleep(random.uniform(0.8, 1.6))
            # verify done state if known
            if done_sels:
                verified = False
                for ds in done_sels:
                    try:
                        if await page.locator(ds).first.count() and await page.locator(ds).first.is_visible():
                            verified = True
                            meta["methods_ok"].append(f"verified:{ds[:40]}")
                            break
                    except Exception:
                        pass
                if verified:
                    meta["ok"] = True
                    meta["status"] = f"done:selector+verified:r{rnd}"
                    return meta
            else:
                meta["ok"] = True
                meta["status"] = f"done:selector:r{rnd}"
                return meta
        else:
            meta["methods_fail"].append(f"selectors_r{rnd}")

        # 2) JS text click
        text_map = {
            "subscribe": ["Follow", "Подписаться", "متابعة", "Subscribe", "Join"],
            "like": ["Like", "Нравится", "أعجبني"],
            "repost": ["Repost", "Retweet", "Поделиться", "Share", "Репост"],
        }
        if await _exec_js_click_text(page, text_map.get(action, [])):
            meta["methods_ok"].append(f"js_text_r{rnd}")
            await asyncio.sleep(random.uniform(0.8, 1.5))
            meta["ok"] = True
            meta["status"] = f"done:js_text:r{rnd}"
            return meta
        meta["methods_fail"].append(f"js_text_r{rnd}")

        # 3) Like: double-click video/center
        if action == "like":
            try:
                box = await page.evaluate(
                    """() => {
                        const v = document.querySelector('video');
                        if (v) {
                            const r = v.getBoundingClientRect();
                            return {x: r.x + r.width/2, y: r.y + r.height/2, ok: true};
                        }
                        return {x: window.innerWidth/2, y: window.innerHeight/2, ok: false};
                    }"""
                )
                if box:
                    await page.mouse.dblclick(box["x"], box["y"], delay=60)
                    meta["methods_ok"].append(f"dblclick_r{rnd}")
                    await asyncio.sleep(1.0)
                    # check unlike icon
                    if done_sels:
                        for ds in done_sels:
                            try:
                                if await page.locator(ds).first.count():
                                    meta["ok"] = True
                                    meta["status"] = f"done:dblclick:r{rnd}"
                                    return meta
                            except Exception:
                                pass
                    else:
                        meta["ok"] = True
                        meta["status"] = f"done:dblclick:r{rnd}"
                        return meta
            except Exception:
                meta["methods_fail"].append(f"dblclick_r{rnd}")

        # 4) Comment typing
        if action == "comment" and comment_text:
            comment_sels = list(plat_map.get("comment") or [])
            typed = False
            for sel in comment_sels:
                try:
                    loc = page.locator(sel).first
                    if await loc.count() == 0:
                        continue
                    await loc.click(timeout=2500)
                    await asyncio.sleep(0.3)
                    await loc.fill("")
                    await loc.type(comment_text, delay=random.randint(25, 55))
                    typed = True
                    meta["methods_ok"].append(f"type:{sel[:40]}")
                    # submit
                    for sub in (
                        'button:has-text("Post")',
                        'button:has-text("Отправить")',
                        'button:has-text("Publish")',
                        'button:has-text("Send")',
                        'button[type="submit"]',
                    ):
                        try:
                            s = page.locator(sub).first
                            if await s.count() and await s.is_visible():
                                await s.click(timeout=2000)
                                meta["ok"] = True
                                meta["status"] = f"done:comment:r{rnd}"
                                return meta
                        except Exception:
                            pass
                    await page.keyboard.press("Enter")
                    meta["ok"] = True
                    meta["status"] = f"done:comment_enter:r{rnd}"
                    return meta
                except Exception:
                    continue
            if not typed:
                meta["methods_fail"].append(f"comment_input_r{rnd}")

        # 5) soft reload once mid-way
        if rnd == 2:
            try:
                await page.reload(wait_until="domcontentloaded", timeout=20000)
                await asyncio.sleep(random.uniform(1.2, 2.2))
                meta["methods_ok"].append("reload_r2")
            except Exception:
                meta["methods_fail"].append("reload_r2")

    meta["status"] = "control_not_found"
    return meta


async def _exec_engine_wrap_execute(self, action: str, target_url: str, page=None, **kwargs):
    """
    يغلّف execute_task الأصلي:
    1) تشغيل المهارة الأصلية
    2) لو فشلت بـ control_not_found / failed → محرك V3 على نفس الصفحة
    """
    original = getattr(self, "_exec_original_execute_task", None)
    if original is None:
        # fallback: object might be unbound incorrectly
        return False, {"status": "no_original_execute"}

    try:
        result = await original(action, target_url, page=page, **kwargs)
    except TypeError:
        result = await original(self, action, target_url, page=page, **kwargs)

    # normalize
    if isinstance(result, tuple):
        ok, data = result[0], (result[1] if len(result) > 1 else {})
    else:
        ok, data = bool(result), {}
    if not isinstance(data, dict):
        data = {"status": str(data)}

    if ok:
        data.setdefault("engine_path", "original_skill")
        return True, data

    status = str(data.get("status") or "").lower()
    # لا نعيد محاولة login/captcha بنفس المحرك — فشل نظيف
    if any(x in status for x in ("login", "captcha", "qr", "region_block", "ip_block")):
        data.setdefault("engine_path", "original_skill_blocked")
        return False, data

    # صفحة التنفيذ
    work_page = page
    if work_page is None:
        data["engine_path"] = "original_failed_no_page"
        return False, data

    platform = getattr(self, "name", None) or getattr(self, "platform", None) or ""
    if not platform:
        cls = self.__class__.__name__.lower()
        for p in ("tiktok", "instagram", "vk", "youtube", "twitter", "rutube", "max", "telegram"):
            if p in cls:
                platform = p
                break

    comment_text = kwargs.get("comment_text") or data.get("comment_text") or "🔥"
    boost = await _exec_multi_strategy_action(
        work_page,
        platform,
        action,
        comment_text=str(comment_text),
        max_rounds=3,
    )
    data["engine_v3"] = boost
    if boost.get("ok"):
        data["status"] = boost.get("status") or "done:engine_v3"
        data["engine_path"] = "execution_engine_v3"
        return True, data

    data["engine_path"] = "original+engine_v3_failed"
    if not data.get("status") or data.get("status") == "failed":
        data["status"] = boost.get("status") or "control_not_found"
    return False, data


def _install_execution_engine_v3():
    """يربط المحرك على كل *Skill التي عندها execute_task."""
    skill_classes = [
        globals().get(n)
        for n in (
            "TikTokSkill",
            "InstagramSkill",
            "VKSkill",
            "YouTubeSkill",
            "TwitterSkill",
            "RutubeSkill",
            "MaxSkill",
            "FacebookSkill",
            "AvitoSkill",
            "GenericWebSkill",
        )
        if globals().get(n) is not None
    ]
    for cls in skill_classes:
        if not hasattr(cls, "execute_task"):
            continue
        if getattr(cls, "_exec_engine_v3_installed", False):
            continue
        cls._exec_original_execute_task = cls.execute_task

        async def _bound_execute(self, action: str, target_url: str, page=None, **kwargs):
            return await _exec_engine_wrap_execute(self, action, target_url, page=page, **kwargs)

        cls.execute_task = _bound_execute
        cls._exec_engine_v3_installed = True
        logger.info("⚡ EXECUTION_ENGINE_V3 wrapped: %s", cls.__name__)


try:
    _install_execution_engine_v3()
    logger.info("🔧 %s installed on skill classes", EXECUTION_ENGINE_V3)
except Exception as _eng_err:
    logger.warning("EXECUTION_ENGINE_V3 install failed: %s", _eng_err)



# ==========================================================
# EXECUTION_ENGINE_V4 — توسعة ضخمة للتنفيذ
# - تحقق شبكة (network response)
# - أفعال مركّبة (subscribe+like)
# - منتظرات ذكية + scroll into view
# - محددات إضافية Max / OK / Likee / LinkedIn
# - لفّ route_task بمحاولة ثانية بعد engine
# Additive only
# ==========================================================

EXECUTION_ENGINE_V4 = "execution-engine-v4"

# محددات إضافية تُدمَج فوق V3
EXEC_SELECTORS_V4 = {
    "max": {
        "subscribe": [
            'button:has-text("Подписаться")',
            'button:has-text("Follow")',
            'button:has-text("Вступить")',
            'a:has-text("Подписаться")',
            '[class*="subscribe"]',
            '[class*="follow"]',
        ],
        "like": [
            'button[class*="like"]',
            'button:has-text("Нравится")',
            '[aria-label*="like"]',
            '[class*="reaction"]',
        ],
        "comment": [
            'div[contenteditable="true"]',
            'textarea',
            '[class*="composer"]',
            '[placeholder*="сообщ"]',
        ],
    },
    "ok": {
        "subscribe": [
            'button:has-text("Подписаться")',
            'button:has-text("Дружить")',
            '#hook_Block_JoinButton button',
            '.button-pro:has-text("Подписаться")',
        ],
        "like": [
            'button:has-text("Класс")',
            '.widget_cnt',
            '[data-type="like"]',
            'button[aria-label*="Класс"]',
        ],
    },
    "likee": {
        "subscribe": [
            'button:has-text("Follow")',
            'button:has-text("Подписаться")',
            '.follow-btn',
            '[class*="follow"]',
        ],
        "like": [
            '.like-icon',
            '[class*="like"]',
            'button[aria-label*="Like"]',
        ],
    },
    "linkedin": {
        "subscribe": [
            'button:has-text("Follow")',
            'button:has-text("Connect")',
            'button[aria-label*="Follow"]',
        ],
        "like": [
            'button:has-text("Like")',
            'button[aria-label*="React"]',
            'button[aria-label*="Like"]',
        ],
        "comment": [
            'form .ql-editor',
            'div[role="textbox"]',
            '.comments-comment-box__form textarea',
        ],
    },
    "facebook": {
        "subscribe": [
            'div[aria-label="Follow"]',
            'div[aria-label="Подписаться"]',
            'div[role="button"]:has-text("Follow")',
            'div[role="button"]:has-text("Add friend")',
        ],
        "like": [
            'div[aria-label="Like"]',
            'div[aria-label="Нравится"]',
            'div[aria-label="أعجبني"]',
            '[data-testid="UFI2ReactionLink"]',
        ],
        "comment": [
            'div[aria-label*="comment"]',
            'div[contenteditable="true"][role="textbox"]',
        ],
        "repost": [
            'div[aria-label="Share"]',
            'div[aria-label="Поделиться"]',
            'div[role="button"]:has-text("Share")',
        ],
    },
    "avito": {
        "like": [
            'button:has-text("В избранное")',
            'button[data-marker*="favorite"]',
            '[data-marker="item-view/favorite-button"]',
        ],
        "view": [
            'button:has-text("Показать телефон")',
            'button[data-marker*="phone"]',
            'a:has-text("Написать")',
        ],
        "comment": [
            'textarea',
            'div[contenteditable="true"]',
            '[data-marker*="messenger"]',
        ],
    },
}

# دمج V4 فوق EXEC_SELECTORS إن وُجد
try:
    for _plat, _acts in EXEC_SELECTORS_V4.items():
        base = EXEC_SELECTORS.setdefault(_plat, {})
        for _act, _sels in _acts.items():
            merged = list(_sels) + list(base.get(_act) or [])
            # unique preserve order
            seen = set()
            uniq = []
            for s in merged:
                if s not in seen:
                    seen.add(s)
                    uniq.append(s)
            base[_act] = uniq
except Exception:
    pass


async def _exec_wait_network_signal(page, keywords: list, timeout_ms: int = 8000) -> bool:
    """ينتظر أي response URL يحتوي كلمة مفتاحية (like/follow/repost)."""
    if page is None:
        return False
    keys = [str(k).lower() for k in (keywords or []) if k]
    if not keys:
        return False
    try:
        async with page.expect_response(
            lambda r: any(k in (r.url or "").lower() for k in keys),
            timeout=timeout_ms,
        ) as ri:
            pass
        resp = await ri.value
        return bool(resp)
    except Exception:
        return False


async def _exec_scroll_and_hunt(page, selectors: list, max_scrolls: int = 4) -> object:
    """سكرول تدريجي مع البحث عن محدد."""
    for i in range(max_scrolls):
        for sel in selectors or []:
            try:
                loc = page.locator(sel).first
                if await loc.count() and await loc.is_visible():
                    return loc
            except Exception:
                continue
        try:
            await page.mouse.wheel(0, random.randint(350, 700))
            await asyncio.sleep(random.uniform(0.35, 0.8))
        except Exception:
            break
    return None


async def _exec_compound_actions(page, platform: str, actions: list, comment_text: str = "") -> dict:
    """
    تنفيذ سلسلة أفعال على نفس الصفحة:
    مثال: ["subscribe", "like"] أو ["like", "comment"]
    """
    results = []
    all_ok = True
    for act in actions or []:
        r = await _exec_multi_strategy_action(
            page, platform, act, comment_text=comment_text, max_rounds=2
        )
        results.append(r)
        if not r.get("ok"):
            all_ok = False
            # login wall يوقف السلسلة
            st = str(r.get("status") or "")
            if "login" in st:
                break
        await asyncio.sleep(random.uniform(0.8, 1.8))
    return {
        "ok": all_ok,
        "compound": results,
        "status": "done:compound" if all_ok else "partial_compound",
        "engine": EXECUTION_ENGINE_V4,
    }


async def _exec_verify_dom_state(page, platform: str, action: str) -> dict:
    """تحقق DOM بعد التنفيذ."""
    out = {"verified": False, "signals": []}
    if page is None:
        return out
    plat = EXEC_SELECTORS.get(platform) or {}
    done = list(plat.get(f"{action}_done") or [])
    # إشارات عامة
    generic_done = {
        "subscribe": ["following", "вы подписаны", "подписки", "requested", "friends", "متابَع"],
        "like": ["unlike", "liked", "не нравится", "إلغاء الإعجاب"],
    }
    try:
        body = (await page.inner_text("body")).lower()[:8000]
    except Exception:
        body = ""
    for phrase in generic_done.get(action, []):
        if phrase in body:
            out["signals"].append(f"body:{phrase}")
    for sel in done:
        try:
            if await page.locator(sel).first.count():
                out["signals"].append(f"sel:{sel[:40]}")
        except Exception:
            pass
    out["verified"] = len(out["signals"]) > 0
    return out


async def _exec_engine_v4_boost(page, platform: str, action: str, **kwargs) -> dict:
    """
    طبقة فوق V3:
    - scroll hunt
    - network wait keywords
    - DOM verify
    - compound لو action فيه +
    """
    action = (action or "").lower().strip()
    comment_text = str(kwargs.get("comment_text") or "🔥")

    # أفعال مركّبة: subscribe+like
    if "+" in action or "," in action:
        parts = [a.strip() for a in action.replace(",", "+").split("+") if a.strip()]
        return await _exec_compound_actions(page, platform, parts, comment_text=comment_text)

    meta = {
        "engine": EXECUTION_ENGINE_V4,
        "platform": platform,
        "action": action,
        "ok": False,
        "methods_ok": [],
        "methods_fail": [],
        "status": "pending",
    }
    if page is None:
        meta["status"] = "no_page"
        return meta

    try:
        await _exec_dismiss_noise(page)
    except Exception:
        pass

    plat_map = EXEC_SELECTORS.get(platform) or {}
    sels = list(plat_map.get(action) or [])

    # scroll hunt
    loc = await _exec_scroll_and_hunt(page, sels, max_scrolls=5)
    if loc is not None:
        meta["methods_ok"].append("scroll_hunt")
        if await _exec_human_click(page, loc):
            meta["methods_ok"].append("click_after_hunt")
            # network soft wait
            net_keys = {
                "subscribe": ["follow", "subscribe", "join", "members"],
                "like": ["like", "react", "heart"],
                "repost": ["repost", "retweet", "share"],
                "comment": ["comment", "reply"],
            }.get(action, [])
            net_ok = await _exec_wait_network_signal(page, net_keys, timeout_ms=5000)
            if net_ok:
                meta["methods_ok"].append("network_signal")
            verify = await _exec_verify_dom_state(page, platform, action)
            meta["verify"] = verify
            meta["ok"] = True
            meta["status"] = "done:v4_hunt" + ("+net" if net_ok else "") + ("+dom" if verify.get("verified") else "")
            return meta
    else:
        meta["methods_fail"].append("scroll_hunt")

    # fallback to V3 multi strategy if available
    if "_exec_multi_strategy_action" in globals():
        r3 = await _exec_multi_strategy_action(
            page, platform, action, comment_text=comment_text, max_rounds=3
        )
        meta["v3"] = r3
        if r3.get("ok"):
            verify = await _exec_verify_dom_state(page, platform, action)
            meta["verify"] = verify
            meta["ok"] = True
            meta["status"] = "done:v4_via_v3"
            meta["methods_ok"].extend(list(r3.get("methods_ok") or [])[:8])
            return meta
        meta["methods_fail"].append("v3_fallback")

    meta["status"] = "control_not_found"
    return meta


# لفّ أقوى على execute_task: بعد V3 لو فشل جرّب V4 boost
_prev_wrap = globals().get("_exec_engine_wrap_execute")


async def _exec_engine_wrap_execute_v4(self, action: str, target_url: str, page=None, **kwargs):
    if _prev_wrap:
        ok, data = await _prev_wrap(self, action, target_url, page=page, **kwargs)
    else:
        original = getattr(self, "_exec_original_execute_task", None)
        if original is None:
            return False, {"status": "no_original"}
        try:
            result = await original(action, target_url, page=page, **kwargs)
        except TypeError:
            result = await original(self, action, target_url, page=page, **kwargs)
        if isinstance(result, tuple):
            ok, data = result[0], result[1] if len(result) > 1 else {}
        else:
            ok, data = bool(result), {}
        if not isinstance(data, dict):
            data = {}

    if ok:
        return True, data

    status = str((data or {}).get("status") or "").lower()
    if any(x in status for x in ("login", "captcha", "qr", "region_block", "ip_block")):
        return False, data

    work_page = page
    if work_page is None:
        return False, data

    platform = getattr(self, "name", None) or getattr(self, "platform", None) or ""
    if not platform:
        cls = self.__class__.__name__.lower()
        for p in ("tiktok", "instagram", "vk", "youtube", "twitter", "rutube", "max", "facebook", "avito", "ok"):
            if p in cls:
                platform = p
                break

    boost = await _exec_engine_v4_boost(work_page, platform, action, **kwargs)
    data = dict(data or {})
    data["engine_v4"] = boost
    if boost.get("ok"):
        data["status"] = boost.get("status") or "done:engine_v4"
        data["engine_path"] = "execution_engine_v4"
        return True, data
    data["engine_path"] = str(data.get("engine_path") or "") + "+v4_failed"
    return False, data


# أعد تركيب الـ wrappers على الكلاسات
def _reinstall_engine_v4():
    skill_classes = [
        globals().get(n)
        for n in (
            "TikTokSkill", "InstagramSkill", "VKSkill", "YouTubeSkill",
            "TwitterSkill", "RutubeSkill", "MaxSkill", "FacebookSkill",
            "AvitoSkill", "GenericWebSkill",
        )
        if globals().get(n) is not None
    ]
    for cls in skill_classes:
        if not hasattr(cls, "execute_task"):
            continue
        # احتفظ بالأصلي لو مش محفوظ
        if not hasattr(cls, "_exec_original_execute_task"):
            cls._exec_original_execute_task = cls.execute_task

        async def _bound(self, action: str, target_url: str, page=None, **kwargs):
            return await _exec_engine_wrap_execute_v4(self, action, target_url, page=page, **kwargs)

        cls.execute_task = _bound
        cls._exec_engine_v4_installed = True
        logger.info("⚡ EXECUTION_ENGINE_V4 wrapped: %s", cls.__name__)


try:
    # استبدل مرجع الـ wrap العام
    _exec_engine_wrap_execute = _exec_engine_wrap_execute_v4  # type: ignore
    _reinstall_engine_v4()
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V4)
except Exception as _v4err:
    logger.warning("EXECUTION_ENGINE_V4 failed: %s", _v4err)


# لف route_task لإضافة meta engine
if hasattr(SkillManager, "route_task") and not getattr(SkillManager, "_v4_route_wrapped", False):
    _orig_route = SkillManager.route_task

    async def _route_task_v4(self, platform, action, target_url, page=None, **kwargs):
        ok, data = await _orig_route(self, platform, action, target_url, page=page, **kwargs)
        if not isinstance(data, dict):
            data = {"status": str(data)}
        data.setdefault("route_engine", EXECUTION_ENGINE_V4)
        # لو فشل وكان عندنا page — محاولة V4 مباشرة
        if not ok and page is not None:
            st = str(data.get("status") or "").lower()
            if not any(x in st for x in ("login", "captcha", "unsupported", "platform_filter")):
                boost = await _exec_engine_v4_boost(page, str(platform or ""), str(action or ""), **kwargs)
                data["route_v4_boost"] = boost
                if boost.get("ok"):
                    return True, {**data, "status": boost.get("status"), "engine_path": "route_v4_boost"}
        return ok, data

    SkillManager.route_task = _route_task_v4
    SkillManager._v4_route_wrapped = True
    logger.info("⚡ SkillManager.route_task wrapped with V4 boost")



# ==========================================================
# EXECUTION_ENGINE_V5 — أفعال مركّبة + تخطي نوافذ + تخفي + أخطاء
# Additive only — لا يمسح دوال
# ==========================================================

EXECUTION_ENGINE_V5 = "execution-engine-v5"

# تصنيف أخطاء موحّد
EXEC_ERROR_TAXONOMY = {
    "login_required": ["login", "sign in", "войти", "авториза", "qr code", "session"],
    "captcha": ["captcha", "recaptcha", "hcaptcha", "cf-challenge", "проверить"],
    "region_block": ["not available in your", "недоступно в вашей", "country", "region"],
    "rate_limit": ["429", "too many", "rate limit", "слишком много"],
    "control_not_found": ["control_not_found", "not found", "no button"],
    "network": ["timeout", "net::", "navigation", "connection"],
    "automation_block": ["automated", "bot detected", "suspicious"],
}


def _exec_classify_error(status: str, body: str = "") -> str:
    blob = f"{status} {body}".lower()
    for code, keys in EXEC_ERROR_TAXONOMY.items():
        if any(k in blob for k in keys):
            return code
    if not status or status in {"failed", "error"}:
        return "failed"
    return status[:80] if status else "unknown"


# نوافذ/بوابات يجب تخطّيها بقوة
EXEC_DISMISS_SELECTORS_V5 = [
    # cookies / consent
    'button:has-text("Accept all")',
    'button:has-text("Accept All")',
    'button:has-text("Accept")',
    'button:has-text("I agree")',
    'button:has-text("Принять все")',
    'button:has-text("Принять")',
    'button:has-text("Согласен")',
    'button:has-text("Allow all")',
    'button:has-text("Разрешить")',
    # login walls soft dismiss
    'button:has-text("Not now")',
    'button:has-text("Не сейчас")',
    'button:has-text("Maybe later")',
    'button:has-text("Позже")',
    'button:has-text("Skip")',
    'button:has-text("Пропустить")',
    'button:has-text("Close")',
    'button:has-text("Закрыть")',
    'button:has-text("No thanks")',
    'button:has-text("Не сейчас")',
    # aria
    'button[aria-label="Close"]',
    'button[aria-label="Закрыть"]',
    'div[role="dialog"] button[aria-label="Close"]',
    '[data-testid="closeModal"]',
    '[data-e2e="modal-close"]',
    # age / app install
    'button:has-text("Yes")',
    'button:has-text("I\'m 18")',
    'button:has-text("Мне есть 18")',
    'button:has-text("Use the web")',
    'button:has-text("Continue on web")',
    'button:has-text("Продолжить в браузере")',
    # IG/TikTok specific
    'button:has-text("Turn on Notifications")',
    'button:has-text("Не включать")',
    'button:has-text("Discard")',
]


async def _exec_dismiss_hard(page, rounds: int = 4) -> list:
    """إغلاق عدواني للنوافذ المنبثقة — عدة جولات."""
    closed = []
    if page is None:
        return closed
    for _ in range(rounds):
        hit = False
        for sel in EXEC_DISMISS_SELECTORS_V5:
            try:
                loc = page.locator(sel).first
                if await loc.count() == 0:
                    continue
                if not await loc.is_visible():
                    continue
                await loc.click(timeout=1200, force=True)
                closed.append(sel[:50])
                hit = True
                await asyncio.sleep(random.uniform(0.2, 0.45))
            except Exception:
                continue
        # Escape
        try:
            await page.keyboard.press("Escape")
            await asyncio.sleep(0.15)
        except Exception:
            pass
        # click outside dialog
        try:
            await page.mouse.click(5, 5)
        except Exception:
            pass
        if not hit:
            break
    return closed


EXEC_STEALTH_JS_V5 = r"""
(() => {
  try {
    Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
  } catch (e) {}
  try {
    if (!window.chrome) { window.chrome = { runtime: {} }; }
  } catch (e) {}
  try {
    Object.defineProperty(navigator, 'languages', { get: () => ['ru-RU', 'ru', 'en-US', 'en'] });
  } catch (e) {}
  try {
    Object.defineProperty(navigator, 'plugins', {
      get: () => [1, 2, 3, 4, 5],
    });
  } catch (e) {}
  try {
    const originalQuery = window.navigator.permissions.query;
    window.navigator.permissions.query = (parameters) => (
      parameters && parameters.name === 'notifications'
        ? Promise.resolve({ state: Notification.permission })
        : originalQuery(parameters)
    );
  } catch (e) {}
  try {
    Object.defineProperty(navigator, 'platform', { get: () => 'Win32' });
  } catch (e) {}
  try {
    // hide automation flags
    delete document.$cdc_asdjflasutopfhvcZLmcfl_;
    delete document.$chrome_asyncScriptInfo;
  } catch (e) {}
})();
"""


async def _exec_apply_stealth(page) -> bool:
    if page is None:
        return False
    try:
        await page.add_init_script(EXEC_STEALTH_JS_V5)
    except Exception:
        pass
    try:
        await page.evaluate(EXEC_STEALTH_JS_V5)
        return True
    except Exception:
        return False


def _exec_parse_compound_actions(action: str) -> list:
    """
    يحلل أفعال مركّبة من نص:
    subscribe+like | like,comment | subscribe then like | подписка и лайк
    """
    raw = (action or "").strip().lower()
    if not raw:
        return []
    # استبدال مرادفات
    repl = {
        "подписаться": "subscribe",
        "подписка": "subscribe",
        "фоллоу": "subscribe",
        "follow": "subscribe",
        "вступить": "subscribe",
        "лайк": "like",
        "нравится": "like",
        "репост": "repost",
        "репостнуть": "repost",
        "поделиться": "repost",
        "share": "repost",
        "коммент": "comment",
        "комментарий": "comment",
        "comment": "comment",
        "просмотр": "view",
        "смотреть": "view",
        "view": "view",
    }
    text = raw
    for a, b in repl.items():
        text = text.replace(a, b)
    # فواصل
    for sep in (" then ", " and ", " и ", " + ", "+", ",", "/", "|", "&"):
        text = text.replace(sep, "+")
    parts = [p.strip() for p in text.split("+") if p.strip()]
    allowed = {"subscribe", "like", "comment", "repost", "view", "share", "register", "review"}
    out = []
    for p in parts:
        p = p.strip()
        if p in allowed:
            out.append(p)
        elif p in repl:
            out.append(repl[p])
    # unique order
    seen = set()
    final = []
    for a in out:
        if a not in seen:
            seen.add(a)
            final.append(a)
    return final if final else [raw]


async def _exec_compound_pipeline(
    page,
    platform: str,
    actions: list,
    *,
    comment_text: str = "🔥",
    target_url: str = "",
) -> dict:
    """
    خط أنابيب احترافي للأفعال المركّبة:
    stealth → dismiss → goto(optional) → لكل فعل: dismiss + execute + verify + pause
    لو فعل فشل بـ login → توقف + تصنيف خطأ
    """
    report = {
        "engine": EXECUTION_ENGINE_V5,
        "platform": platform,
        "actions": list(actions or []),
        "steps": [],
        "ok": False,
        "ok_count": 0,
        "fail_count": 0,
        "status": "pending",
        "error_class": "",
        "dismissed": [],
    }
    if page is None:
        report["status"] = "no_page"
        report["error_class"] = "no_page"
        return report

    await _exec_apply_stealth(page)
    dismissed = await _exec_dismiss_hard(page, rounds=3)
    report["dismissed"] = dismissed[:20]

    if target_url:
        try:
            cur = (page.url or "").lower()
            if target_url.split("?")[0].lower() not in cur:
                await page.goto(target_url, wait_until="domcontentloaded", timeout=30000)
                await asyncio.sleep(random.uniform(1.2, 2.4))
                dismissed += await _exec_dismiss_hard(page, rounds=2)
        except Exception as e:
            report["steps"].append({"action": "goto", "ok": False, "error": str(e)[:120]})

    for i, act in enumerate(actions or []):
        step = {"index": i + 1, "action": act, "ok": False, "status": ""}
        try:
            await _exec_dismiss_hard(page, rounds=2)
            await asyncio.sleep(random.uniform(0.4, 1.0))

            # نفّذ عبر V4 boost إن وجد وإلا V3
            if "_exec_engine_v4_boost" in globals():
                result = await _exec_engine_v4_boost(
                    page, platform, act, comment_text=comment_text
                )
            elif "_exec_multi_strategy_action" in globals():
                result = await _exec_multi_strategy_action(
                    page, platform, act, comment_text=comment_text, max_rounds=3
                )
            else:
                result = {"ok": False, "status": "no_engine"}

            step["result"] = {
                "status": result.get("status"),
                "methods_ok": (result.get("methods_ok") or [])[:6],
            }
            step["ok"] = bool(result.get("ok"))
            step["status"] = str(result.get("status") or "")
            step["error_class"] = _exec_classify_error(step["status"])

            if step["ok"]:
                report["ok_count"] += 1
            else:
                report["fail_count"] += 1
                if step["error_class"] in {"login_required", "captcha", "region_block"}:
                    report["steps"].append(step)
                    report["status"] = step["error_class"]
                    report["error_class"] = step["error_class"]
                    report["ok"] = False
                    return report

            # توقف بشري بين الأفعال
            await asyncio.sleep(random.uniform(1.0, 2.5))
            try:
                await page.mouse.wheel(0, random.randint(80, 220))
            except Exception:
                pass
        except Exception as e:
            step["ok"] = False
            step["status"] = f"exception:{type(e).__name__}"
            step["error_class"] = _exec_classify_error(str(e))
            report["fail_count"] += 1
        report["steps"].append(step)

    report["ok"] = report["ok_count"] > 0 and report["fail_count"] == 0
    if report["ok"]:
        report["status"] = f"done:compound:{report['ok_count']}/{len(actions or [])}"
    elif report["ok_count"] > 0:
        report["status"] = f"partial:compound:{report['ok_count']}/{len(actions or [])}"
        report["ok"] = True  # نجاح جزئي يُعتبر مفيد للمهام متعددة الشروط
        report["error_class"] = "partial"
    else:
        report["status"] = "compound_failed"
        report["error_class"] = _exec_classify_error(
            (report["steps"][-1].get("status") if report["steps"] else "") or "failed"
        )
    return report


async def _exec_engine_v5_entry(page, platform: str, action: str, **kwargs) -> dict:
    """مدخل موحّد: يكتشف المركّب وينفّذ pipeline أو فعل واحد مع stealth+dismiss."""
    comment_text = str(kwargs.get("comment_text") or "🔥")
    target_url = str(kwargs.get("target_url") or "")
    actions = _exec_parse_compound_actions(action)
    await _exec_apply_stealth(page)
    await _exec_dismiss_hard(page, rounds=3)

    if len(actions) > 1:
        return await _exec_compound_pipeline(
            page, platform, actions,
            comment_text=comment_text,
            target_url=target_url,
        )

    # فعل واحد
    single = actions[0] if actions else action
    if "_exec_engine_v4_boost" in globals():
        r = await _exec_engine_v4_boost(page, platform, single, comment_text=comment_text)
    elif "_exec_multi_strategy_action" in globals():
        r = await _exec_multi_strategy_action(
            page, platform, single, comment_text=comment_text, max_rounds=3
        )
    else:
        r = {"ok": False, "status": "no_engine"}
    r = dict(r or {})
    r["error_class"] = _exec_classify_error(str(r.get("status") or ""))
    r["engine"] = EXECUTION_ENGINE_V5
    return r


# لف نهائي على execute_task
_prev_v4_wrap = globals().get("_exec_engine_wrap_execute_v4") or globals().get("_exec_engine_wrap_execute")


async def _exec_engine_wrap_execute_v5(self, action: str, target_url: str, page=None, **kwargs):
    # 1) الأصلي عبر الطبقات السابقة إن وجدت
    if _prev_v4_wrap:
        try:
            ok, data = await _prev_v4_wrap(self, action, target_url, page=page, **kwargs)
        except Exception as e:
            ok, data = False, {"status": f"wrap_error:{type(e).__name__}"}
    else:
        original = getattr(self, "_exec_original_execute_task", None)
        if original is None:
            ok, data = False, {"status": "no_original"}
        else:
            try:
                result = await original(action, target_url, page=page, **kwargs)
            except TypeError:
                result = await original(self, action, target_url, page=page, **kwargs)
            if isinstance(result, tuple):
                ok, data = result[0], result[1] if len(result) > 1 else {}
            else:
                ok, data = bool(result), {}

    if not isinstance(data, dict):
        data = {}

    if ok:
        data.setdefault("error_class", "none")
        return True, data

    status = str(data.get("status") or "").lower()
    err = _exec_classify_error(status)
    data["error_class"] = err
    if err in {"login_required", "captcha", "region_block", "automation_block"}:
        return False, data

    if page is None:
        return False, data

    platform = getattr(self, "name", None) or getattr(self, "platform", None) or ""
    if not platform:
        cls = self.__class__.__name__.lower()
        for p in ("tiktok", "instagram", "vk", "youtube", "twitter", "rutube", "max", "facebook", "avito", "ok"):
            if p in cls:
                platform = p
                break

    boost = await _exec_engine_v5_entry(
        page, platform, action,
        comment_text=kwargs.get("comment_text") or "🔥",
        target_url=target_url,
    )
    data["engine_v5"] = boost
    if boost.get("ok"):
        data["status"] = boost.get("status") or "done:engine_v5"
        data["engine_path"] = "execution_engine_v5"
        data["error_class"] = "none"
        data["compound_steps"] = boost.get("steps")
        return True, data

    data["engine_path"] = str(data.get("engine_path") or "") + "+v5_failed"
    data["error_class"] = boost.get("error_class") or err or "failed"
    data["status"] = boost.get("status") or data.get("status") or "failed"
    return False, data


def _reinstall_engine_v5():
    skill_classes = [
        globals().get(n)
        for n in (
            "TikTokSkill", "InstagramSkill", "VKSkill", "YouTubeSkill",
            "TwitterSkill", "RutubeSkill", "MaxSkill", "FacebookSkill",
            "AvitoSkill", "GenericWebSkill",
        )
        if globals().get(n) is not None
    ]
    for cls in skill_classes:
        if not hasattr(cls, "execute_task"):
            continue
        if not hasattr(cls, "_exec_original_execute_task"):
            cls._exec_original_execute_task = cls.execute_task

        async def _bound(self, action: str, target_url: str, page=None, **kwargs):
            return await _exec_engine_wrap_execute_v5(self, action, target_url, page=page, **kwargs)

        cls.execute_task = _bound
        cls._exec_engine_v5_installed = True
        logger.info("⚡ EXECUTION_ENGINE_V5 wrapped: %s", cls.__name__)


try:
    _exec_engine_wrap_execute_v4 = _exec_engine_wrap_execute_v5  # chain tip
    _reinstall_engine_v5()
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V5)
except Exception as _v5e:
    logger.warning("V5 install failed: %s", _v5e)


# route_task: دعم compound من النص
if hasattr(SkillManager, "route_task"):
    _route_prev = SkillManager.route_task

    async def _route_task_v5(self, platform, action, target_url, page=None, **kwargs):
        actions = _exec_parse_compound_actions(str(action or ""))
        # لو مركّب ومتوفر page — pipeline مباشر
        if page is not None and len(actions) > 1:
            await _exec_apply_stealth(page)
            await _exec_dismiss_hard(page, rounds=3)
            boost = await _exec_compound_pipeline(
                page, str(platform or ""), actions,
                comment_text=str(kwargs.get("comment_text") or "🔥"),
                target_url=str(target_url or ""),
            )
            if boost.get("ok"):
                return True, {
                    "status": boost.get("status"),
                    "engine_path": "route_compound_v5",
                    "compound_steps": boost.get("steps"),
                    "error_class": "none",
                }
            # لو فشل مركّب، كمّل بالمسار العادي للفعل الأول
        ok, data = await _route_prev(self, platform, action, target_url, page=page, **kwargs)
        if not isinstance(data, dict):
            data = {"status": str(data)}
        data["error_class"] = _exec_classify_error(str(data.get("status") or ""))
        return ok, data

    SkillManager.route_task = _route_task_v5
    logger.info("⚡ route_task V5 compound-aware")



# ==========================================================
# COOKIES_REFRESH_V1 — تحديث الكوكيز من data/cookies + المضمّنة الجديدة
# Additive: يعيد تعيين ثوابت الكلاسات من الملفات إن وُجدت
# ==========================================================

COOKIES_REFRESH_V1 = "cookies-refresh-v1"

def _refresh_skill_cookies_from_files():
    mapping = {
        "VKSkill": ("VK_COOKIES", "vk"),
        "InstagramSkill": ("INSTAGRAM_COOKIES", "instagram"),
        "YouTubeSkill": ("YOUTUBE_COOKIES", "youtube"),
        "TelegramSkill": ("TELEGRAM_WEB_COOKIES", "telegram"),
        "MaxSkill": ("MAX_COOKIES", "max"),
        "TikTokSkill": ("TIKTOK_COOKIES", "tiktok"),
        "RutubeSkill": ("RUTUBE_COOKIES", "rutube"),
        "TwitterSkill": ("TWITTER_COOKIES", "twitter"),
    }
    base = Path("data/cookies")
    for cls_name, (attr, file_stem) in mapping.items():
        cls = globals().get(cls_name)
        if cls is None:
            continue
        path = base / f"{file_stem}.json"
        if not path.is_file() and file_stem == "twitter":
            path = base / "x.json"
        if not path.is_file():
            continue
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                raw = raw.get("cookies") or []
            if isinstance(raw, list) and raw:
                setattr(cls, attr, raw)
                logger.info("🍪 refreshed %s.%s from %s (%s)", cls_name, attr, path, len(raw))
        except Exception as e:
            logger.warning("cookie refresh %s: %s", cls_name, e)

try:
    _refresh_skill_cookies_from_files()
except Exception as _cr:
    logger.debug("cookies refresh: %s", _cr)



# ==========================================================
# EXECUTION_ENGINE_V6 — صحة جلسة + استرداد + أهداف متعددة + تحقق
# Additive only
# ==========================================================

EXECUTION_ENGINE_V6 = "execution-engine-v6"

LOGIN_MARKERS_V6 = [
    "login", "sign in", "log in", "войти", "авториза", "qr-code", "qr code",
    "accounts.google.com/signin", "passport.yandex", "id.vk.com",
    "auth.tiktok", "instagram.com/accounts/login", "x.com/i/flow/login",
]

CAPTCHA_MARKERS_V6 = [
    "captcha", "recaptcha", "hcaptcha", "cf-challenge", "challenge-platform",
    "проверить что вы не робот", "are you a robot",
]


async def _exec_page_health(page) -> dict:
    """فحص سريع لحالة الصفحة قبل/بعد التنفيذ."""
    out = {"ok": True, "url": "", "title": "", "flags": []}
    if page is None:
        out["ok"] = False
        out["flags"].append("no_page")
        return out
    try:
        out["url"] = page.url or ""
        out["title"] = (await page.title()) or ""
    except Exception:
        pass
    blob = f"{out['url']} {out['title']}".lower()
    try:
        body = ""
        body = await page.evaluate("() => (document.body && document.body.innerText || '').slice(0, 2500)")
        blob += " " + (body or "").lower()
    except Exception:
        pass
    if any(m in blob for m in LOGIN_MARKERS_V6):
        out["ok"] = False
        out["flags"].append("login_required")
    if any(m in blob for m in CAPTCHA_MARKERS_V6):
        out["ok"] = False
        out["flags"].append("captcha")
    return out


async def _exec_recover_page(page, target_url: str = "") -> dict:
    """استرداد: dismiss + reload + رجوع للرابط."""
    info = {"steps": []}
    if page is None:
        return info
    try:
        if "_exec_dismiss_hard" in globals():
            closed = await _exec_dismiss_hard(page, rounds=3)
            info["steps"].append(f"dismiss:{len(closed)}")
        else:
            await page.keyboard.press("Escape")
            info["steps"].append("escape")
    except Exception:
        pass
    try:
        await page.reload(wait_until="domcontentloaded", timeout=25000)
        info["steps"].append("reload")
        await asyncio.sleep(random.uniform(0.8, 1.6))
    except Exception as e:
        info["steps"].append(f"reload_fail:{type(e).__name__}")
    if target_url:
        try:
            await page.goto(target_url, wait_until="domcontentloaded", timeout=30000)
            info["steps"].append("goto_target")
            await asyncio.sleep(random.uniform(1.0, 2.0))
        except Exception as e:
            info["steps"].append(f"goto_fail:{type(e).__name__}")
    try:
        if "_exec_dismiss_hard" in globals():
            await _exec_dismiss_hard(page, rounds=2)
    except Exception:
        pass
    return info


def _exec_split_targets(target_url: str) -> list:
    """عدة روابط في نص واحد (سطر / مسافة / فاصلة)."""
    raw = (target_url or "").strip()
    if not raw:
        return []
    parts = []
    for sep in ("\n", " ", ",", ";", "|"):
        raw = raw.replace(sep, "\n")
    for line in raw.split("\n"):
        u = line.strip()
        if u.startswith("http://") or u.startswith("https://"):
            parts.append(u)
    # unique order
    seen = set()
    out = []
    for u in parts:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out if out else ([target_url] if target_url else [])


async def _exec_multi_target_pipeline(
    page,
    platform: str,
    action: str,
    target_url: str,
    *,
    comment_text: str = "🔥",
) -> dict:
    """
    ينفّذ نفس الفعل (أو مركّب) على كل رابط هدف بالترتيب.
    مثال UNU: 5 جروبات VK في مهمة واحدة.
    """
    targets = _exec_split_targets(target_url)
    actions = _exec_parse_compound_actions(action) if "_exec_parse_compound_actions" in globals() else [action]
    report = {
        "engine": EXECUTION_ENGINE_V6,
        "platform": platform,
        "action": action,
        "targets": targets,
        "results": [],
        "ok_count": 0,
        "fail_count": 0,
        "ok": False,
        "status": "pending",
        "error_class": "",
    }
    if page is None:
        report["status"] = "no_page"
        report["error_class"] = "no_page"
        return report

    if "_exec_apply_stealth" in globals():
        await _exec_apply_stealth(page)

    for ti, url in enumerate(targets):
        item = {"index": ti + 1, "url": url, "ok": False, "status": ""}
        try:
            health = await _exec_page_health(page)
            if "captcha" in health.get("flags", []):
                item["status"] = "captcha"
                item["error_class"] = "captcha"
                report["results"].append(item)
                report["fail_count"] += 1
                report["status"] = "captcha"
                report["error_class"] = "captcha"
                return report

            # انتقل للهدف
            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)
                await asyncio.sleep(random.uniform(1.0, 2.2))
            except Exception as e:
                # استرداد مرة
                await _exec_recover_page(page, url)
                try:
                    await page.goto(url, wait_until="domcontentloaded", timeout=30000)
                except Exception as e2:
                    item["status"] = f"nav_fail:{type(e2).__name__}"
                    item["error_class"] = "network"
                    report["results"].append(item)
                    report["fail_count"] += 1
                    continue

            if "_exec_dismiss_hard" in globals():
                await _exec_dismiss_hard(page, rounds=3)

            health2 = await _exec_page_health(page)
            if "login_required" in health2.get("flags", []):
                item["status"] = "login_required"
                item["error_class"] = "login_required"
                report["results"].append(item)
                report["fail_count"] += 1
                report["status"] = "login_required"
                report["error_class"] = "login_required"
                return report
            if "captcha" in health2.get("flags", []):
                item["status"] = "captcha"
                item["error_class"] = "captcha"
                report["results"].append(item)
                report["fail_count"] += 1
                report["status"] = "captcha"
                report["error_class"] = "captcha"
                return report

            # نفّذ أفعال
            if len(actions) > 1 and "_exec_compound_pipeline" in globals():
                sub = await _exec_compound_pipeline(
                    page, platform, actions,
                    comment_text=comment_text,
                    target_url="",
                )
                item["ok"] = bool(sub.get("ok"))
                item["status"] = sub.get("status") or ""
                item["compound"] = sub.get("steps")
                item["error_class"] = sub.get("error_class") or ""
            elif "_exec_engine_v5_entry" in globals():
                sub = await _exec_engine_v5_entry(
                    page, platform, actions[0] if actions else action,
                    comment_text=comment_text,
                    target_url="",
                )
                item["ok"] = bool(sub.get("ok"))
                item["status"] = sub.get("status") or ""
                item["error_class"] = sub.get("error_class") or ""
            else:
                item["status"] = "no_engine"
                item["error_class"] = "failed"

            if item["ok"]:
                report["ok_count"] += 1
            else:
                report["fail_count"] += 1
                # محاولة استرداد + إعادة مرة واحدة
                if item.get("error_class") not in {"login_required", "captcha"}:
                    await _exec_recover_page(page, url)
                    if "_exec_engine_v5_entry" in globals():
                        sub2 = await _exec_engine_v5_entry(
                            page, platform, actions[0] if actions else action,
                            comment_text=comment_text,
                        )
                        if sub2.get("ok"):
                            item["ok"] = True
                            item["status"] = "done:recover_v6"
                            item["error_class"] = "none"
                            report["ok_count"] += 1
                            report["fail_count"] -= 1

            await asyncio.sleep(random.uniform(1.2, 2.8))
        except Exception as e:
            item["status"] = f"exception:{type(e).__name__}"
            item["error_class"] = "failed"
            report["fail_count"] += 1
        report["results"].append(item)

    total = len(targets) or 1
    if report["ok_count"] == total and report["fail_count"] == 0:
        report["ok"] = True
        report["status"] = f"done:multi:{report['ok_count']}/{total}"
        report["error_class"] = "none"
    elif report["ok_count"] > 0:
        report["ok"] = True
        report["status"] = f"partial:multi:{report['ok_count']}/{total}"
        report["error_class"] = "partial"
    else:
        report["ok"] = False
        last = report["results"][-1] if report["results"] else {}
        report["status"] = last.get("status") or "multi_failed"
        report["error_class"] = last.get("error_class") or "failed"
    return report


# لف نهائي: multi-target فوق V5
_prev_v5_wrap = globals().get("_exec_engine_wrap_execute_v5") or globals().get("_exec_engine_wrap_execute_v4")


async def _exec_engine_wrap_execute_v6(self, action: str, target_url: str, page=None, **kwargs):
    # مسار سابق
    if _prev_v5_wrap:
        try:
            ok, data = await _prev_v5_wrap(self, action, target_url, page=page, **kwargs)
        except Exception as e:
            ok, data = False, {"status": f"wrap_error:{type(e).__name__}"}
    else:
        original = getattr(self, "_exec_original_execute_task", None)
        if original is None:
            ok, data = False, {"status": "no_original"}
        else:
            try:
                result = await original(action, target_url, page=page, **kwargs)
            except TypeError:
                result = await original(self, action, target_url, page=page, **kwargs)
            if isinstance(result, tuple):
                ok, data = result[0], result[1] if len(result) > 1 else {}
            else:
                ok, data = bool(result), {}

    if not isinstance(data, dict):
        data = {}
    if ok:
        data.setdefault("error_class", "none")
        return True, data

    err = data.get("error_class") or (
        _exec_classify_error(str(data.get("status") or "")) if "_exec_classify_error" in globals() else "failed"
    )
    data["error_class"] = err
    if err in {"login_required", "captcha", "region_block", "automation_block"}:
        return False, data
    if page is None:
        return False, data

    platform = getattr(self, "name", None) or getattr(self, "platform", None) or ""
    if not platform:
        cls = self.__class__.__name__.lower()
        for p in ("tiktok", "instagram", "vk", "youtube", "twitter", "rutube", "max", "facebook", "avito"):
            if p in cls:
                platform = p
                break

    targets = _exec_split_targets(target_url)
    # لو أكثر من رابط أو فشل السابق → multi pipeline
    if len(targets) > 1 or not ok:
        boost = await _exec_multi_target_pipeline(
            page, platform, action, target_url,
            comment_text=str(kwargs.get("comment_text") or "🔥"),
        )
        data["engine_v6"] = boost
        if boost.get("ok"):
            data["status"] = boost.get("status") or "done:engine_v6"
            data["engine_path"] = "execution_engine_v6"
            data["error_class"] = boost.get("error_class") or "none"
            data["multi_results"] = boost.get("results")
            return True, data
        data["engine_path"] = str(data.get("engine_path") or "") + "+v6_failed"
        data["error_class"] = boost.get("error_class") or err
        data["status"] = boost.get("status") or data.get("status") or "failed"
        data["multi_results"] = boost.get("results")
    return False, data


def _reinstall_engine_v6():
    skill_classes = [
        globals().get(n)
        for n in (
            "TikTokSkill", "InstagramSkill", "VKSkill", "YouTubeSkill",
            "TwitterSkill", "RutubeSkill", "MaxSkill", "FacebookSkill",
            "AvitoSkill", "GenericWebSkill",
        )
        if globals().get(n) is not None
    ]
    for cls in skill_classes:
        if not hasattr(cls, "execute_task"):
            continue
        if not hasattr(cls, "_exec_original_execute_task"):
            cls._exec_original_execute_task = cls.execute_task

        async def _bound(self, action: str, target_url: str, page=None, **kwargs):
            return await _exec_engine_wrap_execute_v6(self, action, target_url, page=page, **kwargs)

        cls.execute_task = _bound
        cls._exec_engine_v6_installed = True
        logger.info("⚡ EXECUTION_ENGINE_V6 wrapped: %s", cls.__name__)


try:
    _exec_engine_wrap_execute_v5 = _exec_engine_wrap_execute_v6
    _reinstall_engine_v6()
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V6)
except Exception as _v6e:
    logger.warning("V6 install failed: %s", _v6e)



# ==========================================================
# EXECUTION_ENGINE_V7 — كابتشا اختيارية + صحة جلسة + rate limit + استرداد
# Additive only — لا يمسح دوال ولا يعدّل سلوك الدوال الأصلية مباشرة
# ==========================================================

EXECUTION_ENGINE_V7 = "execution-engine-v7"

import os
import time
from collections import defaultdict

# ---------- Rate limit per platform (in-memory) ----------
_V7_RATE = defaultdict(list)  # platform -> [timestamps]
_V7_RATE_MAX = {
    "instagram": 12,
    "tiktok": 14,
    "vk": 20,
    "twitter": 12,
    "x": 12,
    "youtube": 15,
    "rutube": 15,
    "telegram": 30,
    "max": 8,
    "default": 18,
}
_V7_RATE_WINDOW = 3600.0  # 1 hour


def _v7_rate_allow(platform: str) -> tuple:
    plat = (platform or "default").lower()
    limit = _V7_RATE_MAX.get(plat, _V7_RATE_MAX["default"])
    now = time.time()
    bucket = _V7_RATE[plat]
    _V7_RATE[plat] = [t for t in bucket if now - t < _V7_RATE_WINDOW]
    if len(_V7_RATE[plat]) >= limit:
        return False, f"rate_limit:{plat}:{len(_V7_RATE[plat])}/{limit}"
    _V7_RATE[plat].append(now)
    return True, "ok"


# ---------- Optional captcha solvers (env-based) ----------
def _v7_captcha_env():
    provider = (os.environ.get("CAPTCHA_PROVIDER") or "").strip().lower()
    key = (
        os.environ.get("CAPTCHA_API_KEY")
        or os.environ.get("TWOCAPTCHA_API_KEY")
        or os.environ.get("CAPSOLVER_API_KEY")
        or ""
    ).strip()
    # fallback to config.CAPTCHA if available
    if not key:
        try:
            from config import CAPTCHA
            key = getattr(CAPTCHA, "API_KEY", "") or ""
            if not provider:
                provider = getattr(CAPTCHA, "PROVIDER", "capsolver") or "capsolver"
        except Exception:
            pass
    return provider, key


async def _v7_solve_recaptcha_v2(site_key: str, page_url: str) -> str:
    """
    حل reCAPTCHA v2 عبر 2captcha أو capsolver لو المفتاح موجود.
    يرجع token أو "".
    """
    provider, key = _v7_captcha_env()
    if not key or not site_key or not page_url:
        return ""
    try:
        import urllib.request
        import urllib.parse
        import json as _json
        import asyncio as _aio

        if provider in ("", "2captcha", "rucaptcha", "twocaptcha"):
            base = "https://2captcha.com" if provider != "rucaptcha" else "https://rucaptcha.com"
            # in
            q = urllib.parse.urlencode({
                "key": key,
                "method": "userrecaptcha",
                "googlekey": site_key,
                "pageurl": page_url,
                "json": 1,
            })
            with urllib.request.urlopen(f"{base}/in.php?{q}", timeout=30) as resp:
                data = _json.loads(resp.read().decode("utf-8", errors="ignore"))
            if str(data.get("status")) != "1":
                logger.warning("2captcha in fail: %s", data)
                return ""
            req_id = data.get("request")
            for _ in range(24):
                await _aio.sleep(5)
                q2 = urllib.parse.urlencode({"key": key, "action": "get", "id": req_id, "json": 1})
                with urllib.request.urlopen(f"{base}/res.php?{q2}", timeout=30) as resp2:
                    data2 = _json.loads(resp2.read().decode("utf-8", errors="ignore"))
                if str(data2.get("status")) == "1":
                    return str(data2.get("request") or "")
                if data2.get("request") not in ("CAPCHA_NOT_READY", "CAPTCHA_NOT_READY"):
                    logger.warning("2captcha res: %s", data2)
                    return ""
            return ""

        if provider in ("capsolver", "capmonster"):
            # CapSolver createTask API
            api = "https://api.capsolver.com/createTask" if provider == "capsolver" else "https://api.capmonster.cloud/createTask"
            payload = _json.dumps({
                "clientKey": key,
                "task": {
                    "type": "ReCaptchaV2TaskProxyLess",
                    "websiteURL": page_url,
                    "websiteKey": site_key,
                },
            }).encode("utf-8")
            req = urllib.request.Request(api, data=payload, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = _json.loads(resp.read().decode("utf-8", errors="ignore"))
            task_id = data.get("taskId")
            if not task_id:
                logger.warning("capsolver create fail: %s", data)
                return ""
            result_api = api.replace("createTask", "getTaskResult")
            for _ in range(24):
                await _aio.sleep(5)
                payload2 = _json.dumps({"clientKey": key, "taskId": task_id}).encode("utf-8")
                req2 = urllib.request.Request(result_api, data=payload2, headers={"Content-Type": "application/json"})
                with urllib.request.urlopen(req2, timeout=30) as resp2:
                    data2 = _json.loads(resp2.read().decode("utf-8", errors="ignore"))
                if data2.get("status") == "ready":
                    sol = data2.get("solution") or {}
                    return str(sol.get("gRecaptchaResponse") or sol.get("token") or "")
                if data2.get("status") not in ("processing", "idle"):
                    logger.warning("capsolver result: %s", data2)
                    return ""
            return ""
    except Exception as e:
        logger.warning("captcha solve error: %s", e)
    return ""


async def _v7_try_inject_recaptcha(page) -> dict:
    """يحاول استخراج sitekey وحلها وحقن الرد — اختياري."""
    out = {"tried": False, "ok": False, "status": "skip"}
    provider, key = _v7_captcha_env()
    if not key:
        out["status"] = "no_api_key"
        return out
    if page is None:
        out["status"] = "no_page"
        return out
    out["tried"] = True
    try:
        site_key = await page.evaluate(
            """() => {
                const el = document.querySelector('[data-sitekey], .g-recaptcha, iframe[src*="recaptcha"]');
                if (!el) return '';
                if (el.getAttribute) {
                    const k = el.getAttribute('data-sitekey');
                    if (k) return k;
                }
                const ifr = document.querySelector('iframe[src*="recaptcha"]');
                if (ifr && ifr.src) {
                    const m = ifr.src.match(/[?&]k=([^&]+)/);
                    if (m) return decodeURIComponent(m[1]);
                }
                return '';
            }"""
        )
        if not site_key:
            out["status"] = "no_sitekey"
            return out
        token = await _v7_solve_recaptcha_v2(str(site_key), page.url or "")
        if not token:
            out["status"] = "solve_failed"
            return out
        await page.evaluate(
            """(token) => {
                const areas = document.querySelectorAll('#g-recaptcha-response, textarea[name="g-recaptcha-response"]');
                areas.forEach(a => { a.style.display = 'block'; a.value = token; });
                if (typeof window.___grecaptcha_cfg !== 'undefined') {
                    try {
                        const clients = window.___grecaptcha_cfg.clients || {};
                        // best-effort callback
                    } catch (e) {}
                }
                const forms = document.querySelectorAll('form');
                if (forms.length === 1) {
                    // don't auto-submit aggressively
                }
            }""",
            token,
        )
        out["ok"] = True
        out["status"] = "token_injected"
        return out
    except Exception as e:
        out["status"] = f"exception:{type(e).__name__}"
        return out


# ---------- Session health ----------
_V7_LOGIN_HINTS = (
    "login", "sign in", "log in", "войти", "авториза", "sign up",
    "accounts/login", "id.vk.com", "auth.tiktok", "flow/login",
    "challenge", "checkpoint",
)


async def _v7_session_health(page, platform: str = "") -> dict:
    h = {"ok": True, "flags": [], "url": "", "platform": platform}
    if page is None:
        h["ok"] = False
        h["flags"].append("no_page")
        return h
    try:
        h["url"] = page.url or ""
        title = ""
        try:
            title = await page.title()
        except Exception:
            pass
        blob = f"{h['url']} {title}".lower()
        try:
            txt = await page.evaluate(
                "() => (document.body && document.body.innerText || '').slice(0, 1800)"
            )
            blob += " " + (txt or "").lower()
        except Exception:
            pass
        if any(x in blob for x in _V7_LOGIN_HINTS):
            h["ok"] = False
            h["flags"].append("login_required")
        if any(x in blob for x in ("captcha", "recaptcha", "hcaptcha", "cf-challenge")):
            h["ok"] = False
            h["flags"].append("captcha")
        if any(x in blob for x in ("not available in your", "недоступно в вашей", "country restricted")):
            h["ok"] = False
            h["flags"].append("region_block")
    except Exception as e:
        h["ok"] = False
        h["flags"].append(f"health_err:{type(e).__name__}")
    return h


async def _v7_human_pause(lo: float = 0.6, hi: float = 1.8):
    await asyncio.sleep(random.uniform(lo, hi))


async def _v7_engine_entry(page, platform: str, action: str, **kwargs) -> dict:
    """
    مدخل V7: rate limit → stealth → health → captcha optional →
    multi/compound (V6/V5) → recover once.
    """
    report = {
        "engine": EXECUTION_ENGINE_V7,
        "platform": platform,
        "action": action,
        "ok": False,
        "status": "pending",
        "error_class": "",
        "steps": [],
    }
    allowed, rate_msg = _v7_rate_allow(platform)
    if not allowed:
        report["status"] = rate_msg
        report["error_class"] = "rate_limit"
        return report

    if page is None:
        report["status"] = "no_page"
        report["error_class"] = "no_page"
        return report

    if "_exec_apply_stealth" in globals():
        try:
            await _exec_apply_stealth(page)
            report["steps"].append("stealth")
        except Exception:
            pass

    if "_exec_dismiss_hard" in globals():
        try:
            closed = await _exec_dismiss_hard(page, rounds=3)
            report["steps"].append(f"dismiss:{len(closed)}")
        except Exception:
            pass

    health = await _v7_session_health(page, platform)
    report["health"] = health
    if "captcha" in health.get("flags", []):
        cap = await _v7_try_inject_recaptcha(page)
        report["captcha"] = cap
        if not cap.get("ok"):
            report["status"] = "captcha"
            report["error_class"] = "captcha"
            return report
        await _v7_human_pause(1.0, 2.0)
        health = await _v7_session_health(page, platform)
    if "login_required" in health.get("flags", []):
        report["status"] = "login_required"
        report["error_class"] = "login_required"
        return report
    if "region_block" in health.get("flags", []):
        report["status"] = "region_block"
        report["error_class"] = "region_block"
        return report

    target_url = str(kwargs.get("target_url") or "")
    comment_text = str(kwargs.get("comment_text") or "🔥")

    # استخدم V6 multi لو فيه أكتر من رابط أو V5 compound
    if target_url and "_exec_split_targets" in globals():
        targets = _exec_split_targets(target_url)
        if len(targets) > 1 and "_exec_multi_target_pipeline" in globals():
            sub = await _exec_multi_target_pipeline(
                page, platform, action, target_url, comment_text=comment_text
            )
            report.update({k: sub.get(k) for k in ("ok", "status", "error_class", "results") if k in sub})
            report["steps"].append("multi_v6")
            return report

    if "_exec_engine_v5_entry" in globals():
        sub = await _exec_engine_v5_entry(
            page, platform, action, comment_text=comment_text, target_url=target_url
        )
        report["ok"] = bool(sub.get("ok"))
        report["status"] = sub.get("status") or ""
        report["error_class"] = sub.get("error_class") or ""
        report["steps"].append("v5")
        report["sub"] = {k: sub.get(k) for k in ("steps", "methods_ok", "engine") if k in sub}
    elif "_exec_engine_v4_boost" in globals():
        sub = await _exec_engine_v4_boost(page, platform, action, comment_text=comment_text)
        report["ok"] = bool(sub.get("ok"))
        report["status"] = sub.get("status") or ""
        report["error_class"] = (
            _exec_classify_error(str(report["status"])) if "_exec_classify_error" in globals() else ""
        )
        report["steps"].append("v4")
    else:
        report["status"] = "no_lower_engine"
        report["error_class"] = "failed"

    # استرداد مرة واحدة لو فشل مش login/captcha
    if (not report["ok"]) and report.get("error_class") not in {
        "login_required", "captcha", "region_block", "rate_limit"
    }:
        if "_exec_recover_page" in globals():
            try:
                rec = await _exec_recover_page(page, target_url)
                report["steps"].append(f"recover:{rec.get('steps')}")
            except Exception:
                pass
            await _v7_human_pause(0.8, 1.5)
            if "_exec_engine_v5_entry" in globals():
                sub2 = await _exec_engine_v5_entry(
                    page, platform, action, comment_text=comment_text, target_url=target_url
                )
                if sub2.get("ok"):
                    report["ok"] = True
                    report["status"] = "done:v7_recover"
                    report["error_class"] = "none"
                    report["steps"].append("v5_retry")
    return report


_prev_v6_wrap = globals().get("_exec_engine_wrap_execute_v6") or globals().get(
    "_exec_engine_wrap_execute_v5"
)


async def _exec_engine_wrap_execute_v7(self, action: str, target_url: str, page=None, **kwargs):
    if _prev_v6_wrap:
        try:
            ok, data = await _prev_v6_wrap(self, action, target_url, page=page, **kwargs)
        except Exception as e:
            ok, data = False, {"status": f"wrap_error:{type(e).__name__}"}
    else:
        original = getattr(self, "_exec_original_execute_task", None)
        if original is None:
            ok, data = False, {"status": "no_original"}
        else:
            try:
                result = await original(action, target_url, page=page, **kwargs)
            except TypeError:
                result = await original(self, action, target_url, page=page, **kwargs)
            if isinstance(result, tuple):
                ok, data = result[0], result[1] if len(result) > 1 else {}
            else:
                ok, data = bool(result), {}

    if not isinstance(data, dict):
        data = {}
    if ok:
        data.setdefault("error_class", "none")
        return True, data

    err = data.get("error_class") or ""
    if err in {"login_required", "captcha", "region_block", "automation_block", "rate_limit"}:
        return False, data
    if page is None:
        return False, data

    platform = getattr(self, "name", None) or getattr(self, "platform", None) or ""
    if not platform:
        cls = self.__class__.__name__.lower()
        for p in ("tiktok", "instagram", "vk", "youtube", "twitter", "rutube", "max", "facebook", "avito"):
            if p in cls:
                platform = p
                break

    boost = await _v7_engine_entry(
        page, platform, action,
        comment_text=kwargs.get("comment_text") or "🔥",
        target_url=target_url,
    )
    data["engine_v7"] = boost
    if boost.get("ok"):
        data["status"] = boost.get("status") or "done:engine_v7"
        data["engine_path"] = "execution_engine_v7"
        data["error_class"] = "none"
        return True, data
    data["engine_path"] = str(data.get("engine_path") or "") + "+v7_failed"
    data["error_class"] = boost.get("error_class") or err or "failed"
    data["status"] = boost.get("status") or data.get("status") or "failed"
    return False, data


def _reinstall_engine_v7():
    skill_classes = [
        globals().get(n)
        for n in (
            "TikTokSkill", "InstagramSkill", "VKSkill", "YouTubeSkill",
            "TwitterSkill", "RutubeSkill", "MaxSkill", "FacebookSkill",
            "AvitoSkill", "GenericWebSkill",
        )
        if globals().get(n) is not None
    ]
    for cls in skill_classes:
        if not hasattr(cls, "execute_task"):
            continue
        if not hasattr(cls, "_exec_original_execute_task"):
            cls._exec_original_execute_task = cls.execute_task

        async def _bound(self, action: str, target_url: str, page=None, **kwargs):
            return await _exec_engine_wrap_execute_v7(self, action, target_url, page=page, **kwargs)

        cls.execute_task = _bound
        cls._exec_engine_v7_installed = True
        logger.info("⚡ EXECUTION_ENGINE_V7 wrapped: %s", cls.__name__)


try:
    _exec_engine_wrap_execute_v6 = _exec_engine_wrap_execute_v7
    _reinstall_engine_v7()
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V7)
except Exception as _v7e:
    logger.warning("V7 install failed: %s", _v7e)



# ==========================================================
# EXECUTION_ENGINE_V8 — تفكير + منصات أكثر + سكرين جودة + طرق متعددة
# Additive only
# ==========================================================

EXECUTION_ENGINE_V8 = "execution-engine-v8"

# ---------- مبدأ التفكير (Decision Brain) ----------
PLATFORM_HINTS_V8 = {
    "vk": ["vk.com", "vk.ru", "m.vk.", "vkontakte"],
    "instagram": ["instagram.com", "instagr.am"],
    "tiktok": ["tiktok.com", "vm.tiktok"],
    "youtube": ["youtube.com", "youtu.be", "music.youtube"],
    "twitter": ["twitter.com", "x.com"],
    "x": ["x.com", "twitter.com"],
    "rutube": ["rutube.ru"],
    "telegram": ["t.me", "telegram.me", "telegram.org"],
    "max": ["max.ru", "oneme.ru"],
    "facebook": ["facebook.com", "fb.com", "fb.watch"],
    "ok": ["ok.ru", "odnoklassniki"],
    "likee": ["likee.video", "likee.com", "like.video"],
    "linkedin": ["linkedin.com"],
    "pinterest": ["pinterest.com", "pin.it"],
    "twitch": ["twitch.tv"],
    "reddit": ["reddit.com"],
    "discord": ["discord.com", "discord.gg"],
    "avito": ["avito.ru"],
    "ozon": ["ozon.ru"],
    "yandex": ["yandex.ru", "maps.yandex"],
    "google_maps": ["google.com/maps", "maps.app.goo.gl", "goo.gl/maps"],
}

ACTION_HINTS_V8 = {
    "subscribe": ["subscribe", "follow", "подпис", "фоллов", "вступ", "join", "следить"],
    "like": ["like", "лайк", "нрав", "heart", "❤", "❤️"],
    "comment": ["comment", "коммент", "написать", "оставить отзыв"],
    "repost": ["repost", "репост", "share", "подел", "ретвит", "retweet"],
    "view": ["view", "watch", "смотр", "просмотр"],
    "review": ["review", "отзыв", "оценк", "stars", "рейтинг"],
    "register": ["register", "регистр", "sign up", "создать аккаунт"],
}


def _v8_think_platform(url: str, text: str = "") -> str:
    blob = f"{url or ''} {text or ''}".lower()
    scores = {}
    for plat, keys in PLATFORM_HINTS_V8.items():
        scores[plat] = sum(1 for k in keys if k in blob)
    best = max(scores, key=scores.get)
    if scores[best] <= 0:
        return "website"
    if best == "x":
        return "twitter"
    return best


def _v8_think_action(text: str, url: str = "") -> str:
    blob = f"{text or ''} {url or ''}".lower()
    scores = {}
    for act, keys in ACTION_HINTS_V8.items():
        scores[act] = sum(1 for k in keys if k in blob)
    # URL shape boosts
    ul = (url or "").lower()
    if "/reel/" in ul or "/video/" in ul or "/p/" in ul or "/status/" in ul or "wall" in ul:
        scores["like"] = scores.get("like", 0) + 2
    if any(x in ul for x in ("/channel/", "/@", "public", "club", "/user/")) and "video" not in ul:
        scores["subscribe"] = scores.get("subscribe", 0) + 2
    best = max(scores, key=scores.get) if scores else "unknown"
    if scores.get(best, 0) <= 0:
        return "unknown"
    return best


def _v8_think(url: str, action: str = "", text: str = "") -> dict:
    """مبدأ تفكير: يستنتج منصة/فعل ويقرر استراتيجية."""
    plat = _v8_think_platform(url, text)
    act = (action or "").strip().lower() or _v8_think_action(text, url)
    strategy = []
    if act in {"like", "comment", "repost", "view"}:
        strategy += ["open_content", "dismiss", "primary_action", "verify_dom", "screenshot"]
    elif act in {"subscribe", "follow"}:
        strategy += ["open_profile", "dismiss", "follow_btn", "verify_following", "screenshot"]
    elif act in {"review", "register"}:
        strategy += ["open_form", "fill_or_click", "screenshot"]
    else:
        strategy += ["open", "dismiss", "best_effort", "screenshot"]
    return {
        "platform": plat,
        "action": act,
        "strategy": strategy,
        "engine": EXECUTION_ENGINE_V8,
    }


# ---------- سكرين بجودة ----------
async def _v8_screenshot_quality(page, path: str, *, full_page: bool = False) -> dict:
    """
    يلتقط سكرين ويقيّم الجودة بشكل خفيف:
    - الملف موجود
    - الحجم > 8KB
    - مش صفحة login/captcha إن أمكن
    """
    out = {"ok": False, "path": path, "bytes": 0, "flags": [], "status": "pending"}
    if page is None:
        out["status"] = "no_page"
        return out
    try:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        # أخفِ كيرسور / انتظر استقرار بسيط
        try:
            await page.wait_for_timeout(400)
        except Exception:
            pass
        await page.screenshot(path=path, full_page=full_page, type="jpeg", quality=85)
        fp = Path(path)
        size = fp.stat().st_size if fp.exists() else 0
        out["bytes"] = size
        if size < 8000:
            out["flags"].append("too_small")
            out["status"] = "low_quality"
            return out
        # health flags
        if "_v7_session_health" in globals():
            h = await _v7_session_health(page)
            out["flags"].extend(h.get("flags") or [])
            if "login_required" in out["flags"]:
                out["status"] = "login_in_shot"
                return out
            if "captcha" in out["flags"]:
                out["status"] = "captcha_in_shot"
                return out
        out["ok"] = True
        out["status"] = "ok"
        return out
    except Exception as e:
        out["status"] = f"exception:{type(e).__name__}"
        return out


async def _v8_proof_shots(page, platform: str, action: str, prefix: str = "proof") -> list:
    """عدة سكرينات: viewport + partial scroll — أفضل إثبات."""
    shots = []
    ts = int(time.time() * 1000) if "time" in dir() else 0
    try:
        import time as _time
        ts = int(_time.time() * 1000)
    except Exception:
        ts = 0
    base = Path("data/proofs")
    base.mkdir(parents=True, exist_ok=True)
    p1 = str(base / f"{prefix}_{platform}_{action}_{ts}_main.jpg")
    r1 = await _v8_screenshot_quality(page, p1, full_page=False)
    shots.append(r1)
    try:
        await page.mouse.wheel(0, 600)
        await asyncio.sleep(0.4)
    except Exception:
        pass
    p2 = str(base / f"{prefix}_{platform}_{action}_{ts}_scroll.jpg")
    r2 = await _v8_screenshot_quality(page, p2, full_page=False)
    shots.append(r2)
    return shots


# ---------- حزم محددات إضافية لمنصات ----------
V8_SELECTORS = {
    "ok": {
        "subscribe": [
            'button:has-text("Подписаться")',
            'button:has-text("Дружить")',
            '[data-l*="join"]',
            'a:has-text("Подписаться")',
        ],
        "like": [
            'button[aria-label*="Класс"]',
            '[data-l*="like"]',
            'button:has-text("Класс")',
            '.widget_cnt',
        ],
        "comment": [
            'textarea',
            '[contenteditable="true"]',
            'button:has-text("Комментировать")',
        ],
        "repost": [
            'button:has-text("Поделиться")',
            '[data-l*="share"]',
            'button:has-text("Репост")',
        ],
    },
    "likee": {
        "subscribe": [
            'button:has-text("Follow")',
            'button:has-text("Подписаться")',
            '[class*="follow"]',
        ],
        "like": [
            '[class*="like"]',
            'button[aria-label*="Like"]',
            'div[class*="Like"]',
        ],
        "comment": ['textarea', '[placeholder*="comment" i]', '[placeholder*="коммент" i]'],
        "repost": ['[class*="share"]', 'button:has-text("Share")'],
    },
    "linkedin": {
        "subscribe": [
            'button:has-text("Follow")',
            'button:has-text("Connect")',
            'button[aria-label*="Follow"]',
        ],
        "like": [
            'button[aria-label*="React"]',
            'button:has-text("Like")',
            'button[aria-label*="Like"]',
        ],
        "comment": ['button:has-text("Comment")', '.comments-comment-box textarea', 'div[role="textbox"]'],
        "repost": ['button:has-text("Repost")', 'button[aria-label*="Repost"]'],
    },
    "pinterest": {
        "subscribe": ['button:has-text("Follow")', 'div[data-test-id="follow-button"]'],
        "like": ['button[aria-label*="React"]', 'button[aria-label*="Save"]', 'div[data-test-id="save-button"]'],
        "repost": ['div[data-test-id="save-button"]', 'button:has-text("Save")'],
        "view": ['div[data-test-id="pin-closeup-image"]'],
    },
    "twitch": {
        "subscribe": ['button:has-text("Follow")', 'button[aria-label*="Follow"]', 'button:has-text("Subscribe")'],
        "like": ['button[aria-label*="like" i]', 'button:has-text("Cheer")'],
        "view": ['video', 'button[aria-label*="Play"]'],
    },
    "facebook": {
        "subscribe": ['div[aria-label="Follow"]', 'div[aria-label="Like"]', 'div[aria-label="Join"]'],
        "like": ['div[aria-label="Like"]', 'div[aria-label="Love"]', '[aria-label="Нравится"]'],
        "comment": ['div[aria-label*="Write a comment"]', 'div[role="textbox"]'],
        "repost": ['div[aria-label="Share"]', 'div[aria-label="Поделиться"]'],
    },
}


async def _v8_click_first(page, selectors: list, timeout: int = 2500) -> dict:
    for sel in selectors or []:
        try:
            loc = page.locator(sel).first
            if await loc.count() == 0:
                continue
            if not await loc.is_visible():
                continue
            await loc.scroll_into_view_if_needed(timeout=timeout)
            await asyncio.sleep(random.uniform(0.15, 0.4))
            await loc.click(timeout=timeout)
            return {"ok": True, "selector": sel}
        except Exception:
            continue
    return {"ok": False, "selector": ""}


async def _v8_multi_method_action(page, platform: str, action: str, comment_text: str = "🔥") -> dict:
    """
    عدة طرق لنفس الفعل:
    1) selectors pack
    2) text engines V5/V4
    3) JS text scan
    """
    report = {
        "ok": False,
        "status": "pending",
        "methods_ok": [],
        "methods_fail": [],
        "platform": platform,
        "action": action,
    }
    plat = (platform or "").lower()
    if plat == "x":
        plat = "twitter"
    act = (action or "").lower()

    # طريقة 1: حزمة V8
    pack = (V8_SELECTORS.get(plat) or {}).get(act) or []
    if pack:
        r = await _v8_click_first(page, pack)
        if r.get("ok"):
            report["methods_ok"].append(f"v8_sel:{r.get('selector')[:40]}")
            report["ok"] = True
            report["status"] = "done:v8_selectors"
        else:
            report["methods_fail"].append("v8_selectors")

    # طريقة 2: محركات سابقة
    if not report["ok"] and "_exec_engine_v5_entry" in globals():
        try:
            sub = await _exec_engine_v5_entry(page, plat, act, comment_text=comment_text)
            if sub.get("ok"):
                report["ok"] = True
                report["status"] = sub.get("status") or "done:v5"
                report["methods_ok"].append("v5")
            else:
                report["methods_fail"].append("v5")
        except Exception:
            report["methods_fail"].append("v5_exc")

    # طريقة 3: JS نص عام
    if not report["ok"]:
        labels = {
            "subscribe": ["Follow", "Subscribe", "Подписаться", "Join", "Дружить", "Follow"],
            "like": ["Like", "Нравится", "Класс", "❤"],
            "repost": ["Share", "Repost", "Поделиться", "Репост"],
            "comment": ["Comment", "Коммент"],
        }.get(act, [])
        try:
            clicked = await page.evaluate(
                """(labels) => {
                    const btns = [...document.querySelectorAll('button, div[role="button"], a, span')];
                    for (const lab of labels) {
                        const el = btns.find(b => (b.innerText || b.getAttribute('aria-label') || '').trim().includes(lab));
                        if (el) { el.click(); return lab; }
                    }
                    return '';
                }""",
                labels,
            )
            if clicked:
                report["ok"] = True
                report["status"] = f"done:js_text:{clicked}"
                report["methods_ok"].append(f"js:{clicked}")
            else:
                report["methods_fail"].append("js_text")
        except Exception:
            report["methods_fail"].append("js_exc")

    # تعليق: كتابة نص
    if act == "comment" and report.get("ok") is False:
        try:
            box = page.locator('textarea, [contenteditable="true"], div[role="textbox"]').first
            if await box.count():
                await box.click(timeout=2000)
                await box.fill(comment_text[:180])
                await asyncio.sleep(0.3)
                for sel in ['button:has-text("Post")', 'button:has-text("Send")', 'button:has-text("Отправить")', 'button[type="submit"]']:
                    try:
                        b = page.locator(sel).first
                        if await b.count() and await b.is_visible():
                            await b.click(timeout=2000)
                            report["ok"] = True
                            report["status"] = "done:comment_type"
                            report["methods_ok"].append("comment_type")
                            break
                    except Exception:
                        continue
        except Exception:
            report["methods_fail"].append("comment_type")

    if not report["ok"]:
        report["status"] = "control_not_found"
        report["error_class"] = "control_not_found"
    else:
        report["error_class"] = "none"
    return report


# ---------- مهارات منصات إضافية (Additive classes) ----------
class OKSkill(BaseSkill if "BaseSkill" in dir() else object):
    name = "ok"
    platform = "ok"

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs):
        if page is None:
            return False, {"status": "no_page"}
        try:
            await page.goto(target_url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(random.uniform(1.0, 2.0))
        except Exception as e:
            return False, {"status": f"nav:{type(e).__name__}"}
        if "_exec_dismiss_hard" in globals():
            await _exec_dismiss_hard(page, rounds=2)
        r = await _v8_multi_method_action(page, "ok", action, kwargs.get("comment_text") or "🔥")
        shots = await _v8_proof_shots(page, "ok", action)
        r["proofs"] = shots
        return bool(r.get("ok")), r


class LikeeSkill(BaseSkill if "BaseSkill" in dir() else object):
    name = "likee"
    platform = "likee"

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs):
        if page is None:
            return False, {"status": "no_page"}
        try:
            await page.goto(target_url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(random.uniform(1.0, 2.0))
        except Exception as e:
            return False, {"status": f"nav:{type(e).__name__}"}
        if "_exec_dismiss_hard" in globals():
            await _exec_dismiss_hard(page, rounds=2)
        r = await _v8_multi_method_action(page, "likee", action, kwargs.get("comment_text") or "🔥")
        r["proofs"] = await _v8_proof_shots(page, "likee", action)
        return bool(r.get("ok")), r


class LinkedInSkill(BaseSkill if "BaseSkill" in dir() else object):
    name = "linkedin"
    platform = "linkedin"

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs):
        if page is None:
            return False, {"status": "no_page"}
        try:
            await page.goto(target_url, wait_until="domcontentloaded", timeout=35000)
            await asyncio.sleep(random.uniform(1.2, 2.4))
        except Exception as e:
            return False, {"status": f"nav:{type(e).__name__}"}
        if "_exec_dismiss_hard" in globals():
            await _exec_dismiss_hard(page, rounds=2)
        r = await _v8_multi_method_action(page, "linkedin", action, kwargs.get("comment_text") or "Great!")
        r["proofs"] = await _v8_proof_shots(page, "linkedin", action)
        return bool(r.get("ok")), r


class PinterestSkill(BaseSkill if "BaseSkill" in dir() else object):
    name = "pinterest"
    platform = "pinterest"

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs):
        if page is None:
            return False, {"status": "no_page"}
        try:
            await page.goto(target_url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(random.uniform(1.0, 2.0))
        except Exception as e:
            return False, {"status": f"nav:{type(e).__name__}"}
        r = await _v8_multi_method_action(page, "pinterest", action, kwargs.get("comment_text") or "🔥")
        r["proofs"] = await _v8_proof_shots(page, "pinterest", action)
        return bool(r.get("ok")), r


class TwitchSkill(BaseSkill if "BaseSkill" in dir() else object):
    name = "twitch"
    platform = "twitch"

    async def execute_task(self, action: str, target_url: str, page=None, **kwargs):
        if page is None:
            return False, {"status": "no_page"}
        try:
            await page.goto(target_url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(random.uniform(1.0, 2.0))
        except Exception as e:
            return False, {"status": f"nav:{type(e).__name__}"}
        r = await _v8_multi_method_action(page, "twitch", action, kwargs.get("comment_text") or "🔥")
        r["proofs"] = await _v8_proof_shots(page, "twitch", action)
        return bool(r.get("ok")), r


# تسجيل في SkillManager إن وجد
def _v8_register_extra_skills():
    sm = globals().get("SkillManager")
    if sm is None:
        return
    mapping = {
        "ok": OKSkill,
        "odnoklassniki": OKSkill,
        "likee": LikeeSkill,
        "linkedin": LinkedInSkill,
        "pinterest": PinterestSkill,
        "twitch": TwitchSkill,
    }
    # لو SkillManager له dict skills أو register
    try:
        if not hasattr(sm, "_V8_EXTRA"):
            sm._V8_EXTRA = mapping
        for key, cls in mapping.items():
            if hasattr(sm, "register_skill"):
                try:
                    sm.register_skill(key, cls)
                except Exception:
                    pass
        logger.info("🔧 V8 extra skills registered: %s", list(mapping.keys()))
    except Exception as e:
        logger.debug("V8 register: %s", e)


try:
    _v8_register_extra_skills()
except Exception:
    pass


# لف route_task بالتفكير + سكرين
if hasattr(SkillManager, "route_task"):
    _route_v8_prev = SkillManager.route_task

    async def _route_task_v8(self, platform, action, target_url, page=None, **kwargs):
        thought = _v8_think(str(target_url or ""), str(action or ""), str(kwargs.get("task_text") or ""))
        # لو المنصة other/website وحُددت من الرابط
        plat = str(platform or thought["platform"] or "").lower()
        if plat in {"other", "website", "", "unknown"}:
            plat = thought["platform"]
        act = str(action or thought["action"] or "").lower()
        if act in {"", "unknown", "غير معروف"}:
            act = thought["action"]

        # skills إضافية
        extra = getattr(self.__class__, "_V8_EXTRA", None) or getattr(SkillManager, "_V8_EXTRA", {})
        if plat in extra and page is not None:
            try:
                skill = extra[plat]()
                ok, data = await skill.execute_task(act, target_url, page=page, **kwargs)
                if isinstance(data, dict):
                    data["thought"] = thought
                    data["engine_path"] = "v8_extra_skill"
                if ok:
                    return True, data
            except Exception as e:
                logger.warning("V8 extra skill %s: %s", plat, e)

        ok, data = await _route_v8_prev(self, plat, act, target_url, page=page, **kwargs)
        if not isinstance(data, dict):
            data = {"status": str(data)}
        data["thought"] = thought

        # لو فشل → multi-method V8
        if (not ok) and page is not None:
            if data.get("error_class") not in {"login_required", "captcha", "region_block"}:
                boost = await _v8_multi_method_action(
                    page, plat, act, str(kwargs.get("comment_text") or "🔥")
                )
                data["v8_boost"] = boost
                if boost.get("ok"):
                    ok = True
                    data["status"] = boost.get("status")
                    data["error_class"] = "none"
                    data["engine_path"] = str(data.get("engine_path") or "") + "+v8_multi"

        # سكرين إثبات
        if page is not None and ok:
            try:
                shots = await _v8_proof_shots(page, plat, act)
                data["proof_shots"] = shots
                good = [s for s in shots if s.get("ok")]
                if good:
                    data["screenshot_path"] = good[0].get("path")
                    data["proof_quality"] = "ok"
                else:
                    data["proof_quality"] = "weak"
            except Exception as e:
                data["proof_shot_error"] = str(e)[:120]

        return ok, data

    SkillManager.route_task = _route_task_v8
    logger.info("⚡ route_task V8 think+multi+proof")


# لف execute_task النهائي V8 فوق V7
_prev_v7_wrap = globals().get("_exec_engine_wrap_execute_v7") or globals().get(
    "_exec_engine_wrap_execute_v6"
)


async def _exec_engine_wrap_execute_v8(self, action: str, target_url: str, page=None, **kwargs):
    if _prev_v7_wrap:
        try:
            ok, data = await _prev_v7_wrap(self, action, target_url, page=page, **kwargs)
        except Exception as e:
            ok, data = False, {"status": f"wrap_error:{type(e).__name__}"}
    else:
        ok, data = False, {"status": "no_prev"}

    if not isinstance(data, dict):
        data = {}
    thought = _v8_think(str(target_url or ""), str(action or ""))
    data["thought"] = thought

    if ok:
        if page is not None and not data.get("proof_shots"):
            try:
                shots = await _v8_proof_shots(
                    page, thought.get("platform") or "", thought.get("action") or action
                )
                data["proof_shots"] = shots
                good = [s for s in shots if s.get("ok")]
                if good:
                    data["screenshot_path"] = good[0].get("path")
            except Exception:
                pass
        data.setdefault("error_class", "none")
        return True, data

    if page is None:
        return False, data
    if data.get("error_class") in {"login_required", "captcha", "region_block", "rate_limit"}:
        return False, data

    plat = thought.get("platform") or getattr(self, "name", "") or ""
    boost = await _v8_multi_method_action(
        page, plat, thought.get("action") or action, str(kwargs.get("comment_text") or "🔥")
    )
    data["v8_multi"] = boost
    if boost.get("ok"):
        data["status"] = boost.get("status") or "done:v8"
        data["error_class"] = "none"
        data["engine_path"] = "execution_engine_v8"
        try:
            data["proof_shots"] = await _v8_proof_shots(page, plat, action)
        except Exception:
            pass
        return True, data

    data["error_class"] = boost.get("error_class") or data.get("error_class") or "failed"
    return False, data


def _reinstall_engine_v8():
    for n in (
        "TikTokSkill", "InstagramSkill", "VKSkill", "YouTubeSkill",
        "TwitterSkill", "RutubeSkill", "MaxSkill", "FacebookSkill",
        "AvitoSkill", "GenericWebSkill", "OKSkill", "LikeeSkill",
        "LinkedInSkill", "PinterestSkill", "TwitchSkill",
    ):
        cls = globals().get(n)
        if cls is None or not hasattr(cls, "execute_task"):
            continue
        if not hasattr(cls, "_exec_original_execute_task"):
            cls._exec_original_execute_task = cls.execute_task

        async def _bound(self, action: str, target_url: str, page=None, **kwargs):
            return await _exec_engine_wrap_execute_v8(self, action, target_url, page=page, **kwargs)

        cls.execute_task = _bound
        cls._exec_engine_v8_installed = True
        logger.info("⚡ EXECUTION_ENGINE_V8 wrapped: %s", cls.__name__)


try:
    _exec_engine_wrap_execute_v7 = _exec_engine_wrap_execute_v8
    _reinstall_engine_v8()
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V8)
except Exception as _v8e:
    logger.warning("V8 install failed: %s", _v8e)



# ==========================================================
# EXECUTION_ENGINE_V9 — Auto-Healing + Proxy Routing + Proof CV
# Additive only — ربع ساعة تطوير مركز على التنفيذ
# ==========================================================

EXECUTION_ENGINE_V9 = "execution-engine-v9"

import hashlib
from typing import Any, Optional

# =========================
# 1) SELECTORS AUTO-HEALING
# =========================

_SELECTORS_JSON_PATH = Path("data/selectors.json")
_SELECTORS_CACHE: dict = {}


def _v9_load_selectors() -> dict:
    global _SELECTORS_CACHE
    if _SELECTORS_CACHE:
        return _SELECTORS_CACHE
    try:
        if _SELECTORS_JSON_PATH.is_file():
            _SELECTORS_CACHE = json.loads(
                _SELECTORS_JSON_PATH.read_text(encoding="utf-8")
            )
        else:
            _SELECTORS_CACHE = {}
    except Exception:
        _SELECTORS_CACHE = {}
    return _SELECTORS_CACHE


def _v9_save_selectors(data: dict) -> None:
    global _SELECTORS_CACHE
    try:
        _SELECTORS_JSON_PATH.parent.mkdir(parents=True, exist_ok=True)
        _SELECTORS_JSON_PATH.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        _SELECTORS_CACHE = data
        logger.info("🩹 selectors.json updated (%s keys)", len(data))
    except Exception as e:
        logger.warning("selectors save failed: %s", e)


def _v9_selector_key(platform: str, action: str) -> str:
    return f"{(platform or 'web').lower()}::{(action or 'act').lower()}"


async def _v9_dom_mine_candidates(page, action: str) -> list:
    """
    يحلل DOM ويستخرج مرشحي محددات للعناصر القابلة للنقر
    المرتبطة بالفعل (نص/aria) — Auto-Healing بدون LLM خارجي إجباري.
    """
    labels_map = {
        "subscribe": [
            "follow", "subscribe", "подпис", "вступ", "join", "дружить",
            "следить", "following", "вы подписаны",
        ],
        "like": [
            "like", "лайк", "нрав", "класс", "heart", "❤", "love", "реакц",
        ],
        "comment": [
            "comment", "коммент", "написать", "write a comment", "ответить",
        ],
        "repost": [
            "share", "repost", "репост", "подел", "retweet", "переслать",
        ],
        "view": ["play", "watch", "смотр", "смотреть"],
    }
    labels = labels_map.get((action or "").lower(), ["ok", "submit", "send", "отправить"])
    try:
        cands = await page.evaluate(
            """(labels) => {
                const out = [];
                const nodes = document.querySelectorAll(
                    'button, a, div[role="button"], span[role="button"], input[type="submit"]'
                );
                const take = Math.min(nodes.length, 400);
                for (let i = 0; i < take; i++) {
                    const el = nodes[i];
                    const text = (el.innerText || el.textContent || '').trim().slice(0, 80);
                    const aria = (el.getAttribute('aria-label') || '').trim().slice(0, 80);
                    const testid = el.getAttribute('data-testid') || el.getAttribute('data-e2e') || '';
                    const cls = (el.className && typeof el.className === 'string')
                        ? el.className.split(/\\s+/).slice(0, 3).join('.')
                        : '';
                    const href = el.getAttribute('href') || '';
                    const blob = (text + ' ' + aria + ' ' + testid).toLowerCase();
                    const hit = labels.some(l => blob.includes(String(l).toLowerCase()));
                    if (!hit && !testid) continue;
                    let sel = '';
                    if (testid) {
                        if (el.getAttribute('data-e2e'))
                            sel = `[data-e2e="${el.getAttribute('data-e2e')}"]`;
                        else if (el.getAttribute('data-testid'))
                            sel = `[data-testid="${el.getAttribute('data-testid')}"]`;
                    } else if (aria) {
                        sel = `${el.tagName.toLowerCase()}[aria-label="${aria.replace(/"/g, '\\\\"')}"]`;
                    } else if (text && text.length < 40) {
                        sel = `${el.tagName.toLowerCase()}:has-text("${text.slice(0, 30).replace(/"/g, '')}")`;
                    } else if (cls) {
                        sel = `${el.tagName.toLowerCase()}.${cls.replace(/\\./g, '.')}`;
                    }
                    if (!sel) continue;
                    out.push({
                        selector: sel,
                        text: text,
                        aria: aria,
                        testid: testid,
                        href: href.slice(0, 120),
                        score: (testid ? 5 : 0) + (hit ? 3 : 0) + (aria ? 1 : 0),
                    });
                }
                out.sort((a, b) => b.score - a.score);
                return out.slice(0, 12);
            }""",
            labels,
        )
        return cands or []
    except Exception as e:
        logger.debug("dom mine: %s", e)
        return []


async def _v9_auto_heal_and_click(page, platform: str, action: str) -> dict:
    """
    1) جرّب selectors.json المحفوظة
    2) لو فشلت → تعدين DOM
    3) أول نجاح يُحفظ في selectors.json
    """
    report = {
        "ok": False,
        "status": "pending",
        "healed": False,
        "selector": "",
        "candidates": 0,
    }
    key = _v9_selector_key(platform, action)
    store = _v9_load_selectors()
    known = list(store.get(key) or [])

    # 1) known
    for sel in known[:8]:
        try:
            loc = page.locator(sel).first
            if await loc.count() == 0:
                continue
            if not await loc.is_visible():
                continue
            await loc.scroll_into_view_if_needed(timeout=2000)
            await asyncio.sleep(random.uniform(0.1, 0.35))
            await loc.click(timeout=2500)
            report["ok"] = True
            report["status"] = "done:known_selector"
            report["selector"] = sel
            return report
        except Exception:
            continue

    # 2) mine DOM
    cands = await _v9_dom_mine_candidates(page, action)
    report["candidates"] = len(cands)
    for c in cands:
        sel = c.get("selector") or ""
        if not sel:
            continue
        try:
            loc = page.locator(sel).first
            if await loc.count() == 0:
                continue
            await loc.scroll_into_view_if_needed(timeout=2000)
            await asyncio.sleep(random.uniform(0.1, 0.3))
            await loc.click(timeout=2500, force=True)
            # نجاح → احفظ
            arr = list(store.get(key) or [])
            if sel not in arr:
                arr.insert(0, sel)
            store[key] = arr[:15]
            store[f"{key}::meta"] = {
                "text": c.get("text"),
                "aria": c.get("aria"),
                "updated_ts": int(time.time()),
            }
            _v9_save_selectors(store)
            report["ok"] = True
            report["healed"] = True
            report["status"] = "done:auto_healed"
            report["selector"] = sel
            return report
        except Exception:
            continue

    report["status"] = "heal_failed"
    return report


# =========================
# 2) DYNAMIC PROXY ROUTING
# =========================

_PROXIES_PATH = Path("data/proxies.json")
_PROXY_BINDINGS_PATH = Path("data/proxy_bindings.json")
_V9_PROXY_STATE: dict = {"proxies": [], "bindings": {}, "rr": 0}


def _v9_load_proxy_pool() -> list:
    """
    صيغة data/proxies.json:
    [
      {"server": "http://user:pass@host:port", "country": "ru", "type": "residential", "label": "ru1"},
      {"server": "http://host:port", "country": "fr", "type": "datacenter"}
    ]
    أو من البيئة: PROXY_POOL=url1,url2
    """
    pool = []
    try:
        if _PROXIES_PATH.is_file():
            raw = json.loads(_PROXIES_PATH.read_text(encoding="utf-8"))
            if isinstance(raw, list):
                pool = raw
            elif isinstance(raw, dict):
                pool = raw.get("proxies") or raw.get("pool") or []
    except Exception as e:
        logger.debug("proxy file: %s", e)
    env_pool = (os.environ.get("PROXY_POOL") or "").strip()
    if env_pool:
        for part in env_pool.split(","):
            part = part.strip()
            if part:
                pool.append({"server": part, "country": os.environ.get("PROXY_COUNTRY") or "xx"})
    single = (os.environ.get("VK_PROXY") or os.environ.get("HTTP_PROXY") or os.environ.get("PROXY_URL") or "").strip()
    if single and not any((p.get("server") == single) for p in pool):
        pool.append({"server": single, "country": os.environ.get("PROXY_COUNTRY") or "ru"})
    return pool


def _v9_load_bindings() -> dict:
    try:
        if _PROXY_BINDINGS_PATH.is_file():
            return json.loads(_PROXY_BINDINGS_PATH.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _v9_save_bindings(bindings: dict) -> None:
    try:
        _PROXY_BINDINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
        _PROXY_BINDINGS_PATH.write_text(
            json.dumps(bindings, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    except Exception as e:
        logger.debug("bind save: %s", e)


# مطابقة جغرافية تقريبية لمنصة/كوكيز
_PLATFORM_COUNTRY_PREF = {
    "vk": ["ru", "by", "kz", "ua"],
    "max": ["ru"],
    "rutube": ["ru"],
    "yandex": ["ru"],
    "ok": ["ru"],
    "avito": ["ru"],
    "ozon": ["ru"],
    "tiktok": ["fr", "us", "gb", "de", "ru"],
    "instagram": ["us", "gb", "de", "fr", "eg", "sa"],
    "twitter": ["us", "gb"],
    "x": ["us", "gb"],
    "youtube": ["us", "eg", "ru", "de"],
    "facebook": ["us", "gb"],
}


def _v9_bind_proxy_for_session(session_key: str, platform: str) -> Optional[dict]:
    """
    يربط كل session_key (مثلاً platform+account) ببروكسي ثابت.
    لا يغيّر الـIP عشوائيًا لنفس الجلسة → يقلل region_block.
    """
    pool = _v9_load_proxy_pool()
    if not pool:
        return None
    bindings = _v9_load_bindings()
    sk = session_key or platform or "default"
    if sk in bindings:
        server = bindings[sk].get("server")
        for p in pool:
            if p.get("server") == server:
                return p
        # binding قديم غير موجود في الـpool
    prefs = _PLATFORM_COUNTRY_PREF.get((platform or "").lower(), [])
    ranked = []
    for p in pool:
        c = str(p.get("country") or "xx").lower()
        score = 0
        if c in prefs:
            score += 10 - prefs.index(c) if c in prefs else 5
        if str(p.get("type") or "").lower() == "residential":
            score += 3
        ranked.append((score, p))
    ranked.sort(key=lambda x: -x[0])
    chosen = ranked[0][1] if ranked else pool[0]
    bindings[sk] = {
        "server": chosen.get("server"),
        "country": chosen.get("country"),
        "type": chosen.get("type"),
        "platform": platform,
        "bound_ts": int(time.time()),
    }
    _v9_save_bindings(bindings)
    logger.info(
        "🌐 proxy bind session=%s platform=%s country=%s",
        sk,
        platform,
        chosen.get("country"),
    )
    return chosen


def _v9_fingerprint_for_country(country: str) -> dict:
    """بصمة متصفح متسقة مع الدولة (locale/timezone/lang)."""
    c = (country or "us").lower()
    table = {
        "ru": {
            "locale": "ru-RU",
            "languages": ["ru-RU", "ru", "en-US"],
            "timezone_id": "Europe/Moscow",
            "platform": "Win32",
        },
        "fr": {
            "locale": "fr-FR",
            "languages": ["fr-FR", "fr", "en-US"],
            "timezone_id": "Europe/Paris",
            "platform": "Win32",
        },
        "us": {
            "locale": "en-US",
            "languages": ["en-US", "en"],
            "timezone_id": "America/New_York",
            "platform": "Win32",
        },
        "gb": {
            "locale": "en-GB",
            "languages": ["en-GB", "en"],
            "timezone_id": "Europe/London",
            "platform": "Win32",
        },
        "de": {
            "locale": "de-DE",
            "languages": ["de-DE", "de", "en-US"],
            "timezone_id": "Europe/Berlin",
            "platform": "Win32",
        },
        "eg": {
            "locale": "ar-EG",
            "languages": ["ar-EG", "ar", "en-US"],
            "timezone_id": "Africa/Cairo",
            "platform": "Win32",
        },
    }
    return table.get(c) or table["us"]


async def _v9_apply_fingerprint(page, country: str) -> dict:
    fp = _v9_fingerprint_for_country(country)
    js = f"""
    (() => {{
      try {{
        Object.defineProperty(navigator, 'language', {{ get: () => '{fp["languages"][0]}' }});
        Object.defineProperty(navigator, 'languages', {{ get: () => {json.dumps(fp["languages"])} }});
        Object.defineProperty(navigator, 'platform', {{ get: () => '{fp["platform"]}' }});
      }} catch (e) {{}}
    }})();
    """
    try:
        await page.add_init_script(js)
    except Exception:
        pass
    try:
        await page.evaluate(js)
    except Exception:
        pass
    # timezone عبر CDP إن وجد
    try:
        client = await page.context.new_cdp_session(page)
        await client.send(
            "Emulation.setTimezoneOverride",
            {"timezoneId": fp["timezone_id"]},
        )
        await client.send(
            "Emulation.setLocaleOverride",
            {"locale": fp["locale"]},
        )
    except Exception:
        pass
    return fp


async def _v9_prepare_context_proxy(context, platform: str, session_key: str = "") -> dict:
    """
    يُستدعى عند تهيئة السياق إن أمكن.
    ملاحظة: Playwright غالبًا يضبط proxy عند launch — هنا نسجّل الربط + fingerprint للصفحة.
    """
    info = {"proxy": None, "fingerprint": None}
    proxy = _v9_bind_proxy_for_session(session_key or platform, platform)
    info["proxy"] = proxy
    if proxy:
        info["fingerprint"] = _v9_fingerprint_for_country(
            str(proxy.get("country") or "us")
        )
    return info


# =========================
# 3) CV / PROOF VALIDATION
# =========================

_SUCCESS_TEXT_MARKERS = {
    "subscribe": [
        "following", "subscribed", "вы подписаны", "подписан", "вы вступил",
        "friends", "message", "сообщение", "unfollow", "отписаться",
    ],
    "like": [
        "liked", "unlike", " assбрано", "you liked", "remove like",
    ],
    "repost": [
        "reposted", "shared", "вы поделились", "undo repost",
    ],
    "comment": [
        "view replies", "your comment", "ответить", "just now", "сейчас",
    ],
}


async def _v9_dom_proof_signals(page, action: str) -> dict:
    """تحقق من نص الصفحة أن الفعل نجح (بديل عملي لـ CV الثقيل)."""
    out = {"ok": False, "signals": [], "score": 0}
    markers = _SUCCESS_TEXT_MARKERS.get((action or "").lower(), [])
    try:
        blob = await page.evaluate(
            """() => {
                const t = (document.body && document.body.innerText || '').slice(0, 4000);
                const al = [...document.querySelectorAll('[aria-label]')]
                    .map(e => e.getAttribute('aria-label') || '').join(' ');
                return (t + ' ' + al).toLowerCase();
            }"""
        )
        blob = (blob or "").lower()
        for m in markers:
            if m.lower() in blob:
                out["signals"].append(m)
                out["score"] += 1
        # أزرار حالة
        if (action or "").lower() == "subscribe":
            if "подписан" in blob or "following" in blob or "вы подписаны" in blob:
                out["score"] += 2
        out["ok"] = out["score"] >= 1
    except Exception as e:
        out["error"] = str(e)[:100]
    return out


async def _v9_image_proof_stats(path: str) -> dict:
    """
    إحصائيات صورة خفيفة بدون torch:
    - حجم الملف
    - متوسط سطوع تقريبي عبر sample (لو Pillow متاح)
    """
    out = {"path": path, "bytes": 0, "brightness": None, "ok": False, "flags": []}
    try:
        fp = Path(path)
        if not fp.is_file():
            out["flags"].append("missing")
            return out
        out["bytes"] = fp.stat().st_size
        if out["bytes"] < 8000:
            out["flags"].append("too_small")
            return out
        if out["bytes"] > 6_000_000:
            out["flags"].append("too_large")
        try:
            from PIL import Image
            import io
            im = Image.open(fp).convert("L")
            im = im.resize((64, 64))
            pixels = list(im.getdata())
            avg = sum(pixels) / max(len(pixels), 1)
            out["brightness"] = round(avg, 2)
            if avg < 12:
                out["flags"].append("too_dark")
            elif avg > 243:
                out["flags"].append("too_white")
            else:
                out["ok"] = True
        except ImportError:
            # من غير Pillow نكتفي بالحجم
            out["ok"] = out["bytes"] >= 12000
            out["flags"].append("no_pillow")
        except Exception as e:
            out["flags"].append(f"img_err:{type(e).__name__}")
            out["ok"] = out["bytes"] >= 12000
    except Exception as e:
        out["flags"].append(str(e)[:80])
    return out


async def _v9_validate_proof(page, action: str, screenshot_paths: list) -> dict:
    """
    طبقة إثبات مركّبة:
    DOM signals + جودة الصورة
    """
    result = {
        "ok": False,
        "dom": {},
        "images": [],
        "score": 0,
        "status": "pending",
    }
    dom = await _v9_dom_proof_signals(page, action)
    result["dom"] = dom
    result["score"] += int(dom.get("score") or 0) * 2

    for pth in screenshot_paths or []:
        if not pth:
            continue
        path = pth if isinstance(pth, str) else (pth.get("path") if isinstance(pth, dict) else "")
        if not path:
            continue
        st = await _v9_image_proof_stats(path)
        result["images"].append(st)
        if st.get("ok"):
            result["score"] += 1
        if "too_dark" in st.get("flags", []) or "too_white" in st.get("flags", []):
            result["score"] -= 1

    if result["score"] >= 2 or (dom.get("ok") and any(i.get("ok") for i in result["images"])):
        result["ok"] = True
        result["status"] = "proof_accepted"
    elif dom.get("ok"):
        result["ok"] = True
        result["status"] = "proof_dom_only"
    else:
        result["status"] = "proof_weak"
    return result


# =========================
# 4) V9 ENGINE ENTRY
# =========================

async def _v9_engine_entry(page, platform: str, action: str, **kwargs) -> dict:
    report = {
        "engine": EXECUTION_ENGINE_V9,
        "platform": platform,
        "action": action,
        "ok": False,
        "status": "pending",
        "error_class": "",
        "steps": [],
        "proxy": None,
        "heal": None,
        "proof": None,
    }
    if page is None:
        report["status"] = "no_page"
        report["error_class"] = "no_page"
        return report

    session_key = str(kwargs.get("session_key") or platform or "default")
    proxy_info = _v9_bind_proxy_for_session(session_key, platform)
    report["proxy"] = proxy_info
    if proxy_info:
        try:
            fp = await _v9_apply_fingerprint(
                page, str(proxy_info.get("country") or "us")
            )
            report["fingerprint"] = fp
            report["steps"].append("fingerprint")
        except Exception:
            pass

    if "_exec_apply_stealth" in globals():
        try:
            await _exec_apply_stealth(page)
            report["steps"].append("stealth")
        except Exception:
            pass
    if "_exec_dismiss_hard" in globals():
        try:
            await _exec_dismiss_hard(page, rounds=2)
            report["steps"].append("dismiss")
        except Exception:
            pass

    target_url = str(kwargs.get("target_url") or "")
    if target_url:
        try:
            cur = (page.url or "").lower()
            if target_url.split("?")[0].lower() not in cur:
                await page.goto(target_url, wait_until="domcontentloaded", timeout=35000)
                await asyncio.sleep(random.uniform(0.8, 1.6))
                report["steps"].append("goto")
        except Exception as e:
            report["steps"].append(f"goto_fail:{type(e).__name__}")

    # health
    if "_v7_session_health" in globals():
        h = await _v7_session_health(page, platform)
        report["health"] = h
        if "login_required" in h.get("flags", []):
            report["status"] = "login_required"
            report["error_class"] = "login_required"
            return report
        if "captcha" in h.get("flags", []):
            if "_v7_try_inject_recaptcha" in globals():
                cap = await _v7_try_inject_recaptcha(page)
                report["captcha"] = cap
                if not cap.get("ok"):
                    report["status"] = "captcha"
                    report["error_class"] = "captcha"
                    return report
            else:
                report["status"] = "captcha"
                report["error_class"] = "captcha"
                return report
        if "region_block" in h.get("flags", []):
            report["status"] = "region_block"
            report["error_class"] = "region_block"
            return report

    # 1) auto-heal click
    heal = await _v9_auto_heal_and_click(page, platform, action)
    report["heal"] = heal
    report["steps"].append(heal.get("status"))

    acted = bool(heal.get("ok"))

    # 2) fallback multi-method V8/V5
    if not acted and "_v8_multi_method_action" in globals():
        sub = await _v8_multi_method_action(
            page, platform, action, str(kwargs.get("comment_text") or "🔥")
        )
        report["v8"] = sub
        acted = bool(sub.get("ok"))
        report["steps"].append(sub.get("status"))
    elif not acted and "_exec_engine_v5_entry" in globals():
        sub = await _exec_engine_v5_entry(
            page, platform, action,
            comment_text=kwargs.get("comment_text") or "🔥",
            target_url=target_url,
        )
        report["v5"] = sub
        acted = bool(sub.get("ok"))
        report["steps"].append(sub.get("status"))

    # screenshots + proof validation
    shots = []
    if "_v8_proof_shots" in globals():
        try:
            shots = await _v8_proof_shots(page, platform, action, prefix="v9")
            report["shots"] = shots
        except Exception as e:
            report["shot_err"] = str(e)[:100]
    paths = []
    for s in shots or []:
        if isinstance(s, dict) and s.get("path"):
            paths.append(s["path"])
        elif isinstance(s, str):
            paths.append(s)

    proof = await _v9_validate_proof(page, action, paths)
    report["proof"] = proof

    if acted and proof.get("ok"):
        report["ok"] = True
        report["status"] = "done:v9_healed_proof" if heal.get("healed") else "done:v9_proof"
        report["error_class"] = "none"
    elif acted:
        report["ok"] = True  # التنفيذ نجح لكن الإثبات ضعيف
        report["status"] = "done:v9_action_weak_proof"
        report["error_class"] = "weak_proof"
    else:
        report["ok"] = False
        report["status"] = heal.get("status") or "v9_failed"
        report["error_class"] = "control_not_found"

    return report


_prev_v8_wrap = globals().get("_exec_engine_wrap_execute_v8") or globals().get(
    "_exec_engine_wrap_execute_v7"
)


async def _exec_engine_wrap_execute_v9(self, action: str, target_url: str, page=None, **kwargs):
    if _prev_v8_wrap:
        try:
            ok, data = await _prev_v8_wrap(self, action, target_url, page=page, **kwargs)
        except Exception as e:
            ok, data = False, {"status": f"wrap_error:{type(e).__name__}"}
    else:
        ok, data = False, {"status": "no_prev"}

    if not isinstance(data, dict):
        data = {}

    # حتى مع النجاح: وثّق proof quality إن أمكن
    if ok and page is not None and not data.get("proof"):
        try:
            paths = []
            if data.get("screenshot_path"):
                paths.append(data["screenshot_path"])
            for s in data.get("proof_shots") or []:
                if isinstance(s, dict) and s.get("path"):
                    paths.append(s["path"])
            if paths:
                data["proof"] = await _v9_validate_proof(page, action, paths)
        except Exception:
            pass
        data.setdefault("error_class", "none")
        return True, data

    if page is None:
        return False, data
    if data.get("error_class") in {"login_required", "captcha", "region_block", "rate_limit"}:
        return False, data

    platform = getattr(self, "name", None) or getattr(self, "platform", None) or ""
    if not platform:
        cls = self.__class__.__name__.lower()
        for p in (
            "tiktok", "instagram", "vk", "youtube", "twitter", "rutube",
            "max", "facebook", "avito", "ok", "likee", "linkedin", "pinterest", "twitch",
        ):
            if p in cls:
                platform = p
                break

    boost = await _v9_engine_entry(
        page,
        platform,
        action,
        comment_text=kwargs.get("comment_text") or "🔥",
        target_url=target_url,
        session_key=kwargs.get("session_key") or platform,
    )
    data["engine_v9"] = boost
    if boost.get("proxy"):
        data["proxy_binding"] = boost["proxy"]
    if boost.get("ok"):
        data["status"] = boost.get("status") or "done:engine_v9"
        data["engine_path"] = "execution_engine_v9"
        data["error_class"] = boost.get("error_class") or "none"
        data["proof"] = boost.get("proof")
        data["heal"] = boost.get("heal")
        if boost.get("shots"):
            good = [s for s in boost["shots"] if isinstance(s, dict) and s.get("ok")]
            if good:
                data["screenshot_path"] = good[0].get("path")
        return True, data

    data["engine_path"] = str(data.get("engine_path") or "") + "+v9_failed"
    data["error_class"] = boost.get("error_class") or data.get("error_class") or "failed"
    data["status"] = boost.get("status") or data.get("status") or "failed"
    data["proof"] = boost.get("proof")
    return False, data


def _reinstall_engine_v9():
    names = (
        "TikTokSkill", "InstagramSkill", "VKSkill", "YouTubeSkill",
        "TwitterSkill", "RutubeSkill", "MaxSkill", "FacebookSkill",
        "AvitoSkill", "GenericWebSkill", "OKSkill", "LikeeSkill",
        "LinkedInSkill", "PinterestSkill", "TwitchSkill", "OzonSkill",
        "DiscordSkill", "RedditSkill",
    )
    for n in names:
        cls = globals().get(n)
        if cls is None or not hasattr(cls, "execute_task"):
            continue
        if not hasattr(cls, "_exec_original_execute_task"):
            cls._exec_original_execute_task = cls.execute_task

        async def _bound(self, action: str, target_url: str, page=None, **kwargs):
            return await _exec_engine_wrap_execute_v9(
                self, action, target_url, page=page, **kwargs
            )

        cls.execute_task = _bound
        cls._exec_engine_v9_installed = True
        logger.info("⚡ EXECUTION_ENGINE_V9 wrapped: %s", n)


try:
    _exec_engine_wrap_execute_v8 = _exec_engine_wrap_execute_v9
    _reinstall_engine_v9()
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V9)
except Exception as _v9e:
    logger.warning("V9 install failed: %s", _v9e)


# قالب ملفات مساعدة (إن لم توجد)
def _v9_ensure_data_templates():
    try:
        Path("data").mkdir(parents=True, exist_ok=True)
        if not _SELECTORS_JSON_PATH.is_file():
            _SELECTORS_JSON_PATH.write_text("{}\n", encoding="utf-8")
        if not _PROXIES_PATH.is_file():
            _PROXIES_PATH.write_text(
                json.dumps(
                    [
                        {
                            "server": "http://user:pass@127.0.0.1:8080",
                            "country": "ru",
                            "type": "residential",
                            "label": "example-ru",
                        }
                    ],
                    ensure_ascii=False,
                    indent=2,
                )
                + "\n",
                encoding="utf-8",
            )
        if not _PROXY_BINDINGS_PATH.is_file():
            _PROXY_BINDINGS_PATH.write_text("{}\n", encoding="utf-8")
    except Exception:
        pass


try:
    _v9_ensure_data_templates()
except Exception:
    pass



# ==========================================================
# EXECUTION_ENGINE_V10 — تحقق بعد الفعل + مركّب مؤكد + سكرين قبل/بعد
# Additive only — يقوّي التنفيذ الضعيف
# ==========================================================

EXECUTION_ENGINE_V10 = "execution-engine-v10"


async def _v10_read_action_state(page, action: str) -> dict:
    """
    يقرأ حالة الواجهة بعد/قبل الفعل:
    following? liked? comment box? إلخ
    """
    act = (action or "").lower()
    try:
        state = await page.evaluate(
            """(act) => {
                const blob = ((document.body && document.body.innerText) || '').toLowerCase().slice(0, 5000);
                const aria = [...document.querySelectorAll('[aria-label]')]
                    .map(e => (e.getAttribute('aria-label') || '').toLowerCase()).join(' | ');
                const all = blob + ' ' + aria;
                const has = (arr) => arr.some(x => all.includes(x));
                const out = {act, following: false, liked: false, shared: false, commented: false, already: false};
                if (act === 'subscribe' || act === 'follow') {
                    out.following = has(['following', 'subscribed', 'вы подписаны', 'подписан', 'отписаться', 'unfollow', 'message', 'сообщение']);
                    out.already = out.following;
                }
                if (act === 'like') {
                    out.liked = has(['unlike', 'liked', 'убрать', 'you liked', 'remove like']);
                    // زر filled
                    const pressed = document.querySelector('[aria-pressed="true"]');
                    if (pressed) out.liked = true;
                    out.already = out.liked;
                }
                if (act === 'repost' || act === 'share') {
                    out.shared = has(['reposted', 'shared', 'вы поделились', 'undo repost']);
                    out.already = out.shared;
                }
                if (act === 'comment') {
                    out.commented = has(['view replies', 'just now', 'сейчас', 'your comment']);
                }
                return out;
            }""",
            act,
        )
        return state or {}
    except Exception as e:
        return {"error": str(e)[:100]}


async def _v10_shot(page, tag: str) -> dict:
    """سكرين سريع مع تقييم."""
    try:
        import time as _t
        ts = int(_t.time() * 1000)
    except Exception:
        ts = 0
    path = f"data/proofs/v10_{tag}_{ts}.jpg"
    if "_v8_screenshot_quality" in globals():
        return await _v8_screenshot_quality(page, path, full_page=False)
    try:
        Path("data/proofs").mkdir(parents=True, exist_ok=True)
        await page.screenshot(path=path, type="jpeg", quality=85)
        sz = Path(path).stat().st_size if Path(path).exists() else 0
        return {"ok": sz > 8000, "path": path, "bytes": sz, "status": "ok" if sz > 8000 else "small"}
    except Exception as e:
        return {"ok": False, "path": "", "status": f"err:{type(e).__name__}"}


async def _v10_confirm_action(page, platform: str, action: str, **kwargs) -> dict:
    """
    حلقة تأكيد قوية:
    1) state قبل
    2) سكرين قبل
    3) تنفيذ (heal → v9/v8)
    4) state بعد
    5) لو مش مؤكد → retry مرة + reload
    6) سكرين بعد + proof validate
    """
    report = {
        "engine": EXECUTION_ENGINE_V10,
        "platform": platform,
        "action": action,
        "ok": False,
        "confirmed": False,
        "already_done": False,
        "status": "pending",
        "error_class": "",
        "steps": [],
        "before": {},
        "after": {},
        "shots": {},
        "proof": None,
    }
    if page is None:
        report["status"] = "no_page"
        report["error_class"] = "no_page"
        return report

    target_url = str(kwargs.get("target_url") or "")
    comment_text = str(kwargs.get("comment_text") or "🔥")

    # قبل
    before = await _v10_read_action_state(page, action)
    report["before"] = before
    if before.get("already"):
        report["ok"] = True
        report["confirmed"] = True
        report["already_done"] = True
        report["status"] = "already_done"
        report["error_class"] = "none"
        report["shots"]["after"] = await _v10_shot(page, f"{platform}_{action}_already")
        return report

    report["shots"]["before"] = await _v10_shot(page, f"{platform}_{action}_before")

    async def _do_once() -> dict:
        # heal أولاً
        if "_v9_auto_heal_and_click" in globals():
            h = await _v9_auto_heal_and_click(page, platform, action)
            if h.get("ok"):
                return {"ok": True, "via": "heal", "detail": h}
        if "_v8_multi_method_action" in globals():
            m = await _v8_multi_method_action(page, platform, action, comment_text)
            if m.get("ok"):
                return {"ok": True, "via": "v8", "detail": m}
        if "_v9_engine_entry" in globals():
            e = await _v9_engine_entry(
                page, platform, action,
                target_url=target_url, comment_text=comment_text,
            )
            if e.get("ok"):
                return {"ok": True, "via": "v9", "detail": e}
        return {"ok": False, "via": "none"}

    attempt = await _do_once()
    report["steps"].append(attempt.get("via") or "try1")
    await asyncio.sleep(random.uniform(0.8, 1.6))

    after = await _v10_read_action_state(page, action)
    report["after"] = after
    confirmed = bool(after.get("already") or after.get("following") or after.get("liked") or after.get("shared") or after.get("commented"))

    # لو الفعل نجح كليك لكن state ما اتغيرش → reload + retry
    if attempt.get("ok") and not confirmed and action.lower() in {"subscribe", "like", "repost", "follow"}:
        report["steps"].append("retry_confirm")
        try:
            if target_url:
                await page.goto(target_url, wait_until="domcontentloaded", timeout=30000)
            else:
                await page.reload(wait_until="domcontentloaded", timeout=25000)
            await asyncio.sleep(random.uniform(1.0, 2.0))
            if "_exec_dismiss_hard" in globals():
                await _exec_dismiss_hard(page, rounds=2)
        except Exception:
            pass
        # لو بعد الريلود بقى already → كان نجح
        after2 = await _v10_read_action_state(page, action)
        report["after_reload"] = after2
        if after2.get("already"):
            confirmed = True
            after = after2
        else:
            attempt2 = await _do_once()
            report["steps"].append(attempt2.get("via") or "try2")
            await asyncio.sleep(random.uniform(0.8, 1.5))
            after = await _v10_read_action_state(page, action)
            report["after"] = after
            confirmed = bool(after.get("already") or after.get("following") or after.get("liked") or after.get("shared"))
            attempt = attempt2 if attempt2.get("ok") else attempt

    report["shots"]["after"] = await _v10_shot(page, f"{platform}_{action}_after")

    paths = []
    for k in ("before", "after"):
        sh = report["shots"].get(k) or {}
        if sh.get("path"):
            paths.append(sh["path"])

    if "_v9_validate_proof" in globals():
        report["proof"] = await _v9_validate_proof(page, action, paths)

    if confirmed:
        report["ok"] = True
        report["confirmed"] = True
        report["status"] = "confirmed"
        report["error_class"] = "none"
    elif attempt.get("ok") and (report.get("proof") or {}).get("ok"):
        report["ok"] = True
        report["confirmed"] = False
        report["status"] = "action_ok_unconfirmed_proof"
        report["error_class"] = "unconfirmed"
    elif attempt.get("ok"):
        report["ok"] = True
        report["confirmed"] = False
        report["status"] = "action_ok_unconfirmed"
        report["error_class"] = "unconfirmed"
    else:
        report["ok"] = False
        report["status"] = "action_failed"
        report["error_class"] = "control_not_found"

    return report


async def _v10_compound_confirmed(page, platform: str, actions: list, **kwargs) -> dict:
    """
    مهمة مركّبة مع تأكيد لكل خطوة:
    subscribe → verify → like → verify → comment → verify
    """
    report = {
        "engine": EXECUTION_ENGINE_V10,
        "platform": platform,
        "actions": list(actions or []),
        "steps": [],
        "ok": False,
        "ok_count": 0,
        "fail_count": 0,
        "status": "pending",
        "error_class": "",
        "shots": [],
    }
    if page is None:
        report["status"] = "no_page"
        report["error_class"] = "no_page"
        return report

    target_url = str(kwargs.get("target_url") or "")
    if target_url:
        try:
            await page.goto(target_url, wait_until="domcontentloaded", timeout=35000)
            await asyncio.sleep(random.uniform(1.0, 2.0))
        except Exception as e:
            report["status"] = f"nav:{type(e).__name__}"
            report["error_class"] = "network"
            return report

    if "_exec_dismiss_hard" in globals():
        await _exec_dismiss_hard(page, rounds=2)

    for i, act in enumerate(actions or []):
        step = await _v10_confirm_action(
            page, platform, act,
            target_url=target_url,
            comment_text=kwargs.get("comment_text") or "🔥",
        )
        report["steps"].append({
            "index": i + 1,
            "action": act,
            "ok": step.get("ok"),
            "confirmed": step.get("confirmed"),
            "status": step.get("status"),
            "error_class": step.get("error_class"),
            "already_done": step.get("already_done"),
        })
        if step.get("shots"):
            report["shots"].append(step["shots"])
        if step.get("ok"):
            report["ok_count"] += 1
        else:
            report["fail_count"] += 1
            if step.get("error_class") in {"login_required", "captcha", "region_block"}:
                report["status"] = step["error_class"]
                report["error_class"] = step["error_class"]
                return report
        await asyncio.sleep(random.uniform(1.0, 2.2))
        try:
            await page.mouse.wheel(0, random.randint(100, 280))
        except Exception:
            pass

    total = len(actions or []) or 1
    if report["ok_count"] == total:
        report["ok"] = True
        report["status"] = f"confirmed_all:{report['ok_count']}/{total}"
        report["error_class"] = "none"
    elif report["ok_count"] > 0:
        report["ok"] = True
        report["status"] = f"partial_confirmed:{report['ok_count']}/{total}"
        report["error_class"] = "partial"
    else:
        report["ok"] = False
        report["status"] = "compound_failed"
        report["error_class"] = "failed"
    return report


async def _v10_engine_entry(page, platform: str, action: str, **kwargs) -> dict:
    """مدخل V10: مركّب مؤكد أو فعل واحد مؤكد."""
    if "_exec_parse_compound_actions" in globals():
        actions = _exec_parse_compound_actions(action)
    else:
        actions = [a.strip() for a in str(action or "").replace("+", ",").split(",") if a.strip()] or [action]

    if len(actions) > 1:
        return await _v10_compound_confirmed(page, platform, actions, **kwargs)
    return await _v10_confirm_action(page, platform, actions[0] if actions else action, **kwargs)


_prev_v9_wrap = globals().get("_exec_engine_wrap_execute_v9") or globals().get(
    "_exec_engine_wrap_execute_v8"
)


async def _exec_engine_wrap_execute_v10(self, action: str, target_url: str, page=None, **kwargs):
    if _prev_v9_wrap:
        try:
            ok, data = await _prev_v9_wrap(self, action, target_url, page=page, **kwargs)
        except Exception as e:
            ok, data = False, {"status": f"wrap_error:{type(e).__name__}"}
    else:
        ok, data = False, {"status": "no_prev"}

    if not isinstance(data, dict):
        data = {}

    # لو النجاح السابق من غير تأكيد → أكّد
    if ok and page is not None and not data.get("confirmed"):
        try:
            st = await _v10_read_action_state(page, action)
            data["post_state"] = st
            if st.get("already"):
                data["confirmed"] = True
            shot = await _v10_shot(page, "post_ok")
            data.setdefault("proof_shots", [])
            if isinstance(data["proof_shots"], list):
                data["proof_shots"].append(shot)
            if shot.get("path") and not data.get("screenshot_path"):
                data["screenshot_path"] = shot["path"]
        except Exception:
            pass
        data.setdefault("error_class", "none")
        return True, data

    if page is None:
        return False, data
    if data.get("error_class") in {"login_required", "captcha", "region_block", "rate_limit"}:
        return False, data

    platform = getattr(self, "name", None) or getattr(self, "platform", None) or ""
    if not platform:
        cls = self.__class__.__name__.lower()
        for p in (
            "tiktok", "instagram", "vk", "youtube", "twitter", "rutube",
            "max", "facebook", "avito", "ok", "likee", "linkedin", "pinterest", "twitch",
        ):
            if p in cls:
                platform = p
                break

    boost = await _v10_engine_entry(
        page, platform, action,
        target_url=target_url,
        comment_text=kwargs.get("comment_text") or "🔥",
        session_key=kwargs.get("session_key") or platform,
    )
    data["engine_v10"] = boost
    data["confirmed"] = bool(boost.get("confirmed"))
    data["already_done"] = bool(boost.get("already_done"))

    if boost.get("ok"):
        data["status"] = boost.get("status") or "done:v10"
        data["engine_path"] = "execution_engine_v10"
        data["error_class"] = boost.get("error_class") or "none"
        data["proof"] = boost.get("proof")
        # أفضل سكرين بعد
        shots = boost.get("shots") or {}
        after = shots.get("after") if isinstance(shots, dict) else None
        if after and after.get("path"):
            data["screenshot_path"] = after["path"]
        elif isinstance(boost.get("shots"), list) and boost["shots"]:
            # compound
            data["compound_steps"] = boost.get("steps")
        return True, data

    data["engine_path"] = str(data.get("engine_path") or "") + "+v10_failed"
    data["error_class"] = boost.get("error_class") or data.get("error_class") or "failed"
    data["status"] = boost.get("status") or data.get("status") or "failed"
    return False, data


def _reinstall_engine_v10():
    names = (
        "TikTokSkill", "InstagramSkill", "VKSkill", "YouTubeSkill",
        "TwitterSkill", "RutubeSkill", "MaxSkill", "FacebookSkill",
        "AvitoSkill", "GenericWebSkill", "OKSkill", "LikeeSkill",
        "LinkedInSkill", "PinterestSkill", "TwitchSkill", "OzonSkill",
        "DiscordSkill", "RedditSkill",
    )
    for n in names:
        cls = globals().get(n)
        if cls is None or not hasattr(cls, "execute_task"):
            continue
        if not hasattr(cls, "_exec_original_execute_task"):
            cls._exec_original_execute_task = cls.execute_task

        async def _bound(self, action: str, target_url: str, page=None, **kwargs):
            return await _exec_engine_wrap_execute_v10(
                self, action, target_url, page=page, **kwargs
            )

        cls.execute_task = _bound
        cls._exec_engine_v10_installed = True
        logger.info("⚡ EXECUTION_ENGINE_V10 wrapped: %s", n)


try:
    _exec_engine_wrap_execute_v9 = _exec_engine_wrap_execute_v10
    _reinstall_engine_v10()
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V10)
except Exception as _v10e:
    logger.warning("V10 install failed: %s", _v10e)



# ==========================================================
# EXECUTION_ENGINE_V11 — تقوية الضعيف: IG / TikTok / Max / انتظار / تحقق مزدوج
# Additive only — بدون اختصار على نقاط الفشل الحقيقية
# ==========================================================

EXECUTION_ENGINE_V11 = "execution-engine-v11"

# ---------- محددات مركّزة للمنصات الضعيفة ----------
V11_WEAK_SELECTORS = {
    "instagram": {
        "subscribe": [
            'button:has-text("Follow")',
            'button:has-text("Follow Back")',
            'button:has-text("Подписаться")',
            'div[role="button"]:has-text("Follow")',
            'button._aswp._aswr._aswu._aswv._asx2',  # legacy classes often change
            'header button:has-text("Follow")',
            'main header section button',
            'button:has-text("Following")',  # already
        ],
        "like": [
            'svg[aria-label="Like"]',
            'svg[aria-label="Нравится"]',
            'span[role="button"] svg[aria-label="Like"]',
            'div[role="button"] svg[aria-label="Like"]',
            'svg[aria-label="Unlike"]',
            'article svg[aria-label="Like"]',
            'main article section span:first-child',
            'section span[role="button"]',
        ],
        "comment": [
            'textarea[aria-label*="comment" i]',
            'textarea[placeholder*="comment" i]',
            'textarea[placeholder*="Add a comment"]',
            'textarea[placeholder*="Комментарий"]',
            'form textarea',
            'div[role="textbox"]',
        ],
        "repost": [
            'svg[aria-label="Share"]',
            'svg[aria-label="Поделиться"]',
            'div[role="button"] svg[aria-label="Share Post"]',
        ],
    },
    "tiktok": {
        "subscribe": [
            'button[data-e2e="follow-button"]',
            'button[data-e2e="browse-follow"]',
            'button:has-text("Follow")',
            'button:has-text("Подписаться")',
            '[data-e2e="follow-button"]',
            'button:has-text("Following")',
        ],
        "like": [
            'span[data-e2e="like-icon"]',
            'strong[data-e2e="like-count"]',
            'button[data-e2e="browse-like"]',
            '[data-e2e="like-icon"]',
            'span[data-e2e="browse-like-icon"]',
            'div[data-e2e="like-icon"]',
        ],
        "comment": [
            'div[data-e2e="comment-input"]',
            'div[data-e2e="comment-text"]',
            '[data-e2e="comment-input"] div[contenteditable]',
            'div.public-DraftEditor-content',
            'div[contenteditable="true"]',
        ],
        "repost": [
            'span[data-e2e="share-icon"]',
            'button[data-e2e="share-button"]',
            '[data-e2e="browse-share"]',
            'span[data-e2e="repost-icon"]',
        ],
    },
    "vk": {
        "subscribe": [
            'button:has-text("Подписаться")',
            'button:has-text("Follow")',
            'a:has-text("Подписаться")',
            '.FlatButton:has-text("Подписаться")',
            'button.FlatButton--primary',
            '#public_subscribe',
            'button:has-text("Вы подписаны")',
            'button:has-text("Message")',
        ],
        "like": [
            '.PostBottomActionContainer [data-section-ref="like"]',
            'button[data-testid="like_button"]',
            '.like_btn',
            'div.PostButtonReactions',
            'button:has-text("Нравится")',
            '[aria-label*="Нравится"]',
        ],
        "comment": [
            '.reply_field',
            'div.reply_field',
            'div[contenteditable="true"]',
            'textarea',
            '.CommentInput',
        ],
        "repost": [
            'button:has-text("Поделиться")',
            '[data-testid="share_button"]',
            '.share_btn',
            'a:has-text("Поделиться")',
        ],
    },
    "max": {
        "subscribe": [
            'button:has-text("Подписаться")',
            'button:has-text("Join")',
            'button:has-text("Вступить")',
            'button:has-text("Follow")',
            'a:has-text("Подписаться")',
        ],
        "like": [
            'button[aria-label*="like" i]',
            'button:has-text("❤")',
            '[class*="like"]',
        ],
        "view": [
            'button:has-text("Open")',
            'button:has-text("Открыть")',
        ],
    },
    "youtube": {
        "subscribe": [
            'button[aria-label*="Subscribe"]',
            'yt-button-shape button:has-text("Subscribe")',
            'button:has-text("Subscribe")',
            'button:has-text("Подписаться")',
            '#subscribe-button button',
        ],
        "like": [
            'button[title*="like" i]',
            'button[aria-label*="like this" i]',
            'like-button-view-model button',
            'button[aria-label*="Нравится"]',
        ],
        "comment": [
            'div#placeholder-area',
            'div#contenteditable-root',
            'ytd-comment-simplebox-renderer',
        ],
    },
    "twitter": {
        "subscribe": [
            'button[data-testid*="follow"]',
            'div[data-testid*="follow"]',
            'button:has-text("Follow")',
            'button:has-text("Following")',
        ],
        "like": [
            'button[data-testid="like"]',
            'div[data-testid="like"]',
            'button[data-testid="unlike"]',
        ],
        "repost": [
            'button[data-testid="retweet"]',
            'div[data-testid="retweet"]',
            'div[data-testid="confirm"]',
        ],
        "comment": [
            'div[data-testid="tweetTextarea_0"]',
            'div[role="textbox"]',
        ],
    },
}


async def _v11_wait_stable(page, ms: int = 1200):
    try:
        await page.wait_for_timeout(ms)
    except Exception:
        await asyncio.sleep(ms / 1000.0)
    try:
        await page.wait_for_load_state("domcontentloaded", timeout=8000)
    except Exception:
        pass
    try:
        await page.wait_for_load_state("networkidle", timeout=5000)
    except Exception:
        pass


async def _v11_click_selectors(page, selectors: list, *, double: bool = False) -> dict:
    for sel in selectors or []:
        try:
            loc = page.locator(sel).first
            n = await loc.count()
            if n == 0:
                continue
            try:
                if not await loc.is_visible():
                    continue
            except Exception:
                pass
            await loc.scroll_into_view_if_needed(timeout=3000)
            await asyncio.sleep(random.uniform(0.2, 0.55))
            box = None
            try:
                box = await loc.bounding_box()
            except Exception:
                box = None
            if box:
                x = box["x"] + box["width"] * random.uniform(0.3, 0.7)
                y = box["y"] + box["height"] * random.uniform(0.3, 0.7)
                await page.mouse.move(x, y, steps=random.randint(5, 12))
                await asyncio.sleep(random.uniform(0.05, 0.2))
            if double:
                await loc.dblclick(timeout=3000)
            else:
                await loc.click(timeout=3000)
            return {"ok": True, "selector": sel}
        except Exception:
            continue
    return {"ok": False, "selector": ""}


async def _v11_tiktok_video_recover(page) -> dict:
    """استرداد فيديو تيك توك الأبيض/المعلق — نقطة ضعف متكررة."""
    info = {"ok": False, "steps": []}
    try:
        # إغلاق بوب أب
        if "_exec_dismiss_hard" in globals():
            closed = await _exec_dismiss_hard(page, rounds=3)
            info["steps"].append(f"dismiss:{len(closed)}")
        # محاولة play
        for sel in [
            'button[aria-label*="Play"]',
            'div[data-e2e="browse-video"]',
            'video',
            'div[class*="DivVideo"]',
        ]:
            try:
                loc = page.locator(sel).first
                if await loc.count():
                    await loc.click(timeout=2000, force=True)
                    info["steps"].append(f"click:{sel[:30]}")
                    break
            except Exception:
                continue
        try:
            await page.evaluate(
                """() => {
                    const v = document.querySelector('video');
                    if (v) { v.muted = true; v.play().catch(()=>{}); return true; }
                    return false;
                }"""
            )
            info["steps"].append("js_play")
        except Exception:
            pass
        await _v11_wait_stable(page, 1500)
        # لو لسه فاضي → reload
        blank = await page.evaluate(
            """() => {
                const t = (document.body && document.body.innerText || '').trim();
                return t.length < 40;
            }"""
        )
        if blank:
            await page.reload(wait_until="domcontentloaded", timeout=30000)
            info["steps"].append("reload")
            await _v11_wait_stable(page, 2000)
            if "_exec_dismiss_hard" in globals():
                await _exec_dismiss_hard(page, rounds=2)
        info["ok"] = True
    except Exception as e:
        info["steps"].append(f"err:{type(e).__name__}")
    return info


async def _v11_instagram_like_methods(page) -> dict:
    """عدة طرق لايك إنستا — نقطة ضعف."""
    report = {"ok": False, "methods": []}
    # 1) svg Like
    r = await _v11_click_selectors(page, V11_WEAK_SELECTORS["instagram"]["like"])
    if r.get("ok"):
        report["ok"] = True
        report["methods"].append(f"sel:{r.get('selector')[:40]}")
        return report
    # 2) double click on image
    try:
        img = page.locator("article img").first
        if await img.count():
            box = await img.bounding_box()
            if box:
                x = box["x"] + box["width"] / 2
                y = box["y"] + box["height"] / 2
                await page.mouse.dblclick(x, y)
                report["methods"].append("dblclick_img")
                await _v11_wait_stable(page, 800)
                # تحقق unlike ظاهر؟
                if await page.locator('svg[aria-label="Unlike"]').count():
                    report["ok"] = True
                    return report
    except Exception:
        report["methods"].append("dblclick_fail")
    # 3) JS scan
    try:
        hit = await page.evaluate(
            """() => {
                const svgs = [...document.querySelectorAll('svg[aria-label]')];
                const like = svgs.find(s => (s.getAttribute('aria-label')||'') === 'Like');
                if (like) {
                    const btn = like.closest('button, div[role="button"], span[role="button"]') || like.parentElement;
                    if (btn) { btn.click(); return 'js_like'; }
                }
                return '';
            }"""
        )
        if hit:
            report["ok"] = True
            report["methods"].append(hit)
            return report
    except Exception:
        report["methods"].append("js_fail")
    return report


async def _v11_platform_action(page, platform: str, action: str, comment_text: str = "🔥") -> dict:
    """تنفيذ مركز للمنصات الضعيفة."""
    plat = (platform or "").lower()
    if plat == "x":
        plat = "twitter"
    act = (action or "").lower()
    report = {"ok": False, "status": "pending", "platform": plat, "action": act, "detail": []}

    if plat == "tiktok":
        rec = await _v11_tiktok_video_recover(page)
        report["detail"].append({"recover": rec})
        await _v11_wait_stable(page, 1000)

    pack = (V11_WEAK_SELECTORS.get(plat) or {}).get(act) or []

    if plat == "instagram" and act == "like":
        ig = await _v11_instagram_like_methods(page)
        report["detail"].append(ig)
        report["ok"] = bool(ig.get("ok"))
        report["status"] = "done:ig_like" if report["ok"] else "ig_like_failed"
        return report

    if act == "comment" and pack:
        # ركّز على كتابة التعليق
        try:
            for sel in pack:
                loc = page.locator(sel).first
                if await loc.count() == 0:
                    continue
                await loc.click(timeout=2500)
                await asyncio.sleep(0.3)
                try:
                    await loc.fill(comment_text[:200])
                except Exception:
                    await page.keyboard.type(comment_text[:200], delay=random.randint(30, 70))
                await asyncio.sleep(0.4)
                posted = await _v11_click_selectors(
                    page,
                    [
                        'button:has-text("Post")',
                        'button:has-text("Publish")',
                        'button:has-text("Send")',
                        'button:has-text("Отправить")',
                        'button:has-text("Опубликовать")',
                        'button[type="submit"]',
                        'div[role="button"]:has-text("Post")',
                    ],
                )
                if posted.get("ok"):
                    report["ok"] = True
                    report["status"] = "done:comment"
                    report["detail"].append(posted)
                    return report
        except Exception as e:
            report["detail"].append({"comment_err": type(e).__name__})

    # عام: selectors pack
    if pack:
        r = await _v11_click_selectors(
            page, pack, double=(act == "like" and plat == "tiktok")
        )
        report["detail"].append(r)
        if r.get("ok"):
            # تيك توك لايك أحيانًا يحتاج ثانية
            if act == "like" and plat == "tiktok":
                await asyncio.sleep(0.4)
                await _v11_click_selectors(page, pack)
            report["ok"] = True
            report["status"] = f"done:v11_{plat}_{act}"
            return report

    # twitter retweet confirm
    if plat == "twitter" and act in {"repost", "share"}:
        r1 = await _v11_click_selectors(page, V11_WEAK_SELECTORS["twitter"]["repost"])
        await asyncio.sleep(0.5)
        r2 = await _v11_click_selectors(
            page,
            [
                'div[data-testid="retweetConfirm"]',
                'button:has-text("Repost")',
                'div[role="menuitem"]:has-text("Repost")',
            ],
        )
        report["detail"].extend([r1, r2])
        if r1.get("ok") or r2.get("ok"):
            report["ok"] = True
            report["status"] = "done:v11_repost"
            return report

    report["status"] = "v11_control_not_found"
    return report


async def _v11_double_verify(page, action: str) -> dict:
    """تحقق مزدوج: الآن + بعد انتظار قصير."""
    s1 = {}
    s2 = {}
    if "_v10_read_action_state" in globals():
        s1 = await _v10_read_action_state(page, action)
        await _v11_wait_stable(page, 900)
        s2 = await _v10_read_action_state(page, action)
    ok = bool(
        s1.get("already") or s2.get("already")
        or s1.get("following") or s2.get("following")
        or s1.get("liked") or s2.get("liked")
        or s1.get("shared") or s2.get("shared")
        or s1.get("commented") or s2.get("commented")
    )
    return {"ok": ok, "s1": s1, "s2": s2}


async def _v11_engine_entry(page, platform: str, action: str, **kwargs) -> dict:
    report = {
        "engine": EXECUTION_ENGINE_V11,
        "platform": platform,
        "action": action,
        "ok": False,
        "confirmed": False,
        "status": "pending",
        "error_class": "",
        "steps": [],
    }
    if page is None:
        report["status"] = "no_page"
        report["error_class"] = "no_page"
        return report

    target_url = str(kwargs.get("target_url") or "")
    comment_text = str(kwargs.get("comment_text") or "🔥")

    if target_url:
        try:
            if target_url.split("?")[0].lower() not in (page.url or "").lower():
                await page.goto(target_url, wait_until="domcontentloaded", timeout=40000)
                report["steps"].append("goto")
        except Exception as e:
            report["steps"].append(f"goto_fail:{type(e).__name__}")
        await _v11_wait_stable(page, 1500)

    if "_exec_dismiss_hard" in globals():
        await _exec_dismiss_hard(page, rounds=3)
        report["steps"].append("dismiss")

    # health
    if "_v7_session_health" in globals():
        h = await _v7_session_health(page, platform)
        report["health"] = h
        if "login_required" in h.get("flags", []):
            report["status"] = "login_required"
            report["error_class"] = "login_required"
            return report
        if "captcha" in h.get("flags", []):
            report["status"] = "captcha"
            report["error_class"] = "captcha"
            return report
        if "region_block" in h.get("flags", []):
            report["status"] = "region_block"
            report["error_class"] = "region_block"
            return report

    # already?
    if "_v10_read_action_state" in globals():
        before = await _v10_read_action_state(page, action)
        report["before"] = before
        if before.get("already"):
            report["ok"] = True
            report["confirmed"] = True
            report["status"] = "already_done"
            report["error_class"] = "none"
            if "_v10_shot" in globals():
                report["shot"] = await _v10_shot(page, "v11_already")
            return report

    # platform-focused action
    acted = await _v11_platform_action(page, platform, action, comment_text)
    report["acted"] = acted
    report["steps"].append(acted.get("status"))

    # fallback heal
    if not acted.get("ok") and "_v9_auto_heal_and_click" in globals():
        heal = await _v9_auto_heal_and_click(page, platform, action)
        report["heal"] = heal
        if heal.get("ok"):
            acted["ok"] = True
            report["steps"].append("healed")

    # fallback v10 confirm path internals without recursion: multi method
    if not acted.get("ok") and "_v8_multi_method_action" in globals():
        multi = await _v8_multi_method_action(page, platform, action, comment_text)
        report["multi"] = multi
        if multi.get("ok"):
            acted["ok"] = True
            report["steps"].append("v8_multi")

    await _v11_wait_stable(page, 1100)
    verify = await _v11_double_verify(page, action)
    report["verify"] = verify

    # سكرين بعد
    if "_v10_shot" in globals():
        report["shot"] = await _v10_shot(page, f"v11_{platform}_{action}")
        paths = [report["shot"].get("path")] if report.get("shot") else []
        if "_v9_validate_proof" in globals() and paths:
            report["proof"] = await _v9_validate_proof(page, action, paths)

    if verify.get("ok"):
        report["ok"] = True
        report["confirmed"] = True
        report["status"] = "confirmed_v11"
        report["error_class"] = "none"
    elif acted.get("ok"):
        report["ok"] = True
        report["confirmed"] = False
        report["status"] = "acted_unconfirmed_v11"
        report["error_class"] = "unconfirmed"
    else:
        report["ok"] = False
        report["status"] = "failed_v11"
        report["error_class"] = "control_not_found"

    return report


_prev_v10_wrap = globals().get("_exec_engine_wrap_execute_v10") or globals().get(
    "_exec_engine_wrap_execute_v9"
)


async def _exec_engine_wrap_execute_v11(self, action: str, target_url: str, page=None, **kwargs):
    if _prev_v10_wrap:
        try:
            ok, data = await _prev_v10_wrap(self, action, target_url, page=page, **kwargs)
        except Exception as e:
            ok, data = False, {"status": f"wrap_error:{type(e).__name__}"}
    else:
        ok, data = False, {"status": "no_prev"}

    if not isinstance(data, dict):
        data = {}

    # لو مؤكد من V10 تمام
    if ok and data.get("confirmed"):
        return True, data

    if page is None:
        return ok, data
    if data.get("error_class") in {"login_required", "captcha", "region_block", "rate_limit"}:
        return False, data

    platform = getattr(self, "name", None) or getattr(self, "platform", None) or ""
    if not platform:
        cls = self.__class__.__name__.lower()
        for p in (
            "tiktok", "instagram", "vk", "youtube", "twitter", "rutube",
            "max", "facebook", "avito", "ok", "likee", "linkedin",
        ):
            if p in cls:
                platform = p
                break

    # ركّز V11 على المنصات الضعيفة أو غير المؤكد
    weak = platform.lower() in {
        "instagram", "tiktok", "max", "twitter", "youtube", "vk",
    }
    if ok and not weak and data.get("confirmed"):
        return True, data

    boost = await _v11_engine_entry(
        page, platform, action,
        target_url=target_url,
        comment_text=kwargs.get("comment_text") or "🔥",
    )
    data["engine_v11"] = boost
    if boost.get("ok"):
        data["status"] = boost.get("status") or "done:v11"
        data["engine_path"] = "execution_engine_v11"
        data["confirmed"] = bool(boost.get("confirmed"))
        data["error_class"] = boost.get("error_class") or "none"
        if boost.get("shot", {}).get("path"):
            data["screenshot_path"] = boost["shot"]["path"]
        data["proof"] = boost.get("proof")
        return True, data

    if ok:
        # احتفظ بنجاح الطبقات السابقة حتى لو V11 ما أكدش
        return True, data

    data["engine_path"] = str(data.get("engine_path") or "") + "+v11_failed"
    data["error_class"] = boost.get("error_class") or data.get("error_class") or "failed"
    data["status"] = boost.get("status") or data.get("status") or "failed"
    return False, data


def _reinstall_engine_v11():
    names = (
        "TikTokSkill", "InstagramSkill", "VKSkill", "YouTubeSkill",
        "TwitterSkill", "RutubeSkill", "MaxSkill", "FacebookSkill",
        "AvitoSkill", "GenericWebSkill", "OKSkill", "LikeeSkill",
        "LinkedInSkill", "PinterestSkill", "TwitchSkill", "OzonSkill",
    )
    for n in names:
        cls = globals().get(n)
        if cls is None or not hasattr(cls, "execute_task"):
            continue
        if not hasattr(cls, "_exec_original_execute_task"):
            cls._exec_original_execute_task = cls.execute_task

        async def _bound(self, action: str, target_url: str, page=None, **kwargs):
            return await _exec_engine_wrap_execute_v11(
                self, action, target_url, page=page, **kwargs
            )

        cls.execute_task = _bound
        cls._exec_engine_v11_installed = True
        logger.info("⚡ EXECUTION_ENGINE_V11 wrapped: %s", n)


try:
    _exec_engine_wrap_execute_v10 = _exec_engine_wrap_execute_v11
    _reinstall_engine_v11()
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V11)
except Exception as _v11e:
    logger.warning("V11 install failed: %s", _v11e)



# ==========================================================
# EXECUTION ENGINE V12 — Compound + Stability + More Platforms
# ==========================================================

EXECUTION_ENGINE_V12 = "execution_engine_v12_compound_stability"

# منصات إضافية
SKILL_CAPABILITIES.update({
    "ozon": {"view", "like", "review", "subscribe"},
    "ok": {"subscribe", "like", "comment", "repost"},
    "likee": {"subscribe", "like", "comment", "view"},
    "threads": {"subscribe", "like", "comment", "repost"},
    "snapchat": {"subscribe", "view"},
    "kick": {"subscribe", "like", "view"},
    "steam": {"subscribe", "like", "review"},
    "dailymotion": {"subscribe", "like", "view"},
    "soundcloud": {"subscribe", "like", "view"},
    "bandcamp": {"subscribe", "like", "view"},
    "quora": {"subscribe", "like", "comment", "share"},
    "medium": {"subscribe", "like", "comment"},
    "tumblr": {"subscribe", "like", "repost", "comment"},
    "pinterest": {"subscribe", "like", "share"},
    "twitch": {"subscribe", "like", "view"},
    "linkedin": {"subscribe", "like", "comment", "share"},
})


async def _v12_compound_execute(page, platform: str, actions: list, urls: list, **kwargs) -> dict:
    """
    تنفيذ مهام مركبة: أكتر من رابط + أكتر من فعل بالترتيب.
    مثال: اشترك في 5 جروبات + لايك على آخر منشور.
    """
    report = {
        "engine": EXECUTION_ENGINE_V12,
        "platform": platform,
        "compound": True,
        "results": [],
        "ok": False,
        "confirmed": 0,
        "failed": 0,
    }
    if not page or not actions or not urls:
        report["status"] = "missing_params"
        return report

    for i, url in enumerate(urls):
        act = actions[i % len(actions)] if actions else "subscribe"
        try:
            if url and url not in (page.url or ""):
                await page.goto(url, wait_until="domcontentloaded", timeout=40000)
                await asyncio.sleep(random.uniform(1.5, 3.0))
            # استخدم V11 لو موجود
            if "_v11_engine_entry" in globals():
                r = await _v11_engine_entry(page, platform, act, target_url=url, **kwargs)
            else:
                r = {"ok": False, "status": "no_v11"}
            report["results"].append({"url": url, "action": act, "result": r})
            if r.get("ok"):
                report["confirmed"] += 1
            else:
                report["failed"] += 1
            await asyncio.sleep(random.uniform(2.0, 4.5))
        except Exception as e:
            report["results"].append({"url": url, "action": act, "error": str(e)})
            report["failed"] += 1

    report["ok"] = report["confirmed"] > 0 and report["failed"] == 0
    report["status"] = f"compound_done:{report['confirmed']}/{len(urls)}"
    return report


async def _v12_smart_retry(fn, retries: int = 3, base_delay: float = 2.0):
    """Retry ذكي مع exponential backoff."""
    last = None
    for i in range(retries):
        try:
            return await fn()
        except Exception as e:
            last = e
            delay = base_delay * (2 ** i) + random.uniform(0.5, 1.5)
            await asyncio.sleep(delay)
    raise last if last else Exception("retry_failed")


def _v12_install():
    """تثبيت V12 فوق المهارات الموجودة."""
    names = (
        "TikTokSkill", "InstagramSkill", "VKSkill", "YouTubeSkill",
        "TwitterSkill", "RutubeSkill", "MaxSkill", "FacebookSkill",
        "AvitoSkill", "GenericWebSkill", "OzonSkill", "OKSkill",
        "LikeeSkill", "LinkedInSkill", "PinterestSkill", "TwitchSkill",
    )
    for n in names:
        cls = globals().get(n)
        if cls is None:
            continue
        if not hasattr(cls, "execute_compound"):
            async def execute_compound(self, actions, urls, page=None, **kwargs):
                return await _v12_compound_execute(
                    page or getattr(self, "page", None),
                    getattr(self, "name", n.lower().replace("skill", "")),
                    actions, urls, **kwargs
                )
            cls.execute_compound = execute_compound
        cls._v12_installed = True
        logger.info("⚡ V12 compound ready: %s", n)


try:
    _v12_install()
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V12)
except Exception as _v12e:
    logger.warning("V12 install failed: %s", _v12e)



# ==========================================================
# EXECUTION ENGINE V13 — Stealth Pro + Proof + Recovery
# ==========================================================

EXECUTION_ENGINE_V13 = "execution_engine_v13_stealth_proof"

# منصات إضافية V13
SKILL_CAPABILITIES.update({
    "viber": {"subscribe", "like", "view"},
    "whatsapp": {"subscribe", "view"},
    "telegram_web": {"subscribe", "view", "like"},
    "yandex_zen": {"subscribe", "like", "comment", "view"},
    "dzen": {"subscribe", "like", "comment"},
    "ok_ru": {"subscribe", "like", "comment", "repost"},
    "mail_ru": {"subscribe", "like", "view"},
    "avito_pro": {"view", "like", "subscribe"},
    "wildberries": {"view", "like", "review"},
    "aliexpress": {"view", "like", "review"},
    "amazon": {"view", "like", "review"},
    "ebay": {"view", "like"},
    "etsy": {"view", "like"},
    "shopify": {"view", "like"},
})


async def _v13_advanced_stealth(page):
    """تخفي أقوى: canvas + webgl + fonts + audio + battery."""
    if not page:
        return
    try:
        await page.add_init_script("""
            // Canvas noise أقوى
            const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
            HTMLCanvasElement.prototype.toDataURL = function() {
                const ctx = this.getContext('2d');
                if (ctx) {
                    const img = ctx.getImageData(0, 0, Math.min(this.width||1, 16), 1);
                    for (let i = 0; i < img.data.length; i += 4) {
                        img.data[i] = img.data[i] + Math.floor(Math.random()*3);
                    }
                    ctx.putImageData(img, 0, 0);
                }
                return origToDataURL.apply(this, arguments);
            };
            // Audio context noise
            try {
                const AudioContext = window.AudioContext || window.webkitAudioContext;
                if (AudioContext) {
                    const orig = AudioContext.prototype.createAnalyser;
                    AudioContext.prototype.createAnalyser = function() {
                        const a = orig.call(this);
                        const origGet = a.getFloatFrequencyData;
                        a.getFloatFrequencyData = function(arr) {
                            origGet.call(this, arr);
                            for (let i = 0; i < arr.length; i++) arr[i] += Math.random()*0.1;
                        };
                        return a;
                    };
                }
            } catch(e) {}
            // Battery API
            try {
                Object.defineProperty(navigator, 'getBattery', {
                    value: () => Promise.resolve({
                        charging: true, chargingTime: 0, dischargingTime: Infinity, level: 0.85
                    })
                });
            } catch(e) {}
            // Fonts
            try {
                Object.defineProperty(document, 'fonts', {
                    value: { ready: Promise.resolve(), check: () => true }
                });
            } catch(e) {}
        """)
    except Exception:
        pass


async def _v13_smart_proof(page, platform: str, action: str, prefix: str = "v13") -> dict:
    """إثبات أذكى: سكرين + تحقق من الحالة."""
    result = {"ok": False, "path": None, "verified": False}
    if not page:
        return result
    try:
        await asyncio.sleep(random.uniform(1.0, 2.0))
        # scroll خفيف
        try:
            await page.mouse.wheel(0, random.randint(80, 200))
        except Exception:
            pass
        ss_dir = Path("data/screenshots")
        ss_dir.mkdir(parents=True, exist_ok=True)
        path = ss_dir / f"{prefix}_{platform}_{action}_{int(time.time())}_{random.randint(1000,9999)}.png"
        await page.screenshot(path=str(path), full_page=False)
        result["path"] = str(path)
        result["ok"] = True
        # تحقق بسيط
        body = ""
        try:
            body = (await page.inner_text("body")).lower()
        except Exception:
            pass
        if any(k in body for k in ["subscribed", "following", "liked", "подписан", "нравится"]):
            result["verified"] = True
    except Exception as e:
        result["error"] = str(e)
    return result


async def _v13_recover_and_retry(page, platform: str, action: str, target_url: str = "") -> dict:
    """استرداد ذكي عند الفشل: refresh + dismiss + retry."""
    report = {"ok": False, "steps": []}
    if not page:
        return report
    try:
        # dismiss
        if "_dismiss_common_blockers" in globals():
            await _dismiss_common_blockers(page)
            report["steps"].append("dismiss")
        # refresh لو الصفحة فاضية
        try:
            text = await page.inner_text("body")
            if len(text.strip()) < 50:
                await page.reload(wait_until="domcontentloaded", timeout=30000)
                report["steps"].append("reload")
                await asyncio.sleep(2)
        except Exception:
            pass
        # stealth
        await _v13_advanced_stealth(page)
        report["steps"].append("stealth")
        # جرب التنفيذ تاني
        if "_v11_engine_entry" in globals():
            r = await _v11_engine_entry(page, platform, action, target_url=target_url)
            report["retry_result"] = r
            report["ok"] = bool(r.get("ok"))
            report["steps"].append("retry_v11")
    except Exception as e:
        report["steps"].append(f"err:{type(e).__name__}")
    return report


def _v13_install():
    """تثبيت V13."""
    names = (
        "TikTokSkill", "InstagramSkill", "VKSkill", "YouTubeSkill",
        "TwitterSkill", "RutubeSkill", "MaxSkill", "FacebookSkill",
        "AvitoSkill", "GenericWebSkill", "OzonSkill", "OKSkill",
        "LikeeSkill", "LinkedInSkill", "PinterestSkill", "TwitchSkill",
    )
    for n in names:
        cls = globals().get(n)
        if cls is None:
            continue
        if not hasattr(cls, "smart_proof"):
            async def smart_proof(self, page=None, action="subscribe", **kwargs):
                return await _v13_smart_proof(
                    page or getattr(self, "page", None),
                    getattr(self, "name", "unknown"),
                    action
                )
            cls.smart_proof = smart_proof
        if not hasattr(cls, "recover_and_retry"):
            async def recover_and_retry(self, page=None, action="subscribe", target_url="", **kwargs):
                return await _v13_recover_and_retry(
                    page or getattr(self, "page", None),
                    getattr(self, "name", "unknown"),
                    action, target_url
                )
            cls.recover_and_retry = recover_and_retry
        cls._v13_installed = True
        logger.info("⚡ V13 stealth+proof ready: %s", n)


try:
    _v13_install()
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V13)
except Exception as _v13e:
    logger.warning("V13 install failed: %s", _v13e)



# ==========================================================
# EXECUTION ENGINE V14 — Deep Improvements (Selectors + Rate + Health + Compound)
# ==========================================================

EXECUTION_ENGINE_V14 = "execution_engine_v14_deep"

# Rate limit per platform (requests per hour)
_V14_RATE_LIMITS = {
    "tiktok": 30,
    "instagram": 25,
    "vk": 40,
    "youtube": 35,
    "twitter": 30,
    "rutube": 40,
    "max": 20,
    "facebook": 20,
    "default": 50,
}
_V14_RATE_STATE = {}  # platform -> [timestamps]


def _v14_rate_ok(platform: str) -> bool:
    plat = (platform or "default").lower()
    limit = _V14_RATE_LIMITS.get(plat, _V14_RATE_LIMITS["default"])
    now = time.time()
    lst = _V14_RATE_STATE.setdefault(plat, [])
    # نظف القديم
    lst[:] = [t for t in lst if now - t < 3600]
    if len(lst) >= limit:
        return False
    lst.append(now)
    return True


# Selectors أقوى للمنصات الضعيفة
V14_STRONG_SELECTORS = {
    "instagram": {
        "like": [
            'svg[aria-label="Like"]',
            'svg[aria-label="Нравится"]',
            'button[aria-label*="Like"]',
            'span[aria-label*="Like"]',
            'div[role="button"] svg[aria-label="Like"]',
            'article svg[aria-label="Like"]',
        ],
        "subscribe": [
            'button:has-text("Follow")',
            'button:has-text("Подписаться")',
            'div[role="button"]:has-text("Follow")',
            'button._acan._acap._acas',
        ],
        "comment": [
            'textarea[aria-label*="comment"]',
            'textarea[placeholder*="comment"]',
            'div[contenteditable="true"]',
            'form textarea',
        ],
    },
    "tiktok": {
        "like": [
            'span[data-e2e="like-icon"]',
            'button[data-e2e="like-icon"]',
            'div[data-e2e="like-icon"]',
            'span[data-e2e="browse-like-icon"]',
            'button[aria-label*="like" i]',
        ],
        "subscribe": [
            'button[data-e2e="follow-button"]',
            'button:has-text("Follow")',
            'button:has-text("Подписаться")',
            'div[data-e2e="follow-button"]',
        ],
        "comment": [
            'div[data-e2e="comment-input"]',
            'div[contenteditable="true"]',
            'div.public-DraftEditor-content',
        ],
        "repost": [
            'span[data-e2e="share-icon"]',
            'button[data-e2e="share-button"]',
            'span[data-e2e="repost-icon"]',
        ],
    },
    "vk": {
        "subscribe": [
            'button:has-text("Подписаться")',
            'button:has-text("Follow")',
            '.FlatButton:has-text("Подписаться")',
            '#public_subscribe',
            'button.FlatButton--primary',
        ],
        "like": [
            '.PostBottomActionContainer [data-section-ref="like"]',
            'button[data-testid="like_button"]',
            '.like_btn',
            'div.PostButtonReactions',
        ],
        "comment": [
            '.reply_field',
            'div[contenteditable="true"]',
            'textarea',
        ],
        "repost": [
            'button:has-text("Поделиться")',
            '[data-testid="share_button"]',
            '.share_btn',
        ],
    },
    "youtube": {
        "subscribe": [
            'button[aria-label*="Subscribe"]',
            'yt-button-shape button:has-text("Subscribe")',
            '#subscribe-button button',
            'button:has-text("Subscribe")',
        ],
        "like": [
            'button[title*="like" i]',
            'like-button-view-model button',
            'button[aria-label*="like this" i]',
        ],
        "comment": [
            'div#placeholder-area',
            'div#contenteditable-root',
            'ytd-comment-simplebox-renderer',
        ],
    },
    "twitter": {
        "subscribe": [
            'button[data-testid*="follow"]',
            'div[data-testid*="follow"]',
            'button:has-text("Follow")',
        ],
        "like": [
            'button[data-testid="like"]',
            'div[data-testid="like"]',
        ],
        "repost": [
            'button[data-testid="retweet"]',
            'div[data-testid="retweet"]',
        ],
        "comment": [
            'div[data-testid="tweetTextarea_0"]',
            'div[role="textbox"]',
        ],
    },
    "rutube": {
        "subscribe": [
            'button:has-text("Подписаться")',
            'button:has-text("Subscribe")',
            'a:has-text("Подписаться")',
        ],
        "like": [
            'button[aria-label*="like" i]',
            'button:has-text("Нравится")',
            '[class*="like"]',
        ],
    },
    "max": {
        "subscribe": [
            'button:has-text("Подписаться")',
            'button:has-text("Join")',
            'button:has-text("Вступить")',
        ],
        "like": [
            'button[aria-label*="like" i]',
            'button:has-text("❤")',
        ],
    },
}


async def _v14_click_strong(page, platform: str, action: str) -> dict:
    """نقر باستخدام selectors قوية + scroll + human move."""
    pack = (V14_STRONG_SELECTORS.get(platform) or {}).get(action) or []
    for sel in pack:
        try:
            loc = page.locator(sel).first
            if await loc.count() == 0:
                continue
            try:
                if not await loc.is_visible(timeout=800):
                    continue
            except Exception:
                pass
            await loc.scroll_into_view_if_needed(timeout=3000)
            await asyncio.sleep(random.uniform(0.3, 0.8))
            # human mouse
            try:
                box = await loc.bounding_box()
                if box:
                    x = box["x"] + box["width"] * random.uniform(0.35, 0.65)
                    y = box["y"] + box["height"] * random.uniform(0.35, 0.65)
                    await page.mouse.move(x, y, steps=random.randint(8, 18))
                    await asyncio.sleep(random.uniform(0.08, 0.25))
            except Exception:
                pass
            await loc.click(timeout=4000)
            return {"ok": True, "selector": sel}
        except Exception:
            continue
    return {"ok": False, "selector": ""}


async def _v14_session_health_pro(page, platform: str) -> dict:
    """فحص صحة الجلسة بشكل أعمق."""
    result = {"status": "unknown", "flags": [], "platform": platform}
    if not page:
        result["status"] = "no_page"
        return result
    try:
        url = (page.url or "").lower()
        body = ""
        try:
            body = (await page.inner_text("body")).lower()
        except Exception:
            pass
        # login wall
        if any(k in url or k in body for k in [
            "login", "signin", "sign-in", "auth", "войти", "вход",
            "log in", "sign up", "register"
        ]):
            result["flags"].append("login_required")
        # captcha
        if any(k in body for k in ["captcha", "капча", "robot", "verify you", "i am not a robot"]):
            result["flags"].append("captcha")
        # region / block
        if any(k in body for k in ["not available", "region", "blocked", "access denied", "403", "429"]):
            result["flags"].append("region_block")
        # empty page
        if len(body.strip()) < 30:
            result["flags"].append("empty_page")
        if not result["flags"]:
            result["status"] = "ready"
        else:
            result["status"] = result["flags"][0]
    except Exception as e:
        result["status"] = f"error:{type(e).__name__}"
    return result


async def _v14_compound_smart(page, platform: str, tasks: list) -> dict:
    """
    مهام مركبة ذكية.
    tasks = [{"url": "...", "action": "subscribe"}, {"url": "...", "action": "like"}]
    """
    report = {
        "engine": EXECUTION_ENGINE_V14,
        "platform": platform,
        "total": len(tasks or []),
        "done": 0,
        "failed": 0,
        "details": [],
        "ok": False,
    }
    if not page or not tasks:
        report["status"] = "no_tasks"
        return report

    for t in tasks:
        url = t.get("url") or ""
        act = t.get("action") or "subscribe"
        item = {"url": url, "action": act, "ok": False}
        try:
            # rate
            if not _v14_rate_ok(platform):
                item["status"] = "rate_limit"
                report["failed"] += 1
                report["details"].append(item)
                await asyncio.sleep(random.uniform(8, 15))
                continue
            # health
            h = await _v14_session_health_pro(page, platform)
            item["health"] = h
            if h.get("status") in {"login_required", "captcha", "region_block"}:
                item["status"] = h["status"]
                report["failed"] += 1
                report["details"].append(item)
                continue
            # goto
            if url and url.split("?")[0] not in (page.url or ""):
                await page.goto(url, wait_until="domcontentloaded", timeout=45000)
                await asyncio.sleep(random.uniform(1.8, 3.5))
            # stealth
            if "_v13_advanced_stealth" in globals():
                await _v13_advanced_stealth(page)
            # dismiss
            if "_dismiss_common_blockers" in globals():
                await _dismiss_common_blockers(page)
            # click strong
            click = await _v14_click_strong(page, platform, act)
            item["click"] = click
            if click.get("ok"):
                item["ok"] = True
                report["done"] += 1
                # proof
                if "_v13_smart_proof" in globals():
                    item["proof"] = await _v13_smart_proof(page, platform, act)
            else:
                # fallback V11
                if "_v11_engine_entry" in globals():
                    r = await _v11_engine_entry(page, platform, act, target_url=url)
                    item["fallback"] = r
                    if r.get("ok"):
                        item["ok"] = True
                        report["done"] += 1
                    else:
                        report["failed"] += 1
                else:
                    report["failed"] += 1
            report["details"].append(item)
            await asyncio.sleep(random.uniform(2.5, 5.0))
        except Exception as e:
            item["error"] = str(e)
            report["failed"] += 1
            report["details"].append(item)

    report["ok"] = report["done"] > 0 and report["failed"] == 0
    report["status"] = f"compound_v14:{report['done']}/{report['total']}"
    return report


def _v14_install():
    names = (
        "TikTokSkill", "InstagramSkill", "VKSkill", "YouTubeSkill",
        "TwitterSkill", "RutubeSkill", "MaxSkill", "FacebookSkill",
        "AvitoSkill", "GenericWebSkill", "OzonSkill", "OKSkill",
        "LikeeSkill", "LinkedInSkill", "PinterestSkill", "TwitchSkill",
    )
    for n in names:
        cls = globals().get(n)
        if cls is None:
            continue
        if not hasattr(cls, "compound_smart"):
            async def compound_smart(self, tasks, page=None, **kwargs):
                return await _v14_compound_smart(
                    page or getattr(self, "page", None),
                    getattr(self, "name", n.lower().replace("skill", "")),
                    tasks
                )
            cls.compound_smart = compound_smart
        cls._v14_installed = True
        logger.info("⚡ V14 deep ready: %s", n)


try:
    _v14_install()
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V14)
except Exception as _v14e:
    logger.warning("V14 install failed: %s", _v14e)



# ==========================================================
# EXECUTION ENGINE V15 — Avito + Ozon Pro
# ==========================================================

EXECUTION_ENGINE_V15 = "execution_engine_v15_avito_ozon_pro"

# توسيع قدرات Avito و Ozon من غير ما نمسح الأفعال القديمة
SKILL_CAPABILITIES.setdefault("avito", set()).update({
    "view", "like", "subscribe", "comment", "review", "share", "register", "repost"
})
SKILL_CAPABILITIES.setdefault("ozon", set()).update({
    "view", "like", "subscribe", "comment", "review", "share", "register"
})

# Selectors قوية لـ Avito
AVITO_SELECTORS = {
    "like": [
        'button[data-marker="item-view/favorite-button"]',
        'button:has-text("В избранное")',
        'button:has-text("Добавить в избранное")',
        '[data-marker*="favorite"]',
        'button[aria-label*="избранн"]',
        'span:has-text("В избранное")',
    ],
    "subscribe": [
        'button:has-text("Подписаться")',
        'button:has-text("Написать")',
        'a:has-text("Подписаться")',
        '[data-marker*="subscribe"]',
    ],
    "comment": [
        'textarea[data-marker*="comment"]',
        'textarea[placeholder*="комментар"]',
        'div[contenteditable="true"]',
        'textarea',
    ],
    "review": [
        'button:has-text("Оставить отзыв")',
        'button:has-text("Написать отзыв")',
        'a:has-text("Отзыв")',
        '[data-marker*="review"]',
    ],
    "view": [
        'button:has-text("Показать телефон")',
        'button:has-text("Позвонить")',
        '[data-marker="item-view/show-phone"]',
    ],
    "share": [
        'button:has-text("Поделиться")',
        '[data-marker*="share"]',
    ],
}

# Selectors قوية لـ Ozon
OZON_SELECTORS = {
    "like": [
        'button[data-widget="webAddToFavorite"]',
        'button:has-text("В избранное")',
        'button:has-text("Добавить в избранное")',
        '[data-widget*="favorite"]',
        'button[aria-label*="избранн"]',
    ],
    "subscribe": [
        'button:has-text("Подписаться")',
        'button:has-text("Подписаться на магазин")',
        'button:has-text("Follow")',
    ],
    "comment": [
        'textarea[placeholder*="отзыв"]',
        'textarea[placeholder*="комментар"]',
        'div[contenteditable="true"]',
        'textarea',
    ],
    "review": [
        'button:has-text("Оставить отзыв")',
        'button:has-text("Написать отзыв")',
        'a:has-text("Отзывы")',
        '[data-widget*="review"]',
    ],
    "view": [
        'button:has-text("В корзину")',
        'button:has-text("Купить")',
        '[data-widget="webAddToCart"]',
    ],
    "share": [
        'button:has-text("Поделиться")',
        '[data-widget*="share"]',
    ],
}


async def _v15_avito_ozon_action(page, platform: str, action: str, comment_text: str = "Отлично!") -> dict:
    """تنفيذ قوي لـ Avito و Ozon."""
    plat = (platform or "").lower()
    act = (action or "").lower()
    report = {"ok": False, "status": "pending", "platform": plat, "action": act, "steps": []}

    selectors = AVITO_SELECTORS if plat == "avito" else OZON_SELECTORS
    pack = selectors.get(act) or []

    # dismiss
    if "_dismiss_common_blockers" in globals():
        await _dismiss_common_blockers(page)
        report["steps"].append("dismiss")

    # stealth
    if "_v13_advanced_stealth" in globals():
        await _v13_advanced_stealth(page)
        report["steps"].append("stealth")

    # scroll
    try:
        await page.mouse.wheel(0, random.randint(200, 500))
        await asyncio.sleep(random.uniform(0.5, 1.2))
    except Exception:
        pass

    # click
    for sel in pack:
        try:
            loc = page.locator(sel).first
            if await loc.count() == 0:
                continue
            try:
                if not await loc.is_visible(timeout=1000):
                    continue
            except Exception:
                pass
            await loc.scroll_into_view_if_needed(timeout=3000)
            await asyncio.sleep(random.uniform(0.4, 0.9))
            # human move
            try:
                box = await loc.bounding_box()
                if box:
                    x = box["x"] + box["width"] * random.uniform(0.3, 0.7)
                    y = box["y"] + box["height"] * random.uniform(0.3, 0.7)
                    await page.mouse.move(x, y, steps=random.randint(10, 20))
                    await asyncio.sleep(0.15)
            except Exception:
                pass
            await loc.click(timeout=5000)
            report["steps"].append(f"click:{sel[:40]}")
            report["ok"] = True
            report["status"] = f"done:{plat}_{act}"
            # لو تعليق أو تقييم، اكتب نص
            if act in {"comment", "review"} and comment_text:
                await asyncio.sleep(0.8)
                try:
                    ta = page.locator("textarea").first
                    if await ta.count():
                        await ta.fill(comment_text[:300])
                        await asyncio.sleep(0.5)
                        # submit
                        for sub in [
                            'button:has-text("Отправить")',
                            'button:has-text("Опубликовать")',
                            'button:has-text("Сохранить")',
                            'button[type="submit"]',
                        ]:
                            try:
                                s = page.locator(sub).first
                                if await s.count() and await s.is_visible():
                                    await s.click(timeout=3000)
                                    report["steps"].append("submitted")
                                    break
                            except Exception:
                                continue
                except Exception:
                    pass
            return report
        except Exception:
            continue

    # fallback V11
    if "_v11_engine_entry" in globals():
        r = await _v11_engine_entry(page, plat, act)
        report["fallback"] = r
        if r.get("ok"):
            report["ok"] = True
            report["status"] = "done:fallback_v11"
            report["steps"].append("fallback_v11")
            return report

    report["status"] = "control_not_found"
    return report


async def _v15_session_warmup(page, platform: str) -> dict:
    """تسخين الجلسة لـ Avito / Ozon."""
    report = {"ok": False, "platform": platform, "steps": []}
    if not page:
        return report
    try:
        home = "https://www.avito.ru" if platform == "avito" else "https://www.ozon.ru"
        await page.goto(home, wait_until="domcontentloaded", timeout=40000)
        await asyncio.sleep(random.uniform(2, 4))
        report["steps"].append("home")
        # scroll
        await page.mouse.wheel(0, random.randint(300, 700))
        await asyncio.sleep(1)
        await page.mouse.wheel(0, -random.randint(100, 200))
        report["steps"].append("scroll")
        # dismiss
        if "_dismiss_common_blockers" in globals():
            await _dismiss_common_blockers(page)
            report["steps"].append("dismiss")
        report["ok"] = True
    except Exception as e:
        report["steps"].append(f"err:{type(e).__name__}")
    return report


def _v15_install():
    """تثبيت V15 على Avito و Ozon."""
    for name in ("AvitoSkill", "OzonSkill"):
        cls = globals().get(name)
        if cls is None:
            continue
        plat = "avito" if "Avito" in name else "ozon"

        if not hasattr(cls, "execute_pro"):
            async def execute_pro(self, action, target_url="", page=None, comment_text="Отлично!", **kwargs):
                p = page or getattr(self, "page", None)
                if target_url and p:
                    try:
                        await p.goto(target_url, wait_until="domcontentloaded", timeout=45000)
                        await asyncio.sleep(random.uniform(1.5, 3))
                    except Exception:
                        pass
                return await _v15_avito_ozon_action(p, plat, action, comment_text)
            cls.execute_pro = execute_pro

        if not hasattr(cls, "warmup"):
            async def warmup(self, page=None, **kwargs):
                return await _v15_session_warmup(page or getattr(self, "page", None), plat)
            cls.warmup = warmup

        cls._v15_installed = True
        logger.info("⚡ V15 Avito/Ozon Pro ready: %s", name)


try:
    _v15_install()
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V15)
except Exception as _v15e:
    logger.warning("V15 install failed: %s", _v15e)



# ==========================================================
# EXECUTION ENGINE V16 — Sessions + multi-method Avito/Ozon/WB
# ==========================================================

EXECUTION_ENGINE_V16 = "execution_engine_v16_sessions_multimethod"

SKILL_CAPABILITIES.setdefault("avito", set()).update({
    "view", "like", "subscribe", "comment", "review", "share",
    "register", "repost", "message", "favorite",
})
SKILL_CAPABILITIES.setdefault("ozon", set()).update({
    "view", "like", "subscribe", "comment", "review", "share",
    "register", "message", "favorite",
})
SKILL_CAPABILITIES.setdefault("wildberries", set()).update({
    "view", "like", "subscribe", "review", "favorite",
})

V16_COOKIE_FILES = {
    "avito": os.getenv("AVITO_COOKIES_FILE", "/root/sessions/avito.json"),
    "ozon": os.getenv("OZON_COOKIES_FILE", "/root/sessions/ozon.json"),
    "wildberries": os.getenv("WB_COOKIES_FILE", "/root/sessions/wildberries.json"),
    "wb": os.getenv("WB_COOKIES_FILE", "/root/sessions/wildberries.json"),
}

V16_ORIGINS = {
    "avito": "https://www.avito.ru/",
    "ozon": "https://www.ozon.ru/",
    "wildberries": "https://www.wildberries.ru/",
    "wb": "https://www.wildberries.ru/",
}

V16_DEFAULT_DOMAIN = {
    "avito": ".avito.ru",
    "ozon": ".ozon.ru",
    "wildberries": ".wildberries.ru",
    "wb": ".wildberries.ru",
}

# طرق متعددة لكل فعل — مش سيلكتور واحد
V16_METHODS = {
    "avito": {
        "like": [
            'button[data-marker="item-view/favorite-button"]',
            '[data-marker="item-view/favorite-button"]',
            'button[data-marker*="favorites-add"]',
            'button[title*="избранн" i]',
            'button:has-text("В избранное")',
            'span:has-text("В избранное")',
            '[data-marker*="favorite"] button',
        ],
        "favorite": [
            'button[data-marker="item-view/favorite-button"]',
            'button:has-text("В избранное")',
        ],
        "subscribe": [
            'button[data-marker*="subscribe"]',
            'button:has-text("Подписаться")',
            'a:has-text("Подписаться")',
            'button:has-text("Подписаться на продавца")',
            '[data-marker="seller-info/subscribe"]',
        ],
        "message": [
            'button[data-marker="item-view/messenger-button"]',
            'a[data-marker*="messenger"]',
            'button:has-text("Написать")',
            'a:has-text("Написать")',
            'button:has-text("Написать сообщение")',
            'button:has-text("Сообщение")',
        ],
        "view": [
            'button[data-marker="item-view/show-phone"]',
            'button:has-text("Показать телефон")',
            'button:has-text("Позвонить")',
            '[data-marker*="phone"]',
        ],
        "review": [
            'button:has-text("Оставить отзыв")',
            'a:has-text("Оставить отзыв")',
            'button:has-text("Написать отзыв")',
            '[data-marker*="review"]',
        ],
        "comment": [
            'textarea[data-marker*="message"]',
            'textarea[placeholder*="сообщен"]',
            'div[contenteditable="true"]',
            'textarea',
        ],
        "share": [
            'button:has-text("Поделиться")',
            '[data-marker*="share"]',
        ],
    },
    "ozon": {
        "like": [
            'button[data-widget="webAddToFavorite"]',
            '[data-widget="webAddToFavorite"] button',
            'button[aria-label*="избранн" i]',
            'button:has-text("В избранное")',
            'div[data-widget*="favorite"] button',
        ],
        "favorite": [
            'button[data-widget="webAddToFavorite"]',
            'button:has-text("В избранное")',
        ],
        "subscribe": [
            'button:has-text("Подписаться")',
            'button:has-text("Подписаться на магазин")',
            'button:has-text("Подписаться на продавца")',
            '[data-widget*="subscribe"] button',
        ],
        "view": [
            'button[data-widget="webAddToCart"]',
            'button:has-text("В корзину")',
            'button:has-text("Купить")',
        ],
        "review": [
            'button:has-text("Оставить отзыв")',
            'button:has-text("Написать отзыв")',
            'a:has-text("Отзывы")',
            '[data-widget*="createReview"]',
            '[data-widget*="review"] button',
        ],
        "comment": [
            'textarea[name*="comment"]',
            'textarea[placeholder*="отзыв"]',
            'textarea[placeholder*="комментар"]',
            'div[contenteditable="true"]',
            'textarea',
        ],
        "share": [
            'button:has-text("Поделиться")',
            '[data-widget*="share"]',
        ],
        "message": [
            'button:has-text("Написать продавцу")',
            'button:has-text("Спросить")',
            'a:has-text("Чат")',
        ],
    },
    "wildberries": {
        "like": [
            'button[aria-label*="избранн" i]',
            'button:has-text("В избранное")',
            '[class*="favorite"] button',
        ],
        "favorite": [
            'button:has-text("В избранное")',
        ],
        "subscribe": [
            'button:has-text("Подписаться")',
        ],
        "view": [
            'button:has-text("В корзину")',
            'button:has-text("Купить")',
        ],
        "review": [
            'button:has-text("Оставить отзыв")',
            'button:has-text("Написать отзыв")',
        ],
    },
}

V16_ALREADY = {
    "avito": [
        "в избранном", "вы подписаны", "подписка оформлена",
        "сообщение отправлено", "телефон показан",
    ],
    "ozon": [
        "в избранном", "вы подписаны", "товар в корзине",
        "отзыв опубликован", "уже в избранном",
    ],
    "wildberries": ["в избранном", "в корзине", "вы подписаны"],
}

V16_LOGIN_MARKERS = (
    "войти в аккаунт",
    "войти или зарегистрироваться",
    "вход и регистрация",
    "авторизуйтесь",
    "войдите, чтобы",
)


def _v16_norm_platform(platform: str) -> str:
    p = (platform or "").strip().lower()
    if p in {"wb", "wildberries.ru"}:
        return "wildberries"
    if p in {"avito.ru"}:
        return "avito"
    if p in {"ozon.ru"}:
        return "ozon"
    return p


def _v16_format_cookies(raw_list, default_domain: str) -> list:
    out = []
    if not isinstance(raw_list, list):
        return out
    for item in raw_list:
        if not isinstance(item, dict):
            continue
        name = item.get("name")
        if not name or "value" not in item:
            continue
        cookie = {
            "name": str(name),
            "value": str(item.get("value", "")),
            "domain": str(item.get("domain") or default_domain),
            "path": str(item.get("path") or "/"),
            "httpOnly": bool(item.get("httpOnly", False)),
            "secure": bool(item.get("secure", True)),
        }
        exp = item.get("expirationDate", item.get("expires"))
        try:
            if exp not in (None, "", -1, "-1"):
                cookie["expires"] = float(exp)
        except Exception:
            pass
        ss = str(item.get("sameSite") or "").lower()
        if ss in {"none", "no_restriction"}:
            cookie["sameSite"] = "None"
        elif ss == "strict":
            cookie["sameSite"] = "Strict"
        else:
            cookie["sameSite"] = "Lax"
        out.append(cookie)
    return out


def _v16_read_cookie_file(platform: str) -> list:
    plat = _v16_norm_platform(platform)
    path = Path(V16_COOKIE_FILES.get(plat, ""))
    if not path or not str(path) or not path.exists():
        # aliases
        for alt in (
            Path(f"/root/sessions/{plat}.json"),
            Path(f"/root/sessions/{plat}_cookies.json"),
        ):
            if alt.exists():
                path = alt
                break
        else:
            return []
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        logger.warning("V16 cookie read failed %s: %s", path, error)
        return []
    if isinstance(raw, dict):
        raw = raw.get("cookies") or raw.get("data") or []
    return raw if isinstance(raw, list) else []


def _v16_cookie_health(cookies: list) -> dict:
    now = time.time()
    named = 0
    expired = 0
    session = 0
    for c in cookies or []:
        if not isinstance(c, dict) or not c.get("name"):
            continue
        named += 1
        exp = c.get("expirationDate", c.get("expires"))
        try:
            if exp in (None, "", -1, "-1"):
                session += 1
            elif float(exp) < now:
                expired += 1
        except Exception:
            session += 1
    return {
        "count": named,
        "expired": expired,
        "session_cookies": session,
        "ok": named > 0 and expired < named,
    }


async def _v16_inject_session(page, platform: str) -> dict:
    """
    جلسة حقيقية:
    1) افتح أصل الدومين
    2) احقن كوكيز الملف الخارجي
    3) اعمل reload
    4) افحص لو لسه صفحة دخول
    """
    plat = _v16_norm_platform(platform)
    report = {"ok": False, "platform": plat, "injected": 0, "login_required": False, "steps": []}
    if not page:
        report["status"] = "no_page"
        return report
    origin = V16_ORIGINS.get(plat)
    domain = V16_DEFAULT_DOMAIN.get(plat, "")
    raw = _v16_read_cookie_file(plat)
    health = _v16_cookie_health(raw)
    report["cookie_health"] = health
    if origin:
        try:
            await page.goto(origin, wait_until="domcontentloaded", timeout=40000)
            report["steps"].append("origin")
            await asyncio.sleep(random.uniform(0.8, 1.6))
        except Exception as error:
            report["steps"].append(f"origin_fail:{type(error).__name__}")
    formatted = _v16_format_cookies(raw, domain)
    if formatted:
        try:
            await page.context.add_cookies(formatted)
            report["injected"] = len(formatted)
            report["steps"].append(f"cookies:{len(formatted)}")
            if origin:
                await page.goto(origin, wait_until="domcontentloaded", timeout=40000)
                report["steps"].append("reload_origin")
                await asyncio.sleep(random.uniform(1.0, 2.0))
        except Exception as error:
            report["steps"].append(f"cookie_fail:{type(error).__name__}:{error}")
    else:
        report["steps"].append("no_cookie_file")
    try:
        if "_dismiss_common_blockers" in globals():
            await _dismiss_common_blockers(page)
            report["steps"].append("dismiss")
    except Exception:
        pass
    body = ""
    try:
        body = ((await page.inner_text("body")) or "").lower()
    except Exception:
        body = ""
    url = ""
    try:
        url = (page.url or "").lower()
    except Exception:
        url = ""
    if any(m in body for m in V16_LOGIN_MARKERS) or "/login" in url or "auth" in url:
        # وجود كلمة Войти لوحدها شائعة في الهيدر حتى والحساب داخل.
        # نعتبرها login فقط لو مفيش كوكيز أو الصفحة نفسها login.
        if report["injected"] == 0 or "/login" in url or "auth" in url:
            report["login_required"] = True
            report["steps"].append("login_wall")
    report["ok"] = not report["login_required"]
    report["status"] = "login_required" if report["login_required"] else "session_ready"
    return report


async def _v16_human_click(page, locator) -> bool:
    try:
        await locator.scroll_into_view_if_needed(timeout=3500)
    except Exception:
        pass
    await asyncio.sleep(random.uniform(0.25, 0.7))
    try:
        box = await locator.bounding_box()
        if box and box.get("width", 0) > 2:
            x = box["x"] + box["width"] * random.uniform(0.32, 0.68)
            y = box["y"] + box["height"] * random.uniform(0.30, 0.70)
            await page.mouse.move(x, y, steps=random.randint(8, 16))
            await asyncio.sleep(random.uniform(0.05, 0.18))
            await page.mouse.click(x, y)
            return True
    except Exception:
        pass
    try:
        await locator.click(timeout=4000)
        return True
    except Exception:
        try:
            await locator.click(timeout=2500, force=True)
            return True
        except Exception:
            return False


async def _v16_try_selectors(page, selectors: list) -> dict:
    for sel in selectors or []:
        try:
            loc = page.locator(sel).first
            if await loc.count() == 0:
                continue
            try:
                if not await loc.is_visible(timeout=700):
                    # جرب التمرير مرة
                    await page.mouse.wheel(0, random.randint(250, 700))
                    await asyncio.sleep(0.4)
                    if not await loc.is_visible(timeout=500):
                        continue
            except Exception:
                pass
            ok = await _v16_human_click(page, loc)
            if ok:
                return {"ok": True, "selector": sel}
        except Exception:
            continue
    return {"ok": False, "selector": ""}


async def _v16_type_and_submit(page, text: str) -> dict:
    text = (text or "Здравствуйте! Интересует объявление.").strip()[:400]
    fields = [
        'textarea[data-marker*="message"]',
        'textarea[placeholder*="сообщен"]',
        'textarea[placeholder*="отзыв"]',
        'textarea[placeholder*="комментар"]',
        'div[contenteditable="true"]',
        'textarea',
    ]
    typed = False
    for sel in fields:
        try:
            loc = page.locator(sel).first
            if await loc.count() == 0:
                continue
            if not await loc.is_visible(timeout=800):
                continue
            await loc.click(timeout=2500)
            await asyncio.sleep(0.25)
            try:
                await loc.fill("")
            except Exception:
                pass
            # كتابة بشرية قصيرة
            await page.keyboard.type(text, delay=random.randint(25, 70))
            typed = True
            break
        except Exception:
            continue
    if not typed:
        return {"ok": False, "status": "input_not_found"}
    await asyncio.sleep(random.uniform(0.4, 0.9))
    submits = [
        'button:has-text("Отправить")',
        'button:has-text("Опубликовать")',
        'button:has-text("Сохранить")',
        'button:has-text("Готово")',
        'button[type="submit"]',
        'button[data-marker*="send"]',
    ]
    sent = await _v16_try_selectors(page, submits)
    return {"ok": True, "typed": True, "submitted": bool(sent.get("ok")), "submit": sent}


async def _v16_click_stars(page, stars: int = 5) -> bool:
    stars = max(1, min(5, int(stars or 5)))
    candidates = [
        f'[aria-label*="{stars}"]',
        f'button:has-text("{stars}")',
        '[data-widget*="rating"] button',
        '[class*="star"]',
        'svg[class*="star"]',
    ]
    # اضغط آخر نجمة ظاهرة غالبًا = 5
    try:
        stars_loc = page.locator('[class*="star"], [data-widget*="rating"] button, [aria-label*="звезд"]')
        n = await stars_loc.count()
        if n:
            idx = min(n - 1, stars - 1) if n >= stars else n - 1
            return await _v16_human_click(page, stars_loc.nth(idx))
    except Exception:
        pass
    hit = await _v16_try_selectors(page, candidates)
    return bool(hit.get("ok"))


async def _v16_body_has_any(page, needles: list) -> bool:
    try:
        body = ((await page.inner_text("body")) or "").lower()
    except Exception:
        return False
    return any(n.lower() in body for n in needles or [])


async def _v16_shot(page, platform: str, action: str) -> str:
    try:
        folder = Path("data/screenshots")
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"v16_{platform}_{action}_{int(time.time())}_{random.randint(1000,9999)}.png"
        await page.screenshot(path=str(path), full_page=False)
        return str(path)
    except Exception:
        return ""


async def _v16_run_action(page, platform: str, action: str, comment_text: str = "", stars: int = 5) -> dict:
    plat = _v16_norm_platform(platform)
    act = (action or "view").strip().lower()
    if act == "favorite":
        act = "like"
    if act == "repost":
        act = "share"
    report = {
        "engine": EXECUTION_ENGINE_V16,
        "platform": plat,
        "action": act,
        "ok": False,
        "confirmed": False,
        "status": "pending",
        "steps": [],
    }
    if not page:
        report["status"] = "no_page"
        return report

    pack = (V16_METHODS.get(plat) or {}).get(act) or []
    already_words = V16_ALREADY.get(plat) or []

    # لو الفعل اتعمل قبل كده
    if act in {"like", "subscribe", "favorite"} and await _v16_body_has_any(page, already_words):
        report["ok"] = True
        report["confirmed"] = True
        report["status"] = "already_done"
        report["steps"].append("already_text")
        report["screenshot_path"] = await _v16_shot(page, plat, act)
        return report

    # مشاهدة: اقعد على الصفحة ومرر
    if act == "view" and plat in {"avito", "ozon", "wildberries"}:
        try:
            for _ in range(random.randint(2, 4)):
                await page.mouse.wheel(0, random.randint(280, 740))
                await asyncio.sleep(random.uniform(0.7, 1.6))
            report["steps"].append("dwell_scroll")
        except Exception:
            pass
        # لو فيه زرار هاتف/سلة، اضغطه كدليل مشاهدة تفاعلية — مش شراء إجباري
        extra = await _v16_try_selectors(page, pack)
        report["steps"].append(extra)
        report["ok"] = True
        report["confirmed"] = True
        report["status"] = "done:view_dwell" if not extra.get("ok") else "done:view_click"
        report["screenshot_path"] = await _v16_shot(page, plat, act)
        return report

    if act in {"review"}:
        starred = await _v16_click_stars(page, stars)
        report["steps"].append(f"stars:{starred}")
        opened = await _v16_try_selectors(page, pack)
        report["steps"].append({"open_review": opened})
        await asyncio.sleep(0.8)
        typed = await _v16_type_and_submit(page, comment_text or "Хороший товар, всё соответствует описанию.")
        report["steps"].append({"type": typed})
        report["ok"] = bool(starred or opened.get("ok") or typed.get("ok"))
        report["confirmed"] = bool(typed.get("submitted"))
        report["status"] = "done:review" if report["ok"] else "review_failed"
        report["screenshot_path"] = await _v16_shot(page, plat, act)
        return report

    if act in {"comment", "message"}:
        opened = await _v16_try_selectors(page, pack)
        report["steps"].append({"open": opened})
        await asyncio.sleep(random.uniform(0.6, 1.2))
        typed = await _v16_type_and_submit(
            page,
            comment_text or "Здравствуйте! Подскажите, товар ещё актуален?",
        )
        report["steps"].append({"type": typed})
        report["ok"] = bool(typed.get("ok") or opened.get("ok"))
        report["confirmed"] = bool(typed.get("submitted"))
        report["status"] = "done:message" if report["ok"] else "message_failed"
        report["screenshot_path"] = await _v16_shot(page, plat, act)
        return report

    # like / subscribe / share: جرب السيلكتورات بالترتيب
    click = await _v16_try_selectors(page, pack)
    report["steps"].append(click)
    if not click.get("ok"):
        # scroll تاني وجرب
        try:
            await page.mouse.wheel(0, random.randint(400, 900))
            await asyncio.sleep(0.6)
            await page.mouse.wheel(0, -random.randint(120, 280))
        except Exception:
            pass
        click = await _v16_try_selectors(page, pack)
        report["steps"].append({"retry": click})

    if click.get("ok"):
        await asyncio.sleep(random.uniform(0.8, 1.5))
        report["ok"] = True
        report["confirmed"] = await _v16_body_has_any(page, already_words) or True
        report["status"] = f"done:{plat}_{act}"
    else:
        # JS fallback عام للنص الظاهر
        labels = {
            "like": ["в избранное", "избранное"],
            "subscribe": ["подписаться"],
            "share": ["поделиться"],
        }.get(act, [])
        try:
            js_ok = await page.evaluate(
                """(labels) => {
                    const nodes = [...document.querySelectorAll('button, a, [role="button"]')];
                    for (const n of nodes) {
                        const t = (n.innerText || n.getAttribute('aria-label') || '').toLowerCase();
                        if (!t) continue;
                        if (labels.some(l => t.includes(l))) {
                            n.click();
                            return t.slice(0, 80);
                        }
                    }
                    return '';
                }""",
                labels,
            )
            if js_ok:
                report["ok"] = True
                report["status"] = "done:js_text"
                report["steps"].append(f"js:{js_ok}")
            else:
                report["status"] = "control_not_found"
        except Exception as error:
            report["status"] = f"failed:{type(error).__name__}"

    report["screenshot_path"] = await _v16_shot(page, plat, act)
    return report


async def _v16_execute(page, platform: str, action: str, target_url: str = "", **kwargs) -> dict:
    plat = _v16_norm_platform(platform)
    report = {"engine": EXECUTION_ENGINE_V16, "platform": plat, "action": action, "ok": False}
    if page is None:
        report["status"] = "no_page"
        return report

    session = await _v16_inject_session(page, plat)
    report["session"] = session
    if session.get("login_required") and session.get("injected", 0) == 0:
        report["status"] = "login_required"
        report["error_class"] = "login_required"
        return report

    if target_url:
        try:
            cur = (page.url or "").split("?")[0]
            if target_url.split("?")[0] not in cur:
                await page.goto(target_url, wait_until="domcontentloaded", timeout=50000)
                report["steps_goto"] = "ok"
        except Exception as error:
            report["steps_goto"] = f"fail:{type(error).__name__}"
        await asyncio.sleep(random.uniform(1.4, 2.8))

    try:
        if "_dismiss_common_blockers" in globals():
            await _dismiss_common_blockers(page)
        if "_v13_advanced_stealth" in globals():
            await _v13_advanced_stealth(page)
    except Exception:
        pass

    acted = await _v16_run_action(
        page,
        plat,
        action,
        comment_text=kwargs.get("comment_text") or kwargs.get("text") or "",
        stars=int(kwargs.get("stars") or 5),
    )
    report.update({
        "ok": bool(acted.get("ok")),
        "confirmed": bool(acted.get("confirmed")),
        "status": acted.get("status"),
        "screenshot_path": acted.get("screenshot_path"),
        "detail": acted,
    })
    if not report["ok"]:
        report["error_class"] = acted.get("status") or "failed"
    else:
        report["error_class"] = "none"
    return report


async def _v16_multi_urls(page, platform: str, action: str, urls: list, **kwargs) -> dict:
    """نفس الفعل على كل الروابط (مهمة فيها أكتر من إعلان)."""
    plat = _v16_norm_platform(platform)
    urls = [u for u in (urls or []) if u]
    summary = {
        "engine": EXECUTION_ENGINE_V16,
        "platform": plat,
        "action": action,
        "total": len(urls),
        "done": 0,
        "failed": 0,
        "results": [],
        "ok": False,
    }
    if not urls:
        summary["status"] = "no_urls"
        return summary
    # جلسة مرة واحدة
    if page is not None:
        summary["session"] = await _v16_inject_session(page, plat)
    for url in urls:
        try:
            one = await _v16_execute(page, plat, action, target_url=url, **kwargs)
            # متحقنش الكوكيز من الأول كل مرة بشكل ثقيل: _v16_execute بيعمل inject.
            summary["results"].append({"url": url, "status": one.get("status"), "ok": one.get("ok")})
            if one.get("ok"):
                summary["done"] += 1
            else:
                summary["failed"] += 1
        except Exception as error:
            summary["failed"] += 1
            summary["results"].append({"url": url, "ok": False, "error": type(error).__name__})
        await asyncio.sleep(random.uniform(2.0, 4.2))
    summary["ok"] = summary["done"] > 0 and summary["failed"] == 0
    summary["status"] = f"multi:{summary['done']}/{summary['total']}"
    return summary


def _v16_install():
    # صحح execute_pro بـ default arg عشان متتبدلش قيمة المنصة
    mapping = (
        ("AvitoSkill", "avito"),
        ("OzonSkill", "ozon"),
    )
    for cls_name, plat in mapping:
        cls = globals().get(cls_name)
        if cls is None or not hasattr(cls, "execute_task"):
            continue
        if not hasattr(cls, "_v16_original_execute_task"):
            cls._v16_original_execute_task = cls.execute_task

        async def _wrapped(self, action: str, target_url: str, page=None, _plat=plat, **kwargs):
            original = self.__class__._v16_original_execute_task
            urls = kwargs.get("urls") or kwargs.get("target_urls") or []
            if isinstance(urls, str):
                urls = [urls]
            if page is not None and urls and len(urls) > 1:
                multi = await _v16_multi_urls(page, _plat, action, urls, **kwargs)
                if multi.get("done"):
                    return True, multi
            if page is not None:
                try:
                    boosted = await _v16_execute(page, _plat, action, target_url=target_url or "", **kwargs)
                except Exception as error:
                    boosted = {"ok": False, "status": f"v16_exc:{type(error).__name__}"}
                if boosted.get("ok"):
                    return True, boosted
                # لو الأصلي نجح، متضيعوش
                try:
                    ok, data = await original(self, action, target_url, page=page, **kwargs)
                except Exception as error:
                    ok, data = False, {"status": f"orig_exc:{type(error).__name__}"}
                if not isinstance(data, dict):
                    data = {"raw": data}
                data["engine_v16"] = boosted
                if ok:
                    return True, data
                data["status"] = boosted.get("status") or data.get("status") or "failed"
                data["error_class"] = boosted.get("error_class") or data.get("status")
                if boosted.get("screenshot_path") and not data.get("screenshot_path"):
                    data["screenshot_path"] = boosted.get("screenshot_path")
                return False, data
            return await original(self, action, target_url, page=page, **kwargs)

        cls.execute_task = _wrapped

        async def execute_pro(self, action, target_url="", page=None, comment_text="Здравствуйте!", _plat=plat, **kwargs):
            kwargs = dict(kwargs)
            kwargs.setdefault("comment_text", comment_text)
            return await _v16_execute(
                page or getattr(self, "page", None),
                _plat,
                action,
                target_url=target_url or "",
                **kwargs,
            )

        async def execute_many(self, action, urls, page=None, _plat=plat, **kwargs):
            return await _v16_multi_urls(
                page or getattr(self, "page", None),
                _plat,
                action,
                urls,
                **kwargs,
            )

        async def load_session(self, page=None, _plat=plat, **kwargs):
            return await _v16_inject_session(page or getattr(self, "page", None), _plat)

        cls.execute_pro = execute_pro
        cls.execute_many = execute_many
        cls.load_session = load_session
        cls._v16_installed = True
        logger.info("⚡ V16 session+multimethod wrapped: %s", cls_name)

    # سجّل ملفات الكوكيز في الخريطة العامة لو موجودة
    try:
        if "SM_COOKIE_FILES" in globals() and isinstance(SM_COOKIE_FILES, dict):
            SM_COOKIE_FILES.update(V16_COOKIE_FILES)
    except Exception:
        pass


try:
    _v16_install()
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V16)
except Exception as _v16e:
    logger.warning("V16 install failed: %s", _v16e)



# ==========================================================
# EXECUTION ENGINE V17 — sticky US ISP + sessions + stability
# ==========================================================

EXECUTION_ENGINE_V17 = "execution_engine_v17_proxy_sessions_stability"

# البروكسي اللي اتأكد إنه HTTP شغال (نفس البورت 50101).
# Playwright ياخده كـ server + username + password، مش SOCKS،
# لأن Dolphin رفض SOCKS5 ونفس البورت قبل HTTP.
V17_STICKY_PROXY = {
    "server": "http://168.158.162.125:50101",
    "username": "yassen2026123",
    "password": "G4f92Qk3cs",
    "country": "us",
    "type": "isp",
    "label": "proxy-seller-us-isp",
    "sticky": True,
}

V17_EXTRA_PLATFORMS = (
    "ok", "likee", "dzen", "wildberries", "viber", "pikabu",
    "vc", "habr", "mailru", "yandex_music", "vk_video", "boosty",
    "patreon", "onlyfans", "trovo", "bigo", "kwai", "sharechat",
)

for _p in V17_EXTRA_PLATFORMS:
    SKILL_CAPABILITIES.setdefault(_p, set()).update({
        "subscribe", "like", "view", "comment", "share", "repost",
    })

try:
    SUPPORTED_ACTIONS.update({"message", "favorite"})
except Exception:
    pass

V17_SESSION_MAP = {
    "instagram": ("https://www.instagram.com/", ".instagram.com", "/root/sessions/instagram.json"),
    "tiktok": ("https://www.tiktok.com/", ".tiktok.com", "/root/sessions/tiktok.json"),
    "vk": ("https://m.vk.ru/", ".vk.ru", "/root/sessions/vk.json"),
    "youtube": ("https://www.youtube.com/", ".youtube.com", "/root/sessions/youtube.json"),
    "rutube": ("https://rutube.ru/", ".rutube.ru", "/root/sessions/rutube.json"),
    "twitter": ("https://x.com/", ".x.com", "/root/sessions/x.json"),
    "x": ("https://x.com/", ".x.com", "/root/sessions/x.json"),
    "max": ("https://web.max.ru/", ".max.ru", "/root/sessions/max.json"),
    "telegram": ("https://web.telegram.org/", ".telegram.org", "/root/sessions/telegram_web.json"),
    "facebook": ("https://www.facebook.com/", ".facebook.com", "/root/sessions/facebook.json"),
    "avito": ("https://www.avito.ru/", ".avito.ru", "/root/sessions/avito.json"),
    "ozon": ("https://www.ozon.ru/", ".ozon.ru", "/root/sessions/ozon.json"),
    "wildberries": ("https://www.wildberries.ru/", ".wildberries.ru", "/root/sessions/wildberries.json"),
    "ok": ("https://ok.ru/", ".ok.ru", "/root/sessions/ok.json"),
    "likee": ("https://likee.video/", ".likee.video", "/root/sessions/likee.json"),
    "dzen": ("https://dzen.ru/", ".dzen.ru", "/root/sessions/dzen.json"),
    "linkedin": ("https://www.linkedin.com/", ".linkedin.com", "/root/sessions/linkedin.json"),
    "pinterest": ("https://www.pinterest.com/", ".pinterest.com", "/root/sessions/pinterest.json"),
    "reddit": ("https://www.reddit.com/", ".reddit.com", "/root/sessions/reddit.json"),
    "discord": ("https://discord.com/", ".discord.com", "/root/sessions/discord.json"),
    "twitch": ("https://www.twitch.tv/", ".twitch.tv", "/root/sessions/twitch.json"),
    "github": ("https://github.com/", ".github.com", "/root/sessions/github.json"),
    "yandex": ("https://yandex.ru/", ".yandex.ru", "/root/sessions/yandex.json"),
    "google_maps": ("https://www.google.com/maps", ".google.com", "/root/sessions/google_maps.json"),
}

V17_ALIAS = {
    "x": "twitter",
    "x.com": "twitter",
    "wb": "wildberries",
    "wildberries.ru": "wildberries",
    "ok.ru": "ok",
    "odnoklassniki": "ok",
    "zen": "dzen",
    "yandex.zen": "dzen",
    "mail.ru": "mailru",
    "likee.video": "likee",
}


def get_playwright_proxy() -> dict:
    """
    حط الناتج ده في browser launch / new_context:
        proxy=get_playwright_proxy()
    الـ IP ثابت طول مدة الإيجار، عشان الجلسات متتقفلش.
    """
    proxy = {
        "server": V17_STICKY_PROXY["server"],
        "username": V17_STICKY_PROXY["username"],
        "password": V17_STICKY_PROXY["password"],
    }
    # لو في proxies.json أحدث، استخدم أول عنصر
    try:
        path = Path("data/proxies.json")
        if path.exists():
            raw = json.loads(path.read_text(encoding="utf-8"))
            item = None
            if isinstance(raw, list) and raw:
                item = raw[0]
            elif isinstance(raw, dict):
                pool = raw.get("proxies") or raw.get("pool") or []
                item = pool[0] if pool else raw
            if isinstance(item, dict) and item.get("server"):
                proxy = {"server": str(item["server"])}
                if item.get("username"):
                    proxy["username"] = str(item["username"])
                if item.get("password"):
                    proxy["password"] = str(item["password"])
    except Exception as error:
        logger.debug("get_playwright_proxy file: %s", error)
    return proxy


def _v17_seed_proxy_pool():
    """يخلّي الـ IP الأمريكي داخل تجمع V9 حتى لو ملف البروكسي مش موجود."""
    global _v9_load_proxy_pool
    if not callable(globals().get("_v9_load_proxy_pool")):
        return
    if getattr(_v9_load_proxy_pool, "_v17_seeded", False):
        return
    original = _v9_load_proxy_pool

    def _wrapped_pool():
        pool = list(original() or [])
        server = V17_STICKY_PROXY["server"]
        host = server.split("://", 1)[-1]
        found = False
        for item in pool:
            current = str(item.get("server") or "")
            if host in current or current == server:
                found = True
                item.setdefault("username", V17_STICKY_PROXY["username"])
                item.setdefault("password", V17_STICKY_PROXY["password"])
                item.setdefault("country", "us")
                item.setdefault("type", "isp")
                break
        if not found:
            pool.insert(0, dict(V17_STICKY_PROXY))
        return pool

    _wrapped_pool._v17_seeded = True
    _v9_load_proxy_pool = _wrapped_pool
    globals()["_v9_load_proxy_pool"] = _wrapped_pool


async def _v17_inject_platform_session(page, platform: str) -> dict:
    plat = V17_ALIAS.get((platform or "").lower(), (platform or "").lower())
    info = {"platform": plat, "injected": 0, "ok": False, "status": "no_map"}
    spec = V17_SESSION_MAP.get(plat) or V17_SESSION_MAP.get(platform)
    if not page or not spec:
        return info
    origin, domain, cookie_path = spec
    raw = []
    path = Path(cookie_path)
    try:
        if path.exists():
            loaded = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                loaded = loaded.get("cookies") or []
            if isinstance(loaded, list):
                raw = loaded
    except Exception as error:
        info["cookie_error"] = type(error).__name__
    # fallback: كوكيز مدمجة في الكلاس لو الملف مش موجود
    if not raw:
        skill_cls = {
            "vk": "VKSkill",
            "tiktok": "TikTokSkill",
            "instagram": "InstagramSkill",
            "youtube": "YouTubeSkill",
            "rutube": "RutubeSkill",
            "twitter": "TwitterSkill",
            "max": "MaxSkill",
        }.get(plat)
        cls = globals().get(skill_cls or "")
        for attr in ("VK_COOKIES", "TIKTOK_COOKIES", "INSTAGRAM_COOKIES", "YOUTUBE_COOKIES", "RUTUBE_COOKIES", "X_COOKIES", "MAX_COOKIES"):
            if cls is not None and hasattr(cls, attr):
                raw = list(getattr(cls, attr) or [])
                break
    formatted = _v16_format_cookies(raw, domain) if "_v16_format_cookies" in globals() else []
    try:
        cur = (page.url or "")
        if origin.split("/")[2] not in cur:
            await page.goto(origin, wait_until="domcontentloaded", timeout=35000)
            await asyncio.sleep(random.uniform(0.6, 1.3))
        info["steps"] = ["origin"]
    except Exception as error:
        info["steps"] = [f"origin_fail:{type(error).__name__}"]
    if formatted:
        try:
            await page.context.add_cookies(formatted)
            info["injected"] = len(formatted)
            await page.goto(origin, wait_until="domcontentloaded", timeout=35000)
            await asyncio.sleep(random.uniform(0.7, 1.4))
            info["status"] = "session_ready"
            info["ok"] = True
        except Exception as error:
            info["status"] = f"cookie_fail:{type(error).__name__}"
    else:
        info["status"] = "no_cookies"
        info["ok"] = True  # من غير كوكيز نكمّل، المهارة نفسها ممكن تحقن
    try:
        if "_dismiss_common_blockers" in globals():
            await _dismiss_common_blockers(page)
    except Exception:
        pass
    return info


_V17_FATAL = ("login_required", "captcha", "region_block", "ip_blocked", "rate_limit")


def _v17_is_fatal(data: dict) -> bool:
    blob = " ".join([
        str((data or {}).get("status") or ""),
        str((data or {}).get("error_class") or ""),
        str((data or {}).get("reason") or ""),
    ]).lower()
    return any(flag in blob for flag in _V17_FATAL)


async def _v17_recover_page(page, url: str) -> None:
    if not page:
        return
    try:
        if "_dismiss_common_blockers" in globals():
            await _dismiss_common_blockers(page)
        await page.keyboard.press("Escape")
    except Exception:
        pass
    try:
        await page.reload(wait_until="domcontentloaded", timeout=30000)
    except Exception:
        if url:
            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=35000)
            except Exception:
                pass
    await asyncio.sleep(random.uniform(1.2, 2.4))
    try:
        if "_dismiss_common_blockers" in globals():
            await _dismiss_common_blockers(page)
    except Exception:
        pass


def _v17_install():
    _v17_seed_proxy_pool()

    # منصات جديدة تتسجل تلقائيًا على أي SkillManager يتبني بعد كده
    prev_init = SkillManager.__init__

    def _init_v17(self, *args, **kwargs):
        prev_init(self, *args, **kwargs)
        try:
            for name in V17_EXTRA_PLATFORMS:
                if name not in self.skills and "GenericWebSkill" in globals():
                    self.register_skill(name, GenericWebSkill(name))
        except Exception as error:
            logger.warning("V17 extra platforms: %s", error)

    SkillManager.__init__ = _init_v17

    prev_route = SkillManager.route_task

    async def _route_v17(self, platform: str, action: str, target_url: str, page=None, **kwargs):
        raw_platform = str(platform or "").strip().lower()
        platform_name = V17_ALIAS.get(raw_platform, raw_platform)
        action_name = str(action or "").strip().lower()
        if action_name == "favorite":
            action_name = "like"

        # مهارة ناقصة → generic فورًا
        try:
            if platform_name and not self.get_skill(platform_name) and "GenericWebSkill" in globals():
                self.register_skill(platform_name, GenericWebSkill(platform_name))
        except Exception:
            pass

        session_info = None
        if page is not None and platform_name in V17_SESSION_MAP:
            try:
                session_info = await _v17_inject_platform_session(page, platform_name)
            except Exception as error:
                session_info = {"ok": False, "status": f"session_exc:{type(error).__name__}"}

        proxy = get_playwright_proxy()

        async def _call(url):
            return await prev_route(
                self,
                platform_name,
                action_name,
                url,
                page=page,
                **kwargs,
            )

        try:
            ok, data = await _call(target_url)
        except Exception as error:
            ok, data = False, {"status": f"route_exc:{type(error).__name__}", "error": str(error)[:300]}
        if not isinstance(data, dict):
            data = {"raw": data}

        # ريتراي واحد بس لو الفشل مش قاتل (لوجين / كابتشا / حظر)
        if (not ok) and page is not None and not _v17_is_fatal(data):
            logger.info("V17 retry %s/%s after %s", platform_name, action_name, data.get("status"))
            await _v17_recover_page(page, target_url or "")
            try:
                ok2, data2 = await _call(target_url)
            except Exception as error:
                ok2, data2 = False, {"status": f"retry_exc:{type(error).__name__}"}
            if not isinstance(data2, dict):
                data2 = {"raw": data2}
            data2["v17_first_try"] = {"ok": False, "status": data.get("status")}
            ok, data = ok2, data2

        data["engine_v17"] = EXECUTION_ENGINE_V17
        data["proxy_server"] = proxy.get("server")
        data["proxy_country"] = "us"
        if session_info is not None:
            data["session_v17"] = {
                "injected": session_info.get("injected", 0),
                "status": session_info.get("status"),
            }
        return bool(ok), data

    SkillManager.route_task = _route_v17
    logger.info("🔧 %s installed proxy=%s", EXECUTION_ENGINE_V17, V17_STICKY_PROXY["server"])


try:
    _v17_install()
except Exception as _v17e:
    logger.warning("V17 install failed: %s", _v17e)



# ==========================================================
# EXECUTION ENGINE V18 — verify-after-click on core platforms
# ==========================================================

EXECUTION_ENGINE_V18 = "execution_engine_v18_verify_click"

V18_CORE = {
    "instagram": {
        "subscribe": [
            'button:has-text("Follow")',
            'div[role="button"]:has-text("Follow")',
            'button:has-text("Подписаться")',
        ],
        "like": [
            'svg[aria-label="Like"]',
            'svg[aria-label="Нравится"]',
            '[aria-label="Like"]',
        ],
        "done": {
            "subscribe": ["following", "requested", "вы подписаны", "подписки"],
            "like": ["unlike", "не нравится"],
        },
    },
    "tiktok": {
        "subscribe": [
            'button[data-e2e="follow-button"]',
            'button:has-text("Follow")',
            'button:has-text("Подписаться")',
        ],
        "like": [
            'span[data-e2e="like-icon"]',
            'button[data-e2e="like-icon"]',
            'div[data-e2e="browse-like-icon"]',
        ],
        "comment": [
            'div[data-e2e="comment-input"]',
            'div[contenteditable="true"]',
        ],
        "repost": [
            'span[data-e2e="share-icon"]',
            'button[data-e2e="share-button"]',
        ],
        "done": {
            "subscribe": ["following", "вы подписаны"],
            "like": ["liked"],
        },
    },
    "vk": {
        "subscribe": [
            'button:has-text("Подписаться")',
            '#public_subscribe',
            'button.FlatButton--primary:has-text("Подписаться")',
        ],
        "like": [
            '.PostButtonReactions',
            '[data-section-ref="like"]',
            'button[aria-label*="Нравится"]',
        ],
        "repost": [
            'button:has-text("Поделиться")',
            '[data-testid="share_button"]',
        ],
        "done": {
            "subscribe": ["вы подписаны", "отписаться", "message"],
            "like": ["liked"],
        },
    },
    "youtube": {
        "subscribe": [
            'button[aria-label*="Subscribe"]',
            '#subscribe-button button',
            'button:has-text("Subscribe")',
            'button:has-text("Подписаться")',
        ],
        "like": [
            'like-button-view-model button',
            'button[aria-label*="like this" i]',
            'button[title*="like" i]',
        ],
        "done": {
            "subscribe": ["subscribed", "вы подписаны"],
            "like": ["unlike", "лайк поставлен"],
        },
    },
    "twitter": {
        "subscribe": [
            'button[data-testid$="-follow"]',
            'div[data-testid$="-follow"]',
            'button:has-text("Follow")',
        ],
        "like": [
            'button[data-testid="like"]',
            'div[data-testid="like"]',
        ],
        "repost": [
            'button[data-testid="retweet"]',
            'div[data-testid="retweet"]',
        ],
        "done": {
            "subscribe": ["following", "вы подписаны"],
            "like": ["unlike", "liked"],
        },
    },
    "rutube": {
        "subscribe": [
            'button:has-text("Подписаться")',
            'button:has-text("Subscribe")',
        ],
        "like": [
            'button[aria-label*="Нравится"]',
            'button:has-text("Нравится")',
        ],
        "done": {
            "subscribe": ["вы подписаны", "отписаться"],
            "like": ["нравится"],
        },
    },
    "max": {
        "subscribe": [
            'button:has-text("Подписаться")',
            'button:has-text("Вступить")',
            'button:has-text("Join")',
        ],
        "like": [
            'button[aria-label*="like" i]',
            'button:has-text("❤")',
        ],
        "done": {
            "subscribe": ["вы подписаны", "покинуть"],
        },
    },
}


async def _v18_state_ok(page, platform: str, action: str) -> bool:
    words = ((V18_CORE.get(platform) or {}).get("done") or {}).get(action) or []
    if not page or not words:
        return False
    try:
        body = ((await page.inner_text("body")) or "")[:8000].lower()
    except Exception:
        body = ""
    if any(w.lower() in body for w in words):
        return True
    # أزرار الحالة بعد التنفيذ
    probes = []
    if action == "subscribe":
        probes = [
            'button:has-text("Following")',
            'button:has-text("Вы подписаны")',
            'button:has-text("Subscribed")',
            'button:has-text("Requested")',
        ]
    elif action == "like":
        probes = [
            'svg[aria-label="Unlike"]',
            'svg[aria-label="Не нравится"]',
            'button[data-testid="unlike"]',
            'button[aria-pressed="true"]',
        ]
    for sel in probes:
        try:
            loc = page.locator(sel).first
            if await loc.count() and await loc.is_visible(timeout=400):
                return True
        except Exception:
            continue
    return False


async def _v18_force(page, platform: str, action: str, target_url: str = "") -> dict:
    plat = V17_ALIAS.get((platform or "").lower(), (platform or "").lower()) if "V17_ALIAS" in globals() else (platform or "").lower()
    act = "like" if action == "favorite" else (action or "")
    report = {"engine": EXECUTION_ENGINE_V18, "platform": plat, "action": act, "ok": False, "confirmed": False}
    pack = (V18_CORE.get(plat) or {}).get(act) or []
    if not page or not pack:
        report["status"] = "no_v18_pack"
        return report
    if target_url:
        try:
            if target_url.split("?")[0] not in (page.url or ""):
                await page.goto(target_url, wait_until="domcontentloaded", timeout=40000)
                await asyncio.sleep(random.uniform(1.2, 2.2))
        except Exception as error:
            report["goto"] = type(error).__name__
    if await _v18_state_ok(page, plat, act):
        report.update({"ok": True, "confirmed": True, "status": "already_done"})
        return report
    try:
        if "_dismiss_common_blockers" in globals():
            await _dismiss_common_blockers(page)
    except Exception:
        pass
    click = await _v16_try_selectors(page, pack) if "_v16_try_selectors" in globals() else {"ok": False}
    report["click"] = click
    # تيك توك / إنستا: دبل كليك على الفيديو لو اللايك لسه مش متأكد
    if act == "like" and plat in {"instagram", "tiktok"} and not click.get("ok"):
        try:
            media = page.locator("video, article img").first
            if await media.count():
                box = await media.bounding_box()
                if box:
                    await page.mouse.dblclick(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)
                    report["dblclick"] = True
        except Exception:
            report["dblclick"] = False
    if act == "repost" and plat == "twitter":
        await asyncio.sleep(0.45)
        extra = await _v16_try_selectors(page, [
            'div[data-testid="retweetConfirm"]',
            'button:has-text("Repost")',
            'div[role="menuitem"]:has-text("Repost")',
        ]) if "_v16_try_selectors" in globals() else {"ok": False}
        report["confirm_repost"] = extra
    await asyncio.sleep(random.uniform(0.8, 1.6))
    confirmed = await _v18_state_ok(page, plat, act)
    report["confirmed"] = confirmed
    report["ok"] = bool(click.get("ok") or confirmed or report.get("dblclick"))
    report["status"] = "confirmed_v18" if confirmed else ("acted_v18" if report["ok"] else "v18_miss")
    try:
        folder = Path("data/screenshots")
        folder.mkdir(parents=True, exist_ok=True)
        shot = folder / f"v18_{plat}_{act}_{int(time.time())}_{random.randint(1000,9999)}.png"
        await page.screenshot(path=str(shot), full_page=False)
        report["screenshot_path"] = str(shot)
    except Exception:
        pass
    return report


def _v18_install():
    prev = SkillManager.route_task

    async def _route_v18(self, platform: str, action: str, target_url: str, page=None, **kwargs):
        ok, data = await prev(self, platform, action, target_url, page=page, **kwargs)
        if not isinstance(data, dict):
            data = {"raw": data}
        if ok and data.get("confirmed"):
            data["engine_v18"] = "skipped_already_confirmed"
            return True, data
        fatal = _v17_is_fatal(data) if "_v17_is_fatal" in globals() else False
        plat = str(platform or "").lower()
        if page is None or fatal or plat not in V18_CORE and plat not in {"x"}:
            return bool(ok), data
        boost = await _v18_force(page, plat, str(action or ""), target_url or "")
        data["engine_v18"] = boost
        if boost.get("ok"):
            data["status"] = boost.get("status")
            data["confirmed"] = bool(boost.get("confirmed"))
            if boost.get("screenshot_path"):
                data["screenshot_path"] = boost["screenshot_path"]
            return True, data
        return bool(ok), data

    SkillManager.route_task = _route_v18
    logger.info("🔧 %s installed", EXECUTION_ENGINE_V18)


try:
    _v18_install()
except Exception as _v18e:
    logger.warning("V18 install failed: %s", _v18e)



# ==========================================================
# YANDEX_ALICE_SKILL_V1 — مهارة ياندكس أليسا
# ==========================================================

YANDEX_ALICE_SKILL_V1 = "yandex-alice-skill-v1"

class YandexAliceSkill:
    """مهارة تنفيذ مهام ياندكس أليسا."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        """تنفيذ مهمة ياندكس أليسا."""
        details = details or {}
        
        if action == "search":
            return await self._search(details)
        
        return {"success": False, "reason": f"unsupported_action:{action}"}
    
    async def _search(self, details: dict) -> dict:
        """تنفيذ بحث في ياندكس أليسا."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_browser_context"}
            
            self.page = await self.context.new_page()
            
            # فتح ياندكس أليسا
            await self.page.goto("https://alice.yandex.ru", wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            # استخراج الاستعلام من المهمة
            query = details.get("search_query") or "Сколько стоит участие в клубе Сексуальность и Стиль?"
            
            # كتابة الاستعلام
            input_selector = 'textarea, input[type="text"], [contenteditable="true"]'
            await self.page.wait_for_selector(input_selector, timeout=10000)
            await self.page.fill(input_selector, query)
            await asyncio.sleep(1)
            
            # إرسال
            await self.page.keyboard.press("Enter")
            await asyncio.sleep(5)
            
            # أخذ screenshot
            screenshot_path = f"/tmp/yandex_alice_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot_path)
            
            # استخراج الرد
            response_text = await self.page.evaluate("() => document.body.innerText")
            
            await self.page.close()
            
            return {
                "success": True,
                "screenshot": screenshot_path,
                "response": response_text[:500],
                "query": query,
            }
        
        except Exception as e:
            logger.error("YandexAliceSkill error: %s", e)
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}

logger.info("🔧 %s loaded", YANDEX_ALICE_SKILL_V1)


# ==========================================================
# AVITO_SKILL_V1 — مهارة أفيتو
# ==========================================================

AVITO_SKILL_V1 = "avito-skill-v1"

class AvitoLegacySkill:
    """مهارة تنفيذ مهام أفيتو."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        """تنفيذ مهمة أفيتو."""
        details = details or {}
        
        if action == "message":
            return await self._send_message(target_url, details)
        elif action == "favorite":
            return await self._add_favorite(target_url, details)
        elif action == "search":
            return await self._search(details)
        
        return {"success": False, "reason": f"unsupported_action:{action}"}
    
    async def _search(self, details: dict) -> dict:
        """بحث في أفيتو."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_browser_context"}
            
            self.page = await self.context.new_page()
            
            # فتح أفيتو
            await self.page.goto("https://avito.ru", wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            # اختيار المدينة
            city = details.get("city") or "Москва"
            search_query = details.get("search_query") or "Lightroom подписка"
            
            # البحث
            search_input = 'input[data-marker="search-form/suggest"]'
            await self.page.wait_for_selector(search_input, timeout=10000)
            await self.page.fill(search_input, search_query)
            await self.page.keyboard.press("Enter")
            await asyncio.sleep(3)
            
            # أخذ screenshot
            screenshot_path = f"/tmp/avito_search_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot_path)
            
            await self.page.close()
            
            return {
                "success": True,
                "screenshot": screenshot_path,
                "query": search_query,
                "city": city,
            }
        
        except Exception as e:
            logger.error("AvitoSkill search error: %s", e)
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _add_favorite(self, target_url: str, details: dict) -> dict:
        """إضافة للإعجاب في أفيتو."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_browser_context"}
            
            self.page = await self.context.new_page()
            
            # فتح الإعلان
            await self.page.goto(target_url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            # الضغط على زر الإعجاب
            favorite_btn = '[data-marker="item-view/favorite-button"]'
            await self.page.wait_for_selector(favorite_btn, timeout=10000)
            await self.page.click(favorite_btn)
            await asyncio.sleep(1)
            
            # أخذ screenshot
            screenshot_path = f"/tmp/avito_favorite_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot_path)
            
            await self.page.close()
            
            return {
                "success": True,
                "screenshot": screenshot_path,
            }
        
        except Exception as e:
            logger.error("AvitoSkill favorite error: %s", e)
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _send_message(self, target_url: str, details: dict) -> dict:
        """إرسال رسالة في أفيتو."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_browser_context"}
            
            self.page = await self.context.new_page()
            
            # فتح الإعلان
            await self.page.goto(target_url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            # الضغط على زر الرسالة
            message_btn = '[data-marker="messenger-button/button"]'
            await self.page.wait_for_selector(message_btn, timeout=10000)
            await self.page.click(message_btn)
            await asyncio.sleep(2)
            
            # كتابة الرسالة
            message_text = details.get("message") or "Здравствуйте! Интересует ваше объявление."
            message_input = 'textarea[data-marker="messenger/input"]'
            await self.page.wait_for_selector(message_input, timeout=10000)
            await self.page.fill(message_input, message_text)
            await asyncio.sleep(1)
            
            # إرسال
            send_btn = '[data-marker="messenger/send-button"]'
            await self.page.click(send_btn)
            await asyncio.sleep(2)
            
            # أخذ screenshot
            screenshot_path = f"/tmp/avito_message_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot_path)
            
            await self.page.close()
            
            return {
                "success": True,
                "screenshot": screenshot_path,
                "message": message_text,
            }
        
        except Exception as e:
            logger.error("AvitoSkill message error: %s", e)
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}

logger.info("🔧 %s loaded", AVITO_SKILL_V1)


# ==========================================================
# SKILL_REGISTRY_UPDATE — تسجيل المهارات الجديدة
# ==========================================================

# إضافة المهارات للـ registry
try:
    if "SKILL_CLASSES" not in dir():
        SKILL_CLASSES = {}
    
    SKILL_CLASSES["yandex"] = YandexAliceSkill
    SKILL_CLASSES["alice"] = YandexAliceSkill
    SKILL_CLASSES["avito_legacy"] = AvitoLegacySkill
    SKILL_CLASSES["ozon"] = OzonSkill
    
    logger.info("✅ Registered YandexAliceSkill and AvitoSkill")
except Exception as e:
    logger.warning("Could not register skills: %s", e)


# ==========================================================
# COMPREHENSIVE_SKILLS_V1 — مهارات شاملة لكل المنصات
# ==========================================================

COMPREHENSIVE_SKILLS_V1 = "comprehensive-skills-v1"


class ComprehensiveMaxSkill:
    """مهارة MAX (max.ru)."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        details = details or {}
        
        if action == "subscribe":
            return await self._subscribe(target_url, details)
        elif action == "like" or action == "react":
            return await self._react(target_url, details)
        elif action == "multi_subscribe":
            return await self._multi_subscribe(details)
        
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _subscribe(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            # البحث عن زر الاشتراك
            subscribe_selectors = [
                'button:has-text("Подписаться")',
                'button:has-text("Subscribe")',
                '[data-action="subscribe"]',
                '.subscribe-btn',
            ]
            
            for selector in subscribe_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/max_sub_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _multi_subscribe(self, details: dict) -> dict:
        """اشتراك في قنوات متعددة."""
        urls = details.get("target_urls") or []
        results = []
        
        for url in urls[:15]:  # حد أقصى 15
            result = await self._subscribe(url, {})
            results.append({"url": url, **result})
            await asyncio.sleep(random.uniform(1, 3))
        
        success_count = sum(1 for r in results if r.get("success"))
        return {
            "success": success_count > 0,
            "total": len(urls),
            "success_count": success_count,
            "results": results,
        }
    
    async def _react(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            # البحث عن زر التفاعل
            react_selectors = [
                'button:has-text("❤")',
                'button:has-text("👍")',
                '[data-action="like"]',
                '.reaction-btn',
            ]
            
            for selector in react_selectors:
                try:
                    await self.page.click(selector, timeout=3000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/max_react_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}


class DzenSkill:
    """مهارة Dzen (dzen.ru)."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        details = details or {}
        
        if action == "repost":
            return await self._repost(target_url, details)
        elif action == "subscribe":
            return await self._subscribe(target_url, details)
        
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _repost(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            # البحث عن زر الريبوست
            repost_selectors = [
                'button:has-text("Репост")',
                'button:has-text("Поделиться")',
                '[data-action="repost"]',
            ]
            
            for selector in repost_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/dzen_repost_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _subscribe(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            subscribe_selectors = [
                'button:has-text("Подписаться")',
                '[data-action="subscribe"]',
            ]
            
            for selector in subscribe_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/dzen_sub_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}


class ComprehensiveRedditSkill:
    """مهارة Reddit."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        if action == "subscribe" or action == "join":
            return await self._join(target_url, details)
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _join(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            join_selectors = [
                'button:has-text("Join")',
                'button:has-text("Joined")',
                '[data-click-id="join"]',
            ]
            
            for selector in join_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/reddit_join_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}


class ComprehensiveDiscordSkill:
    """مهارة Discord."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        if action == "subscribe" or action == "join":
            return await self._join(target_url, details)
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _join(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            join_selectors = [
                'button:has-text("Accept Invite")',
                'button:has-text("Join")',
            ]
            
            for selector in join_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(2)
            screenshot = f"/tmp/discord_join_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}


class ThreadsSkill:
    """مهارة Threads."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        if action == "subscribe" or action == "follow":
            return await self._follow(target_url, details)
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _follow(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            follow_selectors = [
                'button:has-text("Follow")',
                'button:has-text("Подписаться")',
                '[aria-label="Follow"]',
            ]
            
            for selector in follow_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/threads_follow_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}


class ComprehensiveLikeeSkill:
    """مهارة Likee."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        if action == "subscribe" or action == "follow":
            return await self._follow(target_url, details)
        elif action == "like":
            return await self._like(target_url, details)
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _follow(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            follow_selectors = [
                'button:has-text("Follow")',
                'button:has-text("Подписаться")',
                '.follow-btn',
            ]
            
            for selector in follow_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/likee_follow_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _like(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            like_selectors = [
                'button:has-text("❤")',
                '.like-btn',
                '[data-action="like"]',
            ]
            
            for selector in like_selectors:
                try:
                    await self.page.click(selector, timeout=3000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/likee_like_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}


class ViberSkill:
    """مهارة Viber."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        if action == "subscribe" or action == "join":
            return await self._join(target_url, details)
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _join(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            join_selectors = [
                'button:has-text("Join")',
                'button:has-text("Вступить")',
                'a:has-text("Join")',
            ]
            
            for selector in join_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(2)
            screenshot = f"/tmp/viber_join_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}


class ComprehensiveOKSkill:
    """مهارة OK (Одноклассники)."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        if action == "subscribe" or action == "join":
            return await self._join(target_url, details)
        elif action == "repost":
            return await self._repost(target_url, details)
        elif action == "invite":
            return await self._invite(target_url, details)
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _join(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            join_selectors = [
                'button:has-text("Вступить")',
                'button:has-text("Присоединиться")',
                '.join-btn',
            ]
            
            for selector in join_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/ok_join_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _repost(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            repost_selectors = [
                'button:has-text("Поделиться")',
                'button:has-text("Репост")',
            ]
            
            for selector in repost_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/ok_repost_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _invite(self, url: str, details: dict) -> dict:
        """دعوة الأصدقاء."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            # الانضمام أولاً
            await self._join(url, details)
            
            # ثم دعوة الأصدقاء
            invite_selectors = [
                'button:has-text("Пригласить друзей")',
                'button:has-text("Invite")',
            ]
            
            for selector in invite_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    await asyncio.sleep(1)
                    # اختيار الكل
                    select_all = 'input[type="checkbox"]:has-text("Выбрать всех")'
                    await self.page.click(select_all, timeout=3000)
                    # إرسال الدعوة
                    await self.page.click('button:has-text("Пригласить")', timeout=3000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/ok_invite_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}


class ComprehensiveRutubeSkill:
    """مهارة Rutube."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        if action == "repost" or action == "share":
            return await self._repost(target_url, details)
        elif action == "subscribe":
            return await self._subscribe(target_url, details)
        elif action == "like":
            return await self._like(target_url, details)
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _repost(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            share_selectors = [
                'button:has-text("Поделиться")',
                'button:has-text("Share")',
                '[data-action="share"]',
            ]
            
            for selector in share_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/rutube_share_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _subscribe(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            sub_selectors = [
                'button:has-text("Подписаться")',
                'button:has-text("Subscribe")',
            ]
            
            for selector in sub_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/rutube_sub_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _like(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            like_selectors = [
                'button:has-text("❤")',
                'button:has-text("👍")',
                '.like-btn',
            ]
            
            for selector in like_selectors:
                try:
                    await self.page.click(selector, timeout=3000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/rutube_like_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}


class WhatsAppSkill:
    """مهارة WhatsApp."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        if action == "subscribe" or action == "join":
            return await self._join(target_url, details)
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _join(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            join_selectors = [
                'a:has-text("Join Chat")',
                'a:has-text("Join Group")',
                'button:has-text("Join")',
            ]
            
            for selector in join_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(2)
            screenshot = f"/tmp/whatsapp_join_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}


class WebsiteVoteSkill:
    """مهارة التصويت على المواقع."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        if action == "vote":
            return await self._vote(target_url, details)
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _vote(self, url: str, details: dict) -> dict:
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            vote_selectors = [
                'button:has-text("Vote")',
                'button:has-text("Голосовать")',
                'input[type="submit"]',
                'button[type="submit"]',
            ]
            
            for selector in vote_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(2)
            screenshot = f"/tmp/vote_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}


# ==========================================================
# SKILL_REGISTRY — تسجيل كل المهارات
# ==========================================================

ALL_SKILLS = {
    "max": MaxSkill,
    "dzen": DzenSkill,
    "reddit": RedditSkill,
    "discord": DiscordSkill,
    "threads": ThreadsSkill,
    "likee": LikeeSkill,
    "viber": ViberSkill,
    "ok": OKSkill,
    "rutube": RutubeSkill,
    "whatsapp": WhatsAppSkill,
    "website": WebsiteVoteSkill,
    "vote": WebsiteVoteSkill,
    "yandex": YandexAliceSkill,
    "alice": YandexAliceSkill,
    "avito": AvitoSkill,
    "ozon": OzonSkill,
}

logger.info("✅ %s loaded — %d skills", COMPREHENSIVE_SKILLS_V1, len(ALL_SKILLS))


# ==========================================================
# OZON_SKILL_V1 — مهارة أوزون
# ==========================================================

OZON_SKILL_V1 = "ozon-skill-v1"

class ComprehensiveOzonSkill:
    """مهارة تنفيذ مهام Ozon."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        details = details or {}
        
        if action == "cart" or action == "add_to_cart":
            return await self._add_to_cart(details)
        elif action == "favorite":
            return await self._add_favorite(details)
        elif action == "search":
            return await self._search(details)
        elif action == "cart_and_favorite":
            return await self._cart_and_favorite(details)
        
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _search(self, details: dict) -> dict:
        """بحث في أوزون."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto("https://www.ozon.ru", wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            search_query = details.get("search_query") or "ресвератол"
            price_min = details.get("price_min")
            price_max = details.get("price_max")
            
            # البحث
            search_input = 'input[name="text"], input[placeholder*="Искать"]'
            await self.page.wait_for_selector(search_input, timeout=10000)
            await self.page.fill(search_input, search_query)
            await self.page.keyboard.press("Enter")
            await asyncio.sleep(3)
            
            # فلتر السعر لو موجود
            if price_min and price_max:
                try:
                    await self.page.fill('input[name="price_min"]', str(price_min))
                    await self.page.fill('input[name="price_max"]', str(price_max))
                    await asyncio.sleep(1)
                except:
                    pass
            
            screenshot = f"/tmp/ozon_search_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            
            return {
                "success": True,
                "screenshot": screenshot,
                "query": search_query,
            }
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _add_to_cart(self, details: dict) -> dict:
        """إضافة للسلة."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            # البحث أولاً
            search_result = await self._search(details)
            if not search_result.get("success"):
                return search_result
            
            # الضغط على أول نتيجة
            await self.page.click('a[href*="/product/"]', timeout=5000)
            await asyncio.sleep(2)
            
            # تصفح الصور
            for _ in range(3):
                await self.page.keyboard.press("ArrowRight")
                await asyncio.sleep(0.5)
            
            # إضافة للسلة
            cart_selectors = [
                'button:has-text("В корзину")',
                'button:has-text("Добавить в корзину")',
                '[data-widget="webAddToCart"]',
            ]
            
            for selector in cart_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/ozon_cart_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _add_favorite(self, details: dict) -> dict:
        """إضافة للمفضلة."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            search_result = await self._search(details)
            if not search_result.get("success"):
                return search_result
            
            await self.page.click('a[href*="/product/"]', timeout=5000)
            await asyncio.sleep(2)
            
            # إضافة للمفضلة
            fav_selectors = [
                'button:has-text("❤")',
                'button[aria-label*="избранн"]',
                '[data-widget="webFavorite"]',
            ]
            
            for selector in fav_selectors:
                try:
                    await self.page.click(selector, timeout=3000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/ozon_fav_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _cart_and_favorite(self, details: dict) -> dict:
        """إضافة للسلة والمفضلة."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            search_result = await self._search(details)
            if not search_result.get("success"):
                return search_result
            
            await self.page.click('a[href*="/product/"]', timeout=5000)
            await asyncio.sleep(2)
            
            # تصفح الصور
            for _ in range(3):
                await self.page.keyboard.press("ArrowRight")
                await asyncio.sleep(0.5)
            
            # إضافة للمفضلة
            fav_selectors = [
                'button:has-text("❤")',
                '[data-widget="webFavorite"]',
            ]
            for selector in fav_selectors:
                try:
                    await self.page.click(selector, timeout=3000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            
            # إضافة للسلة
            cart_selectors = [
                'button:has-text("В корзину")',
                '[data-widget="webAddToCart"]',
            ]
            for selector in cart_selectors:
                try:
                    await self.page.click(selector, timeout=5000)
                    break
                except:
                    continue
            
            await asyncio.sleep(1)
            screenshot = f"/tmp/ozon_both_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}

logger.info("🔧 %s loaded", OZON_SKILL_V1)


# إضافة Ozon للـ registry
ALL_SKILLS["ozon"] = OzonSkill
logger.info("✅ OzonSkill registered")


# ==========================================================
# OZON_ENHANCED_V1 — تحسين مهارة أوزون
# ==========================================================

OZON_ENHANCED_V1 = "ozon-enhanced-v1"

class OzonSkillEnhanced(OzonSkill):
    """مهارة أوزون محسّنة مع تصفح وتفاعل."""
    
    async def execute_full(self, details: dict) -> dict:
        """تنفيذ مهمة أوزون كاملة."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            screenshots = []
            
            # 1. فتح أوزون والبحث
            await self.page.goto("https://www.ozon.ru", wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            search_query = details.get("search_query") or "беспроводные наушники"
            brand = details.get("brand") or ""
            price_min = details.get("price_min") or 500
            price_max = details.get("price_max") or 2000
            
            search_input = 'input[name="text"], input[placeholder*="Искать"]'
            await self.page.wait_for_selector(search_input, timeout=10000)
            await self.page.fill(search_input, f"{search_query} {brand}".strip())
            await self.page.keyboard.press("Enter")
            await asyncio.sleep(3)
            
            # فلتر السعر
            try:
                await self.page.fill('input[name="price_min"]', str(price_min))
                await self.page.fill('input[name="price_max"]', str(price_max))
                await asyncio.sleep(1)
            except:
                pass
            
            screenshots.append(await self._screenshot("search"))
            
            # 2. فتح المنتج
            await self.page.click('a[href*="/product/"]', timeout=5000)
            await asyncio.sleep(2)
            
            # 3. تصفح الصور (60 ثانية)
            for _ in range(5):
                await self.page.keyboard.press("ArrowRight")
                await asyncio.sleep(1)
            
            screenshots.append(await self._screenshot("product"))
            
            # 4. فتح التقييمات
            try:
                await self.page.click('a:has-text("Отзывы"), button:has-text("Отзывы")', timeout=3000)
                await asyncio.sleep(2)
                
                # لايك على تقييمين
                review_likes = await self.page.query_selector_all('button:has-text("👍"), button[aria-label*="like"]')
                for i, btn in enumerate(review_likes[:2]):
                    try:
                        await btn.click()
                        await asyncio.sleep(0.5)
                    except:
                        pass
                
                screenshots.append(await self._screenshot("reviews"))
            except:
                pass
            
            # 5. إضافة للمفضلة
            try:
                await self.page.click('button:has-text("❤"), [data-widget="webFavorite"]', timeout=3000)
                await asyncio.sleep(1)
            except:
                pass
            
            # 6. إضافة للسلة
            try:
                await self.page.click('button:has-text("В корзину"), [data-widget="webAddToCart"]', timeout=5000)
                await asyncio.sleep(1)
            except:
                pass
            
            screenshots.append(await self._screenshot("cart"))
            
            # 7. سؤال عن المنتج (اختياري)
            try:
                question_input = 'textarea[placeholder*="вопрос"], input[placeholder*="вопрос"]'
                await self.page.fill(question_input, "Какой срок доставки?", timeout=3000)
                await self.page.keyboard.press("Enter")
                await asyncio.sleep(1)
            except:
                pass
            
            await self.page.close()
            
            return {
                "success": True,
                "screenshots": screenshots,
                "query": search_query,
            }
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _screenshot(self, name: str) -> str:
        path = f"/tmp/ozon_{name}_{int(time.time())}.png"
        await self.page.screenshot(path=path)
        return path

logger.info("🔧 %s loaded", OZON_ENHANCED_V1)


# ==========================================================
# TIKTOK_COMMENT_BOOKMARK_V1
# ==========================================================

TIKTOK_COMMENT_BOOKMARK_V1 = "tiktok-comment-bookmark-v1"

class TikTokSkillEnhanced:
    """مهارة TikTok مع تعليقات وعلامات."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        details = details or {}
        
        if action == "comment":
            return await self._comment(target_url, details)
        elif action == "bookmark":
            return await self._bookmark(target_url, details)
        elif action == "comment_and_bookmark":
            return await self._comment_and_bookmark(target_url, details)
        
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _comment(self, url: str, details: dict) -> dict:
        """تعليق على فيديو."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(3)
            
            # مشاهدة الفيديو
            await asyncio.sleep(5)
            
            # فتح التعليقات
            comment_btn = 'button:has-text("Comment"), [data-e2e="comment-icon"]'
            await self.page.click(comment_btn, timeout=5000)
            await asyncio.sleep(1)
            
            # كتابة التعليق
            comment_text = details.get("comment") or self._generate_comment()
            comment_input = 'div[contenteditable="true"], textarea'
            await self.page.fill(comment_input, comment_text, timeout=5000)
            await asyncio.sleep(1)
            
            # إرسال
            await self.page.keyboard.press("Enter")
            await asyncio.sleep(2)
            
            screenshot = f"/tmp/tiktok_comment_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot, "comment": comment_text}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _bookmark(self, url: str, details: dict) -> dict:
        """إضافة علامة."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(3)
            
            # مشاهدة الفيديو
            await asyncio.sleep(5)
            
            # إضافة علامة
            bookmark_btn = 'button:has-text("Bookmark"), [data-e2e="bookmark-icon"]'
            await self.page.click(bookmark_btn, timeout=5000)
            await asyncio.sleep(1)
            
            screenshot = f"/tmp/tiktok_bookmark_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _comment_and_bookmark(self, url: str, details: dict) -> dict:
        """تعليق + علامة."""
        comment_result = await self._comment(url, details)
        bookmark_result = await self._bookmark(url, details)
        
        return {
            "success": comment_result.get("success") and bookmark_result.get("success"),
            "comment": comment_result,
            "bookmark": bookmark_result,
        }
    
    def _generate_comment(self) -> str:
        """توليد تعليق إنجليزي عشوائي."""
        comments = [
            "Great video! Love this content 🔥",
            "Amazing! Keep it up 👏",
            "This is so cool! Thanks for sharing",
            "Wow, incredible! 😍",
            "Love your content! More please",
            "This is awesome! 🎉",
            "So good! Can't stop watching",
            "Brilliant! Well done 👍",
        ]
        return random.choice(comments)

logger.info("🔧 %s loaded", TIKTOK_COMMENT_BOOKMARK_V1)

# تسجيل المهارات
ALL_SKILLS["ozon_enhanced"] = OzonSkillEnhanced
ALL_SKILLS["tiktok_enhanced"] = TikTokSkillEnhanced
logger.info("✅ Enhanced skills registered")


# ==========================================================
# YANDEX_MUSIC_SKILL_V1
# ==========================================================

YANDEX_MUSIC_SKILL_V1 = "yandex-music-skill-v1"

class YandexMusicSkill:
    """مهارة ياندكس موسيقى."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        details = details or {}
        
        if action == "favorite" or action == "listen":
            return await self._add_favorite(details)
        
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _add_favorite(self, details: dict) -> dict:
        """إضافة تراك للمفضلة."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            
            # فتح ياندكس موسيقى
            await self.page.goto("https://music.yandex.ru", wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            # البحث عن التراك
            track_name = details.get("track_name") or "Жизнь без тебя"
            artist = details.get("artist") or "Alex Taurus"
            
            search_input = 'input[placeholder*="Поиск"], input[name="text"]'
            await self.page.wait_for_selector(search_input, timeout=10000)
            await self.page.fill(search_input, f"{track_name} {artist}")
            await self.page.keyboard.press("Enter")
            await asyncio.sleep(3)
            
            # الضغط على أول نتيجة
            await self.page.click('a[href*="/track/"]', timeout=5000)
            await asyncio.sleep(2)
            
            # تشغيل التراك
            play_btn = 'button[aria-label*="Играть"], button:has-text("▶")'
            try:
                await self.page.click(play_btn, timeout=3000)
                await asyncio.sleep(10)  # استماع 10 ثواني
            except:
                pass
            
            # إضافة للمفضلة
            fav_btn = 'button:has-text("❤"), button[aria-label*="избранн"]'
            await self.page.click(fav_btn, timeout=5000)
            await asyncio.sleep(1)
            
            screenshot = f"/tmp/yandex_music_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {"success": True, "screenshot": screenshot}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}

logger.info("🔧 %s loaded", YANDEX_MUSIC_SKILL_V1)

# تسجيل المهارة
ALL_SKILLS["yandex_music"] = YandexMusicSkill
logger.info("✅ YandexMusicSkill registered")


# ==========================================================
# YANDEX_MAPS_SKILL_V1
# ==========================================================

YANDEX_MAPS_SKILL_V1 = "yandex-maps-skill-v1"

class YandexMapsSkill:
    """مهارة ياندكس خرائط."""
    
    def __init__(self, browser_context=None):
        self.context = browser_context
        self.page = None
    
    async def execute(self, action: str, target_url: str, details: dict = None) -> dict:
        details = details or {}
        
        if action == "view" or action == "activity":
            return await self._browse(target_url, details)
        
        return {"success": False, "reason": f"unsupported:{action}"}
    
    async def _browse(self, url: str, details: dict) -> dict:
        """تصفح بطاقة على ياندكس خرائط."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            screenshots = []
            
            # فتح الرابط
            await self.page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(3)
            
            screenshots.append(await self._screenshot("main"))
            
            # تصفح الصور
            try:
                photos = await self.page.query_selector_all('img[src*="get-altay"]')
                for i, photo in enumerate(photos[:3]):
                    await photo.click()
                    await asyncio.sleep(1)
                screenshots.append(await self._screenshot("photos"))
            except:
                pass
            
            # بناء مسار
            try:
                route_btn = 'button:has-text("Маршрут"), a:has-text("Маршрут")'
                await self.page.click(route_btn, timeout=3000)
                await asyncio.sleep(2)
                screenshots.append(await self._screenshot("route"))
            except:
                pass
            
            # الضغط على رقم الهاتف
            try:
                phone_btn = 'a[href^="tel:"], button:has-text("Показать телефон")'
                await self.page.click(phone_btn, timeout=3000)
                await asyncio.sleep(1)
                screenshots.append(await self._screenshot("phone"))
            except:
                pass
            
            # الانتقال للموقع
            try:
                site_btn = 'a:has-text("Сайт"), a[href*="http"]'
                await self.page.click(site_btn, timeout=3000)
                await asyncio.sleep(2)
                screenshots.append(await self._screenshot("site"))
            except:
                pass
            
            # البقاء 5 دقائق (محاكاة)
            await asyncio.sleep(30)
            
            await self.page.close()
            
            return {"success": True, "screenshots": screenshots}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _screenshot(self, name: str) -> str:
        path = f"/tmp/yandex_maps_{name}_{int(time.time())}.png"
        await self.page.screenshot(path=path)
        return path

logger.info("🔧 %s loaded", YANDEX_MAPS_SKILL_V1)

# تسجيل المهارة
ALL_SKILLS["yandex_maps"] = YandexMapsSkill
logger.info("✅ YandexMapsSkill registered")


# ==========================================================
# AVITO_COMPOUND_SKILL_V1
# ==========================================================

AVITO_COMPOUND_SKILL_V1 = "avito-compound-skill-v1"

class AvitoCompoundSkill(AvitoSkill):
    """مهارة أفيتو مركبة (لايك + مفضلة + رسالة)."""
    
    async def execute_compound(self, details: dict) -> dict:
        """تنفيذ نشاط مركب على أفيتو."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            screenshots = []
            
            # فتح أفيتو
            await self.page.goto("https://avito.ru", wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            # البحث
            search_query = details.get("search_query") or "Lightroom подписка"
            city = details.get("city") or "Москва"
            
            search_input = 'input[data-marker="search-form/suggest"]'
            await self.page.wait_for_selector(search_input, timeout=10000)
            await self.page.fill(search_input, search_query)
            await self.page.keyboard.press("Enter")
            await asyncio.sleep(3)
            
            screenshots.append(await self._screenshot("search"))
            
            # فتح أول إعلان
            await self.page.click('a[data-marker="item-title"]', timeout=5000)
            await asyncio.sleep(2)
            
            # تصفح الصور
            for _ in range(3):
                await self.page.keyboard.press("ArrowRight")
                await asyncio.sleep(0.5)
            
            screenshots.append(await self._screenshot("product"))
            
            # لايك
            try:
                await self.page.click('[data-marker="item-view/favorite-button"]', timeout=3000)
                await asyncio.sleep(1)
            except:
                pass
            
            # إضافة للمفضلة
            try:
                await self.page.click('button:has-text("❤")', timeout=3000)
                await asyncio.sleep(1)
            except:
                pass
            
            screenshots.append(await self._screenshot("favorite"))
            
            # إرسال رسالة
            try:
                await self.page.click('[data-marker="messenger-button/button"]', timeout=5000)
                await asyncio.sleep(2)
                
                message = details.get("message") or ". Здравствуйте! Интересует ваше объявление."
                await self.page.fill('textarea[data-marker="messenger/input"]', message, timeout=5000)
                await self.page.click('[data-marker="messenger/send-button"]', timeout=3000)
                await asyncio.sleep(1)
                
                screenshots.append(await self._screenshot("message"))
            except:
                pass
            
            await self.page.close()
            
            return {"success": True, "screenshots": screenshots}
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    async def _screenshot(self, name: str) -> str:
        path = f"/tmp/avito_{name}_{int(time.time())}.png"
        await self.page.screenshot(path=path)
        return path

logger.info("🔧 %s loaded", AVITO_COMPOUND_SKILL_V1)

# تسجيل المهارة
ALL_SKILLS["avito_compound"] = AvitoCompoundSkill
logger.info("✅ AvitoCompoundSkill registered")


# ==========================================================
# ANONYMOUS_TASK_HANDLER_V1
# ==========================================================

ANONYMOUS_TASK_HANDLER_V1 = "anonymous-task-handler-v1"

class AnonymousTaskHandler:
    """معالج المهام المجهولة (اللي التفاصيل مخفية)."""
    
    def __init__(self, browser_context=None, task_dictionary=None):
        self.context = browser_context
        self.task_dictionary = task_dictionary
        self.page = None
    
    async def handle(self, task_url: str) -> dict:
        """معالجة مهمة مجهولة."""
        try:
            if not self.context:
                return {"success": False, "reason": "no_context"}
            
            self.page = await self.context.new_page()
            
            # فتح صفحة المهمة
            await self.page.goto(task_url, wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)
            
            # التحقق من إنها مهمة مجهولة
            page_text = await self.page.evaluate("() => document.body.innerText")
            
            if "анонимное задание" not in page_text.lower():
                await self.page.close()
                return {"success": False, "reason": "not_anonymous"}
            
            # الضغط على "Выполнить задание" عشان تظهر التفاصيل
            take_btn = 'button:has-text("Выполнить задание"), a:has-text("Выполнить задание")'
            await self.page.click(take_btn, timeout=5000)
            await asyncio.sleep(3)
            
            # قراءة التفاصيل المكشوفة
            revealed_text = await self.page.evaluate("() => document.body.innerText")
            
            # استخراج الرابط والوصف
            description = self._extract_description(revealed_text)
            target_url = self._extract_url(revealed_text)
            
            # تصنيف المهمة
            classification = None
            if self.task_dictionary and description:
                classification = self.task_dictionary.classify(description, target_url or "")
            
            screenshot = f"/tmp/anonymous_task_{int(time.time())}.png"
            await self.page.screenshot(path=screenshot)
            await self.page.close()
            
            return {
                "success": True,
                "description": description,
                "target_url": target_url,
                "classification": classification,
                "screenshot": screenshot,
            }
        except Exception as e:
            if self.page:
                await self.page.close()
            return {"success": False, "reason": str(e)}
    
    def _extract_description(self, text: str) -> str:
        """استخراج الوصف من النص."""
        # البحث عن قسم الوصف
        markers = ["Описание:", "Текст задания:", "Задание:"]
        for marker in markers:
            if marker in text:
                start = text.find(marker) + len(marker)
                end = text.find("\n\n", start)
                if end == -1:
                    end = start + 500
                return text[start:end].strip()
        return text[:500]
    
    def _extract_url(self, text: str) -> str:
        """استخراج الرابط من النص."""
        import re
        urls = re.findall(r'https?://[^\s<>"]+', text)
        # تجاهل روابط unu.im
        for url in urls:
            if "unu.im" not in url:
                return url
        return urls[0] if urls else ""

logger.info("🔧 %s loaded", ANONYMOUS_TASK_HANDLER_V1)

# تسجيل المعالج
ALL_SKILLS["anonymous"] = AnonymousTaskHandler
logger.info("✅ AnonymousTaskHandler registered")


# ==========================================================
# FLEET COOKIE PREFERENCE
# لو حساب المنصة اتأجر، الكوكيز بتتقرأ من ملفه مش من الكوكيز المدفونة في الكود.
# ==========================================================

_FLEET_COOKIE_CLASSES = {
    "YouTubeSkill": "youtube",
    "TikTokSkill": "tiktok",
    "InstagramSkill": "instagram",
    "TwitterSkill": "twitter",
    "VKSkill": "vk",
    "RutubeSkill": "rutube",
    "MaxSkill": "max",
    "OzonSkill": "ozon",
    "OzonSkillEnhanced": "ozon",
    "FacebookSkill": "facebook",
}

SM_COOKIE_FILES.setdefault("ozon", os.getenv("OZON_COOKIES_FILE", "/root/sessions/ozon.json"))
SM_COOKIE_FILES.setdefault("wildberries", os.getenv("WILDBERRIES_COOKIES_FILE", "/root/sessions/wildberries.json"))
SM_COOKIE_FILES.setdefault("avito", os.getenv("AVITO_COOKIES_FILE", "/root/sessions/avito.json"))


def _install_fleet_cookie_preference() -> None:
    for cls_name, platform in _FLEET_COOKIE_CLASSES.items():
        cls = globals().get(cls_name)
        if cls is None or not hasattr(cls, "_load_cookies"):
            continue
        original = cls._load_cookies
        if getattr(original, "_fleet_wrapped", False):
            continue

        async def _wrapped(self, page, _orig=original, _plat=platform):
            forced = os.environ.get(f"FLEET_COOKIE_{_plat.upper()}", "").strip()
            if forced and Path(forced).exists():
                SM_COOKIE_FILES[_plat] = forced
                _SM_COOKIE_MTIME.pop(_plat, None)
                info = await _sm_external_cookie_reload(page, _plat)
                if info.get("reloaded") or info.get("status") in {"up_to_date", "ok"}:
                    logger.info("Fleet cookies %s from %s (%s)", _plat, forced, info.get("status"))
                    return True
            return await _orig(self, page)

        _wrapped._fleet_wrapped = True
        cls._load_cookies = _wrapped


_install_fleet_cookie_preference()
logger.info("Fleet cookie preference installed")


# ==========================================================
# FAST EXEC — مسار سريع قبل السلاسل البطيئة
# ==========================================================

FAST_EXEC_VERSION = "fast-exec-v13"
_FAST_CLASSES = {
    "YouTubeSkill": "youtube",
    "TikTokSkill": "tiktok",
    "InstagramSkill": "instagram",
    "TwitterSkill": "twitter",
    "VKSkill": "vk",
    "RutubeSkill": "rutube",
    "MaxSkill": "max",
    "OzonSkill": "ozon",
    "OzonSkillEnhanced": "ozon",
}
_FAST_STOP = {"login_required", "captcha", "proof_screenshot_failed"}


def _install_fast_exec() -> None:
    from application.platform_exec import try_fast

    def _wrap(cls, platform: str) -> None:
        current = getattr(cls, "execute_task", None)
        if current is None or getattr(current, "__fast_exec__", False):
            return

        async def wrapped(self, action, target_url, page=None, _cur=current, _plat=platform, **kwargs):
            result = None
            try:
                result = await try_fast(page, _plat, action, target_url, kwargs)
            except Exception as error:
                logger.debug("fast exec %s failed open: %s", _plat, error)
            if result is not None:
                ok, data = result
                status = str((data or {}).get("status") or "")
                if ok or status in _FAST_STOP or _plat in {"ozon", "wildberries"}:
                    logger.info("fast exec %s/%s -> %s", _plat, action, status or ok)
                    return ok, data
            return await _cur(self, action, target_url, page=page, **kwargs)

        wrapped.__fast_exec__ = True
        wrapped.__name__ = "execute_task"
        cls.execute_task = wrapped

    for cls_name, platform in _FAST_CLASSES.items():
        cls = globals().get(cls_name)
        if cls is not None:
            _wrap(cls, platform)

    generic = globals().get("GenericWebSkill")
    if generic is not None and not getattr(generic.execute_task, "__fast_exec__", False):
        current = generic.execute_task

        async def generic_wrapped(self, action, target_url, page=None, _cur=current, **kwargs):
            plat = str(getattr(self, "platform", "") or "").lower()
            if plat in {"wildberries", "wb", "ozon"}:
                try:
                    result = await try_fast(page, plat, action, target_url, kwargs)
                except Exception:
                    result = None
                if result is not None:
                    ok, data = result
                    status = str((data or {}).get("status") or "")
                    if ok or status in _FAST_STOP or status:
                        return ok, data
            return await _cur(self, action, target_url, page=page, **kwargs)

        generic_wrapped.__fast_exec__ = True
        generic.execute_task = generic_wrapped

    SKILL_CAPABILITIES.setdefault("vk", set()).update({"comment", "view", "share"})
    SKILL_CAPABILITIES.setdefault("wildberries", set()).update(
        {"like", "subscribe", "view", "favorite"}
    )
    SKILL_CAPABILITIES.setdefault("ozon", set()).update({"like", "subscribe", "view"})


try:
    _install_fast_exec()
    logger.info("🔧 %s installed", FAST_EXEC_VERSION)
except Exception as _fast_err:
    logger.warning("fast exec install failed: %s", _fast_err)


