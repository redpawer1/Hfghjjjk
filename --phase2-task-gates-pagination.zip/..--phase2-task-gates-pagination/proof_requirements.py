"""Extract explicit report/proof requirements from task text."""

from __future__ import annotations

import re
from typing import Any


_JUNK = {"", "-", "none", "null", "unknown", "не указан", "не указано", "غير محدد"}
_MARKERS = {
    "account_url": (
        "account link", "profile link", "channel link", "page link", "account url",
        "url профиля", "ссылка на аккаунт", "ссылка на профиль", "ссылка на канал",
        "ссылку на аккаунт", "ссылку на профиль", "ссылку на канал",
        "رابط الحساب", "رابط حسابك", "رابط البروفايل", "رابط الملف الشخصي",
        "رابط القناة", "لينك الحساب", "لينك البروفايل", "رابط صفحتك",
    ),
    "username": (
        "username", "user name", "handle", "nickname", "nick",
        "ник", "логин", "имя пользователя", "имя аккаунта", "юзер",
        "اسم المستخدم", "اليوزر", "اسم الحساب", "معرف الحساب",
    ),
    "comment": (
        "comment text", "text of comment", "review text", "your comment",
        "текст комментар", "текст отзыва", "ваш комментарий", "комментарий",
        "نص التعليق", "نص المراجعة", "التعليق",
    ),
    "screenshot": (
        "screenshot", "screen shot", "скрин", "скриншот", "фотоотчет",
        "снимок экрана", "سكرين", "لقطة شاشة", "صورة الإثبات",
    ),
    "email": ("email", "e-mail", "почт", "البريد الإلكتروني", "ايميل"),
    "code": ("verification code", "код подтверждения", "رمز التحقق", "otp"),
    "sensitive": (
        "password", "парол", "пароль", "كلمة المرور", "cookie", "куки",
        "access token", "токен доступа", "sms", "телефон", "phone",
        "رقم الهاتف", "phone number", "video proof", "видеоотчет", "فيديو إثبات",
    ),
}


def parse_proof_requirements(details: dict[str, Any] | None) -> dict[str, Any]:
    details = details or {}
    fields = ("proof", "info_for_work", "description", "raw_page_text", "title")
    text = " ".join(str(details.get(key) or "") for key in fields)
    text = text.lower().replace("ё", "е")
    explicit = str(details.get("proof") or "").strip().lower()
    if explicit in _JUNK:
        explicit = ""
    explicit_aliases = {
        "link": "account_url",
        "url": "account_url",
        "account_url": "account_url",
        "username": "username",
        "ник": "username",
        "screenshot": "screenshot",
        "скриншот": "screenshot",
        "text": "comment",
    }

    hits: list[tuple[int, str]] = []
    for kind, markers in _MARKERS.items():
        positions = [text.find(marker) for marker in markers if marker in text]
        if positions:
            hits.append((min(positions), kind))
    hits.sort()
    kinds = []
    for _, kind in hits:
        if kind not in kinds:
            kinds.append(kind)
    if explicit in explicit_aliases and explicit_aliases[explicit] not in kinds:
        kinds.insert(0, explicit_aliases[explicit])

    unsupported = []
    for kind in ("email", "code", "sensitive"):
        if kind in kinds:
            unsupported.append(kind)

    # A bare generic "link" is not enough; require account/profile context.
    if not kinds and re.search(r"\b(link|url|ссылк|رابط|لينك)\b", text):
        if any(token in text for token in ("account", "profile", "channel", "حساب", "بروفايل", "قناة", "профил", "аккаунт")):
            kinds.append("account_url")

    return {
        "kinds": kinds,
        "strict": bool(kinds or explicit),
        "unsupported": unsupported,
        "raw": explicit or text[:500],
        "status": "unsupported" if unsupported else ("required" if kinds else "unspecified"),
    }
