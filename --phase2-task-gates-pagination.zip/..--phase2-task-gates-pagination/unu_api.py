#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU API Client — Fast balance + tasks via AJAX endpoints
"""
import re
import secrets
import logging
import random
import time
from typing import Optional
import httpx

logger = logging.getLogger("UnuAPI")

class UnuAPI:
    BASE = "https://unu.im"
    BALANCE_URL = f"{BASE}/include/ajax_balance.php"
    TASKS_URL = f"{BASE}/include/ajax_tasks_search_v2.php"
    
    def __init__(self, cookies: dict, account_id: str = ""):
        self.cookies = cookies
        self.account_id = str(account_id or "")
        self.client = httpx.Client(
            cookies=cookies,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "X-Requested-With": "XMLHttpRequest",
                "Accept": "*/*",
                "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
                "Referer": f"{self.BASE}/tasks/search",
                "Origin": self.BASE,
            },
            timeout=30,
            follow_redirects=True,
        )
        self._search_id = None
        self.last_collection_stats = {}
    
    def get_balance(self) -> dict:
        """جلب الرصيد الحقيقي"""
        result = {"available": 0.0, "hold": 0.0, "total": 0.0, "error": None, "raw": ""}
        try:
            r = self.client.get(self.BALANCE_URL)
            r.raise_for_status()
            text = r.text
            result["raw"] = text.strip()[:200]
            # Parse: <a href="..."><span>188.41 ₽</span></a>
            m = re.search(r'<span>([\d\s,\.]+)\s*₽</span>', text)
            if m:
                num = m.group(1).replace(" ", "").replace(",", ".")
                result["available"] = float(num)
                result["total"] = result["available"]
            else:
                # Fallback
                nums = re.findall(r'[\d,\.]+', text)
                if nums:
                    result["available"] = float(nums[0].replace(",", "."))
                    result["total"] = result["available"]
        except Exception as e:
            result["error"] = str(e)[:100]
            logger.warning("Balance fetch failed: %s", e)
        return result

    def count_open_works(self) -> int:
        """عدد المهام المحجوزة دلوقتي على /tasks/works. -1 لو الصفحة متعذرت."""
        urls = self.get_open_works()
        if urls is None:
            return -1
        logger.info("Open reserved works: %s", len(urls))
        return len(urls)

    def get_open_works(self):
        """روابط المهام المعلقة. الـ ajax أولاً لأن صفحة /tasks/works بتتبني بالـJS."""
        try:
            works = self.get_works("active") or []
            urls = [w.get("url") for w in works if w.get("url")]
            if urls:
                logger.info("Open works via ajax: %s", len(urls))
                return urls
        except Exception as error:
            logger.warning("ajax works failed: %s", error)
        try:
            response = self.client.get(f"{self.BASE}/tasks/works")
            response.raise_for_status()
            ids = list(dict.fromkeys(re.findall(r"/tasks/report/(\d+)", response.text)))
            return [f"{self.BASE}/tasks/report/{i}/worker" for i in ids]
        except Exception as error:
            logger.warning("Open works fetch failed: %s", error)
            return None
    
    def _new_search_id(self) -> str:
        self._search_id = secrets.token_hex(16)
        return self._search_id
    
    def get_tasks(self, page: int = 0, search_id: Optional[str] = None) -> dict:
        """جلب المهام من صفحة معينة. كل مهمة تاخد رابط القبول بتاعها هي مش أول رابط في الصفحة."""
        if not search_id:
            search_id = self._new_search_id()

        result = {"tasks": [], "no_more": False, "next_page": page + 1, "search_id": search_id, "error": None}
        try:
            r = self.client.get(
                self.TASKS_URL,
                params={
                    "search_id": search_id,
                    "page": page,
                    "start": 1 if page == 0 else 0,
                },
            )
            r.raise_for_status()
            data = r.json()

            no_more = data.get("no_more")
            result["no_more"] = no_more is True or str(no_more).strip().lower() in {"1", "true", "yes"}
            result["next_page"] = data.get("next_page", page + 1)
            html = data.get("html", "") or ""
            chunks = re.split(r"(?=id=['\"]task\d+['\"])", html)
            seen = set()
            for chunk in chunks:
                id_match = re.search(r"id=['\"]task(\d+)['\"]", chunk)
                if not id_match:
                    continue
                task_id = id_match.group(1)
                if task_id in seen:
                    continue
                seen.add(task_id)
                title_match = re.search(
                    r"class=['\"]task-name['\"][^>]*>(.*?)</a>",
                    chunk,
                    re.S,
                )
                title = re.sub(r"<[^>]+>", "", title_match.group(1)).strip() if title_match else ""
                title = re.sub(r"\s+", " ", title)
                accept_match = re.search(
                    rf"tasks/accept/([a-z0-9\-]+-{task_id})\b",
                    chunk,
                    re.I,
                )
                if not accept_match:
                    accept_match = re.search(
                        rf"tasks/accept/([a-z0-9\-]+-{task_id})\b",
                        html,
                        re.I,
                    )
                accept_url = f"{self.BASE}/tasks/accept/{accept_match.group(1)}" if accept_match else ""
                price = 0.0
                price_match = re.search(r"(\d+[\.,]\d+)\s*руб", chunk, re.I)
                if not price_match:
                    price_match = re.search(r"(\d+[\.,]\d+)\s*₽", chunk)
                if price_match:
                    price = float(price_match.group(1).replace(",", ".").replace(" ", ""))
                result["tasks"].append({
                    "id": task_id,
                    "title": title[:200],
                    "accept_url": accept_url,
                    "price": price,
                })

            logger.info("Fetched %d tasks (page %d)", len(result["tasks"]), page)
        except Exception as e:
            result["error"] = str(e)[:100]
            logger.warning("Tasks fetch failed: %s", e)

        return result

    def get_all_tasks(self, max_pages: int = 50, stop_below: int = 40) -> list:
        """قراءة صفحات متتالية بحد أقصى 50 صفحة مع إزالة التكرار."""
        max_pages = min(max(int(max_pages), 1), 50)
        all_tasks = []
        seen = set()
        seen_urls = {}
        search_id = self._new_search_id()
        page = 0
        pages_requested = 0
        pages_succeeded = 0
        raw_tasks = 0
        duplicate_tasks = 0
        invalid_tasks = 0
        errors = []
        for _ in range(max_pages):
            pages_requested += 1
            data = self.get_tasks(page=page, search_id=search_id)

            if data.get("error"):
                errors.append(str(data["error"])[:120])
                logger.warning("Page %d error: %s", page, data["error"])
                break

            pages_succeeded += 1
            tasks = data.get("tasks", [])
            raw_count = len(tasks)
            raw_tasks += raw_count
            fresh = []
            for task in tasks:
                task_id = str(task.get("id") or "").strip()
                fallback_key = str(task.get("accept_url") or "").split("?", 1)[0].rstrip("/").lower()
                if not task_id and not fallback_key:
                    invalid_tasks += 1
                    logger.warning("Skipping task without ID or accept URL on page %d", page)
                    continue
                key = ("id", task_id) if task_id else ("url", fallback_key)
                if key in seen:
                    duplicate_tasks += 1
                    if task_id and ("id", task_id) in seen:
                        previous_url = seen_urls.get(("id", task_id), "")
                        current_url = fallback_key
                        if current_url and previous_url and current_url != previous_url:
                            logger.warning(
                                "Duplicate task ID with conflicting URLs: id=%s old=%s new=%s",
                                task_id,
                                previous_url,
                                current_url,
                            )
                    continue
                seen.add(key)
                if task_id:
                    seen_urls[("id", task_id)] = fallback_key
                fresh.append(task)
            count = len(fresh)
            if raw_count == 0:
                logger.info("Page %d empty — stopping", page)
                break

            all_tasks.extend(fresh)
            logger.info("Page %d: %d fresh/%d raw tasks (total: %d)", page, count, raw_count, len(all_tasks))

            if data.get("no_more"):
                logger.info("no_more flag — stopping at page %d", page)
                break
            if raw_count < stop_below:
                logger.info(
                    "Page %d returned %d raw tasks; page size is unverified, continuing sequentially",
                    page,
                    raw_count,
                )
            reported_next = data.get("next_page")
            if reported_next is not None:
                try:
                    if int(reported_next) != page + 1:
                        logger.warning(
                            "Unverified UNU next_page=%r at page=%s; using sequential page=%s",
                            reported_next,
                            page,
                            page + 1,
                        )
                except (TypeError, ValueError):
                    logger.warning(
                        "Unverified UNU next_page=%r at page=%s; using sequential page=%s",
                        reported_next,
                        page,
                        page + 1,
                    )
            page += 1
            if page < max_pages:
                # Keep sequential requests polite without creating a busy loop.
                time.sleep(random.uniform(0.05, 0.15))

        self.last_collection_stats = {
            "pages_requested": pages_requested,
            "pages_succeeded": pages_succeeded,
            "raw_tasks": raw_tasks,
            "unique_tasks": len(all_tasks),
            "duplicate_tasks": duplicate_tasks,
            "invalid_tasks": invalid_tasks,
            "errors": errors,
            "search_id_used": bool(search_id),
        }
        logger.info("Total tasks collected: %d", len(all_tasks))
        return all_tasks
    
    def get_money_history(self, limit: int = 20) -> list:
        """جلب سجل المعاملات المالية"""
        try:
            r = self.client.get(f"{self.BASE}/include/ajax_money.php")
            r.raise_for_status()
            data = r.json()
            html = data.get("html", "")
            # Parse transactions
            transactions = []
            rows = re.findall(r'class="story-table__row">(.*?)</div>\s*(?:<div class="story-table__row"|$)', html, re.S)
            for row in rows[:limit]:
                cells = re.findall(r'class="story-table__cell"[^>]*>(.*?)</div>', row, re.S)
                if len(cells) >= 3:
                    desc = re.sub(r'<[^>]+>', '', cells[0]).strip()
                    date = re.sub(r'<[^>]+>', '', cells[1]).strip()
                    amount = re.sub(r'<[^>]+>', '', cells[2]).strip()
                    transactions.append({"desc": desc[:100], "date": date, "amount": amount})
            return transactions
        except Exception as e:
            logger.warning("Money history failed: %s", e)
            return []
    
    def hide_task(self, task_id: str) -> bool:
        """إخفاء مهمة (تخطي)"""
        try:
            r = self.client.post(
                f"{self.BASE}/include/ajax_task_hide.php",
                data={"id": task_id, "action": "hide"},
            )
            return r.status_code in (200, 204)
        except Exception as e:
            logger.warning("Hide task failed: %s", e)
            return False
    
    def mark_task_viewed(self, task_id: str) -> bool:
        """تعليم مهمة كـ viewed"""
        try:
            r = self.client.post(
                f"{self.BASE}/include/ajax_task_firstview.php",
                data={"task_id": task_id},
            )
            return r.status_code == 200
        except Exception as e:
            logger.warning("Mark viewed failed: %s", e)
            return False
    
    def get_task_share_url(self, task_id: str) -> str:
        """رابط صفحة المهمة"""
        return f"{self.BASE}/tasks/share/{task_id}"
    
    def get_task_accept_url(self, accept_hash: str) -> str:
        """رابط قبول المهمة"""
        return f"{self.BASE}/tasks/accept/{accept_hash}"
    
    def get_my_works(self, work_type: str = "active") -> list:
        """جلب مهامي (active/done/pending/rejected/all)"""
        try:
            r = self.client.post(
                f"{self.BASE}/include/ajax_tasks_works.php",
                data={"showed_ids": "", "start": "1", "type": work_type},
            )
            r.raise_for_status()
            data = r.json()
            html = data.get("html", "")
            # Parse works
            works = []
            # Find task blocks
            blocks = re.findall(r'class="[^"]*work[^"]*"[^>]*>(.*?)</div>\s*</div>', html, re.S)
            if not blocks:
                # Fallback: extract task IDs and status
                task_ids = re.findall(r'tasks/(?:accept|share)/([a-z0-9\-]+)', html)
                statuses = re.findall(r'(выполн|проверк|отклон|одобр|ожидан)[^<]{0,20}', html, re.I)
                for i, tid in enumerate(set(task_ids)):
                    works.append({
                        "id": tid,
                        "status": statuses[i] if i < len(statuses) else "unknown",
                    })
            return works
        except Exception as e:
            logger.warning("Get works failed: %s", e)
            return []
    
    def get_works(self, status: str = "active") -> list:
        """جلب المهام (active/check/done/fail)"""
        result = []
        try:
            r = self.client.get(f"{self.BASE}/include/ajax_tasks_works.php?page=0")
            r.raise_for_status()
            data = r.json()
            html = data.get("html", "")
            
            task_ids = re.findall(r'tasks/report/(\d+)/worker', html)
            prices = re.findall(r'class="sum">([^<]+)', html)
            statuses = re.findall(r"job__status[^>]*>([^<]+)", html)
            
            for i, tid in enumerate(task_ids):
                result.append({
                    "id": tid,
                    "price": prices[i] if i < len(prices) else "?",
                    "status": statuses[i] if i < len(statuses) else "?",
                    "url": f"{self.BASE}/tasks/report/{tid}/worker",
                })
        except Exception as e:
            logger.warning("Works fetch failed: %s", e)
        return result
    
    def get_frozen(self) -> dict:
        """جلب الأموال المجمدة"""
        result = {"total": 0.0, "tasks": [], "error": None}
        try:
            r = self.client.get(f"{self.BASE}/money/freeze")
            r.raise_for_status()
            text = r.text
            # Total frozen from money page
            r2 = self.client.get(f"{self.BASE}/money")
            frozen_match = re.search(r'money/freeze[^>]*>([^<]+)', r2.text)
            if frozen_match:
                num = re.search(r'([\d,\.]+)', frozen_match.group(1))
                if num:
                    result["total"] = float(num.group(1).replace(",", "."))
            # Parse frozen tasks
            rows = re.findall(r'freeze-table__row[^>]*>(.*?)</div>\s*</div>\s*</div>', text, re.S)
            for row in rows[:20]:
                task_match = re.search(r'tasks/edit/(\d+)[^>]*>([^<]+)', row)
                amount_match = re.search(r'(\d+[\.,]\d+)\s*руб', row)
                if task_match:
                    result["tasks"].append({
                        "id": task_match.group(1),
                        "title": task_match.group(2)[:60],
                        "amount": float(amount_match.group(1).replace(",", ".")) if amount_match else 0,
                    })
        except Exception as e:
            result["error"] = str(e)[:100]
        return result
    
    def get_withdrawal_methods(self) -> list:
        """جلب طرق السحب المتاحة"""
        try:
            r = self.client.get(f"{self.BASE}/money/withdrawal")
            r.raise_for_status()
            text = r.text
            methods = []
            matches = re.findall(r'href="(/money/withdrawal/(\d+))"[^>]*>.*?(?:alt="([^"]*)"|>([^<]{3,50})<)', text, re.S)
            for m in matches:
                name = (m[2] or m[3]).strip()
                if name and len(name) > 2:
                    methods.append({"id": m[1], "name": name, "url": f"{self.BASE}{m[0]}"})
            return methods
        except Exception as e:
            logger.warning("Withdrawal methods failed: %s", e)
            return []
    
    def get_withdrawal_info(self, method_id: str = "17") -> dict:
        """جلب معلومات السحب لطريقة معينة"""
        result = {"available": 0.0, "min": 0.0, "method_id": method_id, "error": None}
        try:
            r = self.client.get(f"{self.BASE}/money/withdrawal/{method_id}")
            r.raise_for_status()
            text = r.text
            # Available
            avail = re.search(r'доступно[^<]*(\d+[\.,]\d+)', text, re.I)
            if avail:
                result["available"] = float(avail.group(1).replace(",", "."))
            # Minimum
            min_amt = re.search(r'(?:минимум|min)[^<]*(\d+)', text, re.I)
            if min_amt:
                result["min"] = float(min_amt.group(1))
            # Form fields
            inputs = re.findall(r'<input[^>]*name="([^"]+)"', text)
            result["fields"] = inputs
        except Exception as e:
            result["error"] = str(e)[:100]
        return result

    def get_balance_detailed(self) -> dict:
        """جلب الرصيد من صفحة المال (أدق)"""
        result = {"available": 0.0, "withdrawn": 0.0, "error": None}
        try:
            r = self.client.get(f"{self.BASE}/money")
            r.raise_for_status()
            text = r.text
            # Main balance
            m = re.search(r'panel-balance__val[^>]*>([^<]+)', text)
            if m:
                num = re.search(r'([\d,\.]+)', m.group(1))
                if num:
                    result["available"] = float(num.group(1).replace(",", "."))
            # Total withdrawn
            withdrawals = re.findall(r'withdrawal-table__cell[^>]*>.*?(\d+[\.,]\d+)\s*руб', text, re.S)
            if withdrawals:
                result["withdrawn"] = sum(float(w.replace(",", ".")) for w in withdrawals)
        except Exception as e:
            result["error"] = str(e)[:100]
        return result

    def close(self):
        self.client.close()


def load_cookies_from_storage(path: str = None) -> dict:
    """تحميل الكوكيز من storage_state.json"""
    import json
    from pathlib import Path
    
    # جرب مسارات متعددة
    paths = [
        path,
        "/root/sessions/storage_state.json",
        "/root/unu-bot/data/sessions/storage_state.json",
        "data/sessions/storage_state.json",
        "/workspace/artifacts/data/sessions/storage_state.json",
    ]
    
    p = None
    for try_path in paths:
        if try_path and Path(try_path).exists():
            p = Path(try_path)
            break
    
    if not p:
        return {}
    data = json.loads(p.read_text())
    cookies = {}
    for c in data.get("cookies", []):
        if "unu.im" in c.get("domain", ""):
            cookies[c["name"]] = c["value"]
    return cookies


if __name__ == "__main__":
    cookies = load_cookies_from_storage()
    api = UnuAPI(cookies)
    
    print("=== Balance ===")
    bal = api.get_balance()
    print(bal)
    
    print("\n=== Tasks (page 0) ===")
    tasks = api.get_tasks(page=0)
    print(f"Count: {len(tasks['tasks'])}")
    for t in tasks["tasks"][:5]:
        print(f"  #{t['id']} {t['price']}₽ — {t['title'][:60]}")
    
    api.close()
