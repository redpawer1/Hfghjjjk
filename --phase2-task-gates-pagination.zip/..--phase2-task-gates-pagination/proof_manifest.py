"""Build durable metadata for screenshot proof artifacts."""

from __future__ import annotations

import hashlib
import time
from pathlib import Path
from typing import Any


def build_proof_manifest(
    path: str | Path,
    *,
    platform: str = "",
    action: str = "",
    page_url: str = "",
    stage: str = "end",
) -> dict[str, Any]:
    artifact = Path(str(path))
    manifest: dict[str, Any] = {
        "path": str(artifact),
        "platform": str(platform or "").strip().lower(),
        "action": str(action or "").strip().lower(),
        "page_url": str(page_url or ""),
        "stage": stage,
        "captured_at": time.time(),
    }
    if not artifact.is_file():
        manifest["status"] = "missing"
        return manifest

    digest = hashlib.sha256()
    with artifact.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    manifest.update({
        "status": "ok",
        "bytes": artifact.stat().st_size,
        "sha256": digest.hexdigest(),
    })
    try:
        from PIL import Image

        with Image.open(artifact) as image:
            manifest["width"], manifest["height"] = image.size
            manifest["format"] = image.format or ""
    except Exception:
        manifest["image_metadata"] = "unavailable"
    return manifest
