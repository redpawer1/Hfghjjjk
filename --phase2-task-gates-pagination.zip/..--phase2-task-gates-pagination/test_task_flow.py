import asyncio
import importlib
import sys
import types
import unittest
import ast
from pathlib import Path
from typing import Optional


class TaskFlowTests(unittest.TestCase):
    def test_api_pagination_is_sequential_and_deduplicated_by_id(self):
        httpx_stub = types.ModuleType("httpx")
        httpx_stub.Client = object
        sys.modules.setdefault("httpx", httpx_stub)
        unu_api = importlib.import_module("unu_api")

        pages = {
            0: {
                "tasks": [{"id": "1", "accept_url": "https://unu.im/tasks/accept/a-1"}],
                "next_page": 2,
            },
            1: {
                "tasks": [
                    {"id": "1", "accept_url": "https://unu.im/tasks/accept/other-1"},
                    {"id": "2", "accept_url": "https://unu.im/tasks/accept/a-2"},
                ],
                "no_more": True,
            },
        }
        api = object.__new__(unu_api.UnuAPI)
        api._new_search_id = lambda: "mock-search"
        api.get_tasks = lambda page, search_id: {
            "tasks": pages[page]["tasks"],
            "next_page": pages[page].get("next_page", page + 1),
            "no_more": pages[page].get("no_more", False),
            "error": None,
        }

        tasks = api.get_all_tasks(max_pages=50, stop_below=1)

        self.assertEqual([task["id"] for task in tasks], ["1", "2"])

    def test_api_pagination_never_exceeds_50_pages(self):
        httpx_stub = types.ModuleType("httpx")
        httpx_stub.Client = object
        sys.modules["httpx"] = httpx_stub
        unu_api = importlib.reload(importlib.import_module("unu_api"))
        api = object.__new__(unu_api.UnuAPI)
        api._new_search_id = lambda: "mock-search"
        calls = []

        def get_tasks(page, search_id):
            calls.append(page)
            return {
                "tasks": [{"id": str(page), "accept_url": f"https://unu.im/tasks/accept/a-{page}"}],
                "no_more": False,
                "next_page": page + 1,
                "error": None,
            }

        api.get_tasks = get_tasks
        tasks = api.get_all_tasks()
        self.assertEqual(len(tasks), 50)
        self.assertEqual(calls, list(range(50)))

    def test_api_timeout_and_empty_page_stop_safely(self):
        httpx_stub = types.ModuleType("httpx")
        httpx_stub.Client = object
        sys.modules["httpx"] = httpx_stub
        unu_api = importlib.reload(importlib.import_module("unu_api"))
        api = object.__new__(unu_api.UnuAPI)
        api._new_search_id = lambda: "mock-search"
        api.get_tasks = lambda page, search_id: {
            "tasks": [],
            "no_more": False,
            "next_page": page + 1,
            "error": "timeout",
        }
        self.assertEqual(api.get_all_tasks(), [])

        calls = []
        api.get_tasks = lambda page, search_id: (
            calls.append(page) or {
                "tasks": [],
                "no_more": False,
                "next_page": page + 1,
                "error": None,
            }
        )
        self.assertEqual(api.get_all_tasks(), [])
        self.assertEqual(calls, [0])

    def test_reserved_processing_is_before_new_collection_enable(self):
        source = Path(__file__).with_name("main.py").read_text(encoding="utf-8")
        self.assertLess(
            source.index("await self._check_urls_batch(works_norm)"),
            source.index("self._allow_new_task_collection = True"),
        )

    def test_collector_preserves_ambiguous_titles_for_review(self):
        application = types.ModuleType("application")
        pre_filter = types.ModuleType("application.pre_filter")
        pre_filter.should_accept_task = lambda *args, **kwargs: (True, "ok")
        pre_filter.classify_title = lambda title: (
            {"tier": "accepted", "platform": "telegram", "action": "subscribe", "reason": "clear"}
            if "подписаться" in title.lower()
            else {"tier": "suspicious", "platform": "", "action": "", "reason": "unknown_title"}
        )
        session_registry = types.ModuleType("application.session_registry")
        session_registry.session_registry = types.SimpleNamespace(
            get_available_platforms=lambda: {"telegram"}
        )
        task_queue = types.ModuleType("application.task_queue")
        task_queue.TaskQueue = None
        task_queue.TaskStatus = None
        sys.modules.update(
            {
                "application": application,
                "application.pre_filter": pre_filter,
                "application.session_registry": session_registry,
                "application.task_queue": task_queue,
            }
        )
        collector_module = importlib.import_module("task_collector")

        class Bot:
            filter_price_min = 0
            filter_price_max = 999999

            async def get_tasks_api(self, max_pages):
                return [
                    {
                        "id": "accepted",
                        "title": "Подписаться на канал Telegram",
                        "accept_url": "https://unu.im/tasks/accept/a-accepted",
                    },
                    {
                        "id": "suspicious",
                        "title": "Неясное задание",
                        "accept_url": "https://unu.im/tasks/accept/a-suspicious",
                    },
                ]

        bot = Bot()
        collector = collector_module.TaskCollector(bot)
        asyncio.run(collector._collect(full=True))

        self.assertCountEqual(
            list(collector.pending_urls),
            [
                "https://unu.im/tasks/accept/a-suspicious",
                "https://unu.im/tasks/accept/a-accepted",
            ],
        )
        self.assertNotIn(
            "https://unu.im/tasks/accept/a-suspicious",
            collector.rejected_urls,
        )

    def test_price_does_not_change_title_decision(self):
        pre_filter = importlib.import_module("pre_filter")
        title = "Подписаться на канал Telegram"
        low = pre_filter.should_accept_task(title, {"telegram"}, price=0.01)
        high = pre_filter.should_accept_task(title, {"telegram"}, price=999999)
        self.assertEqual(low, high)

    def test_ai_provider_failure_is_not_a_successful_analysis(self):
        httpx_stub = types.ModuleType("httpx")
        httpx_stub.AsyncClient = type("AsyncClient", (), {"__init__": lambda self, **kwargs: None})
        sys.modules["httpx"] = httpx_stub
        groq_stub = types.ModuleType("groq")
        groq_stub.AsyncGroq = type("AsyncGroq", (), {"__init__": lambda self, **kwargs: None})
        sys.modules["groq"] = groq_stub
        ai_core = importlib.import_module("ai_core")

        async def no_result(_text):
            return None

        async def deep_think(result, _text):
            return result

        brain = object.__new__(ai_core.AIBrain)
        brain._cache = {}
        brain._route_and_analyze = no_result
        brain._normalize_ai_result = lambda result, _text: result
        brain._apply_policy_thinking = lambda result, _text: result
        brain._deep_think_pipeline = deep_think

        result = asyncio.run(brain.analyze_task("clear task text"))

        self.assertEqual(result["analysis_status"], "unavailable")
        self.assertFalse(result["executable"])

    def test_same_id_is_deduplicated_across_accounts_and_conflict_is_safe(self):
        collector_module = importlib.import_module("task_collector")
        dictionary = types.ModuleType("task_dictionary")
        dictionary.task_dictionary = types.SimpleNamespace(find=lambda *args, **kwargs: None)
        sys.modules["task_dictionary"] = dictionary
        collector_module.should_accept_task = lambda *args, **kwargs: (True, "ok")
        collector_module.classify_title = lambda title: {
            "tier": "accepted",
            "platform": "telegram",
            "action": "subscribe",
            "reason": "clear",
        }
        bot = types.SimpleNamespace(
            filter_price_min=0,
            filter_price_max=999999,
            task_queue=None,
            get_tasks_api=None,
        )
        collector = collector_module.TaskCollector(bot)
        bot.fleet = None

        async def collect(tasks):
            async def get_tasks_api(max_pages):
                return tasks
            bot.get_tasks_api = get_tasks_api
            await collector._collect(full=True)

        asyncio.run(collect([{
            "id": "same",
            "title": "Подписаться на канал Telegram",
            "accept_url": "https://unu.im/tasks/accept/a-same",
        }]))
        asyncio.run(collect([{
            "id": "same",
            "title": "Подписаться на канал Telegram",
            "accept_url": "https://unu.im/tasks/accept/b-same",
        }]))
        self.assertEqual(len(collector.pending_urls), 1)

    def test_suspicious_reaches_detailed_analysis_for_review(self):
        method = self._load_main_method("_process_url")

        class Probe:
            _process_url = method

            def __init__(self):
                self.invalid = set()
                self.invalid_reasons = {}
                self.inspected = False
                self.tasks_details = {
                    "https://unu.im/tasks/accept/a": {"title": "ambiguous"}
                }
                self._verification_records = {}

            def _clean_url(self, url):
                return url

            def _invalidate_task_verification(self, url):
                self._verification_records.pop(url, None)

            def _normalize_task_url(self, url):
                return url

            async def _check_url(self, url):
                return True

            def _accept_to_share(self, url):
                return url

            def _is_works_url(self, url):
                return False

            async def _get_task_title(self, url):
                return "ambiguous"

            def _classify_title_tier(self, title):
                return {"tier": "suspicious", "reason": "ambiguous"}

            async def _inspect_task_detailed(self, url):
                self.inspected = True
                return {
                    "title": "ambiguous",
                    "task_id": "a",
                    "platform": "",
                    "action": "",
                }

            async def _mark_task_review(self, *args, **kwargs):
                return None

            def _store_task_details(self, url, details):
                self.tasks_details[url] = details

            async def _try_execute_task(self, url, details):
                details["execution_success"] = False

        probe = Probe()
        result = asyncio.run(probe._process_url("https://unu.im/tasks/accept/a"))
        self.assertFalse(result)
        self.assertFalse(probe.inspected)
        self.assertEqual(
            probe.tasks_details["https://unu.im/tasks/accept/a"]["decision_status"],
            "needs_review",
        )

    def test_direct_execution_call_cannot_bypass_verification_gate(self):
        method = self._load_main_method("_try_execute_task")

        class Probe:
            _try_execute_task = method

            def __init__(self):
                self.invalid = []

            async def _mark_task_invalid(self, url, reason, alert=False):
                self.invalid.append((url, reason))

        probe = Probe()
        probe.mode = "execute"
        result = asyncio.run(probe._try_execute_task("u", {
            "title_tier": "suspicious",
            "title_check_passed": False,
            "detail_check_passed": False,
        }))
        self.assertIsNone(result)
        self.assertEqual(probe.invalid, [("u", "unresolved_account")])
        self.assertIsNone(asyncio.run(probe._try_execute_task("u", None)))

    def test_verified_task_created_by_internal_scan_can_reserve(self):
        methods = self._load_main_methods(
            "_process_url",
            "_fast_reserve",
            "_invalidate_task_verification",
            "_register_verification_record",
            "_verification_fingerprint",
            "_extract_task_id_from_url",
        )

        class Response:
            url = "https://unu.im/tasks/report/1"
            status_code = 200

        class Client:
            async def get(self, *args, **kwargs):
                return Response()

        class Runtime:
            reservation_lock = asyncio.Lock()

            def reserve_task(self, url):
                return True

        class Fleet:
            def resolve_runtime(self, account_id):
                return Runtime() if account_id == "legacy" else None

        class Probe:
            for name, value in methods.items():
                locals()[name] = value

            def __init__(self):
                self.tasks_details = {
                    "https://unu.im/tasks/accept/a-1": {
                        "title": "Подписаться на канал Telegram",
                        "task_id": "1",
                    }
                }
                self._verification_records = {}
                self.verification_ttl_seconds = 300
                self._accepted_tasks = set()
                self._fast_reserve_inflight = set()
                self._http_client = Client()
                self.context = None
                self.fleet = Fleet()

            def _normalize_task_url(self, url):
                return url.rstrip("/")

            async def _check_url(self, url):
                return True

            def _accept_to_share(self, url):
                return url

            def _classify_title_tier(self, title):
                return {
                    "tier": "accepted",
                    "platform": "telegram",
                    "action": "subscribe",
                    "reason": "mock",
                }

            async def _inspect_task_detailed(self, url):
                return {
                    "title": "Подписаться на канал Telegram",
                    "task_id": "1",
                    "platform": "telegram",
                    "action": "subscribe",
                }

            def _store_task_details(self, url, details):
                self.tasks_details[url] = details

            async def _try_execute_task(self, url, details):
                details["execution_success"] = True

        async def run():
            probe = Probe()
            self.assertTrue(
                await probe._process_url("https://unu.im/tasks/accept/a-1")
            )
            self.assertTrue(
                await probe._fast_reserve("https://unu.im/tasks/accept/a-1", account_id="legacy")
            )

        asyncio.run(run())

    def test_synthetic_verification_is_ignored_without_internal_record(self):
        probe = self._build_fast_probe()
        fake = {
            "title_tier": "accepted",
            "title_check_passed": True,
            "detail_check_passed": True,
        }
        self.assertFalse(
            asyncio.run(
                probe._fast_reserve("https://unu.im/tasks/accept/a-1", fake, account_id="legacy")
            )
        )

    def test_early_tasks_details_record_is_not_a_verification_record(self):
        probe = self._build_fast_probe()
        probe.tasks_details["https://unu.im/tasks/accept/a-1"] = {
            "title": "accepted",
            "title_tier": "accepted",
            "title_check_passed": True,
            "detail_check_passed": True,
        }
        self.assertFalse(
            asyncio.run(probe._fast_reserve("https://unu.im/tasks/accept/a-1", account_id="legacy"))
        )

    def test_fast_reserve_rejects_task_id_and_url_mismatches(self):
        probe = self._build_fast_probe()
        details = self._valid_details()
        probe.tasks_details["https://unu.im/tasks/accept/a-1"] = details
        self.assertTrue(probe._register_verification_record(
            "https://unu.im/tasks/accept/a-1", details
        ))
        probe._verification_records[
            "https://unu.im/tasks/accept/a-1"
        ]["task_id"] = "2"
        self.assertFalse(
            asyncio.run(probe._fast_reserve("https://unu.im/tasks/accept/a-1", account_id="legacy"))
        )
        self.assertFalse(
            asyncio.run(probe._fast_reserve("https://unu.im/tasks/accept/b-1", account_id="legacy"))
        )

    def test_expired_verification_is_rejected(self):
        probe = self._build_fast_probe()
        details = self._valid_details()
        url = "https://unu.im/tasks/accept/a-1"
        probe.tasks_details[url] = details
        probe._register_verification_record(url, details)
        probe._verification_records[url]["expires_at"] = 0
        self.assertFalse(asyncio.run(probe._fast_reserve(url, account_id="legacy")))

    def test_recollection_and_changed_data_invalidate_verification(self):
        probe = self._build_fast_probe()
        details = self._valid_details()
        url = "https://unu.im/tasks/accept/a-1"
        probe.tasks_details[url] = details
        probe._register_verification_record(url, details)
        probe._invalidate_task_verification(url, account_id="legacy")
        self.assertFalse(asyncio.run(probe._fast_reserve(url, account_id="legacy")))
        probe._register_verification_record(url, details)
        probe.tasks_details[url]["title"] = "changed"
        self.assertFalse(asyncio.run(probe._fast_reserve(url, account_id="legacy")))

    def test_rejected_suspicious_ai_failure_and_rule_fallback_are_rejected(self):
        for change in (
            {"title_tier": "rejected"},
            {"title_tier": "suspicious"},
            {"analysis_status": "unavailable"},
            {"ai_source": "rule_fallback"},
        ):
            probe = self._build_fast_probe()
            details = {**self._valid_details(), **change}
            url = "https://unu.im/tasks/accept/a-1"
            probe.tasks_details[url] = details
            probe._register_verification_record(url, details)
            self.assertFalse(asyncio.run(probe._fast_reserve(url, account_id="legacy")), change)

    def test_concurrent_fast_reserve_allows_only_one_attempt(self):
        probe = self._build_fast_probe(delay=0.02)
        details = self._valid_details()
        url = "https://unu.im/tasks/accept/a-1"
        probe.tasks_details[url] = details
        probe._register_verification_record(url, details)

        async def run():
            return await asyncio.gather(
                probe._fast_reserve(url, account_id="legacy"),
                probe._fast_reserve(url, account_id="legacy"),
            )

        self.assertEqual(sum(bool(value) for value in asyncio.run(run())), 1)

    def test_all_three_collectors_use_the_internal_url_only_gate(self):
        root = Path(__file__).with_name("main.py").parent
        for relative in (
            "task_collector.py",
            "application/task_collector.py",
            "application/smart_collector.py",
        ):
            source = (root / relative).read_text(encoding="utf-8")
            if relative != "application/smart_collector.py":
                self.assertIn("account_id=self.account_id", source)
            self.assertNotIn("verification=", source)

    @staticmethod
    def _valid_details():
        return {
            "task_id": "1",
            "title": "Подписuntar على قناة Telegram",
            "title_tier": "accepted",
            "title_check_passed": True,
            "detail_check_passed": True,
            "title_platform": "telegram",
            "platform": "telegram",
            "title_action": "subscribe",
            "action": "subscribe",
            "analysis_status": "available",
            "ai_source": "ai",
            "unu_account_id": "legacy",
        }

    @classmethod
    def _build_fast_probe(cls, delay=0):
        methods = cls._load_main_methods(
            "_fast_reserve",
            "_invalidate_task_verification",
            "_register_verification_record",
            "_verification_fingerprint",
            "_extract_task_id_from_url",
        )

        class Response:
            url = "https://unu.im/tasks/report/1"
            status_code = 200

        class Client:
            async def get(self, *args, **kwargs):
                if delay:
                    await asyncio.sleep(delay)
                return Response()

        class Runtime:
            def __init__(self):
                self.reservation_lock = asyncio.Lock()

            def reserve_task(self, url):
                return True

        class Fleet:
            def __init__(self):
                self.runtime = Runtime()

            def resolve_runtime(self, account_id):
                return self.runtime if account_id == "legacy" else None

        class Probe:
            for name, value in methods.items():
                locals()[name] = value

            def __init__(self):
                self._verification_records = {}
                self.tasks_details = {}
                self.verification_ttl_seconds = 300
                self._accepted_tasks = set()
                self._fast_reserve_inflight = set()
                self._http_client = Client()
                self.context = None
                self.fleet = Fleet()

            def _normalize_task_url(self, url):
                return url.rstrip("/")

        return Probe()

    @staticmethod
    def _load_main_method(name):
        return TaskFlowTests._load_main_methods(name)[name]

    @staticmethod
    def _load_main_methods(*names):
        source = Path(__file__).with_name("main.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        namespace = {
            "Optional": Optional,
            "asyncio": asyncio,
            "dict": dict,
            "json": importlib.import_module("json"),
            "hashlib": importlib.import_module("hashlib"),
            "time": importlib.import_module("time"),
            "re": importlib.import_module("re"),
            "logger": types.SimpleNamespace(
                info=lambda *a, **k: None,
                warning=lambda *a, **k: None,
                debug=lambda *a, **k: None,
            ),
            "normalize_text": lambda value: str(value or ""),
        }
        functions = [
            node
            for node in ast.walk(tree)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name in names
        ]
        exec(compile(ast.Module(body=functions, type_ignores=[]), "main.py", "exec"), namespace)
        return {name: namespace[name] for name in names}


if __name__ == "__main__":
    unittest.main()
