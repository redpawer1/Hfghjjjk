"""Single source of truth for platforms enabled for task execution."""

from __future__ import annotations

from typing import Any


EXECUTION_PLATFORMS = frozenset({
    "telegram",
    "vk",
    "youtube",
    "tiktok",
    "instagram",
    "max",
    "rutube",
})


ALIASES = {
    "вк": "vk",
    "вконтакте": "vk",
    "ютуб": "youtube",
    "ютюб": "youtube",
    "тикток": "tiktok",
    "тик ток": "tiktok",
    "инстаграм": "instagram",
    "инста": "instagram",
    "рутуб": "rutube",
    "рутьюб": "rutube",
    "макс": "max",
    "max messenger": "max",
}


def canonical_platform(value: Any) -> str:
    platform = str(value or "").strip().lower()
    return ALIASES.get(platform, platform)


def is_execution_platform(value: Any) -> bool:
    return canonical_platform(value) in EXECUTION_PLATFORMS
