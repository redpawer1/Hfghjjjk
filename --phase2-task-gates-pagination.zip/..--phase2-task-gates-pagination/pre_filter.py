"""
Pre-Filter - فحص سريع قبل الحجز
يتوافق مع task_dictionary والمنصات المفعّلة:
telegram / vk / max / instagram / tiktok / twitter / youtube / rutube
"""
from __future__ import annotations

import logging
import re
from typing import Optional, Set

logger = logging.getLogger("PreFilter")

# المنصات المسموحة للتنفيذ حالياً
ALLOWED_PLATFORMS = {
    "youtube",
    "tiktok",
    "instagram",
    "twitter",
    "rutube",
    "telegram",
    "vk",
    "max",
}

# كلمات محظورة — حدود كلمة حتى ما يتقفش «работа» بسبب «бот»
FORBIDDEN_TITLE_WORDS = [
    "регистрация",
    "регистр",
    "скачать",
    "установить",
    "mini app",
    "miniapp",
    "крипт",
    "usdt",
    "btc",
    "вывод",
    "вывести",
    "кошелек",
    "wallet",
    "телефон",
    "номер",
    "sms",
    "смс",
    "aviso",
    "bux.money",
    "bux money",
    "surfearner",
    "vktarget",
    "socpublic",
    "faucet",
    "кран",
    "вибратор",
    "заработок",
    "никаких вложений",
    "перевести wmt",
    "wmt",
]

# بوت صريح (مش جوه كلمة تانية)
BOT_WORD_RE = re.compile(r"(?<![а-яёa-z0-9])бот(?:а|у|ом|е|ы|ов)?(?![а-яёa-z0-9])", re.I)
START_BOT_RE = re.compile(
    r"(запустить|активировать|старт)\s*.{0,20}бот|бот.{0,15}(start|старт)|telegram[- ]?бот",
    re.I,
)
BOOST_RE = re.compile(r"\bboost\b|буст\b|/boost/", re.I)

PLATFORM_PATTERNS = {
    "telegram": [r"telegram", r"телеграм", r"тг\b", r"t\.me"],
    "vk": [r"\bвк\b", r"\bvk\b", r"вконтакте", r"vk\.com", r"vk\.ru"],
    "youtube": [r"youtube", r"ютуб", r"ютюб"],
    "tiktok": [r"tiktok", r"tik\s*tok", r"тикток", r"тик\s*ток"],
    "instagram": [r"instagram", r"инстаграм", r"инста\b"],
    "twitter": [r"twitter", r"твиттер", r"\bx\b", r"\(x\)"],
    "rutube": [r"rutube", r"рутуб"],
    "max": [r"\bmax\b", r"\bмакс\b", r"мах\b", r"max\.ru"],
    # معروفة لكن مش مفعّلة → تترفض
    "ozon": [r"ozon", r"озон"],
    "avito": [r"avito", r"авито"],
    "booking": [r"booking", r"букинг"],
    "chrome": [r"chrome", r"хром", r"расширени"],
    "google": [r"google\s*(play|chrome|maps)", r"гугл"],
    "facebook": [r"facebook", r"фейсбук"],
    "yandex": [r"yandex", r"яндекс"],
    "ok": [r"одноклассник", r"\bok\.ru\b", r"ok\.ru"],
    "wildberries": [r"wildberries", r"вайлдберриз", r"\bвб\b"],
}

TRAP_PATTERNS = [
    r"стать рефералом",
    r"change-ref",
    r"реферал",
    r"партнёр",
    r"партнер",
    r"приглас",
    r"friends\?act=invite",
    r"скачать приложение",
    r"установить приложение",
    r"play\.google\.com",
    r"apps\.apple\.com",
    r"startapp",
    r"mini\s*app",
    r"usdt",
    r"binance",
    r"bep20",
    r"trc20",
    r"кошелек",
    r"wallet",
    r"вывести деньги",
    r"подтвердить почту",
    r"дебетов",
    r"оформить карт",
    r"альфа-банк",
    r"альфа банк",
    r"идентификац",
    r"паспорт",
    r"банковск\w* карт",
    r"оформлен\w* заявк",
    r"kyc",
]

CLEAR_ACTIONS = {
    "like": [r"лайк", r"like", r"класс", r"реакц", r"reaction"],
    "subscribe": [r"подпис", r"вступ", r"subscribe", r"follow"],
    "view": [r"просмотр", r"посмотр", r"просмотр", r"view", r"watch", r"слушать"],
    "comment": [r"коммент", r"comment", r"отзыв"],
    "repost": [r"репост", r"ретвит", r"repost", r"retweet"],
    "share": [r"поделиться", r"share"],
}


def detect_platform_from_title(title: str) -> Optional[str]:
    if not title:
        return None
    title_lower = title.lower()
    # أولوية للمنصات المسموحة قبل المرفوضة
    order = list(ALLOWED_PLATFORMS) + [p for p in PLATFORM_PATTERNS if p not in ALLOWED_PLATFORMS]
    for platform in order:
        patterns = PLATFORM_PATTERNS.get(platform) or []
        for pattern in patterns:
            if re.search(pattern, title_lower, re.I):
                return platform
    return None


def title_has_forbidden(title: str) -> bool:
    if not title:
        return False
    title_lower = title.lower().replace("ё", "е")
    # بوت صريح أو start bot
    if START_BOT_RE.search(title_lower) or BOT_WORD_RE.search(title_lower):
        # استثناء: لو النص واضح إنه مش مهمة بوت (مثل «работа»)
        if BOT_WORD_RE.search(title_lower) and not START_BOT_RE.search(title_lower):
            # «бот» لوحدها في عنوان تيليجرام غالباً مهمة بوت
            if re.search(r"телеграм|telegram|тг\b", title_lower):
                return True
        elif START_BOT_RE.search(title_lower):
            return True
    for word in FORBIDDEN_TITLE_WORDS:
        if word in ("смс", "sms", "btc"):
            if re.search(rf"(?<![а-яёa-z0-9]){re.escape(word)}(?![а-яёa-z0-9])", title_lower):
                return True
            continue
        if word in title_lower:
            return True
    return False


def is_trap_task(title: str, description: str = "") -> tuple:
    text = f"{title} {description}".lower()
    for pattern in TRAP_PATTERNS:
        if re.search(pattern, text, re.I):
            return True, f"trap:{pattern}"
    if BOOST_RE.search(text):
        return True, "trap:boost"
    return False, ""


def detect_action_from_title(title: str) -> str:
    text = (title or "").lower().replace("ё", "е")
    for action, patterns in CLEAR_ACTIONS.items():
        for pattern in patterns:
            if re.search(pattern, text, re.I):
                return action
    return ""


def _dictionary_hint(title: str) -> Optional[dict]:
    """استشارة القاموس لو متاح — أدق من الريجكس."""
    try:
        from task_dictionary import task_dictionary

        hit = task_dictionary.find(title or "", {"title": title or ""})
        if not hit:
            return None
        return {
            "platform": str(hit.get("platform") or ""),
            "action": str(hit.get("action") or ""),
            "executable": hit.get("executable", True),
            "reject_reason": hit.get("reject_reason"),
            "confidence": float(hit.get("confidence") or 0),
            "rule_id": hit.get("rule_id"),
            "actions_list": hit.get("actions_list") or [],
            "is_compound": bool(hit.get("is_compound")),
        }
    except Exception as err:
        logger.debug("dictionary hint skip: %s", err)
        return None


def classify_title(title: str) -> dict:
    """تصنيف العنوان: high / suspicious / rejected."""
    text = (title or "").lower().replace("ё", "е")
    if not text.strip():
        return {"tier": "rejected", "reason": "empty_title", "platform": "", "action": ""}

    # قاموس أولاً
    dhint = _dictionary_hint(title)
    if dhint and dhint.get("confidence", 0) >= 0.80:
        plat = dhint["platform"]
        if plat == "x":
            plat = "twitter"
        if dhint.get("executable") is False:
            return {
                "tier": "rejected",
                "reason": "dict:" + str(dhint.get("reject_reason") or "blocked"),
                "platform": plat,
                "action": dhint.get("action") or "",
            }
        if plat and plat not in ALLOWED_PLATFORMS:
            return {
                "tier": "rejected",
                "reason": f"platform_not_allowed:{plat}",
                "platform": plat,
                "action": dhint.get("action") or "",
            }
        if plat in ALLOWED_PLATFORMS and dhint.get("action"):
            return {
                "tier": "accepted",
                "reason": "dictionary:" + str(dhint.get("rule_id") or "ok"),
                "platform": plat,
                "action": dhint["action"],
                "actions_list": dhint.get("actions_list") or [],
                "is_compound": dhint.get("is_compound"),
            }

    if title_has_forbidden(title):
        return {"tier": "rejected", "reason": "forbidden", "platform": "", "action": ""}

    trap, trap_reason = is_trap_task(title)
    if trap:
        return {"tier": "rejected", "reason": trap_reason, "platform": "", "action": ""}

    for phrase in (
        "только для граждан рф",
        "только для росси",
        "гражданам рф",
        "только ру",
        "только рф",
        "только россия",
    ):
        if phrase in text:
            return {"tier": "rejected", "reason": "russian_only", "platform": "", "action": ""}

    for phrase in (
        "карт",
        "апельсин",
        "android",
        "ios",
        "оформить",
        "получить карту",
        "отзыв android",
        "регистрац",
        "регитстрац",
        "surfearner",
        "звезды",
        "звезд",
    ):
        if phrase in text and not detect_platform_from_title(title):
            return {"tier": "rejected", "reason": "not_supported_task", "platform": "", "action": ""}

    if any(w in text for w in ("звезд", "stars", "регистрац", "регитстрац", "surfearner")):
        return {"tier": "rejected", "reason": "not_supported_task", "platform": "", "action": ""}

    platform = detect_platform_from_title(title) or ""
    if platform == "x":
        platform = "twitter"
    if platform and platform not in ALLOWED_PLATFORMS:
        return {
            "tier": "rejected",
            "reason": f"platform_not_allowed:{platform}",
            "platform": platform,
            "action": "",
        }

    action = detect_action_from_title(title)
    if platform in ALLOWED_PLATFORMS and action:
        return {"tier": "accepted", "reason": "clear_title", "platform": platform, "action": action}
    if platform in ALLOWED_PLATFORMS:
        return {"tier": "suspicious", "reason": "platform_no_action", "platform": platform, "action": ""}
    # عناوين عامة من غير منصة → رفض من الطابور
    generic_bits = (
        "легкое задание", "лёгкое задание", "простое задание", "очень легко",
        "просто и быстро", "задание часть", "минута сёрф", "минута серф",
    )
    if any(g in text for g in generic_bits):
        return {"tier": "rejected", "reason": "generic_title_no_platform", "platform": "", "action": ""}
    return {"tier": "suspicious", "reason": "unknown_title", "platform": "", "action": ""}


def should_accept_task(
    title: str,
    available_platforms: Set[str],
    min_price: float = 0,
    max_price: float = 999999,
    price: float = 0,
) -> tuple:
    """
    فحص سريع قبل الحجز.
    Returns: (should_accept: bool, reason: str)
    """
    # فلتر السعر ملغي
    is_trap, trap_reason = is_trap_task(title)
    if is_trap:
        return False, trap_reason

    if title_has_forbidden(title):
        return False, "forbidden_word"

    title_low = (title or "").lower()
    bad_title = (
        "авито",
        "avito",
        "букинг",
        "booking",
        "одноклассник",
        "chrome",
        "хром",
        "расширени",
        "яндекс",
        "yandex",
        "ozon",
        "озон",
    )
    if any(w in title_low for w in bad_title):
        return False, "bad_title_platform"

    classified = classify_title(title)
    if classified["tier"] == "rejected":
        return False, classified["reason"]

    platform = classified.get("platform") or detect_platform_from_title(title) or ""
    if platform == "x":
        platform = "twitter"

    if classified["tier"] == "suspicious":
        # suspicious مسموح يدخل للطابور — التفصيل بعدين
        return True, "suspicious"

    if not platform:
        return True, "suspicious"

    if platform not in ALLOWED_PLATFORMS:
        return False, f"platform_not_allowed:{platform}"

    if available_platforms and platform not in available_platforms:
        return False, f"no_session:{platform}"

    return True, "ok"
