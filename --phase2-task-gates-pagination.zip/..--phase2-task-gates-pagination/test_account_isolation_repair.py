import importlib.util
import asyncio
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from account_runtime import AccountRuntime
from application.fleet import AccountFleet
from application.task_queue import TaskQueue
from persistence import BotPersistence
from unu_api import UnuAPI


class FakeApi:
    def __init__(self, cookies):
        self.cookies = dict(cookies)
        self.client = self
        self.closed = False

    def close(self):
        self.closed = True

    def get_balance(self):
        return {"available": 1.0}

    def get_all_tasks(self, **kwargs):
        return []

    def count_open_works(self):
        return 0


class AccountIsolationRepairTests(unittest.TestCase):
    def _fleet(self, root):
        states = {}
        for account_id, value in (("A", "cookie-a"), ("B", "cookie-b")):
            path = root / f"{account_id}.json"
            path.write_text(
                json.dumps(
                    {"cookies": [{"domain": "unu.im", "name": "id", "value": value}]}
                ),
                encoding="utf-8",
            )
            states[account_id] = str(path)
        config = root / "accounts.json"
        config.write_text(
            json.dumps(
                {
                    "version": 1,
                    "unu": [
                        {"id": key, "enabled": True, "storage_state": value}
                        for key, value in states.items()
                    ],
                    "platforms": {},
                }
            ),
            encoding="utf-8",
        )
        return AccountFleet(str(config)), states

    def test_explicit_runtime_resolution_is_fail_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            fleet, _ = self._fleet(Path(directory))
            self.assertIsNone(fleet.resolve_runtime("missing"))
            self.assertIsNone(fleet.resolve_runtime(""))

    def test_explicit_collection_failure_is_not_returned_as_empty_success(self):
        methods = {}
        source = Path("main.py").read_text(encoding="utf-8")
        tree = __import__("ast").parse(source)
        namespace = {
            "Optional": __import__("typing").Optional,
            "asyncio": asyncio,
            "time": __import__("time"),
            "logger": type("Logger", (), {"warning": staticmethod(lambda *a, **k: None)})(),
        }
        nodes = [
            node for node in __import__("ast").walk(tree)
            if isinstance(node, __import__("ast").AsyncFunctionDef)
            and node.name == "get_tasks_api"
        ]
        exec(
            compile(__import__("ast").Module(body=nodes, type_ignores=[]), "main.py", "exec"),
            namespace,
        )
        method = namespace["get_tasks_api"]

        class Fleet:
            def healthy_unu(self, account_id=None):
                return [{"id": "A"}]

            def resolve_runtime(self, account_id):
                return None

        probe = type("Probe", (), {"fleet": Fleet()})()
        with self.assertRaises(RuntimeError):
            asyncio.run(method(probe, account_id="A"))

    def test_clients_and_cookies_are_independent(self):
        with tempfile.TemporaryDirectory() as directory:
            fleet, _ = self._fleet(Path(directory))
            a = fleet.resolve_runtime("A")
            b = fleet.resolve_runtime("B")
            a.api_client = a.get_api(lambda cookies: FakeApi(cookies))
            b.api_client = b.get_api(lambda cookies: FakeApi(cookies))
            self.assertEqual(a.get_api().cookies["id"], "cookie-a")
            self.assertEqual(b.get_api().cookies["id"], "cookie-b")
            self.assertIsNot(a.get_api(), b.get_api())

    def test_refresh_and_disconnect_do_not_cross_accounts(self):
        with tempfile.TemporaryDirectory() as directory:
            fleet, states = self._fleet(Path(directory))
            a = fleet.resolve_runtime("A")
            b = fleet.resolve_runtime("B")
            a.api_client = a.get_api(lambda cookies: FakeApi(cookies))
            b.api_client = b.get_api(lambda cookies: FakeApi(cookies))
            Path(states["A"]).write_text(
                json.dumps({"cookies": [{"domain": "unu.im", "name": "id", "value": "new-a"}]}),
                encoding="utf-8",
            )
            refreshed = fleet.resolve_runtime("A")
            self.assertEqual(refreshed.cookies["id"], "new-a")
            self.assertEqual(b.cookies["id"], "cookie-b")
            self.assertTrue(fleet.disconnect_unu("A"))
            self.assertIsNotNone(fleet.resolve_runtime("B"))

    def test_same_task_id_and_url_are_account_scoped(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            queue = TaskQueue(root / "queue.sqlite")
            self.assertTrue(queue.add("123", "url-a", account_id="A"))
            self.assertTrue(queue.add("123", "url-b", account_id="B"))
            self.assertEqual(queue.get_pending_count("A"), 1)
            self.assertEqual(queue.get_pending_count("B"), 1)

            persistence = BotPersistence(root / "state.sqlite")
            persistence.add_history("123", account_id="A")
            persistence.add_history("123", account_id="B")
            self.assertEqual(persistence.load_history_set(account_id="A"), {"123"})
            self.assertEqual(persistence.load_history_set(account_id="B"), {"123"})

    def test_pagination_is_sequential_and_capped(self):
        client = UnuAPI.__new__(UnuAPI)
        pages = []

        def get_tasks(page=0, search_id=None):
            pages.append(page)
            return {"tasks": [{"id": str(page), "accept_url": f"/tasks/accept/x-{page}"}]}

        client._new_search_id = lambda: "mock-search"
        client.get_tasks = get_tasks
        result = client.get_all_tasks(max_pages=80, stop_below=0)
        self.assertEqual(pages, list(range(50)))
        self.assertEqual(len(result), 50)

    def test_migration_keeps_legacy_tables_as_recovery_copies(self):
        spec = importlib.util.spec_from_file_location("database_module", "core/database.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as directory:
            db_path = Path(directory) / "legacy.sqlite"
            conn = sqlite3.connect(db_path)
            conn.executescript(
                """
                CREATE TABLE tasks (
                    id INTEGER PRIMARY KEY, account_id TEXT, url TEXT UNIQUE,
                    title TEXT, platform TEXT, actions TEXT, status TEXT,
                    price REAL, confidence REAL, priority INTEGER, attempts INTEGER,
                    reject_reason TEXT, created_at TEXT, completed_at TEXT, proof_data TEXT
                );
                INSERT INTO tasks(id, account_id, url) VALUES (1, 'legacy', 'u');
                CREATE TABLE pending_tasks (
                    id INTEGER PRIMARY KEY, url TEXT UNIQUE, data TEXT,
                    reason TEXT, created_at TEXT
                );
                INSERT INTO pending_tasks(id, url) VALUES (1, 'u');
                """
            )
            conn.commit()
            conn.close()
            module.Database(db_path)
            names = {
                row[0]
                for row in sqlite3.connect(db_path).execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )
            }
            self.assertTrue(any(name.startswith("tasks_legacy_backup_") for name in names))
            self.assertTrue(any(name.startswith("pending_tasks_legacy_backup_") for name in names))


if __name__ == "__main__":
    unittest.main()
