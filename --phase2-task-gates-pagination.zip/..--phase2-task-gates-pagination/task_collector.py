"""
TaskCollector — تجميع بدون حجز وبدون موافقة.
يجمع 50 صفحة لكل حساب بعد انتهاء فحص الأعمال المفتوحة،
ويمنع تكرار المهام ولا يسمح بمرور العناوين المشكوك فيها للمرحلة التالية.
المهمة اللي جلستها مش موجودة دلوقتي بترجع تتفحص بعدين، مش بتتشال للأبد.
"""
import asyncio
import inspect
import logging
import time
from typing import Set, Dict, List, Optional

logger = logging.getLogger("TaskCollector")

try:
    from application.pre_filter import should_accept_task
    from application.pre_filter import classify_title
    from application.session_registry import session_registry
    from application.task_queue import TaskQueue, TaskStatus
except ImportError:
    should_accept_task = None
    classify_title = None
    session_registry = None
    TaskQueue = None
    TaskStatus = None

# المنصات المفعّلة حالياً
CORE_FOCUS_PLATFORMS = frozenset({
    "telegram", "vk", "max", "instagram", "tiktok", "twitter", "x",
    "youtube", "rutube",
})

class TaskCollector:
    def __init__(
        self,
        bot,
        price_min: float = 0.0,
        price_max: float = 999999.0,
        account_id: str = "legacy",
    ):
        self.bot = bot
        self.account_id = str(account_id or "legacy")
        self.price_min = price_min
        self.price_max = price_max
        self.banned_words: Set[str] = set()

        self.running = False
        self._task: Optional[asyncio.Task] = None

        self.awaiting_approval: Dict[str, dict] = {}
        self.pending_urls: Set[str] = set()
        self.pending_meta: Dict[str, dict] = {}
        self.processed: Set[str] = set()
        self.processed_task_ids: Set[str] = set()
        self.task_id_urls: Dict[str, str] = {}
        self.rejected_urls: Dict[str, str] = {}
        self._soft_until: Dict[str, float] = {}
        self._last_full = 0.0

        self.stats = {"collected": 0, "filtered": 0, "approved": 0, "rejected": 0, "queued": 0}
        self.manual_mode = False
        self.queue = getattr(bot, "task_queue", None)
        if self.account_id != "legacy" and TaskQueue is not None:
            try:
                self.queue = TaskQueue(
                    f"data/accounts/{self.account_id}/task_queue.db"
                )
            except Exception as error:
                logger.warning("Account queue init failed: %s", error)
        if self.queue is None and TaskQueue is not None:
            try:
                self.queue = TaskQueue("data/task_queue.db")
                bot.task_queue = self.queue
            except Exception as error:
                logger.warning("TaskQueue init failed: %s", error)
                self.queue = None

    async def start(self):
        if self.running:
            return
        self.running = True
        if self.queue is not None:
            try:
                self.queue.recover_stale(30)
            except Exception as error:
                logger.debug("queue recover failed: %s", error)
            self.restore_open()
        self._task = asyncio.create_task(self._loop())
        logger.info("TaskCollector started (manual=%s)", self.manual_mode)

    async def stop(self):
        self.running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except Exception:
                pass

    async def _loop(self):
        while self.running:
            try:
                if not getattr(self.bot, "_allow_new_task_collection", True):
                    await asyncio.sleep(0.2)
                    continue
                full = (time.time() - self._last_full) > 600
                await self._collect(full=full)
                await asyncio.sleep(25 if not full else 8)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning("Collect error: %s", e)
                await asyncio.sleep(45)

    def _available_platforms(self) -> set:
        available = set()
        if session_registry:
            try:
                available |= set(session_registry.get_available_platforms() or [])
            except Exception:
                pass
        fleet = getattr(self.bot, "fleet", None)
        if fleet:
            try:
                available |= set(fleet.available_platforms() or [])
            except Exception:
                pass
        return available

    async def _collect(self, full: bool = False):
        if not hasattr(self.bot, "get_tasks_api"):
            return
        pages = 50
        try:
            get_tasks = self.bot.get_tasks_api
            parameters = inspect.signature(get_tasks).parameters
            if "account_id" not in parameters and self.account_id != "legacy":
                raise RuntimeError("collector_api_missing_account_context")
            if "account_id" in parameters:
                tasks = await get_tasks(max_pages=pages, account_id=self.account_id)
            else:
                tasks = await get_tasks(max_pages=pages)
        except Exception as e:
            logger.debug("API error: %s", e)
            return
        if full:
            self._last_full = time.time()
        if not tasks:
            return

        now = time.time()
        if len(self._soft_until) > 5000:
            self._soft_until = {k: v for k, v in self._soft_until.items() if v > now}
        if len(self.processed) > 30000:
            self.processed.clear()
        if len(self.processed_task_ids) > 30000:
            self.processed_task_ids.clear()
            self.task_id_urls.clear()
        if len(self.rejected_urls) > 20000:
            self.rejected_urls.clear()

        available = self._available_platforms()

        for t in tasks:
            url = t.get("accept_url", "")
            title = t.get("title", "")
            task_id = str(t.get("id") or "").strip()
            task_url = self._normalize_url(url)
            if not url or "/tasks/accept/" not in url:
                continue
            if task_id:
                previous_url = self.task_id_urls.get(task_id)
                if task_id in self.processed_task_ids:
                    if previous_url and task_url and previous_url != task_url:
                        logger.warning(
                            "Duplicate task ID with conflicting URLs across accounts: id=%s old=%s new=%s",
                            task_id,
                            previous_url,
                            task_url,
                        )
                    continue
                self.processed_task_ids.add(task_id)
                if task_url:
                    self.task_id_urls[task_id] = task_url
            price = float(t.get("price", 0) or 0)
            norm = self._normalize_url(url)
            invalidate = getattr(self.bot, "_invalidate_task_verification", None)
            if callable(invalidate):
                invalidate(norm, self.account_id)
            if norm in self.processed or norm in self.rejected_urls or norm in self.pending_urls:
                continue
            soft = self._soft_until.get(norm, 0)
            if soft and soft > now:
                continue

            self.stats["collected"] += 1
            if should_accept_task:
                accept, reason = should_accept_task(
                    title, available, min_price=0, max_price=999999, price=0,
                )
                if not accept:
                    logger.info(
                        "preliminary title filter deferred to detailed analysis: %s | %s",
                        (title or "")[:40],
                        reason,
                    )

            # تصنيف العنوان: Dictionary أولاً ثم pre_filter
            classified = {"tier": "unknown", "platform": "", "action": "", "reason": ""}
            try:
                from task_dictionary import task_dictionary as _td
                dhit = _td.find(title or "", {"title": title or ""})
                if dhit:
                    if dhit.get("executable") is False:
                        reason = str(dhit.get("reject_reason") or "dictionary_blocked")
                        # بوتات/boost نرفض من الطابور مباشرة
                        if reason in {
                            "telegram_bot_blocked",
                            "telegram_boost_blocked",
                            "unu_internal",
                            "generic_homepage",
                        }:
                            self.rejected_urls[norm] = "dict:" + reason
                            self.processed.add(norm)
                            self.stats["filtered"] += 1
                            logger.info("dict reject %s | %s", (title or "")[:40], reason)
                            continue
                    plat = str(dhit.get("platform") or "")
                    act = str(dhit.get("action") or "")
                    conf = float(dhit.get("confidence") or 0)
                    classified = {
                        "tier": "accepted" if conf >= 0.85 else "suspicious",
                        "platform": plat,
                        "action": act,
                        "reason": dhit.get("rule_id") or "dictionary",
                        "confidence": conf,
                        "executable": dhit.get("executable", True),
                    }
            except Exception as _de:
                logger.debug("dict title classify: %s", _de)
            if not classified.get("platform"):
                try:
                    from application.pre_filter import classify_title
                    classified = classify_title(title) or classified
                except Exception:
                    pass
            if classified.get("tier") == "rejected":
                self.rejected_urls[norm] = classified.get("reason") or "rejected"
                self.processed.add(norm)
                self.stats["filtered"] += 1
                logger.info("title rejected %s | %s", (title or "")[:40], classified.get("reason"))
                continue
            if classified.get("tier") != "accepted":
                self.pending_meta[norm] = {
                    "url": url,
                    "title": title,
                    "price": price,
                    "unu_account_id": self.account_id,
                    "task_id": task_id,
                    "title_tier": classified.get("tier"),
                    "title_platform": classified.get("platform"),
                    "title_action": classified.get("action"),
                    "decision_status": "needs_review",
                    "decision_reason": classified.get("reason") or "ambiguous_title",
                }
                self.pending_urls.add(norm)
                self.processed.add(norm)
                self.stats["filtered"] += 1
                self.stats["queued"] += 1
                logger.info("title needs review; preserved %s | %s", (title or "")[:40], classified.get("reason"))
                continue
            plat = str(classified.get("platform") or "").lower()
            if plat == "x":
                plat = "twitter"
            # خارج الـ 6 منصات الحالية → رفض نهائي (مش defer)
            if plat and plat not in CORE_FOCUS_PLATFORMS and plat not in {"", "other", "unknown"}:
                self.rejected_urls[norm] = "out_of_focus:" + plat
                self.processed.add(norm)
                self.stats["filtered"] += 1
                logger.info("skip out_of_focus %s | %s", (title or "")[:40], plat)
                continue
            # لو المنصة من الـ6 ومفيش جلسة — soft defer
            if plat and available and plat not in available:
                self._soft_until[norm] = now + 900
                self.stats["filtered"] += 1
                logger.info("defer no_session %s | %s", (title or "")[:40], plat)
                continue
            self.pending_meta[norm] = {
                "url": url,
                "title": title,
                "price": price,
                "unu_account_id": t.get("unu_account_id") or "",
                "task_id": task_id,
                "title_tier": classified.get("tier"),
                "title_platform": classified.get("platform"),
                "title_action": classified.get("action"),
            }
            self.pending_urls.add(norm)
            self._remember(norm, url, title, price)
            self.stats["queued"] += 1
            logger.info("queued: %s | acc=%s", (title or "")[:40], t.get("unu_account_id") or "-")

        logger.info(
            "collect full=%s pages=%s c=%s f=%s pending=%s",
            full, pages, self.stats["collected"], self.stats["filtered"], len(self.pending_urls),
        )

    async def _send_approval_request(self, url: str, title: str, price: float, share_url: str):
        return

    async def approve(self, task_code: str) -> bool:
        for norm, data in list(self.awaiting_approval.items()):
            if task_code in data["url"]:
                del self.awaiting_approval[norm]
                success = await self._do_reserve(data["url"], data["title"], norm)
                if success:
                    self.stats["approved"] += 1
                return success
        return False

    async def reject(self, task_code: str) -> bool:
        for norm, data in list(self.awaiting_approval.items()):
            if task_code in data["url"]:
                del self.awaiting_approval[norm]
                self.rejected_urls[norm] = "user_rejected"
                self.stats["rejected"] += 1
                return True
        return False

    async def _do_reserve(self, url: str, title: str, norm: str) -> bool:
        try:
            processor = getattr(self.bot, "_process_collected_task", None)
            if not callable(processor):
                return False
            result = await processor(
                {
                    "accept_url": url,
                    "title": title,
                    "task_id": (self.pending_meta.get(norm) or {}).get("task_id", ""),
                    "unu_account_id": self.account_id,
                },
                account_id=self.account_id,
            )
            if result:
                self.pending_urls.add(norm)
                return True
        except Exception as e:
            logger.debug("Reserve error: %s", e)
        return False

    def _normalize_url(self, url: str) -> str:
        if hasattr(self.bot, "_normalize_task_url"):
            return self.bot._normalize_task_url(url)
        return url.split("?")[0].rstrip("/")

    def _remember(self, norm: str, url: str, title: str, price: float) -> None:
        if self.queue is None:
            return
        try:
            self.queue.add(
                norm,
                url,
                title,
                price,
                {"title": title, "account_id": self.account_id},
                account_id=self.account_id,
            )
        except Exception as error:
            logger.debug("queue add failed: %s", error)

    def _queue_key(self, url: str) -> str:
        norm = self._normalize_url(url)
        if norm in self.pending_meta or norm in self.processed or norm in self.rejected_urls:
            return norm
        for key, meta in self.pending_meta.items():
            stored = str((meta or {}).get("url") or "")
            if stored == url or self._normalize_url(stored) == norm:
                return key
        return norm

    def note_results(self, urls: List[str], results: List) -> None:
        """نجاح يتقفل. فشل تقني يرجع للطابور. رفض صريح يتشال."""
        for url, result in zip(urls, results):
            norm = self._queue_key(url)
            if result is True:
                self.processed.add(norm)
                self.pending_urls.discard(norm)
                self.pending_meta.pop(norm, None)
                self._set_queue(norm, "completed")
            elif result is False:
                self.processed.add(norm)
                self.rejected_urls[norm] = "rejected"
                self.pending_urls.discard(norm)
                self.pending_meta.pop(norm, None)
                self._set_queue(norm, "rejected")
            else:
                self.processed.discard(norm)
                meta = self.pending_meta.get(norm) or {"url": url, "title": "", "price": 0}
                self.pending_meta[norm] = meta
                self.pending_urls.add(norm)
                self._set_queue(norm, "retryable", error="technical")

    def _set_queue(self, task_id: str, status: str, error: str = None) -> None:
        if self.queue is None or TaskStatus is None:
            return
        mapping = {
            "completed": TaskStatus.COMPLETED,
            "rejected": TaskStatus.REJECTED,
            "retryable": TaskStatus.RETRYABLE,
            "in_progress": TaskStatus.IN_PROGRESS,
        }
        try:
            self.queue.update_status(
                task_id,
                mapping[status],
                error=error,
                account_id=self.account_id,
            )
        except Exception as error_value:
            logger.debug("queue status failed: %s", error_value)

    def restore_open(self) -> int:
        """يرجع المهام المفتوحة من قاعدة الطابور للذاكرة بعد إعادة التشغيل."""
        if self.queue is None or not hasattr(self.queue, "get_pending"):
            return 0
        restored = 0
        try:
            rows = self.queue.get_pending(limit=500, account_id=self.account_id)
        except Exception as error:
            logger.debug("restore failed: %s", error)
            return 0
        for row in rows:
            norm = str(row.get("id") or "")
            url = str(row.get("url") or "")
            if not norm or not url:
                continue
            if norm in self.processed or norm in self.rejected_urls:
                continue
            self.pending_meta.setdefault(norm, {
                "url": url,
                "title": row.get("title") or "",
                "price": row.get("price") or 0,
            })
            self.pending_urls.add(norm)
            restored += 1
        if restored:
            logger.info("restored %s open tasks from queue", restored)
        return restored

    def get_pending(self, limit: int = 0) -> List[str]:
        urls = []
        ordered = list(self.pending_urls)
        cap = int(limit or 0)
        if cap > 0:
            ordered = ordered[:cap]
        for norm in ordered:
            meta = self.pending_meta.get(norm) or {}
            raw = meta.get("url") or norm
            urls.append(raw)
            self.pending_urls.discard(norm)
            self._set_queue(norm, "in_progress")
            slot = {
                "title": meta.get("title") or "",
                "price": meta.get("price") or 0,
                "accept_url": raw,
                "unu_account_id": meta.get("unu_account_id") or self.account_id,
                "task_id": meta.get("task_id") or "",
                "decision_status": meta.get("decision_status") or "pending",
                "decision_reason": meta.get("decision_reason") or "",
            }
            if meta.get("title_tier"):
                slot["title_tier"] = meta.get("title_tier")
                slot["title_platform"] = meta.get("title_platform") or ""
                slot["title_action"] = meta.get("title_action") or ""
            setter = getattr(self.bot, "_set_task_details", None)
            if callable(setter):
                setter(raw, slot, self.account_id)
        return urls

    def get_stats(self) -> Dict:
        return {
            **self.stats,
            "awaiting": len(self.awaiting_approval),
            "pending": len(self.pending_urls),
        }
