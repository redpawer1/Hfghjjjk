"""Shared, non-destructive helpers for reconciling task classifications."""

from __future__ import annotations

from typing import Any, Callable, Dict


def canonical_value(value: Any, canonicalize: Callable[[str], str] | None = None) -> str:
    text = str(value or "").strip().lower()
    if canonicalize is not None:
        text = str(canonicalize(text) or "").strip().lower()
    return text


def reconcile_classifications(
    preliminary: Dict[str, Any] | None,
    detailed: Dict[str, Any] | None,
    *,
    canonicalize_platform: Callable[[str], str] | None = None,
) -> Dict[str, Any]:
    """Keep both classifications and make the detailed result authoritative.

    A preliminary title classifier is a fast hint, not a safety decision.  A
    mismatch is retained for observability, while an accepted detailed result
    remains executable.  Explicit rejections are never weakened.
    """
    first = dict(preliminary or {})
    second = dict(detailed or {})
    expected_platform = canonical_value(first.get("platform"), canonicalize_platform)
    expected_action = canonical_value(first.get("action"))
    actual_platform = canonical_value(second.get("platform"), canonicalize_platform)
    actual_action = canonical_value(second.get("action"))

    mismatches = []
    if expected_platform and actual_platform and expected_platform != actual_platform:
        mismatches.append("platform")
    if expected_action and actual_action and expected_action != actual_action:
        mismatches.append("action")

    result = {
        "mismatch": bool(mismatches),
        "mismatch_fields": mismatches,
        "preliminary": first,
        "detailed": second,
    }
    if mismatches:
        result["warning"] = "preliminary and detailed classifications differ"
    return result
