#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
UNU BOT — AI Core (Ultimate Hybrid Edition)
العقل المدبر المُطوّر للعمليات (جاهز للإنتاج 100% وبدون أي اختصارات):
- Exponential Backoff لحماية الـ API من الـ Rate Limit.
- Gemini Vision للتحقق من لقطات الشاشة قبل الرفع وتقليل الرفض لـ 0%.
- Smart Caching لتسريع التنفيذ وتوفير الرصيد.
- Ultimate JSON Sanitization لمنع انهيار السكريبت.
- Hybrid Orchestrator: Groq 1 -> Groq 2 -> Cerebras -> Gemini -> Mistral -> DeepSeek -> OpenRouter.
"""

import re
import json
import base64
import os
from pathlib import Path
import logging
import httpx
import asyncio
import random
from typing import Dict, Any, Optional

try:
    from groq import AsyncGroq
except ImportError:
    pass

logger = logging.getLogger("AICore")

AI_MONITOR = {"requests": 0, "ok": 0, "err_429": 0, "timeout": 0, "other": 0, "by_provider": {}}

class AIBrain:
    def __init__(self):
        # 🔑 المفاتيح الأساسية والمحدثة
        self.groq_api_key_1 = os.getenv("GROQ_API_KEY", "")
        self.groq_api_key_2 = os.getenv("GROQ_API_KEY_2", "")
        self.cerebras_api_key = os.getenv("CEREBRAS_API_KEY", "") 
        self.gemini_api_key = os.getenv("GEMINI_API_KEY", "") 
        self.mistral_api_key = os.getenv("MISTRAL_API_KEY", "")
        
        # 🔑 المفاتيح الاحتياطية (الطوارئ)
        self.openrouter_api_key = os.getenv("OPENROUTER_API_KEY", "")
        self.deepseek_api_key = os.getenv("DEEPSEEK_API_KEY", "") 

        # 🚀 أسماء النماذج (الإصدارات النهائية العاملة بناءً على التحديثات الحالية لتفادي أخطاء 404 و 400)
        self.groq_model = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b") # تم التحديث للنموذج المتاح في منصة Groq
        self.gemini_vision_model = os.getenv("GEMINI_VISION_MODEL", "gemini-3.8-flash") # تم التحديث لأحدث وأذكى إصدار
        self.gemini_text_model = os.getenv("GEMINI_TEXT_MODEL", "gemini-3.8-flash") # تم التحديث لأحدث وأذكى إصدار
        self.cerebras_model = os.getenv("CEREBRAS_MODEL", "gemma-4-31b") # تم التحديث للنموذج المتاح في Cerebras
        
        # 🚀 نظام التخزين المؤقت الذكي (Smart Cache)
        self._cache: Dict[str, dict] = {}

        # استخدام جلسة واحدة لتقليل استهلاك الموارد وتسريع الطلبات
        self.http_client = httpx.AsyncClient(timeout=25.0)
        
        # عملاء Groq
        self.groq_client_1 = None
        self.groq_client_2 = None

        self._setup_clients()

    def _setup_clients(self):
        # تهيئة Groq الحساب الأول
        try:
            self.groq_client_1 = AsyncGroq(
                api_key=self.groq_api_key_1,
                http_client=self.http_client
            )
            logger.info("⚡ تم تفعيل محرك Groq (الحساب الأول الأساسي).")
        except Exception as e:
            logger.error(f"❌ فشل تهيئة Groq الأول: {e}")

        # تهيئة Groq الحساب الثاني (الاحتياطي)
        try:
            self.groq_client_2 = AsyncGroq(
                api_key=self.groq_api_key_2,
                http_client=self.http_client
            )
            logger.info("⚡ تم تفعيل محرك Groq (الحساب الثاني الاحتياطي).")
        except Exception as e:
            logger.error(f"❌ فشل تهيئة Groq الثاني: {e}")

        logger.info("🚀 تم تفعيل محرك Cerebras.")
        logger.info("✨ تم تفعيل محرك Google Gemini (النصوص + الرؤية).")
        logger.info("🌪️ تم تفعيل محرك Mistral.")
        logger.info("🧠 تم تفعيل محرك DeepSeek.")
        logger.info("🌐 تم تفعيل محرك OpenRouter.")

    # --------------------------------------------------------
    # 🔄 دالة الـ Exponential Backoff لحماية البوت من حظر الـ API
    # --------------------------------------------------------
    async def _safe_api_call(self, func, *args, **kwargs):
        """تمنع انهيار البوت عند ضغط السيرفرات (Error 429) وتجرب مرة تانية بذكاء"""
        max_retries = 3
        delay = 2
        for attempt in range(max_retries):
            try:
                return await func(*args, **kwargs)
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 429:
                    logger.warning(f"⚠️ ضغط على السيرفر (429). إعادة المحاولة بعد {delay} ثواني (المحاولة {attempt+1}/{max_retries})")
                    await asyncio.sleep(delay)
                    delay *= 2  # مضاعفة الوقت (2, 4, 8)
                else:
                    raise e
            except Exception as e:
                logger.error(f"⚠️ خطأ غير متوقع أثناء الاتصال بالـ API: {e}")
                raise e
        raise Exception("❌ استنفاد جميع محاولات الاتصال بالـ API للأسف.")

    def _get_system_instruction(self) -> str:
        """
        System 2 prompt. الرابط يحكم المنصة. كلمة بوت في النص وحدها لا ترفض.
        """
        return """
You are a STRICT UNU microtask analyst. You NEVER guess. You NEVER invent platforms.
Think slowly. Evidence order is mandatory: URL domain first, URL shape second, verbs third, surrounding words last.

<system_rules>
1) Extract every http(s) URL. Drop unu.im/tasks, unu.im/users, unu.im/partner, href wrappers after unwrapping them.
2) Unwrap href.li/?https://... and clck.ru redirects by reading the inner URL if it is written in the text.
3) Platform comes ONLY from the target domain. Words like telegram/бот/VK in the sentence do not override the domain.
4) If several target URLs exist, put ALL of them in target_urls in order. is_compound=true when more than one action OR more than one URL that must all be done.
5) Action comes from the verb AND the URL shape. If they conflict, URL shape wins for like-vs-subscribe, EXCEPT when the text explicitly says repost/comment/like of the latest post on a profile URL.
6) If unsure, executable=false. Never invent a platform.
</system_rules>

<strict_constraints>
- URL WINS over text for platform. Always.
- The word бот / bot / telegram inside a sentence is NOT a bot task.
- is_telegram_bot=true ONLY when a target URL is t.me/<name>bot or contains ?start= or startapp or tgwebapp.
- t.me/channel/123 (a post) is a channel post: platform=telegram, action=view or like, is_telegram_bot=false, executable=true.
- t.me/channel or t.me/+join is subscribe, executable=true.
- t.me/boost/... is executable=false, reject_reason=unsupported_action.
- A task whose only URL is avito.ru, socpublic.com, drive.google.com, ozon.ru, max.ru, vk.ru, instagram, tiktok, youtube, rutube, x.com is NEVER telegram_bot_blocked, even if the text mentions Telegram, Start, or a bot.
- Generic homepage (https://www.youtube.com/ or https://www.tiktok.com/ or https://vk.com/ with empty path) → is_generic_homepage=true, executable=false.
- unu.im/users/change-ref and unu.im/partner/competitions as the goal → executable=false, reject_reason=high_risk.
- Do not output platform "other" if any allowed domain is present.
</strict_constraints>

<edge_cases>
Case A — real bot, reject:
URL https://t.me/botpvx or https://t.me/NameBot?start=1
→ platform=telegram, action=start_bot, is_telegram_bot=true, executable=false, reject_reason=telegram_bot_blocked

Case B — channel post, allow:
URL https://t.me/zloiiolz/166 or href.li/?https://t.me/name/122
→ platform=telegram, action=view, is_telegram_bot=false, executable=true
The words «букс» or «бот» in the description do not change this.

Case C — not telegram at all:
URL https://www.avito.ru/... or https://socpublic.com/... or a Google Drive QR
Text may say «через Telegram» or «бот».
→ platform=avito or website, is_telegram_bot=false, executable=false only if the platform is unsupported, reject_reason must NOT be telegram_bot_blocked

Case D — Max, not other:
URL https://max.ru/join/... or https://max.ru/u/...
→ platform=max, action=subscribe, executable=true

Case E — Instagram reel is a like:
URL https://www.instagram.com/reel/XXXX/
→ platform=instagram, action=like, NOT subscribe

Case F — X repost:
Text «Сделать репост последней записи» and URL https://x.com/username
→ platform=twitter, action=repost, is_compound=false, executable=true
URL https://x.com/user/status/1 plus «репост» → action=repost not subscribe

Case G — compound VK:
Text: subscribe to 5 groups AND like the last post. Five vk.ru URLs.
→ platform=vk, is_compound=true, actions_list=["subscribe","like"], target_urls=all five, executable=true

Case H — homepage:
URL only https://www.youtube.com/
→ is_generic_homepage=true, executable=false, reject_reason=generic_homepage

Case I — Rutube channel:
URL https://rutube.ru/channel/123/
→ platform=rutube, action=subscribe, executable=true
</edge_cases>

CANONICAL platform:
telegram, vk, tiktok, instagram, youtube, rutube, twitter, max, facebook, ok, likee, linkedin, avito, ozon, yandex, google_maps, website, other
x.com is twitter. Never output "x".

CANONICAL action:
subscribe, like, comment, repost, share, view, review, register, start_bot, install, unknown

URL SHAPE:
- instagram /reel/ /p/ /tv/ → like (comment if the verb is comment)
- instagram.com/<user> only → subscribe
- tiktok /video/ → like; tiktok.com/@user only → subscribe
- vk wall → like; vk club/public/id → subscribe
- youtube watch/shorts → like or view; /@ or /channel/ → subscribe
- x.com/status → like, or repost if the verb is репост/repost
- rutube /channel/ → subscribe; /video/ → like or view

Return ONE JSON object. No markdown. Fill thinking_process first.

{
  "thinking_process": "1) urls 2) domain 3) verbs 4) traps 5) self-check",
  "platform": "vk",
  "action": "subscribe",
  "actions_list": ["subscribe"],
  "execution_steps": [{"step": 1, "action": "goto"}, {"step": 2, "action": "subscribe"}, {"step": 3, "action": "verify"}],
  "is_compound": false,
  "target_urls": ["https://..."],
  "is_telegram_bot": false,
  "is_generic_homepage": false,
  "is_honeypot": false,
  "required_proof": "screenshot",
  "executable": true,
  "reject_reason": null,
  "confidence": 0.0,
  "risk": "low",
  "summary": "جملة عربية قصيرة"
}

reject_reason is null or one of:
telegram_bot_blocked, generic_homepage, unsupported_platform, unsupported_action, no_target_url, high_risk, honeypot_trap, unknown

Honeypot only if the task itself says ignore the first link, prove you are not a robot, or the only goal is a captcha. A normal social task is not a honeypot.

Self-check before you close the JSON:
If platform is telegram but no t.me/telegram.me target exists, change platform to the real domain.
If is_telegram_bot is true but no bot URL exists, set it false and clear telegram_bot_blocked.
If action is install and platform is youtube, set action=unknown and executable=false.
"""


    def _safe_json_parse(self, text: str) -> dict:
        """استخراج وتحنيد JSON بذكاء فائق لتفادي أي رموز أو ماركداون إضافي (Ultimate Sanitization)"""
        try:
            # 1. تنظيف النص من علامات الـ Markdown البايخة مثل ```json و ```
            cleaned_text = re.sub(r'```(?:json)?\s*', '', text)
            cleaned_text = re.sub(r'```\s*', '', cleaned_text).strip()
            
            # 2. محاولة البحث عن أول قوس بداية وأخر قوس نهاية لـ JSON
            match = re.search(r'\{.*\}', cleaned_text, re.DOTALL)
            if match:
                return json.loads(match.group(0))
            
            # 3. إذا فشل البحث، محاولة التحليل المباشر للنص المنظف
            return json.loads(cleaned_text)
        except Exception as e:
            logger.error(f"⚠️ فشل تحليل JSON نهائياً. النص الأصلي: {text[:100]}... الخطأ: {e}")
            # 4. Fallback Dictionary: في حال الفشل التام، نرجع قيمة افتراضية آمنة لمنع تعطل البوت
            logger.warning("🛡️ تم استخدام القاموس الافتراضي الآمن بسبب فشل استخراج JSON.")
            return {
                "platform": "other",
                "action": "unknown",
                "required_proof": "screenshot",
                "target_urls": [],
                "is_compound": False,
                "actions_list": [],
                "is_telegram_bot": False,
                "is_generic_homepage": False,
                "executable": False,
                "reject_reason": "unknown",
                "confidence": 0.1,
                "risk": "high",
                "summary": "فشل التحليل الذكي — رفض احترازي",
            }

    # --------------------------------------------------------
    # 👁️ دالة الرؤية الخارقة (Gemini Vision Verification)
    # --------------------------------------------------------
    async def verify_task_screenshot(self, image_path: str, task_description: str) -> bool:
        """ترفع الصورة لجيميناي لتأكيد التنفيذ وتقليل نسبة الرفض لـ 0%"""
        logger.info(f"👁️ جاري فحص الصورة عبر Gemini Vision للتأكد من تنفيذ: {task_description}")
        try:
            with open(image_path, "rb") as image_file:
                encoded_string = base64.b64encode(image_file.read()).decode('utf-8')

            url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.gemini_vision_model}:generateContent?key={self.gemini_api_key}"
            payload = {
                "contents": [{
                    "parts": [
                        {"text": f"أنت مدقق مهام صارم. هل هذه الصورة تحتوي على دليل قاطع يثبت تنفيذ المهمة التالية: '{task_description}'؟ أجب بكلمة 'نعم' أو 'لا' فقط وبدون أي إضافات."},
                        {"inline_data": {"mime_type": "image/png", "data": encoded_string}}
                    ]
                }],
                "generationConfig": {"temperature": 0.0} # صفر لتقليل الهلوسة
            }
            
            async def _call_gemini_vision():
                response = await self.http_client.post(url, json=payload)
                response.raise_for_status()
                return response.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
            
            answer = await self._safe_api_call(_call_gemini_vision)
            
            if "نعم" in answer or "yes" in answer.lower():
                logger.info("✅ Gemini: الصورة مطابقة وتم تنفيذ المهمة بنجاح!")
                return True
            else:
                logger.warning("❌ Gemini: الصورة لا تثبت تنفيذ المهمة. (سيتم الرفض أو الإعادة)")
                return False
                
        except Exception as e:
            logger.error(f"⚠️ فشل التحقق من الصورة عبر Gemini: {e}")
            # فشل المدقق لا يساوي نجاحاً. نعيد False حتى لا يتم
            # قبول إثبات لم يتم التحقق منه فعلياً.
            return False

    async def _analyze_with_gemini_vision(
        self,
        text_description: str,
        screenshot_path: str,
    ) -> dict:
        """تحليل نص المهمة وScreenshot التفاصيل معًا قبل التنفيذ."""
        image_file = Path(screenshot_path)
        if not image_file.exists():
            raise FileNotFoundError(f"Screenshot not found: {screenshot_path}")

        mime_type = "image/png"
        suffix = image_file.suffix.lower()
        if suffix in (".jpg", ".jpeg"):
            mime_type = "image/jpeg"
        elif suffix == ".webp":
            mime_type = "image/webp"

        encoded = base64.b64encode(
            image_file.read_bytes()
        ).decode("utf-8")

        prompt = (
            f"{self._get_system_instruction()}\n\n"
            "حلل النص الخام والصورة معًا. لا تختصر التعليمات. "
            "استخرج العملية المطلوبة ونوع الإثبات بدقة. إذا كان النص والصورة متعارضين، "
            "اعتمد على الأكثر وضوحًا وأشر إلى التعارض داخل summary. "
            "أعد JSON فقط.\n\n"
            f"النص الخام الكامل:\n{text_description}"
        )
        url = (
            "https://generativelanguage.googleapis.com/v1beta/"
            f"models/{self.gemini_vision_model}:generateContent?key={self.gemini_api_key}"
        )
        payload = {
            "contents": [{
                "parts": [
                    {"text": prompt},
                    {
                        "inline_data": {
                            "mime_type": mime_type,
                            "data": encoded,
                        }
                    },
                ]
            }],
            "generationConfig": {
                "temperature": 0.0,
                "maxOutputTokens": 4096,
            },
        }

        async def _call():
            response = await self.http_client.post(url, json=payload)
            response.raise_for_status()
            return response.json()["candidates"][0]["content"]["parts"][0]["text"]

        raw = await self._safe_api_call(_call)
        result = self._safe_json_parse(raw)
        if not isinstance(result, dict):
            raise ValueError("Vision analysis did not return an object")
        return result

    # --------------------------------------------------------
    # محركات التحليل (مع دمج Exponential Backoff لكل محرك وزيادة التوكنز إلى 4096)
    # --------------------------------------------------------

    async def _analyze_with_groq_1(self, text_description: str) -> dict:
        async def _call():
            prompt = f"{self._get_system_instruction()}\n\nوصف المهمة:\n{text_description}"
            response = await self.groq_client_1.chat.completions.create(
                messages=[{"role": "user", "content": prompt}],
                model=self.groq_model, 
                temperature=0.1,
                max_tokens=4096,
                response_format={"type": "json_object"}
            )
            return response.choices[0].message.content
        
        logger.info("⚡ جاري التحليل عبر Groq (المحرك الأول - الحساب 1)...")
        content = await self._safe_api_call(_call)
        return self._safe_json_parse(content)

    async def _analyze_with_groq_2(self, text_description: str) -> dict:
        async def _call():
            prompt = f"{self._get_system_instruction()}\n\nوصف المهمة:\n{text_description}"
            response = await self.groq_client_2.chat.completions.create(
                messages=[{"role": "user", "content": prompt}],
                model=self.groq_model, 
                temperature=0.1,
                max_tokens=4096,
                response_format={"type": "json_object"}
            )
            return response.choices[0].message.content
        
        logger.info("⚡ جاري التحليل عبر Groq (المحرك الثاني - الحساب 2)...")
        content = await self._safe_api_call(_call)
        return self._safe_json_parse(content)

    async def _analyze_with_cerebras(self, text_description: str) -> dict:
        async def _call():
            headers = {"Authorization": f"Bearer {self.cerebras_api_key}", "Content-Type": "application/json"}
            payload = {
                "model": self.cerebras_model,
                "messages": [{"role": "system", "content": self._get_system_instruction()}, {"role": "user", "content": f"وصف المهمة:\n{text_description}"}],
                "temperature": 0.1, "max_tokens": 4096 
            }
            response = await self.http_client.post("https://api.cerebras.ai/v1/chat/completions", headers=headers, json=payload)
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
            
        logger.info("🚀 جاري التحليل عبر Cerebras (السرعة الفائقة)...")
        content = await self._safe_api_call(_call)
        return self._safe_json_parse(content)

    async def _analyze_with_gemini(self, text_description: str) -> dict:
        async def _call():
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.gemini_text_model}:generateContent?key={self.gemini_api_key}"
            payload = {
                "contents": [{"parts": [{"text": f"{self._get_system_instruction()}\n\nوصف المهمة:\n{text_description}"}]}],
                "generationConfig": {"temperature": 0.1, "responseMimeType": "application/json"}
            }
            response = await self.http_client.post(url, json=payload)
            response.raise_for_status()
            return response.json()["candidates"][0]["content"]["parts"][0]["text"]
            
        logger.info("✨ جاري التحليل عبر Google Gemini...")
        content = await self._safe_api_call(_call)
        return self._safe_json_parse(content)

    async def _analyze_with_mistral(self, text_description: str) -> dict:
        async def _call():
            headers = {"Authorization": f"Bearer {self.mistral_api_key}", "Content-Type": "application/json", "Accept": "application/json"}
            payload = {
                "model": "mistral-small-latest",
                "messages": [{"role": "system", "content": self._get_system_instruction()}, {"role": "user", "content": f"وصف المهمة:\n{text_description}"}],
                "temperature": 0.1, "max_tokens": 4096, 
                "response_format": {"type": "json_object"}
            }
            response = await self.http_client.post("https://api.mistral.ai/v1/chat/completions", headers=headers, json=payload)
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
            
        logger.info("🌪️ جاري التحليل عبر Mistral...")
        content = await self._safe_api_call(_call)
        return self._safe_json_parse(content)

    async def _analyze_with_deepseek(self, text_description: str) -> dict:
        async def _call():
            headers = {"Authorization": f"Bearer {self.deepseek_api_key}", "Content-Type": "application/json"}
            payload = {
                "model": "deepseek-chat",
                "messages": [{"role": "system", "content": self._get_system_instruction()}, {"role": "user", "content": f"وصف المهمة:\n{text_description}"}],
                "temperature": 0.1, "max_tokens": 4096, 
                "response_format": {"type": "json_object"}
            }
            response = await self.http_client.post("https://api.deepseek.com/v1/chat/completions", headers=headers, json=payload)
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
            
        logger.info("🧠 جاري التحليل عبر DeepSeek...")
        content = await self._safe_api_call(_call)
        return self._safe_json_parse(content)

    async def _analyze_with_openrouter(self, text_description: str) -> dict:
        async def _call():
            headers = {"Authorization": f"Bearer {self.openrouter_api_key}", "HTTP-Referer": "https://github.com/unu-bot", "X-Title": "UNU Bot Auto", "Content-Type": "application/json"}
            payload = {
                "model": "openrouter/free", 
                "messages": [{"role": "system", "content": self._get_system_instruction()}, {"role": "user", "content": f"وصف المهمة:\n{text_description}"}],
                "temperature": 0.1
            }
            response = await self.http_client.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload)
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
            
        logger.info("🌐 جاري التحليل عبر OpenRouter...")
        content = await self._safe_api_call(_call)
        return self._safe_json_parse(content)

    # --------------------------------------------------------
    # قواعد الطوارئ (Rule-Based Fallback) - الموسوعة الشاملة
    # --------------------------------------------------------

    def _rule_based_fallback(self, text_description: str) -> dict:
        logger.warning("⚙️ تفعيل النظام الآلي الموسع للتحليل (الموسوعة الشاملة)...")

        fallback_result = {
            "platform": "other",
            "action": "unknown",
            "required_proof": "screenshot",
            "summary": "تحليل آلي للمهمة بناءً على الكلمات المفتاحية"
        }

        text_lower = text_description.lower()

        # 0. تطبيع الصيغ الشائعة قبل فحص الكلمات المفتاحية.
        text_lower = text_lower.replace("ё", "е")

        # 1. تحديد المنصة (Platform) - قاموس شامل
        platform_keywords = {
            "telegram": ["телеграм", "telegram", "t.me", "telegram.me"],
            "vk": ["вконтакте", "vk.com", "vk", "вк", "паблик", "группу vk"],
            "tiktok": ["tiktok", "тикток", "тт", "тик-ток"],
            "youtube": ["youtube", "ютуб", "youtube.com", "yt"],
            "rutube": ["rutube", "рутуб"],
            "instagram": ["instagram", "инстаграм", "инста", "inst"],
            "facebook": ["facebook", "фейсбук", "fb"],
            "twitter": ["twitter", "твиттер", "x.com"],
            "discord": ["discord", "дискорд"],
            "reddit": ["reddit", "реддит"],
            "avito": ["авито", "avito", "avito.ru"],
            "yandex": ["яндекс", "yandex", "дзен", "dzen", "яндекс.карты", "yandex.maps"],
            "google_play": ["google play", "гугл плей", "play market", "плэй маркет", "android app"],
            "app_store": ["app store", "аппстор", "ios app", "apple store"],
            "website": ["сайт", "вебсайт", "website", "переход", "серфинг", "посетить", "клик"],
            "review": ["отзыв", "оценка", "review", "комментарий на сайте", "рейтинг"]
        }

        for platform, keywords in platform_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                fallback_result["platform"] = platform
                break
        if fallback_result["platform"] == "telegram" and not any(
            x in text_lower for x in ("t.me/", "telegram.me/", "telegram", "телеграм")
        ):
            fallback_result["platform"] = "other"
        fallback_result["source"] = "rule_fallback"
        fallback_result["confidence"] = 0.35

        # 2. تحديد الإجراء (Action) - قاموس شامل
        action_keywords = {
            "subscribe": ["подпис", "подписаться", "вступить", "subscribe", "follow", "следить", "join", "фоллов"],
            "like": ["лайк", "like", "нравится", "класс"],
            "comment": ["комментарий", "коммент", "comment", "написать"],
            "start_bot": ["бот", "bot", "запустить", "start bot"],
            "register": ["рег", "регистрация", "зарегистрироваться", "зарегистрируйтесь", "забрать бонус", "создать аккаунт", "register", "sign up", "account"],
            "view": ["просмотр", "просмотреть", "смотреть", "смотри", "view", "watch", "посетить", "посетить сайт", "зайти", "зайти на сайт", "заход", "войти на сайт", "найти", "поиск", "через поиск", "серфинг", "кликнуть", "клик", "перейти", "переход"],
            "review": ["оценка", "оценить", "оцените", "rate", "5 звезд", "пять звезд", "отзыв", "отзыв на"],
            "share": ["поделиться", "share"],
            "repost": ["репост", "repost"],
            "install": ["установить", "скачать", "install", "download", "приложение", "app"]
        }

        # نكشف الإجراء الأكثر تحديداً أولاً حتى لا تسبق كلمة عامة
        # مثل "бот" إجراءً أدق مثل التسجيل أو الاشتراك.
        action_priority = [
            "register",
            "subscribe",
            "like",
            "comment",
            "start_bot",
            "review",
            "share",
            "repost",
            "view",
            "install",
        ]
        for action in action_priority:
            keywords = action_keywords.get(action, [])
            if any(keyword in text_lower for keyword in keywords):
                if action == "start_bot" and not any(
                    marker in text_lower
                    for marker in ["запустить", "запусти", "нажать start", "нажмите start", "start bot"]
                ):
                    continue
                fallback_result["action"] = action
                break

        # توحيد action إلى قيمة canonical قبل إرجاع النتيجة.
        action_aliases = {
            "اشتراك/متابعة": "subscribe",
            "إعجاب": "like",
            "تعليق": "comment",
            "تشغيل بوت": "start_bot",
            "تسجيل": "register",
            "تصفح/مشاهدة": "view",
            "تقييم/مراجعة": "review",
            "إعادة نشر/مشاركة": "share",
            "تثبيت تطبيق": "install",
            "غير محدد": "unknown",
        }
        fallback_result["action"] = action_aliases.get(
            fallback_result["action"], fallback_result["action"]
        )

        # 3. تحديد الإثبات المطلوبة (Required Proof)
        proof_keywords = {
            "screenshot": ["скрин", "скриншот", "screenshot", "снимок экрана", "фото"],
            "username": ["ник", "имя", "username", "логин", "login", "имя пользователя", "профиль"],
            "link": ["ссылка", "link", "url", "адрес"],
            "email": ["email", "почта", "e-mail", "электронная почта"],
            "text": ["текст", "сообщение", "ответ"]
        }

        for proof, keywords in proof_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                fallback_result["required_proof"] = proof
                break

        return fallback_result

    # --------------------------------------------------------
    # المحرك الأساسي (المدير والموزع للطلبات - The Orchestrator)
    # --------------------------------------------------------


    async def generate_comment(
        self,
        task_description: str,
        task_screenshot: Optional[str] = None,
        target_screenshot: Optional[str] = None,
        platform: str = "",
        language_hint: str = "ru",
    ) -> str:
        """
        يولّد تعليقًا طبيعيًا قصيرًا من وصف المهمة + سكرين المهمة + سكرين المحتوى.
        يُفضّل Gemini Vision عند توفر الصور، ثم النص فقط.
        """
        import base64
        from pathlib import Path as _Path

        lang = "Russian" if language_hint.startswith("ru") else "the task language"
        instruction = (
            "You write ONE short natural social-media comment. "
            f"Language: {lang}. 1-2 sentences. No spam hashtags. "
            "Return JSON only: {\"comment\": \"...\"}.\n\n"
            f"Platform: {platform}\n"
            f"Task instructions:\n{task_description[:4000]}"
        )

        async def _vision_comment(image_path: str) -> str:
            image_file = _Path(image_path)
            if not image_file.exists():
                return ""
            mime = "image/png"
            suf = image_file.suffix.lower()
            if suf in (".jpg", ".jpeg"):
                mime = "image/jpeg"
            elif suf == ".webp":
                mime = "image/webp"
            encoded = base64.b64encode(image_file.read_bytes()).decode("utf-8")
            url = (
                "https://generativelanguage.googleapis.com/v1beta/"
                f"models/{self.gemini_vision_model}:generateContent?key={self.gemini_api_key}"
            )
            payload = {
                "contents": [{
                    "parts": [
                        {"text": instruction},
                        {"inline_data": {"mime_type": mime, "data": encoded}},
                    ]
                }],
                "generationConfig": {"temperature": 0.4, "maxOutputTokens": 256},
            }
            response = await self.http_client.post(url, json=payload)
            response.raise_for_status()
            raw = response.json()["candidates"][0]["content"]["parts"][0]["text"]
            parsed = self._safe_json_parse(raw)
            if isinstance(parsed, dict):
                return str(parsed.get("comment") or parsed.get("text") or "").strip()
            return ""

        # جرّب سكرين الهدف ثم سكرين المهمة
        for shot in (target_screenshot, task_screenshot):
            if not shot:
                continue
            try:
                text = await self._safe_api_call(_vision_comment, shot)
                if text:
                    logger.info("✅ Comment generated via Vision")
                    return text[:500]
            except Exception as error:
                logger.warning("Vision comment failed: %s", error)

        # نص فقط عبر Gemini
        try:
            result = await self._analyze_with_gemini(
                instruction + "\nReturn JSON {\"comment\": \"...\"} only."
            )
            if isinstance(result, dict):
                text = str(result.get("comment") or result.get("summary") or "").strip()
                if text:
                    return text[:500]
        except Exception as error:
            logger.warning("Text comment generation failed: %s", error)

        # Fallback demographic-aware if classic path empty
        try:
            demo = await self.generate_comment_demographic(
                task_description,
                platform=platform,
                task_screenshot=task_screenshot,
                target_screenshot=target_screenshot,
                language_hint=language_hint,
            )
            if demo:
                return demo[:500]
        except Exception:
            pass
        return "Отличный контент, спасибо!"

    async def analyze_task(self, text_description: str, screenshot_path: Optional[str] = None) -> dict:
        if not text_description or text_description.strip() == "":
            logger.warning("⚠️ وصف المهمة فارغ. سيتم استخدام القواعد الآلية المباشرة.")
            result = self._rule_based_fallback(text_description)
            result["source"] = "rule_fallback"
            result["analysis_status"] = "unavailable"
            result["executable"] = False
            return result

        # 🚀 فحص التخزين المؤقت (Cache Check)
        # الصورة جزء من هوية التحليل؛ لا نستخدم نتيجة نص قديم
        # مع Screenshot مختلف.
        image_stamp = ""
        if screenshot_path:
            image_file = Path(screenshot_path)
            if image_file.exists():
                stat = image_file.stat()
                image_stamp = f"|{image_file.resolve()}|{stat.st_size}|{stat.st_mtime_ns}"
        cache_key = text_description.strip().lower() + image_stamp
        if cache_key in self._cache:
            logger.info("📦 تم العثور على نتيجة المهمة في التخزين المؤقت (Cache hit)! جلب فوري.")
            return self._cache[cache_key]

        result = None

        # --------------------------------------------------------
        # Vision أولًا عند توفر Screenshot
        # --------------------------------------------------------
        # هذا هو المسار الأساسي للتفاصيل: الصورة والنص الخام معًا.
        # VISION_SKIP_LONG_TEXT: النص الطويل يكفي — يقلل 429 على Gemini
        _skip_vision = len(str(text_description or "")) >= 180
        if screenshot_path and Path(screenshot_path).exists() and not _skip_vision:
            try:
                result = await self._analyze_with_gemini_vision(
                    text_description,
                    screenshot_path,
                )
                logger.info("✅ تم تحليل المهمة بالنص وScreenshot عبر Vision")
            except Exception as error:
                logger.warning(
                    "Vision analysis failed; using text engines: %s",
                    error,
                )
        elif _skip_vision and screenshot_path:
            logger.info("⏭️ تخطّي Vision (النص طويل كفاية) لتوفير الحصة وتفادي 429")

        # --------------------------------------------------------
        # Dynamic Semantic Routing (AI Core V3)
        # --------------------------------------------------------
        if not result:
            try:
                result = await self._route_and_analyze(text_description)
            except Exception as e:
                logger.error(f"❌ Router pipeline failed: {e}")
                result = None

        # Fallback القوي (القواعد الآلية)
        if not result:
            logger.warning("⚠️ جميع محركات الذكاء الاصطناعي فشلت؛ المهمة لن تُقبل.")
            result = {
                "platform": "other",
                "action": "unknown",
                "required_proof": "screenshot",
                "summary": "",
                "confidence": 0.0,
                "executable": False,
                "analysis_status": "unavailable",
                "source": "ai_unavailable",
            }

        # تطبيع + مبدأ تفكير/بوابات بعد أي مصدر (AI أو fallback)
        result = self._normalize_ai_result(result, text_description)
        result = self._apply_policy_thinking(result, text_description)
        # Thinking V4: تحقق CoT + كشف تناقض + مرور تصحيح للمهام المعقدة
        try:
            result = await self._deep_think_pipeline(result, text_description)
        except Exception as _dt_err:
            logger.warning("deep_think_pipeline: %s", _dt_err)

        # 💾 حفظ النتيجة في التخزين المؤقت (Cache Store)
        if result:
            if len(self._cache) > 1000:
                self._cache.pop(next(iter(self._cache)))
            self._cache[cache_key] = result

        return result

    # =========================================================
    # AI CORE V2 — تطبيع النتيجة + بوابات التفكير (Additive)
    # =========================================================

    _CANONICAL_PLATFORMS = {
        "telegram", "vk", "tiktok", "instagram", "youtube", "rutube",
        "twitter", "x", "max", "facebook", "ok", "likee", "linkedin",
        "pinterest", "twitch", "discord", "reddit", "avito", "ozon",
        "yandex", "google_play", "app_store", "google_maps", "website",
        "review", "other",
    }

    _CANONICAL_ACTIONS = {
        "subscribe", "like", "comment", "repost", "share", "view",
        "review", "register", "start_bot", "install", "unknown",
    }

    _PLATFORM_ALIASES = {
        "x": "twitter",
        "твиттер": "twitter",
        "twitter/x": "twitter",
        "вк": "vk",
        "вконтакте": "vk",
        "тикток": "tiktok",
        "инстаграм": "instagram",
        "инста": "instagram",
        "ютуб": "youtube",
        "рутуб": "rutube",
        "тг": "telegram",
        "телеграм": "telegram",
        "одноклассники": "ok",
        "ok.ru": "ok",
    }

    _ACTION_ALIASES = {
        "follow": "subscribe",
        "join": "subscribe",
        "اشتراك": "subscribe",
        "متابعة": "subscribe",
        "подписка": "subscribe",
        "подписаться": "subscribe",
        "лайк": "like",
        "إعجاب": "like",
        "коммент": "comment",
        "تعليق": "comment",
        "репост": "repost",
        "retweet": "repost",
        "поделиться": "share",
        "مشاركة": "share",
        "просмотр": "view",
        "مشاهدة": "view",
        "отзыв": "review",
        "تقييم": "review",
        "регистрация": "register",
        "تسجيل": "register",
        "start bot": "start_bot",
        "запустить бота": "start_bot",
        "غير محدد": "unknown",
        "غير معروف": "unknown",
    }

    def _extract_urls_from_text(self, text: str) -> list:
        if not text:
            return []
        found = re.findall(r"https?://[^\s\]\)\>\"']+", text, flags=re.I)
        cleaned = []
        for u in found:
            u = u.rstrip(".,;:)")
            low = u.lower()
            if "unu.im/tasks/" in low:
                continue
            if u not in cleaned:
                cleaned.append(u)
        return cleaned

    def _infer_platform_from_url(self, url: str) -> str:
        u = (url or "").lower()
        rules = [
            ("telegram", ["t.me/", "telegram.me/", "telegram.org"]),
            ("vk", ["vk.com/", "vk.ru/", "m.vk."]),
            ("instagram", ["instagram.com"]),
            ("tiktok", ["tiktok.com", "vm.tiktok"]),
            ("youtube", ["youtube.com", "youtu.be"]),
            ("rutube", ["rutube.ru"]),
            ("twitter", ["x.com/", "twitter.com"]),
            ("max", ["max.ru", "oneme.ru"]),
            ("facebook", ["facebook.com", "fb.com", "fb.watch"]),
            ("ok", ["ok.ru", "odnoklassniki"]),
            ("likee", ["likee.video", "likee.com"]),
            ("avito", ["avito.ru"]),
            ("ozon", ["ozon.ru"]),
            ("yandex", ["yandex.ru", "dzen.ru"]),
            ("google_maps", ["google.com/maps", "maps.app.goo.gl", "goo.gl/maps"]),
            ("discord", ["discord.com", "discord.gg"]),
            ("reddit", ["reddit.com"]),
            ("linkedin", ["linkedin.com"]),
            ("pinterest", ["pinterest.com", "pin.it"]),
            ("twitch", ["twitch.tv"]),
        ]
        for plat, keys in rules:
            if any(k in u for k in keys):
                return plat
        return ""

    def _infer_action_from_url(self, url: str, platform: str) -> str:
        u = (url or "").lower()
        p = (platform or "").lower()
        if p == "instagram":
            if any(x in u for x in ("/reel/", "/p/", "/tv/")):
                return "like"
            if re.search(r"instagram\.com/[^/]+/?$", u.split("?")[0]):
                return "subscribe"
        if p == "tiktok":
            if "/video/" in u:
                return "like"
            if "/@" in u and "/video/" not in u:
                return "subscribe"
        if p == "vk":
            if "wall" in u:
                return "like"
            return "subscribe"
        if p == "youtube":
            if any(x in u for x in ("watch", "shorts", "youtu.be/")):
                return "like"
            if "/@" in u or "/channel/" in u or "/c/" in u:
                return "subscribe"
        if p == "twitter":
            if "/status/" in u:
                return "like"
            return "subscribe"
        if p == "telegram":
            if "boost/" in u:
                return "unknown"
            if re.search(r"/(?:[a-z0-9_]*bot)(?:\?|$)", u) or u.rstrip("/").endswith("bot"):
                return "start_bot"
            if re.search(r"t\.me/[^/]+/\d+", u):
                return "view"
            return "subscribe"
        if p == "max":
            return "subscribe"
        if p == "rutube":
            if "/video/" in u:
                return "view"
            return "subscribe"
        return ""

    def _detect_telegram_bot(self, text: str, urls: list) -> bool:
        """بوت فقط لو الرابط نفسه بوت. كلمة бот في النص لا تكفي."""
        for raw in urls or []:
            ul = str(raw or "").lower()
            if "href.li/?" in ul:
                ul = ul.split("href.li/?", 1)[-1].split("&")[0]
            if "t.me/" not in ul and "telegram.me/" not in ul:
                continue
            if "start=" in ul or "startapp" in ul or "tgwebapp" in ul:
                return True
            path = ul.split("t.me/")[-1].split("telegram.me/")[-1]
            path = path.split("?")[0].strip("/")
            first = path.split("/")[0]
            rest = path.split("/")[1:]
            if not first or first in {"joinchat", "boost", "c", "+"}:
                continue
            if first.endswith("bot") or first.startswith("bot"):
                return True
            if "start=" in ul or "startapp" in ul:
                return True
            if rest and rest[0].isdigit():
                continue
        return False

    def _detect_generic_homepage(self, urls: list) -> bool:
        if not urls:
            return False
        generics = {
            "https://www.youtube.com/",
            "https://youtube.com/",
            "https://www.tiktok.com/",
            "https://tiktok.com/",
            "https://www.instagram.com/",
            "https://instagram.com/",
            "https://x.com/",
            "https://twitter.com/",
            "https://vk.com/",
            "https://vk.ru/",
        }
        for u in urls:
            base = u.split("?")[0].rstrip("/") + "/"
            # homepage if path almost empty
            try:
                from urllib.parse import urlparse
                pr = urlparse(u)
                path = (pr.path or "/").rstrip("/")
                if path in ("", "/") and u.lower().startswith(("http://", "https://")):
                    host = (pr.netloc or "").lower().replace("www.", "")
                    if host in {
                        "youtube.com", "tiktok.com", "instagram.com",
                        "x.com", "twitter.com", "vk.com", "vk.ru",
                    }:
                        return True
            except Exception:
                pass
            if u.rstrip("/") + "/" in generics or u in generics:
                return True
        return False

    def _normalize_ai_result(self, result: dict, text_description: str = "") -> dict:
        if not isinstance(result, dict):
            result = {}

        out = dict(result)
        text = text_description or ""
        urls = out.get("target_urls") if isinstance(out.get("target_urls"), list) else []
        urls = [str(u).strip() for u in urls if u]
        extracted = self._extract_urls_from_text(text)
        for u in extracted:
            if u not in urls:
                urls.append(u)
        out["target_urls"] = urls

        # platform
        plat = str(out.get("platform") or "other").strip().lower()
        plat = self._PLATFORM_ALIASES.get(plat, plat)
        if plat == "x":
            plat = "twitter"
        if plat not in self._CANONICAL_PLATFORMS:
            plat = "other"
        # boost from URL
        if urls:
            inferred = ""
            for candidate in urls:
                inferred = self._infer_platform_from_url(str(candidate))
                if inferred:
                    break
            if inferred and (plat in {"other", "website", "", "telegram"} or plat != inferred):
                if plat == "telegram" and inferred == "telegram":
                    pass
                elif inferred:
                    plat = inferred
            blob = text.lower()
            if plat == "twitter" and any(k in blob for k in ("репост", "repost", "retweet")):
                act_hint = "repost"
            elif plat == "instagram" and any("/reel/" in str(u).lower() or "/p/" in str(u).lower() for u in urls):
                act_hint = "like"
            else:
                act_hint = ""
        else:
            act_hint = ""
        out["platform"] = plat

        # action
        act = str(out.get("action") or "unknown").strip().lower()
        act = self._ACTION_ALIASES.get(act, act)
        if act not in self._CANONICAL_ACTIONS:
            act = "unknown"
        if act == "unknown" and urls:
            inferred_a = self._infer_action_from_url(urls[0], plat)
            if inferred_a:
                act = inferred_a
        if act_hint == "repost" and act in {"subscribe", "like", "unknown"}:
            act = "repost"
        if act_hint == "like" and act == "subscribe":
            act = "like"
        out["action"] = act

        # actions_list / compound
        alist = out.get("actions_list")
        if not isinstance(alist, list):
            alist = []
        alist = [self._ACTION_ALIASES.get(str(a).lower(), str(a).lower()) for a in alist]
        alist = [a for a in alist if a in self._CANONICAL_ACTIONS and a != "unknown"]
        if not alist:
            alist = [act] if act != "unknown" else []
        # detect compound from text
        blob = text.lower()
        compound_hits = []
        for a, keys in (
            ("subscribe", ["подпис", "follow", "вступ"]),
            ("like", ["лайк", "like", "нрав"]),
            ("comment", ["коммент", "comment"]),
            ("repost", ["репост", "repost", "ретвит"]),
        ):
            if any(k in blob for k in keys) and a not in compound_hits:
                compound_hits.append(a)
        if len(compound_hits) > 1:
            out["is_compound"] = True
            # merge order
            for a in compound_hits:
                if a not in alist:
                    alist.append(a)
        out["actions_list"] = alist or ([act] if act != "unknown" else [])
        out["is_compound"] = bool(out.get("is_compound")) or len(out["actions_list"]) > 1

        # proof
        proof = str(out.get("required_proof") or "screenshot").strip().lower()
        if proof not in {"screenshot", "username", "link", "text", "email", "unknown"}:
            proof = "screenshot"
        out["required_proof"] = proof

        # confidence
        try:
            conf = float(out.get("confidence", 0.55))
        except Exception:
            conf = 0.55
        out["confidence"] = max(0.0, min(1.0, conf))

        # summary
        if not out.get("summary"):
            out["summary"] = f"{out['action']} على {out['platform']}"
        out["summary"] = str(out["summary"])[:240]

        # defaults
        out.setdefault("is_telegram_bot", False)
        out.setdefault("is_generic_homepage", False)
        out.setdefault("executable", True)
        out.setdefault("reject_reason", None)
        out.setdefault("risk", "mid")
        # execution_steps chain
        steps = out.get("execution_steps")
        if not isinstance(steps, list) or not steps:
            steps = self._default_execution_steps(out)
        else:
            # sanitize
            clean = []
            for i, s in enumerate(steps):
                if not isinstance(s, dict):
                    continue
                act = str(s.get("action") or "wait").lower()
                step = {"step": int(s.get("step") or (i + 1)), "action": act}
                if "duration_seconds" in s:
                    try:
                        step["duration_seconds"] = int(s.get("duration_seconds") or 0)
                    except Exception:
                        pass
                if s.get("text"):
                    step["text"] = str(s.get("text"))[:300]
                clean.append(step)
            steps = clean or self._default_execution_steps(out)
        out["execution_steps"] = steps

        out.setdefault("is_honeypot", False)
        out["normalized"] = True
        return out

    def _apply_policy_thinking(self, result: dict, text_description: str = "") -> dict:
        """بوابات صارمة لتقليل التنفيذ الغلط قبل main Gate."""
        out = dict(result or {})
        text = text_description or ""
        urls = out.get("target_urls") or []
        plat = out.get("platform") or "other"
        act = out.get("action") or "unknown"

        # Honeypot radar (local)
        is_honey = bool(out.get("is_honeypot")) or self._detect_honeypot(text, urls)
        out["is_honeypot"] = is_honey
        if is_honey:
            out["executable"] = False
            out["reject_reason"] = "honeypot_trap"
            out["risk"] = "high"
            out["confidence"] = max(float(out.get("confidence") or 0.5), 0.85)
            return out

        real_bot = self._detect_telegram_bot(text, urls)
        if not real_bot:
            out["is_telegram_bot"] = False
            if str(out.get("reject_reason") or "") == "telegram_bot_blocked":
                out["reject_reason"] = None
                out["executable"] = True
                if str(out.get("action") or "") == "start_bot":
                    guessed = ""
                    for candidate in urls:
                        guessed = self._infer_action_from_url(str(candidate), plat)
                        if guessed and guessed != "start_bot":
                            break
                    out["action"] = guessed or ("subscribe" if plat == "telegram" else "unknown")
        else:
            out["is_telegram_bot"] = True

        is_bot = bool(out.get("is_telegram_bot"))

        is_home = bool(out.get("is_generic_homepage")) or self._detect_generic_homepage(urls)
        out["is_generic_homepage"] = is_home

        # boost telegram boost links
        if any("boost/" in str(u).lower() for u in urls):
            out["executable"] = False
            out["reject_reason"] = "unsupported_action"
            out["risk"] = "high"
            out["confidence"] = min(float(out.get("confidence") or 0.5), 0.4)
            return out

        if is_bot:
            out["platform"] = "telegram"
            out["action"] = "start_bot"
            out["executable"] = False
            out["reject_reason"] = "telegram_bot_blocked"
            out["risk"] = "high"
            out["confidence"] = max(float(out.get("confidence") or 0.5), 0.75)
            return out

        if is_home:
            out["executable"] = False
            out["reject_reason"] = "generic_homepage"
            out["risk"] = "high"
            return out

        if not urls and act not in {"unknown"}:
            # مهام بدون رابط هدف غالبًا فاشلة للتنفيذ الآلي
            blob = text.lower()
            if not any(x in blob for x in ("t.me/", "http://", "https://", "vk.com", "vk.ru")):
                out["executable"] = False
                out["reject_reason"] = "no_target_url"
                out["risk"] = "high"
                return out

        if plat not in {"other", "website", ""} and str(out.get("reject_reason") or "") in {
            "unsupported_platform", "telegram_bot_blocked",
        }:
            if not real_bot:
                out["reject_reason"] = None
                out["executable"] = True

        if plat in {"other", ""} and act == "unknown":
            out["executable"] = False
            out["reject_reason"] = "unsupported_platform"
            out["risk"] = "high"
            out["confidence"] = min(float(out.get("confidence") or 0.5), 0.35)
            return out

        # website/register high risk default
        if plat == "website" and act in {"register", "install"}:
            out["risk"] = "high"
            # لا نرفض تلقائيًا هنا — main يقرر المنصات المسموحة

        # executable default true if not blocked
        if out.get("reject_reason"):
            out["executable"] = False
        else:
            out["executable"] = bool(out.get("executable", True))
            if out.get("reject_reason") is None and out["executable"]:
                out["reject_reason"] = None

        # confidence floor from signals
        if urls and plat not in {"other", "website"}:
            out["confidence"] = max(float(out.get("confidence") or 0.5), 0.6)
        # RL prior boost/penalty
        try:
            prior = self.rl_prior_boost(plat, act)
            conf = float(out.get("confidence") or 0.5)
            # prior 0.5 neutral; >0.5 boost; <0.5 dampen
            conf = conf + (prior - 0.5) * 0.3
            out["confidence"] = max(0.05, min(0.99, conf))
            out["rl_prior"] = prior
        except Exception:
            pass
        return out


    # =====================================================================
    # AI CORE V3 — Dynamic Routing | CoT+Few-Shot | Vision Grounding |
    # Self-Reflection | Demographic Comments | Captcha+Mouse Trajectory
    # Additive only — لا يمسح دوال قديمة
    # =====================================================================

    _FEWSHOT_PATH = Path("data/ai_fewshot.json")
    _MEMORY_PATH = Path("data/ai_long_term_memory.json")
    _REJECT_LOG_PATH = Path("data/ai_reject_lessons.json")

    def _score_task_complexity(self, text: str) -> dict:
        """
        موجه دلالي خفيف (بدون API): يقيس تعقيد المهمة.
        simple → Groq السريع | complex → DeepSeek/Gemini الأثقل
        """
        t = (text or "")
        low = t.lower()
        score = 0
        reasons = []
        urls = re.findall(r"https?://[^\s\]\)\>\"']+", t)
        if len(urls) >= 3:
            score += 3
            reasons.append("multi_url")
        elif len(urls) >= 2:
            score += 2
            reasons.append("dual_url")
        # شروط متعددة
        for k in ("и ", " and ", "ثم", "بعد", "1)", "2)", "3)", "①", "②"):
            if k in low:
                score += 1
        if sum(1 for k in ("подпис", "лайк", "коммент", "репост", "follow", "like", "comment") if k in low) >= 2:
            score += 2
            reasons.append("multi_action")
        if any(k in low for k in ("бот", "bot", "мини", "captcha", "vpn", "qr", "карт", "bank")):
            score += 3
            reasons.append("trap_keywords")
        if len(t) > 1200:
            score += 2
            reasons.append("long_text")
        if len(t) > 2500:
            score += 2
            reasons.append("very_long")
        # مهمة بسيطة جدًا
        simple_patterns = (
            "подписаться на канал",
            "подписаться на группу",
            "поставить лайк",
            "subscribe to",
            "follow the",
        )
        if any(p in low for p in simple_patterns) and score <= 2:
            score = max(0, score - 1)
            reasons.append("simple_pattern")
        if score <= 2:
            tier = "simple"
        elif score <= 5:
            tier = "medium"
        else:
            tier = "complex"
        return {"score": score, "tier": tier, "reasons": reasons, "url_count": len(urls)}

    def _load_json_file(self, path: Path, default):
        try:
            if path.is_file():
                return json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            logger.debug("load %s: %s", path, e)
        return default

    def _save_json_file(self, path: Path, data) -> None:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            logger.warning("save %s failed: %s", path, e)

    def _fewshot_examples(self, text: str, k: int = 3) -> list:
        """
        Active RAG: جرّب Vector memory أولاً، ثم fallback كلمات مفتاحية.
        """
        try:
            vec_hits = self._vector_rag_query(text, k=k)
            if vec_hits:
                return vec_hits
        except Exception as _vr:
            logger.debug("vector rag: %s", _vr)
        db = self._load_json_file(self._FEWSHOT_PATH, {"examples": []})
        examples = db.get("examples") if isinstance(db, dict) else db
        if not isinstance(examples, list) or not examples:
            # أمثلة افتراضية عالية الجودة
            examples = [
                {
                    "input": "Подписаться на канал https://t.me/example_channel Скриншот",
                    "output": {
                        "thinking_process": "URL t.me without bot suffix → telegram channel subscribe",
                        "platform": "telegram",
                        "action": "subscribe",
                        "is_telegram_bot": False,
                        "executable": True,
                        "confidence": 0.92,
                    },
                },
                {
                    "input": "Поставить лайк https://www.instagram.com/reel/ABC123/",
                    "output": {
                        "thinking_process": "instagram reel URL → like not subscribe",
                        "platform": "instagram",
                        "action": "like",
                        "executable": True,
                        "confidence": 0.9,
                    },
                },
                {
                    "input": "Запустить бота https://t.me/SomeNameBot?start=123 и выполнить задания",
                    "output": {
                        "thinking_process": "t.me bot + start param → telegram bot blocked",
                        "platform": "telegram",
                        "action": "start_bot",
                        "is_telegram_bot": True,
                        "executable": False,
                        "reject_reason": "telegram_bot_blocked",
                        "confidence": 0.95,
                    },
                },
                {
                    "input": "Подписаться и лайкнуть последнюю запись https://vk.com/public123",
                    "output": {
                        "thinking_process": "VK public + subscribe and like → compound",
                        "platform": "vk",
                        "action": "subscribe",
                        "is_compound": True,
                        "actions_list": ["subscribe", "like"],
                        "executable": True,
                        "confidence": 0.88,
                    },
                },
            ]
        q = set(re.findall(r"[a-zA-Zа-яА-Я0-9_]{3,}", (text or "").lower()))
        scored = []
        for ex in examples:
            inp = str(ex.get("input") or "").lower()
            tokens = set(re.findall(r"[a-zA-Zа-яА-Я0-9_]{3,}", inp))
            overlap = len(q & tokens)
            scored.append((overlap, ex))
        scored.sort(key=lambda x: -x[0])
        return [ex for sc, ex in scored[:k] if sc > 0] or [ex for _, ex in scored[:k]]


    def _wrap_task_xml(self, text_description: str) -> str:
        """عزل المدخلات بوسوم XML لأي محرك لا يستخدم _build_fewshot_prompt."""
        return (
            "<system_rules>\n"
            + self._get_system_instruction()
            + "\n</system_rules>\n"
            "<strict_constraints>\n"
            "- URL priority over free text.\n"
            "- No invented platforms.\n"
            "- thinking_process with 5 steps + SC required.\n"
            "</strict_constraints>\n"
            f"<task_input>\n{str(text_description or '')[:8000]}\n</task_input>\n"
            "<response_format>JSON_ONLY</response_format>"
        )

    def _build_fewshot_prompt(self, text: str) -> str:
        """
        XML-tagged prompt: system_rules + strict_constraints + few_shot + memory + task_input.
        Forces System-2 structure for light models (Gemini Flash, Groq, etc.).
        """
        examples = self._fewshot_examples(text, k=3)
        memory = self._load_json_file(self._MEMORY_PATH, {"rules": []})
        rules = memory.get("rules") if isinstance(memory, dict) else []
        rules = rules[-8:] if isinstance(rules, list) else []

        edge_cases = """
<edge_cases>
CaseA: text join-channel but URL t.me/NameBot?start= → telegram start_bot executable=false telegram_bot_blocked
CaseB: watch video but URL only youtube.com/ → executable=false generic_homepage
CaseC: like+subscribe on vk.com/wall-... → is_compound true actions_list [like, subscribe]
CaseD: instagram.com/reel/ → action like not subscribe
CaseE: instagram.com/user → subscribe; x.com/user/status → like/repost
</edge_cases>
"""
        few = ["<few_shot_examples>"]
        for i, ex in enumerate(examples, 1):
            few.append(f"<example id=\"{i}\">")
            few.append(f"<input>{str(ex.get('input') or '')[:1200]}</input>")
            few.append(f"<output>{json.dumps(ex.get('output') or {}, ensure_ascii=False)}</output>")
            few.append("</example>")
        few.append("</few_shot_examples>")

        mem_block = ["<long_term_memory>"]
        if rules:
            for r in rules:
                mem_block.append(f"<rule>{r}</rule>")
        else:
            mem_block.append("<rule>none</rule>")
        mem_block.append("</long_term_memory>")

        parts = [
            "<system_rules>",
            self._get_system_instruction(),
            "</system_rules>",
            edge_cases,
            "\n".join(few),
            "\n".join(mem_block),
            "<strict_constraints>",
            "- Never invent platforms outside the canonical list.",
            "- If text conflicts with URL, URL has absolute priority.",
            "- thinking_process must include the 5 numbered steps + SC self-check.",
            "- Return a single JSON object only.",
            "</strict_constraints>",
            "<task_input>",
            str(text or "")[:8000],
            "</task_input>",
            "<response_format>JSON_ONLY</response_format>",
        ]
        return "\n".join(parts)


    async def _analyze_text_with_engine(self, engine: str, text: str) -> dict:
        """تشغيل محرك واحد مع few-shot prompt عند الإمكان."""
        prompt_blob = self._build_fewshot_prompt(text)
        # المحركات الحالية تأخذ text_description وتضيف system instruction داخليًا
        # نمرّر النص الغني few-shot كوصف مهمة
        engines = {
            "groq1": self._analyze_with_groq_1,
            "groq2": self._analyze_with_groq_2,
            "cerebras": self._analyze_with_cerebras,
            "gemini": self._analyze_with_gemini,
            "mistral": self._analyze_with_mistral,
            "deepseek": self._analyze_with_deepseek,
            "openrouter": self._analyze_with_openrouter,
        }
        fn = engines.get(engine)
        if not fn:
            raise ValueError(f"unknown engine {engine}")
        if engine == "deepseek" and self.deepseek_api_key == "YOUR_DEEPSEEK_API_KEY_HERE":
            raise RuntimeError("deepseek key missing")
        return await fn(prompt_blob)

    def _route_order(self, tier: str) -> list:
        """التوزيع المعلن. اللي من غير مفتاح يتخطى، وبعد السلسلة الأساسية باقي المحركات."""
        announced = {
            "simple": ["groq1", "groq2", "cerebras"],
            "medium": ["groq1", "gemini", "cerebras"],
            "complex": ["deepseek", "gemini", "openrouter", "groq1"],
        }
        tail = ["groq1", "groq2", "gemini", "cerebras", "mistral", "deepseek", "openrouter"]
        order = list(announced.get(tier, announced["medium"]))
        for engine in tail:
            if engine not in order:
                order.append(engine)
        return order

    def _engine_ready(self, engine: str) -> bool:
        if engine == "groq1":
            return bool(self.groq_client_1 and self.groq_api_key_1)
        if engine == "groq2":
            return bool(self.groq_client_2 and self.groq_api_key_2)
        if engine == "gemini":
            return bool(self.gemini_api_key)
        if engine == "deepseek":
            return bool(self.deepseek_api_key) and self.deepseek_api_key != "YOUR_DEEPSEEK_API_KEY_HERE"
        if engine == "openrouter":
            return bool(self.openrouter_api_key)
        if engine == "cerebras":
            return bool(self.cerebras_api_key)
        if engine == "mistral":
            return bool(self.mistral_api_key)
        return False

    async def _route_and_analyze(self, text_description: str) -> dict:
        """
        Dynamic Semantic Router:
        simple  → groq1 → groq2 → cerebras
        medium  → groq1 → gemini → cerebras
        complex → deepseek → gemini → openrouter → groq1
        ثم باقي المحركات اللي عندها مفتاح: mistral وgroq2 وغيرهم.
        """
        meta = self._score_task_complexity(text_description)
        tier = meta["tier"]
        order = self._route_order(tier)
        logger.info(
            "🧭 Semantic route tier=%s score=%s order=%s reasons=%s",
            tier,
            meta["score"],
            ">".join(order),
            ",".join(meta["reasons"]) or "-",
        )

        last_err = None
        for eng in order:
            if not self._engine_ready(eng):
                continue
            try:
                result = await self._analyze_text_with_engine(eng, text_description)
                if result and isinstance(result, dict) and result.get("platform"):
                    result["router_tier"] = tier
                    result["router_engine"] = eng
                    result["router_score"] = meta["score"]
                    return result
            except Exception as e:
                last_err = e
                logger.warning("router engine %s failed: %s", eng, e)
        if last_err:
            logger.error("all routed engines failed: %s", last_err)
        return None

    # ---------- Visual Grounding ----------
    async def locate_ui_element(
        self,
        screenshot_path: str,
        element_description: str,
        page_width: int = 1280,
        page_height: int = 720,
    ) -> dict:
        """
        Vision Grounding: يستخرج إحداثيات زر/عنصر من صورة الشاشة.
        الإخراج: {ok, x, y, confidence, label}
        x,y بنسبة 0..1 من عرض/ارتفاع الصورة ثم تُحوّل لبكسل.
        """
        out = {"ok": False, "x": None, "y": None, "px": None, "py": None, "confidence": 0.0, "label": element_description}
        image_file = Path(screenshot_path)
        if not image_file.is_file():
            out["error"] = "missing_image"
            return out
        try:
            encoded = base64.b64encode(image_file.read_bytes()).decode("utf-8")
            mime = "image/png"
            if image_file.suffix.lower() in (".jpg", ".jpeg"):
                mime = "image/jpeg"
            prompt = (
                "You are a UI grounding model. Look at the screenshot and find the UI element described.\n"
                f"Element: {element_description}\n"
                "Return JSON ONLY:\n"
                '{"found": true, "x_norm": 0.0, "y_norm": 0.0, "confidence": 0.0, "note": "..."}\n'
                "x_norm,y_norm are relative coordinates from 0 to 1 (top-left origin).\n"
                "If not found: {\"found\": false, \"x_norm\": null, \"y_norm\": null, \"confidence\": 0}"
            )
            url = (
                "https://generativelanguage.googleapis.com/v1beta/"
                f"models/{self.gemini_vision_model}:generateContent?key={self.gemini_api_key}"
            )
            payload = {
                "contents": [{
                    "parts": [
                        {"text": prompt},
                        {"inline_data": {"mime_type": mime, "data": encoded}},
                    ]
                }],
                "generationConfig": {"temperature": 0.0, "maxOutputTokens": 256},
            }

            async def _call():
                response = await self.http_client.post(url, json=payload)
                response.raise_for_status()
                return response.json()["candidates"][0]["content"]["parts"][0]["text"]

            raw = await self._safe_api_call(_call)
            parsed = self._safe_json_parse(raw)
            if not isinstance(parsed, dict) or not parsed.get("found"):
                out["raw"] = str(raw)[:200]
                return out
            xn = float(parsed.get("x_norm"))
            yn = float(parsed.get("y_norm"))
            xn = min(0.99, max(0.01, xn))
            yn = min(0.99, max(0.01, yn))
            out["ok"] = True
            out["x"] = xn
            out["y"] = yn
            out["px"] = int(xn * page_width)
            out["py"] = int(yn * page_height)
            out["confidence"] = float(parsed.get("confidence") or 0.5)
            out["note"] = parsed.get("note")
            return out
        except Exception as e:
            out["error"] = str(e)[:160]
            logger.warning("locate_ui_element failed: %s", e)
            return out

    async def click_by_vision(self, page, element_description: str) -> dict:
        """يلتقط سكرين الصفحة → grounding → نقر بالماوس على الإحداثيات."""
        report = {"ok": False, "status": "pending"}
        if page is None:
            report["status"] = "no_page"
            return report
        try:
            Path("data/proofs").mkdir(parents=True, exist_ok=True)
            import time as _time
            path = f"data/proofs/ground_{int(_time.time()*1000)}.jpg"
            await page.screenshot(path=path, type="jpeg", quality=85)
            vp = page.viewport_size or {"width": 1280, "height": 720}
            loc = await self.locate_ui_element(
                path,
                element_description,
                page_width=int(vp.get("width") or 1280),
                page_height=int(vp.get("height") or 720),
            )
            report["locate"] = loc
            if not loc.get("ok"):
                report["status"] = "not_found"
                return report
            px, py = int(loc["px"]), int(loc["py"])
            # مسار ماوس بشري قبل النقر
            await self.human_mouse_move(page, px, py)
            await page.mouse.click(px, py)
            report["ok"] = True
            report["status"] = "clicked"
            report["x"], report["y"] = px, py
            return report
        except Exception as e:
            report["status"] = f"error:{type(e).__name__}"
            report["error"] = str(e)[:160]
            return report

    # ---------- Self-Reflection / Auto-Healing memory ----------
    async def reflect_on_rejection(
        self,
        task_text: str,
        original_json: dict,
        reject_reason: str,
        screenshot_path: Optional[str] = None,
    ) -> dict:
        """
        عند رفض UNU: يحلّل الخطأ ويستخرج قاعدة جديدة للذاكرة طويلة المدى.
        """
        lesson = {
            "ok": False,
            "rule": "",
            "analysis": "",
            "reject_reason": reject_reason,
        }
        prompt = (
            "You are improving an automation classifier.\n"
            f"The task was REJECTED. Reason: {reject_reason}\n"
            f"Original classifier JSON:\n{json.dumps(original_json or {}, ensure_ascii=False)[:3000]}\n"
            f"Task text:\n{(task_text or '')[:3500]}\n"
            "Explain the mistake briefly and produce ONE durable rule to prevent recurrence.\n"
            "Return JSON only: "
            '{"analysis": "...", "rule": "IF ... THEN ...", "adjust_platform": null, '
            '"adjust_action": null, "force_reject_reason": null}'
        )
        try:
            raw = None
            if screenshot_path and Path(screenshot_path).is_file():
                try:
                    # vision optional
                    encoded = base64.b64encode(Path(screenshot_path).read_bytes()).decode("utf-8")
                    mime = "image/jpeg" if Path(screenshot_path).suffix.lower() in (".jpg", ".jpeg") else "image/png"
                    url = (
                        "https://generativelanguage.googleapis.com/v1beta/"
                        f"models/{self.gemini_vision_model}:generateContent?key={self.gemini_api_key}"
                    )
                    payload = {
                        "contents": [{
                            "parts": [
                                {"text": prompt},
                                {"inline_data": {"mime_type": mime, "data": encoded}},
                            ]
                        }],
                        "generationConfig": {"temperature": 0.2, "maxOutputTokens": 512},
                    }
                    async def _call():
                        r = await self.http_client.post(url, json=payload)
                        r.raise_for_status()
                        return r.json()["candidates"][0]["content"]["parts"][0]["text"]
                    raw = await self._safe_api_call(_call)
                except Exception as e:
                    logger.warning("reflect vision failed: %s", e)
            if not raw:
                # text engines
                try:
                    raw_dict = await self._analyze_with_gemini(prompt)
                    if isinstance(raw_dict, dict) and raw_dict.get("rule"):
                        parsed = raw_dict
                    else:
                        parsed = self._safe_json_parse(str(raw_dict))
                except Exception:
                    parsed = await self._analyze_with_groq_1(prompt) if self.groq_client_1 else {}
            else:
                parsed = self._safe_json_parse(raw)

            if not isinstance(parsed, dict):
                parsed = {}
            rule = str(parsed.get("rule") or "").strip()
            analysis = str(parsed.get("analysis") or "").strip()
            lesson["analysis"] = analysis
            lesson["rule"] = rule
            if rule:
                mem = self._load_json_file(self._MEMORY_PATH, {"rules": []})
                rules = mem.get("rules") if isinstance(mem, dict) else []
                if not isinstance(rules, list):
                    rules = []
                if rule not in rules:
                    rules.append(rule)
                mem = {"rules": rules[-50:]}
                self._save_json_file(self._MEMORY_PATH, mem)
                # fewshot negative example
                fs = self._load_json_file(self._FEWSHOT_PATH, {"examples": []})
                examples = fs.get("examples") if isinstance(fs, dict) else []
                if not isinstance(examples, list):
                    examples = []
                examples.append({
                    "input": (task_text or "")[:1500],
                    "output": {
                        "thinking_process": analysis[:500],
                        "platform": (original_json or {}).get("platform") or "other",
                        "action": (original_json or {}).get("action") or "unknown",
                        "executable": False,
                        "reject_reason": reject_reason or "unknown",
                        "confidence": 0.8,
                    },
                    "source": "rejection_lesson",
                })
                self._save_json_file(self._FEWSHOT_PATH, {"examples": examples[-200:]})
                lesson["ok"] = True
            # log
            logs = self._load_json_file(self._REJECT_LOG_PATH, [])
            if not isinstance(logs, list):
                logs = []
            logs.append({
                "reject_reason": reject_reason,
                "rule": rule,
                "analysis": analysis[:500],
                "task_preview": (task_text or "")[:300],
            })
            self._save_json_file(self._REJECT_LOG_PATH, logs[-300:])
            return lesson
        except Exception as e:
            lesson["error"] = str(e)[:160]
            logger.warning("reflect_on_rejection failed: %s", e)
            return lesson

    # ---------- Demographic-aware comments ----------
    _PLATFORM_TONE = {
        "tiktok": {
            "lang": "ru",
            "style": "GenZ slang, short, 1-2 emojis max, energetic, no corporate tone",
            "examples": ["огонь 🔥", "топчик", "это зашло"],
        },
        "instagram": {
            "lang": "ru",
            "style": "casual aesthetic, soft compliments, light emoji",
            "examples": ["очень красиво ✨", "атмосфера огонь"],
        },
        "vk": {
            "lang": "ru",
            "style": "plain Russian, friendly, minimal emoji, slightly informal",
            "examples": ["классный пост", "согласен, хорошо сказано"],
        },
        "youtube": {
            "lang": "ru",
            "style": "supportive viewer comment, mention content not spam",
            "examples": ["интересное видео, спасибо"],
        },
        "twitter": {
            "lang": "en",
            "style": "short witty, under 120 chars, minimal hashtags",
            "examples": ["this hits different"],
        },
        "linkedin": {
            "lang": "en",
            "style": "professional, no slang, no excessive emoji",
            "examples": ["Great insights, thanks for sharing."],
        },
        "telegram": {
            "lang": "ru",
            "style": "short neutral",
            "examples": ["👍"],
        },
    }

    def _inject_human_typos(self, text: str, platform: str) -> str:
        """أخطاء إملائية خفيفة مقصودة — ليست على LinkedIn."""
        if (platform or "").lower() in {"linkedin", "youtube"}:
            return text
        if not text or len(text) < 8:
            return text
        import random as _r
        if _r.random() > 0.35:
            return text
        chars = list(text)
        # حذف مسافة مزدوجة أو تكرار حرف بسيط
        i = _r.randint(1, max(1, len(chars) - 2))
        if chars[i].isalpha() and _r.random() < 0.5:
            chars.insert(i, chars[i])  # تكرار حرف
        return "".join(chars)

    async def generate_comment_demographic(
        self,
        task_description: str,
        platform: str = "",
        task_screenshot: Optional[str] = None,
        target_screenshot: Optional[str] = None,
        language_hint: str = "ru",
    ) -> str:
        """
        توليد تعليق مطابق لنبرة المنصة + عمر جمهور تقريبي + typo خفيف.
        """
        plat = (platform or "").lower() or "vk"
        tone = self._PLATFORM_TONE.get(plat) or self._PLATFORM_TONE["vk"]
        instruction = (
            "Write ONE authentic social comment.\n"
            f"Platform: {plat}\n"
            f"Tone rules: {tone['style']}\n"
            f"Language preference: {tone.get('lang') or language_hint}\n"
            f"Style examples: {', '.join(tone.get('examples') or [])}\n"
            "No hashtag spam. No links. No quotes around the comment.\n"
            "Return JSON only: {\"comment\": \"...\", \"audience\": \"teen|young_adult|adult\"}\n\n"
            f"Task context:\n{(task_description or '')[:3500]}"
        )
        text = ""
        # reuse vision path from generate_comment style
        try:
            for shot in (target_screenshot, task_screenshot):
                if not shot or not Path(shot).is_file():
                    continue
                encoded = base64.b64encode(Path(shot).read_bytes()).decode("utf-8")
                mime = "image/jpeg" if Path(shot).suffix.lower() in (".jpg", ".jpeg") else "image/png"
                url = (
                    "https://generativelanguage.googleapis.com/v1beta/"
                    f"models/{self.gemini_vision_model}:generateContent?key={self.gemini_api_key}"
                )
                payload = {
                    "contents": [{
                        "parts": [
                            {"text": instruction},
                            {"inline_data": {"mime_type": mime, "data": encoded}},
                        ]
                    }],
                    "generationConfig": {"temperature": 0.55, "maxOutputTokens": 200},
                }
                async def _call():
                    r = await self.http_client.post(url, json=payload)
                    r.raise_for_status()
                    return r.json()["candidates"][0]["content"]["parts"][0]["text"]
                raw = await self._safe_api_call(_call)
                parsed = self._safe_json_parse(raw)
                if isinstance(parsed, dict):
                    text = str(parsed.get("comment") or "").strip()
                if text:
                    break
        except Exception as e:
            logger.warning("demographic vision comment: %s", e)
        if not text:
            try:
                # text-only via groq/gemini
                if self.groq_client_1:
                    result = await self._analyze_with_groq_1(instruction)
                else:
                    result = await self._analyze_with_gemini(instruction)
                if isinstance(result, dict):
                    text = str(result.get("comment") or result.get("summary") or "").strip()
            except Exception as e:
                logger.warning("demographic text comment: %s", e)
        if not text:
            text = (tone.get("examples") or ["Отличный контент!"])[0]
        text = self._inject_human_typos(text, plat)
        return text[:500]

    # ---------- Mouse trajectory + captcha vision ----------
    async def human_mouse_move(self, page, x: float, y: float, steps: int = 0) -> None:
        """
        مسار ماوس منحني شبه بشري (Bezier تقريبي) مع تأخيرات غير منتظمة.
        """
        if page is None:
            return
        import random as _r
        import math as _m
        try:
            # نقطة بداية عشوائية قريبة
            start_x = _r.uniform(50, 400)
            start_y = _r.uniform(80, 300)
            try:
                # لو في موضع حالي غير معروف نبدأ من زاوية
                pass
            except Exception:
                pass
            n = steps or _r.randint(12, 28)
            # نقطة تحكم Bezier
            cx = (start_x + x) / 2 + _r.uniform(-80, 80)
            cy = (start_y + y) / 2 + _r.uniform(-60, 60)
            for i in range(n + 1):
                t = i / n
                # quadratic bezier
                bx = (1 - t) ** 2 * start_x + 2 * (1 - t) * t * cx + t ** 2 * x
                by = (1 - t) ** 2 * start_y + 2 * (1 - t) * t * cy + t ** 2 * y
                # jitter
                bx += _r.uniform(-1.2, 1.2)
                by += _r.uniform(-1.2, 1.2)
                await page.mouse.move(bx, by)
                await asyncio.sleep(_r.uniform(0.005, 0.025))
                # تردد بسيط في المنتصف
                if i == n // 2 and _r.random() < 0.3:
                    await asyncio.sleep(_r.uniform(0.05, 0.15))
            await asyncio.sleep(_r.uniform(0.04, 0.12))
        except Exception as e:
            logger.debug("human_mouse_move: %s", e)
            try:
                await page.mouse.move(x, y)
            except Exception:
                pass

    async def solve_image_captcha_grid(
        self,
        screenshot_path: str,
        instruction: str = "Select all squares with traffic lights",
        grid_size: int = 3,
    ) -> dict:
        """
        تحليل كابتشا شبكية بالرؤية وإرجاع قائمة خلايا للنقر (صف,عمود) 0-based.
        """
        out = {"ok": False, "cells": [], "instruction": instruction}
        if not Path(screenshot_path).is_file():
            out["error"] = "missing_image"
            return out
        try:
            encoded = base64.b64encode(Path(screenshot_path).read_bytes()).decode("utf-8")
            mime = "image/jpeg" if Path(screenshot_path).suffix.lower() in (".jpg", ".jpeg") else "image/png"
            prompt = (
                f"This is a {grid_size}x{grid_size} image CAPTCHA grid.\n"
                f"User instruction: {instruction}\n"
                "Return JSON ONLY: {\"cells\": [[row, col], ...], \"confidence\": 0.0}\n"
                "row and col are 0-indexed from top-left. Include only cells that match."
            )
            url = (
                "https://generativelanguage.googleapis.com/v1beta/"
                f"models/{self.gemini_vision_model}:generateContent?key={self.gemini_api_key}"
            )
            payload = {
                "contents": [{
                    "parts": [
                        {"text": prompt},
                        {"inline_data": {"mime_type": mime, "data": encoded}},
                    ]
                }],
                "generationConfig": {"temperature": 0.0, "maxOutputTokens": 256},
            }
            async def _call():
                r = await self.http_client.post(url, json=payload)
                r.raise_for_status()
                return r.json()["candidates"][0]["content"]["parts"][0]["text"]
            raw = await self._safe_api_call(_call)
            parsed = self._safe_json_parse(raw)
            cells = parsed.get("cells") if isinstance(parsed, dict) else []
            if isinstance(cells, list) and cells:
                out["cells"] = cells
                out["ok"] = True
                out["confidence"] = float(parsed.get("confidence") or 0.5)
            return out
        except Exception as e:
            out["error"] = str(e)[:160]
            return out

    async def click_captcha_cells(
        self,
        page,
        cells: list,
        grid_bbox: dict,
        grid_size: int = 3,
    ) -> dict:
        """
        ينقر خلايا الشبكة.
        grid_bbox: {x, y, width, height} بالبكسل لمربع الكابتشا.
        """
        report = {"ok": False, "clicked": []}
        if page is None or not cells or not grid_bbox:
            return report
        try:
            x0 = float(grid_bbox["x"])
            y0 = float(grid_bbox["y"])
            w = float(grid_bbox["width"])
            h = float(grid_bbox["height"])
            cw, ch = w / grid_size, h / grid_size
            for cell in cells:
                if not isinstance(cell, (list, tuple)) or len(cell) < 2:
                    continue
                row, col = int(cell[0]), int(cell[1])
                cx = x0 + (col + 0.5) * cw
                cy = y0 + (row + 0.5) * ch
                await self.human_mouse_move(page, cx, cy)
                await page.mouse.click(cx, cy)
                report["clicked"].append([row, col])
                await asyncio.sleep(random.uniform(0.15, 0.4))
            report["ok"] = bool(report["clicked"])
            return report
        except Exception as e:
            report["error"] = str(e)[:160]
            return report



    # =====================================================================
    # AI CORE THINKING V4 — تفكير أعمق: CoT audit / تناقض / مرور ثانٍ
    # =====================================================================
    AI_CORE_THINKING_V4 = "ai-core-thinking-v4"

    def _audit_thinking_process(self, result: dict, text: str) -> dict:
        """
        يفحص هل thinking_process غطّى الخطوات الإلزامية ويرمّم النواقص محليًا.
        """
        out = dict(result or {})
        tp = str(out.get("thinking_process") or "")
        urls = out.get("target_urls") or self._extract_urls_from_text(text)
        checks = {
            "has_url_step": bool(re.search(r"1\)|URL_EXTRACT|url", tp, re.I)) or bool(urls),
            "has_platform_step": bool(re.search(r"2\)|DOMAIN_PLATFORM|platform", tp, re.I)),
            "has_action_step": bool(re.search(r"3\)|ACTION_VERBS|action", tp, re.I)),
            "has_reject_step": bool(re.search(r"4\)|REJECT_RULES|reject|bot|homepage", tp, re.I)),
            "has_self_check": bool(re.search(r"5\)|SELF_CHECK|SC:", tp, re.I)),
        }
        missing = [k for k, v in checks.items() if not v]
        # رمّم thinking_process لو ناقص
        if missing or len(tp) < 40:
            rebuilt = []
            rebuilt.append(
                f"1) URL_EXTRACT: {urls if urls else 'NO_URLS_FOUND'}"
            )
            plat = out.get("platform") or "other"
            rebuilt.append(
                f"2) DOMAIN_PLATFORM: platform={plat} from urls/domains"
            )
            act = out.get("action") or "unknown"
            rebuilt.append(
                f"3) ACTION_VERBS: action={act} actions_list={out.get('actions_list')}"
            )
            flags = []
            if out.get("is_telegram_bot"):
                flags.append("telegram_bot")
            if out.get("is_generic_homepage"):
                flags.append("generic_homepage")
            if out.get("reject_reason"):
                flags.append(str(out.get("reject_reason")))
            rebuilt.append(
                f"4) REJECT_RULES: flags={flags or ['none']} executable={out.get('executable')}"
            )
            coherent = self._platform_action_coherent(plat, act)
            rebuilt.append(
                f"5) SELF_CHECK / SC: platform {plat} + action {act} coherent={coherent}"
            )
            if tp:
                rebuilt.append(f"ORIGINAL_MODEL_THOUGHT: {tp[:500]}")
            out["thinking_process"] = " | ".join(rebuilt)
            out["thinking_repaired"] = True
        else:
            out["thinking_repaired"] = False
        out["thinking_audit"] = checks
        out["thinking_missing"] = missing
        return out

    def _platform_action_coherent(self, platform: str, action: str) -> bool:
        p = (platform or "").lower()
        a = (action or "").lower()
        if a in {"unknown", ""}:
            return False
        if p in {"other", ""} and a not in {"unknown"}:
            return False
        bad = {
            ("youtube", "install"),
            ("youtube", "register"),
            ("rutube", "install"),
            ("telegram", "install"),
            ("vk", "install"),
            ("instagram", "install"),
            ("website", "start_bot"),
            ("avito", "start_bot"),
            ("google_maps", "start_bot"),
            ("google_maps", "repost"),
        }
        if (p, a) in bad:
            return False
        # start_bot فقط تيليجرام
        if a == "start_bot" and p != "telegram":
            return False
        return True

    def _detect_contradictions(self, result: dict, text: str) -> list:
        """قائمة تناقضات منطقية بين الحقول والنص/الروابط."""
        issues = []
        out = result or {}
        plat = str(out.get("platform") or "")
        act = str(out.get("action") or "")
        urls = out.get("target_urls") or []
        blob = (text or "").lower()

        if out.get("executable") and out.get("reject_reason"):
            issues.append("executable_true_with_reject_reason")
        if out.get("is_telegram_bot") and out.get("executable"):
            issues.append("telegram_bot_marked_executable")
        if out.get("is_generic_homepage") and out.get("executable"):
            issues.append("homepage_marked_executable")
        if not self._platform_action_coherent(plat, act):
            issues.append(f"incoherent_pair:{plat}+{act}")
        if urls:
            inferred = self._infer_platform_from_url(urls[0])
            if inferred and plat not in {inferred, "website", "other"} and inferred != plat:
                # استثناء twitter/x
                if not ({inferred, plat} <= {"twitter", "x"}):
                    issues.append(f"url_platform_mismatch:{inferred}!={plat}")
            inferred_a = self._infer_action_from_url(urls[0], inferred or plat)
            if inferred_a and act in {"subscribe"} and inferred_a == "like":
                if any(x in (urls[0] or "").lower() for x in ("/reel/", "/p/", "/video/", "wall", "/status/")):
                    issues.append("subscribe_on_content_url_should_be_like")
        if act == "start_bot" and not out.get("is_telegram_bot"):
            issues.append("start_bot_without_bot_flag")
        if plat == "telegram" and any("bot" in u.lower().split("t.me/")[-1][:40] for u in urls if "t.me/" in u.lower()):
            if out.get("executable") and not out.get("is_telegram_bot"):
                issues.append("likely_bot_url_executable")
        # مركّب بدون قائمة
        if out.get("is_compound") and len(out.get("actions_list") or []) < 2:
            issues.append("compound_without_actions_list")
        return issues

    def _repair_contradictions(self, result: dict, issues: list, text: str) -> dict:
        out = dict(result or {})
        if not issues:
            out["contradictions"] = []
            return out
        out["contradictions"] = list(issues)
        urls = out.get("target_urls") or self._extract_urls_from_text(text)

        if "executable_true_with_reject_reason" in issues:
            out["executable"] = False
        if "telegram_bot_marked_executable" in issues or "likely_bot_url_executable" in issues:
            out["is_telegram_bot"] = True
            out["action"] = "start_bot"
            out["platform"] = "telegram"
            out["executable"] = False
            out["reject_reason"] = "telegram_bot_blocked"
        if "homepage_marked_executable" in issues:
            out["executable"] = False
            out["reject_reason"] = "generic_homepage"
        if any(i.startswith("incoherent_pair") for i in issues):
            out["action"] = "unknown"
            out["executable"] = False
            out["reject_reason"] = out.get("reject_reason") or "unknown"
            out["confidence"] = min(float(out.get("confidence") or 0.5), 0.35)
        if any(i.startswith("url_platform_mismatch") for i in issues) and urls:
            inferred = self._infer_platform_from_url(urls[0])
            if inferred:
                out["platform"] = inferred
                out["confidence"] = min(float(out.get("confidence") or 0.7), 0.7)
        if "subscribe_on_content_url_should_be_like" in issues:
            out["action"] = "like"
            alist = out.get("actions_list") or []
            if "like" not in alist:
                alist = ["like"] + [a for a in alist if a != "subscribe"]
            out["actions_list"] = alist or ["like"]
        if "start_bot_without_bot_flag" in issues:
            out["is_telegram_bot"] = True
            out["executable"] = False
            out["reject_reason"] = "telegram_bot_blocked"
        if "compound_without_actions_list" in issues:
            # حاول من النص
            blob = (text or "").lower()
            alist = []
            for a, keys in (
                ("subscribe", ["подпис", "follow", "вступ"]),
                ("like", ["лайк", "like"]),
                ("comment", ["коммент", "comment"]),
                ("repost", ["репост", "repost"]),
            ):
                if any(k in blob for k in keys):
                    alist.append(a)
            out["actions_list"] = alist or [out.get("action") or "unknown"]
            out["is_compound"] = len(out["actions_list"]) > 1
        out["repaired_by"] = "thinking_v4"
        return out

    async def _second_pass_reflect(self, result: dict, text: str) -> dict:
        """
        مرور ثانٍ نصي قصير للمهام المعقدة فقط — يصحح JSON إن لزم.
        """
        meta = self._score_task_complexity(text)
        if meta.get("tier") == "simple" and float((result or {}).get("confidence") or 0) >= 0.8:
            return result
        issues = self._detect_contradictions(result, text)
        # لو مفيش مشاكل كبيرة ومتوسط الثقة عالي — تخطّي API
        hard = [i for i in issues if not i.startswith("compound")]
        if not hard and float((result or {}).get("confidence") or 0) >= 0.75:
            return result

        prompt = (
            "<system_rules>\n"
            "You are a critic. Fix the JSON analysis. Keep canonical fields.\n"
            "Must include thinking_process with 5 steps + SC.\n"
            "</system_rules>\n"
            f"<previous_json>\n{json.dumps(result or {}, ensure_ascii=False)[:3500]}\n</previous_json>\n"
            f"<detected_issues>\n{json.dumps(issues, ensure_ascii=False)}\n</detected_issues>\n"
            f"<task_input>\n{(text or '')[:5000]}\n</task_input>\n"
            "Return corrected JSON only."
        )
        fixed = None
        try:
            if self.groq_client_1:
                fixed = await self._analyze_with_groq_1(prompt)
            elif self.groq_client_2:
                fixed = await self._analyze_with_groq_2(prompt)
            else:
                fixed = await self._analyze_with_gemini(prompt)
        except Exception as e:
            logger.warning("second_pass_reflect API: %s", e)
            fixed = None
        if not isinstance(fixed, dict) or not fixed.get("platform"):
            return result
        fixed["second_pass"] = True
        fixed["router_tier"] = (result or {}).get("router_tier")
        return fixed

    async def _deep_think_pipeline(self, result: dict, text: str) -> dict:
        """
        مسار التفكير العميق بعد أي محرك:
        audit CoT → detect contradictions → local repair → optional second pass → re-normalize/policy
        """
        out = dict(result or {})
        out = self._audit_thinking_process(out, text)
        issues = self._detect_contradictions(out, text)
        out = self._repair_contradictions(out, issues, text)
        # مرور ثانٍ عند الحاجة
        try:
            out2 = await self._second_pass_reflect(out, text)
            if isinstance(out2, dict) and out2 is not out:
                out2 = self._normalize_ai_result(out2, text)
                out2 = self._apply_policy_thinking(out2, text)
                out2 = self._audit_thinking_process(out2, text)
                issues2 = self._detect_contradictions(out2, text)
                out2 = self._repair_contradictions(out2, issues2, text)
                out = out2
        except Exception as e:
            logger.debug("second pass skip: %s", e)
        out["thinking_engine"] = self.AI_CORE_THINKING_V4
        # خفض ثقة لو لسه فيه تناقضات
        left = self._detect_contradictions(out, text)
        out["contradictions_final"] = left
        if left:
            out["confidence"] = min(float(out.get("confidence") or 0.5), 0.55)
            if any(
                x in left
                for x in (
                    "telegram_bot_marked_executable",
                    "homepage_marked_executable",
                    "likely_bot_url_executable",
                )
            ):
                out["executable"] = False
        # Multi-Agent Debate عند الثقة الواطية أو التعقيد العالي
        try:
            conf = float(out.get("confidence") or 0)
            tier = self._score_task_complexity(text).get("tier")
            if conf < 0.60 or tier == "complex":
                debated = await self._multi_agent_debate(text, out)
                if isinstance(debated, dict) and debated.get("platform"):
                    debated = self._normalize_ai_result(debated, text)
                    debated = self._apply_policy_thinking(debated, text)
                    debated["debate_applied"] = True
                    out = debated
        except Exception as _deb_e:
            logger.warning("debate skip: %s", _deb_e)
        return out



    # =====================================================================
    # AI CORE V5 — Active RAG | Vision-to-Action | Multi-Agent Debate |
    # Generative Biometrics | Auto-Prompt Optimization | Video Tokens
    # =====================================================================
    AI_CORE_V5 = "ai-core-v5"

    _VECTOR_DIR = Path("data/vector_memory")
    _VECTOR_META = Path("data/vector_memory/meta.json")
    _PROMPT_BANK = Path("data/ai_prompt_bank.json")

    # ---------- 1) Active RAG / Vector Memory ----------
    def _simple_embed(self, text: str, dim: int = 128) -> list:
        """
        Embedding محلي خفيف بدون اعتماد إلزامي على مكتبات.
        يستخدم hashing n-grams — كافٍ للتشابه التقريبي + FAISS اختياري.
        """
        import math
        vec = [0.0] * dim
        tokens = re.findall(r"[a-zA-Zа-яА-Я0-9_]{2,}", (text or "").lower())
        if not tokens:
            return vec
        for i, tok in enumerate(tokens):
            h = hash(tok) % dim
            vec[h] += 1.0
            h2 = hash(tok[::-1]) % dim
            vec[h2] += 0.5
            if i + 1 < len(tokens):
                big = tok + "_" + tokens[i + 1]
                vec[hash(big) % dim] += 1.2
        # L2 normalize
        norm = math.sqrt(sum(v * v for v in vec)) or 1.0
        return [v / norm for v in vec]

    def _cosine(self, a: list, b: list) -> float:
        return sum(x * y for x, y in zip(a, b))

    def _vector_store_load(self) -> dict:
        meta = self._load_json_file(self._VECTOR_META, {"items": []})
        if not isinstance(meta, dict):
            meta = {"items": []}
        if "items" not in meta:
            meta["items"] = []
        return meta

    def vector_memory_add(
        self,
        task_text: str,
        *,
        reject_reason: str = "",
        correct_json: dict = None,
        lesson: str = "",
        success: bool = False,
    ) -> dict:
        """
        يخزن مهمة (فشل/نجاح) كـ embedding + metadata للتعلم اللاحق.
        """
        meta = self._vector_store_load()
        item = {
            "id": abs(hash((task_text or "")[:200] + str(reject_reason))) % (10**12),
            "text": (task_text or "")[:2000],
            "reject_reason": reject_reason or "",
            "lesson": lesson or "",
            "success": bool(success),
            "correct_json": correct_json or {},
            "embedding": self._simple_embed(task_text or ""),
        }
        items = meta.get("items") or []
        items.append(item)
        meta["items"] = items[-500:]  # سقف
        self._VECTOR_DIR.mkdir(parents=True, exist_ok=True)
        self._save_json_file(self._VECTOR_META, meta)
        # FAISS اختياري
        try:
            self._faiss_rebuild(meta["items"])
        except Exception as e:
            logger.debug("faiss rebuild: %s", e)
        return {"ok": True, "stored": len(meta["items"])}

    def _faiss_rebuild(self, items: list) -> None:
        try:
            import numpy as np
            import faiss  # type: ignore
        except Exception:
            return
        if not items:
            return
        mat = np.array([it["embedding"] for it in items], dtype="float32")
        index = faiss.IndexFlatIP(mat.shape[1])
        index.add(mat)
        self._VECTOR_DIR.mkdir(parents=True, exist_ok=True)
        faiss.write_index(index, str(self._VECTOR_DIR / "index.faiss"))
        self._save_json_file(self._VECTOR_DIR / "faiss_ids.json", [it["id"] for it in items])

    def _vector_rag_query(self, text: str, k: int = 2) -> list:
        """
        أقرب مهام مشابهة → تُحقن كـ few-shot / long_term_memory.
        """
        meta = self._vector_store_load()
        items = meta.get("items") or []
        if not items:
            return []
        q = self._simple_embed(text or "")
        scored = []
        for it in items:
            emb = it.get("embedding") or self._simple_embed(it.get("text") or "")
            scored.append((self._cosine(q, emb), it))
        scored.sort(key=lambda x: -x[0])
        out = []
        for score, it in scored[:k]:
            if score < 0.15:
                continue
            correct = it.get("correct_json") or {}
            # صياغة few-shot
            out.append({
                "input": it.get("text") or "",
                "output": correct if correct else {
                    "thinking_process": f"Past case score={score:.2f} reason={it.get('reject_reason')}",
                    "executable": bool(it.get("success")),
                    "reject_reason": it.get("reject_reason") or None,
                    "summary": it.get("lesson") or "",
                },
                "rag_score": round(float(score), 4),
                "source": "vector_memory",
            })
        return out

    async def remember_rejection_vector(
        self, task_text: str, original_json: dict, reject_reason: str, screenshot_path: str = None
    ) -> dict:
        """دمج reflect_on_rejection + تخزين vector."""
        lesson = await self.reflect_on_rejection(
            task_text, original_json, reject_reason, screenshot_path
        )
        self.vector_memory_add(
            task_text,
            reject_reason=reject_reason,
            correct_json={
                "executable": False,
                "reject_reason": reject_reason,
                "platform": (original_json or {}).get("platform"),
                "action": (original_json or {}).get("action"),
                "thinking_process": lesson.get("analysis") or "",
            },
            lesson=lesson.get("rule") or lesson.get("analysis") or "",
            success=False,
        )
        return lesson

    # ---------- 2) Vision-to-Action (Bounding Box) ----------
    async def locate_ui_bbox(
        self,
        screenshot_path: str,
        element_description: str,
        page_width: int = 1280,
        page_height: int = 720,
    ) -> dict:
        """
        يرجع صندوق العنصر + مركز النقر.
        {"ok", "x1","y1","x2","y2", "cx","cy", "confidence"}
        إحداثيات مطلقة بالبكسل حسب page_width/height.
        """
        out = {"ok": False, "cx": None, "cy": None}
        if not Path(screenshot_path).is_file():
            out["error"] = "missing_image"
            return out
        try:
            encoded = base64.b64encode(Path(screenshot_path).read_bytes()).decode("utf-8")
            mime = "image/jpeg" if Path(screenshot_path).suffix.lower() in (".jpg", ".jpeg") else "image/png"
            prompt = (
                "You are a computer-use visual grounding model.\n"
                f"Find this UI element: {element_description}\n"
                "Return JSON ONLY with normalized bbox 0..1:\n"
                '{"found": true, "x1": 0.0, "y1": 0.0, "x2": 0.0, "y2": 0.0, "confidence": 0.0, "label": "..."}\n'
                "If not found: {\"found\": false}"
            )
            url = (
                "https://generativelanguage.googleapis.com/v1beta/"
                f"models/{self.gemini_vision_model}:generateContent?key={self.gemini_api_key}"
            )
            payload = {
                "contents": [{
                    "parts": [
                        {"text": prompt},
                        {"inline_data": {"mime_type": mime, "data": encoded}},
                    ]
                }],
                "generationConfig": {"temperature": 0.0, "maxOutputTokens": 256},
            }

            async def _call():
                r = await self.http_client.post(url, json=payload)
                r.raise_for_status()
                return r.json()["candidates"][0]["content"]["parts"][0]["text"]

            raw = await self._safe_api_call(_call)
            parsed = self._safe_json_parse(raw)
            if not isinstance(parsed, dict) or not parsed.get("found"):
                out["raw"] = str(raw)[:180]
                return out
            x1 = min(0.99, max(0.0, float(parsed["x1"])))
            y1 = min(0.99, max(0.0, float(parsed["y1"])))
            x2 = min(1.0, max(0.0, float(parsed["x2"])))
            y2 = min(1.0, max(0.0, float(parsed["y2"])))
            if x2 < x1:
                x1, x2 = x2, x1
            if y2 < y1:
                y1, y2 = y2, y1
            out.update({
                "ok": True,
                "x1": int(x1 * page_width),
                "y1": int(y1 * page_height),
                "x2": int(x2 * page_width),
                "y2": int(y2 * page_height),
                "cx": int(((x1 + x2) / 2) * page_width),
                "cy": int(((y1 + y2) / 2) * page_height),
                "confidence": float(parsed.get("confidence") or 0.5),
                "label": parsed.get("label") or element_description,
            })
            return out
        except Exception as e:
            out["error"] = str(e)[:160]
            return out

    async def click_by_vision_bbox(self, page, element_description: str) -> dict:
        """نقر DOM-less بالكامل عبر Bounding Box + مسار بشري توليدي."""
        report = {"ok": False, "status": "pending"}
        if page is None:
            report["status"] = "no_page"
            return report
        try:
            Path("data/proofs").mkdir(parents=True, exist_ok=True)
            import time as _time
            path = f"data/proofs/bbox_{int(_time.time()*1000)}.jpg"
            await page.screenshot(path=path, type="jpeg", quality=85)
            vp = page.viewport_size or {"width": 1280, "height": 720}
            box = await self.locate_ui_bbox(
                path,
                element_description,
                page_width=int(vp.get("width") or 1280),
                page_height=int(vp.get("height") or 720),
            )
            report["bbox"] = box
            if not box.get("ok"):
                # fallback نقطة مركزية من locate_ui_element القديم
                if hasattr(self, "locate_ui_element"):
                    loc = await self.locate_ui_element(
                        path, element_description,
                        page_width=int(vp.get("width") or 1280),
                        page_height=int(vp.get("height") or 720),
                    )
                    report["point_fallback"] = loc
                    if loc.get("ok"):
                        await self.human_mouse_move_generative(page, loc["px"], loc["py"])
                        await page.mouse.click(loc["px"], loc["py"])
                        report["ok"] = True
                        report["status"] = "clicked_point"
                        return report
                report["status"] = "not_found"
                return report
            cx, cy = int(box["cx"]), int(box["cy"])
            await self.human_mouse_move_generative(page, cx, cy, overshoot=True)
            await page.mouse.click(cx, cy)
            report["ok"] = True
            report["status"] = "clicked_bbox"
            report["x"], report["y"] = cx, cy
            return report
        except Exception as e:
            report["status"] = f"error:{type(e).__name__}"
            report["error"] = str(e)[:160]
            return report

    # ---------- 3) Multi-Agent Debate ----------
    async def _multi_agent_debate(self, text: str, prior: dict = None) -> dict:
        """
        الوكيل1 Groq · الوكيل2 Mistral · القاضي DeepSeek/Gemini عند الاختلاف.
        """
        prompt = self._build_fewshot_prompt(text) if hasattr(self, "_build_fewshot_prompt") else text
        agent1 = agent2 = None
        try:
            if self.groq_client_1:
                agent1 = await self._analyze_with_groq_1(prompt)
        except Exception as e:
            logger.warning("debate agent1: %s", e)
        try:
            agent2 = await self._analyze_with_mistral(prompt)
        except Exception as e:
            logger.warning("debate agent2: %s", e)

        if not agent1 and not agent2:
            return prior or {}
        if agent1 and not agent2:
            agent1["debate_role"] = "agent1_only"
            return agent1
        if agent2 and not agent1:
            agent2["debate_role"] = "agent2_only"
            return agent2

        p1 = str((agent1 or {}).get("platform"))
        a1 = str((agent1 or {}).get("action"))
        e1 = bool((agent1 or {}).get("executable", True))
        p2 = str((agent2 or {}).get("platform"))
        a2 = str((agent2 or {}).get("action"))
        e2 = bool((agent2 or {}).get("executable", True))

        agree = (p1 == p2 and a1 == a2 and e1 == e2)
        if agree:
            agent1["debate_role"] = "agents_agree"
            agent1["confidence"] = max(float(agent1.get("confidence") or 0.5), 0.8)
            return agent1

        judge_prompt = (
            "<system_rules>You are the JUDGE. Two agents disagree. Pick the correct JSON analysis.\n"
            "Obey URL priority, bot traps, homepage traps. JSON only.</system_rules>\n"
            f"<agent1>{json.dumps(agent1, ensure_ascii=False)[:2500]}</agent1>\n"
            f"<agent2>{json.dumps(agent2, ensure_ascii=False)[:2500]}</agent2>\n"
            f"<task_input>{(text or '')[:5000]}</task_input>\n"
            f"<prior>{json.dumps(prior or {}, ensure_ascii=False)[:1500]}</prior>"
        )
        judge = None
        try:
            if self.deepseek_api_key and self.deepseek_api_key != "YOUR_DEEPSEEK_API_KEY_HERE":
                judge = await self._analyze_with_deepseek(judge_prompt)
            else:
                judge = await self._analyze_with_gemini(judge_prompt)
        except Exception as e:
            logger.warning("judge failed: %s", e)
        if isinstance(judge, dict) and judge.get("platform"):
            judge["debate_role"] = "judge_final"
            judge["agent1"] = {"platform": p1, "action": a1, "executable": e1}
            judge["agent2"] = {"platform": p2, "action": a2, "executable": e2}
            return judge
        # fallback: safer of two (non-executable wins if conflict on safety)
        if e1 is False or e2 is False:
            safer = agent1 if e1 is False else agent2
            safer["debate_role"] = "safer_fallback"
            return safer
        agent1["debate_role"] = "agent1_fallback"
        return agent1

    # ---------- 4) Generative Human Biometrics ----------
    async def human_mouse_move_generative(
        self, page, x: float, y: float, *, overshoot: bool = True, reading_ms: int = 0
    ) -> None:
        """
        Bezier متقدم + overshoot + micro-delays + تردد قبل النقر.
        """
        if page is None:
            return
        import math as _m
        try:
            sx = random.uniform(40, 380)
            sy = random.uniform(60, 320)
            # نقطتا تحكم
            c1x = sx + (x - sx) * random.uniform(0.2, 0.45) + random.uniform(-100, 100)
            c1y = sy + (y - sy) * random.uniform(0.1, 0.4) + random.uniform(-80, 80)
            c2x = sx + (x - sx) * random.uniform(0.55, 0.85) + random.uniform(-60, 60)
            c2y = sy + (y - sy) * random.uniform(0.5, 0.9) + random.uniform(-60, 60)
            # overshoot target
            ox, oy = x, y
            if overshoot and random.random() < 0.7:
                ox = x + random.uniform(4, 18) * random.choice([-1, 1])
                oy = y + random.uniform(3, 14) * random.choice([-1, 1])
            n = random.randint(18, 36)
            for i in range(n + 1):
                tpar = i / n
                # cubic bezier
                bx = (
                    (1 - tpar) ** 3 * sx
                    + 3 * (1 - tpar) ** 2 * tpar * c1x
                    + 3 * (1 - tpar) * tpar ** 2 * c2x
                    + tpar ** 3 * ox
                )
                by = (
                    (1 - tpar) ** 3 * sy
                    + 3 * (1 - tpar) ** 2 * tpar * c1y
                    + 3 * (1 - tpar) * tpar ** 2 * c2y
                    + tpar ** 3 * oy
                )
                bx += random.uniform(-1.5, 1.5)
                by += random.uniform(-1.5, 1.5)
                await page.mouse.move(bx, by)
                await asyncio.sleep(random.uniform(0.004, 0.022))
                if i in {n // 3, (2 * n) // 3} and random.random() < 0.35:
                    await asyncio.sleep(random.uniform(0.04, 0.12))
            if overshoot and (ox != x or oy != y):
                # رجوع للهدف
                await page.mouse.move(x, y, steps=random.randint(3, 7))
            # تفكير قبل النقر
            think = reading_ms / 1000.0 if reading_ms else random.uniform(0.08, 0.28)
            await asyncio.sleep(think)
        except Exception as e:
            logger.debug("gen mouse: %s", e)
            try:
                await page.mouse.move(x, y)
            except Exception:
                pass

    async def human_scroll_for_reading(self, page, text: str = "", total_px: int = 900) -> None:
        """تمرير بسرعة قراءة بشرية حسب طول النص."""
        if page is None:
            return
        chars = max(len(text or ""), 80)
        # ~15-25 حرف/ثانية قراءة سطحية
        seconds = min(12.0, max(1.2, chars / random.uniform(18, 28)))
        steps = random.randint(6, 14)
        chunk = total_px / steps
        delay = seconds / steps
        for _ in range(steps):
            await page.mouse.wheel(0, chunk * random.uniform(0.7, 1.3))
            await asyncio.sleep(delay * random.uniform(0.7, 1.4))

    # ---------- 5) Auto-Prompt Optimization ----------
    async def nightly_prompt_optimize(self, max_lessons: int = 20) -> dict:
        """
        تحليل رفض اليوم → توليد system_rules/edge_cases أحدث.
        يُستدعى يدويًا أو من cron يومي.
        """
        report = {"ok": False, "rules_added": 0}
        logs = self._load_json_file(self._REJECT_LOG_PATH, [])
        if not isinstance(logs, list) or not logs:
            report["status"] = "no_lessons"
            return report
        sample = logs[-max_lessons:]
        prompt = (
            "You are a prompt engineer for a UNU task classifier.\n"
            "Given today's failures, propose STRICT new rules and edge cases.\n"
            "Return JSON only:\n"
            '{"new_rules": ["..."], "new_edge_cases": ["..."], "notes": "..."}\n\n'
            f"FAILURES:\n{json.dumps(sample, ensure_ascii=False)[:7000]}"
        )
        try:
            parsed = await self._analyze_with_gemini(prompt)
            if not isinstance(parsed, dict):
                parsed = self._safe_json_parse(str(parsed))
            rules = parsed.get("new_rules") if isinstance(parsed, dict) else []
            edges = parsed.get("new_edge_cases") if isinstance(parsed, dict) else []
            mem = self._load_json_file(self._MEMORY_PATH, {"rules": []})
            existing = mem.get("rules") if isinstance(mem, dict) else []
            if not isinstance(existing, list):
                existing = []
            added = 0
            for r in rules or []:
                r = str(r).strip()
                if r and r not in existing:
                    existing.append(r)
                    added += 1
            for e in edges or []:
                e = str(e).strip()
                if e and e not in existing:
                    existing.append("EDGE: " + e)
                    added += 1
            self._save_json_file(self._MEMORY_PATH, {"rules": existing[-80:]})
            bank = self._load_json_file(self._PROMPT_BANK, {"versions": []})
            versions = bank.get("versions") if isinstance(bank, dict) else []
            if not isinstance(versions, list):
                versions = []
            versions.append({
                "ts": int(__import__("time").time()),
                "added": added,
                "notes": (parsed or {}).get("notes") if isinstance(parsed, dict) else "",
                "sample_size": len(sample),
            })
            self._save_json_file(self._PROMPT_BANK, {"versions": versions[-60:]})
            report["ok"] = True
            report["rules_added"] = added
            report["status"] = "optimized"
            return report
        except Exception as e:
            report["error"] = str(e)[:160]
            return report

    # ---------- 6) Video / Audio token helper ----------
    async def analyze_video_frame_comment(
        self,
        frame_path: str,
        task_description: str = "",
        platform: str = "tiktok",
    ) -> dict:
        """
        من لقطة فيديو: وصف محتوى + اقتراح تعليق غير سبام يقتبس المشهد.
        (تحليل فريم؛ مسار كامل للفيديو يحتاج API فيديو منفصل إن توفر)
        """
        out = {"ok": False, "caption": "", "comment": ""}
        if not frame_path or not Path(frame_path).is_file():
            out["error"] = "missing_frame"
            return out
        try:
            encoded = base64.b64encode(Path(frame_path).read_bytes()).decode("utf-8")
            mime = "image/jpeg" if Path(frame_path).suffix.lower() in (".jpg", ".jpeg") else "image/png"
            prompt = (
                "Describe what is visible in this video frame in one short sentence.\n"
                "Then propose ONE authentic non-spam comment that references the scene.\n"
                f"Platform={platform}. Task: {(task_description or '')[:800]}\n"
                'Return JSON: {"caption": "...", "comment": "...", "nsfw": false}'
            )
            url = (
                "https://generativelanguage.googleapis.com/v1beta/"
                f"models/{self.gemini_vision_model}:generateContent?key={self.gemini_api_key}"
            )
            payload = {
                "contents": [{
                    "parts": [
                        {"text": prompt},
                        {"inline_data": {"mime_type": mime, "data": encoded}},
                    ]
                }],
                "generationConfig": {"temperature": 0.4, "maxOutputTokens": 300},
            }

            async def _call():
                r = await self.http_client.post(url, json=payload)
                r.raise_for_status()
                return r.json()["candidates"][0]["content"]["parts"][0]["text"]

            raw = await self._safe_api_call(_call)
            parsed = self._safe_json_parse(raw)
            if isinstance(parsed, dict):
                out["caption"] = str(parsed.get("caption") or "")
                out["comment"] = str(parsed.get("comment") or "")
                out["ok"] = bool(out["comment"] or out["caption"])
            return out
        except Exception as e:
            out["error"] = str(e)[:160]
            return out

    async def extract_video_frame(self, page, path: str = None) -> str:
        """يلتقط فريم من صفحة فيديو كسكرين للتحليل."""
        Path("data/proofs").mkdir(parents=True, exist_ok=True)
        import time as _time
        path = path or f"data/proofs/vidframe_{int(_time.time()*1000)}.jpg"
        if page is None:
            return ""
        try:
            await page.screenshot(path=path, type="jpeg", quality=85)
            return path
        except Exception:
            return ""



    # =====================================================================
    # AI CORE V6 — Honeypot Radar | Action Chaining | Persona Comments |
    # AXTree + Vision Grounding
    # =====================================================================
    AI_CORE_V6 = "ai-core-v6"

    _HONEYPOT_MARKERS = (
        "ignore the first link",
        "تجاهل الرابط الأول",
        "تجاهل الرابط الاول",
        "проигнорируйте первую",
        "игнорируйте первую ссылку",
        "prove you are not a robot",
        "لست روبوت",
        "انست روبوت",
        "not a robot",
        "не робот",
        "я не робот",
        "click here to verify",
        "اثبت أنك",
        "اثبت انك",
        "human verification",
        "только для людей",
        "для проверки ботов",
        "bot test",
        "if you are a bot",
        "إذا كنت بوت",
        "لو انت بوت",
        "honeypot",
        "hidden instruction",
        "تعليمات مخفية",
    )

    def _detect_honeypot(self, text: str, urls: list = None) -> bool:
        blob = (text or "").lower()
        if any(m in blob for m in self._HONEYPOT_MARKERS):
            return True
        # تعارض: أكتر من رابط مع جملة تجاهل الأول
        if urls and len(urls) >= 2 and any(
            x in blob for x in ("ignore", "تجاهل", "игнорир", "not the first", "не первую")
        ):
            return True
        return False

    def _default_execution_steps(self, result: dict) -> list:
        """يبني سيناريو Playwright منطقي من action/actions_list."""
        acts = result.get("actions_list") if isinstance(result.get("actions_list"), list) else []
        primary = str(result.get("action") or "unknown").lower()
        if not acts:
            acts = [primary] if primary != "unknown" else ["goto"]
        steps = [{"step": 1, "action": "goto"}]
        n = 2
        steps.append({"step": n, "action": "dismiss_popup"})
        n += 1
        for a in acts:
            a = str(a).lower()
            if a == "view":
                steps.append({"step": n, "action": "view", "duration_seconds": 15})
                n += 1
                steps.append({"step": n, "action": "scroll_to_bottom"})
                n += 1
            elif a == "comment":
                steps.append({"step": n, "action": "type_comment"})
                n += 1
                steps.append({"step": n, "action": "comment"})
                n += 1
            elif a in {"subscribe", "like", "repost", "share", "review", "register"}:
                steps.append({"step": n, "action": a})
                n += 1
            else:
                steps.append({"step": n, "action": a or "wait"})
                n += 1
        steps.append({"step": n, "action": "verify"})
        n += 1
        steps.append({"step": n, "action": "screenshot"})
        return steps

    async def generate_comment_persona(
        self,
        task_description: str,
        platform: str = "",
        task_screenshot: Optional[str] = None,
        target_screenshot: Optional[str] = None,
    ) -> str:
        """
        Persona-Driven Commenting: لغة دارجة + عيوب بشرية + بدون هاشتاج.
        """
        plat = (platform or "vk").lower()
        instruction = (
            "You are a normal internet user, NOT an AI.\n"
            "Write ONE very short comment matching the task content.\n"
            "Rules:\n"
            "- Casual slang for the platform language (Russian for VK/TikTok/IG if task is RU).\n"
            "- Imperfect punctuation is OK.\n"
            "- Intentionally include ONE minor typo or human abbreviation.\n"
            "- NO hashtags. NO formal corporate tone. NO links.\n"
            "- Max 12 words.\n"
            f"Platform: {plat}\n"
            f"Task:\n{(task_description or '')[:2500]}\n"
            'Return JSON only: {"comment": "..."}\n'
        )
        text = ""
        try:
            for shot in (target_screenshot, task_screenshot):
                if not shot or not Path(shot).is_file():
                    continue
                encoded = base64.b64encode(Path(shot).read_bytes()).decode("utf-8")
                mime = "image/jpeg" if Path(shot).suffix.lower() in (".jpg", ".jpeg") else "image/png"
                url = (
                    "https://generativelanguage.googleapis.com/v1beta/"
                    f"models/{self.gemini_vision_model}:generateContent?key={self.gemini_api_key}"
                )
                payload = {
                    "contents": [{
                        "parts": [
                            {"text": instruction},
                            {"inline_data": {"mime_type": mime, "data": encoded}},
                        ]
                    }],
                    "generationConfig": {"temperature": 0.7, "maxOutputTokens": 120},
                }

                async def _call():
                    r = await self.http_client.post(url, json=payload)
                    r.raise_for_status()
                    return r.json()["candidates"][0]["content"]["parts"][0]["text"]

                raw = await self._safe_api_call(_call)
                parsed = self._safe_json_parse(raw)
                if isinstance(parsed, dict):
                    text = str(parsed.get("comment") or "").strip()
                if text:
                    break
        except Exception as e:
            logger.warning("persona comment vision: %s", e)
        if not text:
            try:
                if self.groq_client_1:
                    parsed = await self._analyze_with_groq_1(instruction)
                else:
                    parsed = await self._analyze_with_gemini(instruction)
                if isinstance(parsed, dict):
                    text = str(parsed.get("comment") or "").strip()
            except Exception:
                text = ""
        if not text:
            text = "норм 👍"
        # فرض عيب بشري بسيط لو الرد نظيف زيادة
        if hasattr(self, "_inject_human_typos"):
            text = self._inject_human_typos(text, plat)
        text = re.sub(r"[#＠@]\w+", "", text).strip()
        return text[:200]

    async def get_page_ax_tree(self, page, interesting_only: bool = True) -> str:
        """يسحب Accessibility Tree مبسّطة من Playwright."""
        if page is None:
            return ""
        try:
            # Playwright accessibility snapshot
            snap = await page.accessibility.snapshot()
            if not snap:
                return ""

            lines = []

            def walk(node, depth=0):
                if not node or depth > 12:
                    return
                role = node.get("role") or ""
                name = (node.get("name") or "").strip()
                if interesting_only:
                    if role in {
                        "button", "link", "textbox", "searchbox", "checkbox",
                        "menuitem", "tab", "switch",
                    } or name:
                        if name or role in {"button", "link", "textbox"}:
                            lines.append(f"{'  '*depth}{role}: {name[:80]}")
                else:
                    lines.append(f"{'  '*depth}{role}: {name[:80]}")
                for ch in node.get("children") or []:
                    walk(ch, depth + 1)

            walk(snap)
            text = "\n".join(lines[:120])
            return text
        except Exception as e:
            logger.debug("ax_tree: %s", e)
            # fallback: aria labels from DOM
            try:
                return await page.evaluate(
                    """() => {
                        const nodes = [...document.querySelectorAll('button, a, [role="button"], input, [aria-label]')];
                        return nodes.slice(0, 80).map(el => {
                            const role = el.getAttribute('role') || el.tagName.toLowerCase();
                            const name = el.getAttribute('aria-label') || el.innerText || el.getAttribute('placeholder') || '';
                            return role + ': ' + String(name).trim().slice(0, 80);
                        }).join('\\n');
                    }"""
                )
            except Exception:
                return ""

    async def resolve_click_target_ax_vision(
        self,
        page,
        action: str = "subscribe",
        screenshot_path: str = None,
    ) -> dict:
        """
        AXTree + Vision: يحدد aria-label و/أو إحداثيات النقر دون CSS selectors.
        """
        report = {"ok": False, "status": "pending", "aria_label": "", "x": None, "y": None}
        if page is None:
            report["status"] = "no_page"
            return report
        try:
            ax = await self.get_page_ax_tree(page)
            report["ax_preview"] = (ax or "")[:1500]
            if not screenshot_path:
                Path("data/proofs").mkdir(parents=True, exist_ok=True)
                import time as _time
                screenshot_path = f"data/proofs/axvis_{int(_time.time()*1000)}.jpg"
                await page.screenshot(path=screenshot_path, type="jpeg", quality=85)

            labels_hint = {
                "subscribe": "Follow / Subscribe / Подписаться / Join / Дружить",
                "like": "Like / Нравится / ❤ / Класс",
                "comment": "Comment / Комментарий / Write a comment",
                "repost": "Share / Repost / Поделиться / Retweet",
            }.get((action or "").lower(), action)

            encoded = base64.b64encode(Path(screenshot_path).read_bytes()).decode("utf-8")
            mime = "image/jpeg" if Path(screenshot_path).suffix.lower() in (".jpg", ".jpeg") else "image/png"
            prompt = (
                "You see a browser screenshot AND an accessibility tree (AXTree).\n"
                f"Goal action: {action} ({labels_hint})\n"
                "Pick the exact control to click.\n"
                "Return JSON ONLY:\n"
                '{"found": true, "aria_label": "...", "ax_role": "button", '
                '"x_norm": 0.0, "y_norm": 0.0, "confidence": 0.0, "reason": "..."}\n'
                "Prefer matching an AXTree name/aria_label that is visible in the image.\n"
                "Coordinates are normalized 0..1 from top-left.\n\n"
                f"<ax_tree>\n{(ax or '')[:3500]}\n</ax_tree>"
            )
            url = (
                "https://generativelanguage.googleapis.com/v1beta/"
                f"models/{self.gemini_vision_model}:generateContent?key={self.gemini_api_key}"
            )
            payload = {
                "contents": [{
                    "parts": [
                        {"text": prompt},
                        {"inline_data": {"mime_type": mime, "data": encoded}},
                    ]
                }],
                "generationConfig": {"temperature": 0.0, "maxOutputTokens": 300},
            }

            async def _call():
                r = await self.http_client.post(url, json=payload)
                r.raise_for_status()
                return r.json()["candidates"][0]["content"]["parts"][0]["text"]

            raw = await self._safe_api_call(_call)
            parsed = self._safe_json_parse(raw)
            if not isinstance(parsed, dict) or not parsed.get("found"):
                report["status"] = "not_found"
                report["raw"] = str(raw)[:200]
                return report

            aria = str(parsed.get("aria_label") or "").strip()
            report["aria_label"] = aria
            report["ax_role"] = parsed.get("ax_role")
            report["reason"] = parsed.get("reason")
            report["confidence"] = float(parsed.get("confidence") or 0.5)

            # 1) جرّب النقر بالاسم من AX/DOM
            if aria:
                try:
                    loc = page.get_by_role("button", name=re.compile(re.escape(aria[:40]), re.I))
                    if await loc.count() == 0:
                        loc = page.get_by_text(re.compile(re.escape(aria[:40]), re.I))
                    if await loc.count():
                        await loc.first.click(timeout=3000)
                        report["ok"] = True
                        report["status"] = "clicked_by_aria"
                        return report
                except Exception:
                    pass

            # 2) إحداثيات
            vp = page.viewport_size or {"width": 1280, "height": 720}
            xn = float(parsed.get("x_norm") or 0.5)
            yn = float(parsed.get("y_norm") or 0.5)
            xn = min(0.99, max(0.01, xn))
            yn = min(0.99, max(0.01, yn))
            x = int(xn * int(vp.get("width") or 1280))
            y = int(yn * int(vp.get("height") or 720))
            report["x"], report["y"] = x, y
            if hasattr(self, "human_mouse_move_generative"):
                await self.human_mouse_move_generative(page, x, y, overshoot=True)
            else:
                await page.mouse.move(x, y)
            await page.mouse.click(x, y)
            report["ok"] = True
            report["status"] = "clicked_by_coords"
            return report
        except Exception as e:
            report["status"] = f"error:{type(e).__name__}"
            report["error"] = str(e)[:160]
            return report



    # =====================================================================
    # AI CORE V7 — Zero-Shot Nav | RL Feedback | OS-Level | Swarm GraphRAG |
    # Temporal Video Verification
    # =====================================================================
    AI_CORE_V7 = "ai-core-v7"

    _RL_PATH = Path("data/ai_rl_state.json")
    _GRAPH_PATH = Path("data/swarm_knowledge_graph.json")
    _REWARD_LOG = Path("data/ai_reward_log.json")

    # ---------- 1) Zero-Shot Web Navigation ----------
    async def zero_shot_plan(
        self,
        page,
        task_text: str,
        screenshot_path: str = None,
    ) -> dict:
        """
        يخطط تنفيذًا لأي موقع غير معروف مسبقًا من DOM/AX + صورة + نص المهمة.
        لا يعتمد على قائمة منصات ثابتة.
        """
        plan = {
            "ok": False,
            "platform": "website",
            "execution_steps": [],
            "click_targets": [],
            "status": "pending",
        }
        if page is None:
            plan["status"] = "no_page"
            return plan
        try:
            url = page.url or ""
            title = ""
            try:
                title = await page.title()
            except Exception:
                pass
            ax = ""
            if hasattr(self, "get_page_ax_tree"):
                ax = await self.get_page_ax_tree(page)
            dom_summary = ""
            try:
                dom_summary = await page.evaluate(
                    """() => {
                        const btns = [...document.querySelectorAll('button, a, [role="button"], input[type="submit"]')]
                            .slice(0, 40)
                            .map(el => ({
                                tag: el.tagName.toLowerCase(),
                                text: (el.innerText || el.value || el.getAttribute('aria-label') || '').trim().slice(0, 60),
                                href: (el.getAttribute('href') || '').slice(0, 80),
                            }));
                        return JSON.stringify(btns);
                    }"""
                )
            except Exception:
                dom_summary = "[]"
            if not screenshot_path:
                Path("data/proofs").mkdir(parents=True, exist_ok=True)
                import time as _time
                screenshot_path = f"data/proofs/zshot_{int(_time.time()*1000)}.jpg"
                await page.screenshot(path=screenshot_path, type="jpeg", quality=80)

            prompt = (
                "<system_rules>\n"
                "You are a zero-shot web agent. The site may be ANY language/platform.\n"
                "Plan concrete UI steps to fulfill the task. Prefer visible buttons.\n"
                "Return JSON only:\n"
                "{\n"
                '  "thinking_process": "...",\n'
                '  "inferred_platform": "website|other|...",\n'
                '  "goal_action": "subscribe|like|register|view|unknown",\n'
                '  "execution_steps": [{"step":1,"action":"goto|click|type|wait|scroll|verify","target_text":"...","duration_seconds":0}],\n'
                '  "primary_click_text": "exact visible label to click",\n'
                '  "executable": true,\n'
                '  "reject_reason": null,\n'
                '  "confidence": 0.0\n'
                "}\n"
                "If the page is a captcha wall or login wall only → executable=false.\n"
                "</system_rules>\n"
                f"<page_url>{url}</page_url>\n"
                f"<page_title>{title}</page_title>\n"
                f"<ax_tree>\n{(ax or '')[:2500]}\n</ax_tree>\n"
                f"<dom_buttons>{(dom_summary or '')[:2500]}</dom_buttons>\n"
                f"<task_input>\n{(task_text or '')[:3000]}\n</task_input>\n"
            )
            encoded = base64.b64encode(Path(screenshot_path).read_bytes()).decode("utf-8")
            mime = "image/jpeg" if Path(screenshot_path).suffix.lower() in (".jpg", ".jpeg") else "image/png"
            api = (
                "https://generativelanguage.googleapis.com/v1beta/"
                f"models/{self.gemini_vision_model}:generateContent?key={self.gemini_api_key}"
            )
            payload = {
                "contents": [{
                    "parts": [
                        {"text": prompt},
                        {"inline_data": {"mime_type": mime, "data": encoded}},
                    ]
                }],
                "generationConfig": {"temperature": 0.1, "maxOutputTokens": 800},
            }

            async def _call():
                r = await self.http_client.post(api, json=payload)
                r.raise_for_status()
                return r.json()["candidates"][0]["content"]["parts"][0]["text"]

            raw = await self._safe_api_call(_call)
            parsed = self._safe_json_parse(raw)
            if not isinstance(parsed, dict):
                plan["status"] = "parse_fail"
                return plan
            plan.update({k: parsed.get(k) for k in parsed})
            plan["ok"] = bool(parsed.get("executable", True)) and bool(parsed.get("execution_steps"))
            plan["status"] = "planned"
            plan["screenshot"] = screenshot_path
            # نفّذ النقرة الأساسية إن وُجد نص
            label = str(parsed.get("primary_click_text") or "").strip()
            if label and page is not None:
                try:
                    if hasattr(self, "resolve_click_target_ax_vision"):
                        click = await self.resolve_click_target_ax_vision(
                            page, action=str(parsed.get("goal_action") or "subscribe"),
                            screenshot_path=screenshot_path,
                        )
                        plan["click_result"] = click
                    else:
                        loc = page.get_by_text(re.compile(re.escape(label[:40]), re.I))
                        if await loc.count():
                            await loc.first.click(timeout=3000)
                            plan["click_result"] = {"ok": True, "via": "text"}
                except Exception as e:
                    plan["click_error"] = str(e)[:120]
            return plan
        except Exception as e:
            plan["status"] = f"error:{type(e).__name__}"
            plan["error"] = str(e)[:160]
            return plan

    async def zero_shot_execute_steps(self, page, steps: list, comment_text: str = "🔥") -> dict:
        """ينفّذ execution_steps العامة على أي صفحة."""
        report = {"ok": False, "done": [], "failed": []}
        if page is None:
            return report
        for s in steps or []:
            if not isinstance(s, dict):
                continue
            act = str(s.get("action") or "").lower()
            try:
                if act in {"goto", "open"}:
                    report["done"].append(act)
                elif act in {"wait", "view"}:
                    sec = int(s.get("duration_seconds") or 5)
                    await asyncio.sleep(min(max(sec, 1), 60))
                    report["done"].append(act)
                elif act in {"scroll", "scroll_to_bottom"}:
                    await page.mouse.wheel(0, 1200 if act == "scroll_to_bottom" else 500)
                    await asyncio.sleep(0.5)
                    report["done"].append(act)
                elif act in {"dismiss_popup", "dismiss"}:
                    if "_exec_dismiss_hard" in globals():
                        await _exec_dismiss_hard(page, rounds=2)
                    report["done"].append(act)
                elif act in {"click", "subscribe", "like", "repost", "share", "register"}:
                    target = str(s.get("target_text") or act)
                    if hasattr(self, "resolve_click_target_ax_vision"):
                        r = await self.resolve_click_target_ax_vision(page, action=act)
                        if r.get("ok"):
                            report["done"].append(act)
                        else:
                            report["failed"].append(act)
                    else:
                        loc = page.get_by_text(re.compile(target[:30], re.I))
                        if await loc.count():
                            await loc.first.click(timeout=3000)
                            report["done"].append(act)
                        else:
                            report["failed"].append(act)
                elif act in {"type", "type_comment", "comment"}:
                    box = page.locator('textarea, [contenteditable="true"], div[role="textbox"]').first
                    if await box.count():
                        await box.click(timeout=2000)
                        await box.fill((s.get("text") or comment_text)[:200])
                        report["done"].append(act)
                    else:
                        report["failed"].append(act)
                elif act in {"verify", "screenshot"}:
                    report["done"].append(act)
                else:
                    report["done"].append(f"skip:{act}")
                await asyncio.sleep(random.uniform(0.4, 1.0))
            except Exception as e:
                report["failed"].append(f"{act}:{type(e).__name__}")
        report["ok"] = len(report["failed"]) == 0 and len(report["done"]) > 0
        return report

    # ---------- 2) RL from Environment Feedback ----------
    def _rl_load(self) -> dict:
        data = self._load_json_file(self._RL_PATH, {
            "weights": {},
            "total_reward": 0.0,
            "success": 0,
            "reject": 0,
            "history": [],
        })
        return data if isinstance(data, dict) else {}

    def _rl_save(self, data: dict) -> None:
        self._save_json_file(self._RL_PATH, data)

    def rl_apply_feedback(
        self,
        *,
        success: bool,
        reward_amount: float = 0.0,
        platform: str = "",
        action: str = "",
        thinking_signature: str = "",
        reject_reason: str = "",
        task_text: str = "",
    ) -> dict:
        """
        مكافأة/عقوبة حسب نتيجة UNU (رصيد أو رفض).
        يعزّز مسارات ناجحة ويكتب قواعد ضد المسارات الفاشلة.
        """
        st = self._rl_load()
        key = f"{(platform or 'any').lower()}::{(action or 'any').lower()}"
        weights = st.get("weights") if isinstance(st.get("weights"), dict) else {}
        w = float(weights.get(key, 0.5))
        if success:
            delta = 0.08 + min(0.15, abs(float(reward_amount)) * 0.02)
            w = min(0.99, w + delta)
            st["success"] = int(st.get("success") or 0) + 1
            st["total_reward"] = float(st.get("total_reward") or 0) + float(reward_amount or 0)
            # عزّز few-shot إيجابي
            try:
                self.vector_memory_add(
                    task_text or thinking_signature,
                    reject_reason="",
                    correct_json={
                        "platform": platform,
                        "action": action,
                        "executable": True,
                        "confidence": 0.9,
                    },
                    lesson=f"RL_SUCCESS {key} reward={reward_amount}",
                    success=True,
                )
            except Exception:
                pass
        else:
            delta = 0.1
            w = max(0.01, w - delta)
            st["reject"] = int(st.get("reject") or 0) + 1
            # عقوبة → ذاكرة + قاعدة
            try:
                self.vector_memory_add(
                    task_text or thinking_signature,
                    reject_reason=reject_reason or "rejected",
                    correct_json={
                        "platform": platform,
                        "action": action,
                        "executable": False,
                        "reject_reason": reject_reason or "unknown",
                    },
                    lesson=f"RL_PENALTY {key} reason={reject_reason}",
                    success=False,
                )
                mem = self._load_json_file(self._MEMORY_PATH, {"rules": []})
                rules = mem.get("rules") if isinstance(mem, dict) else []
                if not isinstance(rules, list):
                    rules = []
                rule = f"IF platform={platform} action={action} failed with {reject_reason} THEN re-check traps and lower confidence"
                if rule not in rules:
                    rules.append(rule)
                self._save_json_file(self._MEMORY_PATH, {"rules": rules[-80:]})
            except Exception:
                pass
        weights[key] = round(w, 4)
        st["weights"] = weights
        hist = st.get("history") if isinstance(st.get("history"), list) else []
        hist.append({
            "success": success,
            "key": key,
            "reward": reward_amount,
            "reject_reason": reject_reason,
            "w": weights[key],
        })
        st["history"] = hist[-300:]
        self._rl_save(st)
        # reward log
        rlog = self._load_json_file(self._REWARD_LOG, [])
        if not isinstance(rlog, list):
            rlog = []
        rlog.append(hist[-1])
        self._save_json_file(self._REWARD_LOG, rlog[-500:])
        # swarm graph update
        try:
            self.swarm_publish_event(
                kind="rl_feedback",
                platform=platform,
                action=action,
                success=success,
                reject_reason=reject_reason,
                weight=weights[key],
            )
        except Exception:
            pass
        return {"key": key, "weight": weights[key], "success": success}

    def rl_prior_boost(self, platform: str, action: str) -> float:
        """وزن سابق يُستخدم لرفع/خفض confidence."""
        st = self._rl_load()
        weights = st.get("weights") if isinstance(st.get("weights"), dict) else {}
        return float(weights.get(f"{(platform or '').lower()}::{(action or '').lower()}", 0.5))

    # ---------- 3) OS-Level automation (optional) ----------
    async def os_level_click(self, x: int, y: int) -> dict:
        """
        نقر على مستوى النظام عبر PyAutoGUI (يحتاج بيئة سطح مكتب).
        يُفعّل فقط إذا ENABLE_OS_LEVEL=1.
        """
        if os.environ.get("ENABLE_OS_LEVEL", "").strip() not in {"1", "true", "yes"}:
            return {"ok": False, "status": "os_level_disabled"}
        try:
            import pyautogui  # type: ignore
            pyautogui.FAILSAFE = True
            pyautogui.moveTo(x, y, duration=random.uniform(0.15, 0.45))
            await asyncio.sleep(random.uniform(0.05, 0.15))
            pyautogui.click()
            return {"ok": True, "status": "clicked", "x": x, "y": y}
        except Exception as e:
            return {"ok": False, "status": f"error:{type(e).__name__}", "error": str(e)[:120]}

    async def os_level_type(self, text: str, interval: float = 0.05) -> dict:
        if os.environ.get("ENABLE_OS_LEVEL", "").strip() not in {"1", "true", "yes"}:
            return {"ok": False, "status": "os_level_disabled"}
        try:
            import pyautogui  # type: ignore
            pyautogui.typewrite(text, interval=interval)
            return {"ok": True, "status": "typed"}
        except Exception as e:
            # typewrite ضعيف مع غير اللاتيني
            try:
                import pyautogui
                import pyperclip  # type: ignore
                pyperclip.copy(text)
                pyautogui.hotkey("ctrl", "v")
                return {"ok": True, "status": "pasted"}
            except Exception as e2:
                return {"ok": False, "error": str(e2)[:120]}

    # ---------- 4) Swarm Intelligence + GraphRAG ----------
    def _graph_load(self) -> dict:
        g = self._load_json_file(self._GRAPH_PATH, {"nodes": {}, "edges": []})
        if not isinstance(g, dict):
            g = {"nodes": {}, "edges": []}
        g.setdefault("nodes", {})
        g.setdefault("edges", [])
        return g

    def swarm_publish_event(
        self,
        *,
        kind: str,
        platform: str = "",
        action: str = "",
        success: bool = False,
        reject_reason: str = "",
        weight: float = 0.5,
        note: str = "",
        selector_hint: str = "",
    ) -> dict:
        """
        يحدّث معرفة مشتركة بين نسخ البوت (ملف graph واحد / شبكة ملفات).
        """
        g = self._graph_load()
        node_id = f"{(platform or 'web').lower()}:{kind}"
        nodes = g["nodes"]
        node = nodes.get(node_id) or {
            "platform": platform,
            "kind": kind,
            "success": 0,
            "fail": 0,
            "notes": [],
            "hints": [],
        }
        if success:
            node["success"] = int(node.get("success") or 0) + 1
        else:
            node["fail"] = int(node.get("fail") or 0) + 1
        if note:
            notes = node.get("notes") or []
            notes.append(str(note)[:200])
            node["notes"] = notes[-20:]
        if selector_hint:
            hints = node.get("hints") or []
            if selector_hint not in hints:
                hints.append(selector_hint[:120])
            node["hints"] = hints[-15:]
        if reject_reason:
            node["last_reject"] = reject_reason
        node["weight"] = weight
        node["updated"] = int(__import__("time").time())
        nodes[node_id] = node
        edges = g.get("edges") or []
        edges.append({
            "from": node_id,
            "to": f"action:{(action or 'any').lower()}",
            "success": success,
            "ts": node["updated"],
        })
        g["edges"] = edges[-1000:]
        g["nodes"] = nodes
        self._save_json_file(self._GRAPH_PATH, g)
        return {"node": node_id, "node_data": node}

    def swarm_query(self, platform: str, kind: str = "rl_feedback") -> dict:
        g = self._graph_load()
        node_id = f"{(platform or 'web').lower()}:{kind}"
        return (g.get("nodes") or {}).get(node_id) or {}

    def graph_rag_context(self, platform: str, action: str = "") -> str:
        """نص يُحقن في البرومبت من معرفة السرب."""
        g = self._graph_load()
        nodes = g.get("nodes") or {}
        lines = []
        for nid, node in list(nodes.items())[-30:]:
            if platform and platform.lower() not in nid and platform.lower() != str(node.get("platform") or "").lower():
                continue
            lines.append(
                f"{nid}: success={node.get('success')} fail={node.get('fail')} "
                f"reject={node.get('last_reject')} hints={node.get('hints')}"
            )
        return "\n".join(lines[:15])

    # ---------- 5) Temporal Video Verification ----------
    async def record_interaction_clip(
        self,
        page,
        duration_s: float = 3.0,
        out_dir: str = "data/proofs/video_clips",
    ) -> dict:
        """
        يسجّل مقطعًا قصيرًا عبر سلسلة إطارات (frame sampling) أثناء التفاعل.
        لا يعتمد على ffmpeg إلزاميًا — يحفظ إطارات + optional webm لو السياق يدعم.
        """
        report = {"ok": False, "frames": [], "dir": out_dir}
        if page is None:
            return report
        try:
            Path(out_dir).mkdir(parents=True, exist_ok=True)
            import time as _time
            stamp = int(_time.time() * 1000)
            clip_dir = Path(out_dir) / f"clip_{stamp}"
            clip_dir.mkdir(parents=True, exist_ok=True)
            frames = []
            n = max(3, int(duration_s * 2))  # ~2 fps
            for i in range(n):
                fp = str(clip_dir / f"frame_{i:02d}.jpg")
                await page.screenshot(path=fp, type="jpeg", quality=70)
                frames.append(fp)
                await asyncio.sleep(duration_s / n)
            report["frames"] = frames
            report["ok"] = len(frames) >= 3
            report["dir"] = str(clip_dir)
            return report
        except Exception as e:
            report["error"] = str(e)[:160]
            return report

    async def verify_temporal_interaction(
        self,
        frame_paths: list,
        expected_action: str = "like",
        task_text: str = "",
    ) -> dict:
        """
        يرسل عدة إطارات زمنية لـ Gemini Vision للتأكد أن التفاعل حصل ديناميكيًا
        (مثلاً تغيّر شكل زر اللايك بين إطار وإطار).
        """
        out = {"ok": False, "status": "pending", "confidence": 0.0}
        paths = [p for p in (frame_paths or []) if p and Path(p).is_file()][:6]
        if len(paths) < 2:
            out["status"] = "need_more_frames"
            return out
        try:
            parts = [{
                "text": (
                    "You are verifying a REAL UI interaction over time.\n"
                    f"Expected action: {expected_action}\n"
                    f"Task: {(task_text or '')[:800]}\n"
                    "You will see sequential frames. Decide if the action likely happened "
                    "(e.g. button state changed, follow became following, like filled).\n"
                    'Return JSON only: {"happened": true, "confidence": 0.0, "evidence": "..."}\n'
                )
            }]
            for fp in paths:
                mime = "image/jpeg" if Path(fp).suffix.lower() in (".jpg", ".jpeg") else "image/png"
                parts.append({
                    "inline_data": {
                        "mime_type": mime,
                        "data": base64.b64encode(Path(fp).read_bytes()).decode("utf-8"),
                    }
                })
            api = (
                "https://generativelanguage.googleapis.com/v1beta/"
                f"models/{self.gemini_vision_model}:generateContent?key={self.gemini_api_key}"
            )
            payload = {
                "contents": [{"parts": parts}],
                "generationConfig": {"temperature": 0.0, "maxOutputTokens": 256},
            }

            async def _call():
                r = await self.http_client.post(api, json=payload)
                r.raise_for_status()
                return r.json()["candidates"][0]["content"]["parts"][0]["text"]

            raw = await self._safe_api_call(_call)
            parsed = self._safe_json_parse(raw)
            if isinstance(parsed, dict) and parsed.get("happened"):
                out["ok"] = True
                out["status"] = "verified"
                out["confidence"] = float(parsed.get("confidence") or 0.6)
                out["evidence"] = parsed.get("evidence")
            else:
                out["status"] = "not_verified"
                out["raw"] = str(raw)[:200]
            return out
        except Exception as e:
            out["status"] = f"error:{type(e).__name__}"
            out["error"] = str(e)[:160]
            return out

    async def temporal_proof_bundle(
        self,
        page,
        expected_action: str,
        task_text: str = "",
        duration_s: float = 3.0,
    ) -> dict:
        """تسجيل إطارات أثناء/بعد الفعل + تحقق زمني."""
        clip = await self.record_interaction_clip(page, duration_s=duration_s)
        ver = await self.verify_temporal_interaction(
            clip.get("frames") or [],
            expected_action=expected_action,
            task_text=task_text,
        )
        return {"clip": clip, "verification": ver, "ok": bool(ver.get("ok"))}


    async def close(self):
        """إغلاق الجلسات بشكل نظيف لتحرير الذاكرة"""
        await self.http_client.aclose()

# --------------------------------------------------------
# هذا السطر ضروري جداً ليقوم ملف main.py باستيراد كائن brain بنجاح!
# --------------------------------------------------------


# ==========================================================
# AI CORE V5 — evidence classifier
# الرابط يحدد المنصة والشكل. الفعل من شكل الرابط + الفعل الصريح.
# ==========================================================

AI_CORE_V5 = "ai-core-v5"

_ORIG_EXTRACT_URLS = AIBrain._extract_urls_from_text
_ORIG_NORMALIZE = AIBrain._normalize_ai_result


def _unwrap_url(url: str) -> str:
    raw = (url or "").strip().rstrip(".,;:)")
    low = raw.lower()
    for marker in ("href.li/?", "href.li/?url=", "clck.ru/"):
        if marker in low and "http" in low[low.find(marker):]:
            inner = raw.split("?", 1)[-1]
            if inner.lower().startswith("url="):
                inner = inner[4:]
            if inner.lower().startswith("http"):
                return inner.split("&")[0]
    return raw


def _extract_urls_v5(self, text: str) -> list:
    found = _ORIG_EXTRACT_URLS(self, text) or []
    extra = re.findall(r"https?://[^\s\]\)\>\"']+", text or "", flags=re.I)
    cleaned = []
    for raw in list(found) + extra:
        url = _unwrap_url(raw)
        low = url.lower()
        if any(x in low for x in (
            "unu.im/tasks/", "unu.im/users/", "unu.im/partner/",
            "unu.im/tasks/accept", "unu.im/tasks/share",
        )):
            continue
        if url and url not in cleaned:
            cleaned.append(url)
    return cleaned


def _verbs_from_text(text: str) -> list:
    blob = (text or "").lower().replace("ё", "е")
    hits = []
    table = (
        ("subscribe", ("подпис", "вступить", "follow", "اشتراك", "متابعة", "join the", "subscribe")),
        ("like", ("лайк", "like", "нрав", "إعجاب", "поставить лайк")),
        ("comment", ("коммент", "comment", "تعليق", "напишите комментарий")),
        ("repost", ("репост", "repost", "retweet", "ретвит")),
        ("view", ("просмотр", "watch", "مشاهدة", "посмотреть")),
        ("review", ("отзыв", "review", "تقييم", "оценк")),
        ("register", ("регистрац", "sign up", "register", "تسجيل")),
    )
    for name, keys in table:
        if any(k in blob for k in keys) and name not in hits:
            hits.append(name)
    return hits


def _classify_evidence(self, text: str, urls: list) -> dict:
    urls = [_unwrap_url(u) for u in (urls or []) if u]
    platform = ""
    for url in urls:
        platform = self._infer_platform_from_url(url)
        if platform:
            break
    verbs = _verbs_from_text(text)
    action = ""
    if urls and platform:
        action = self._infer_action_from_url(urls[0], platform)
    if "repost" in verbs:
        action = "repost"
    elif "comment" in verbs and action in {"", "like", "subscribe", "unknown"}:
        action = "comment"
    elif "review" in verbs:
        action = "review"
    elif not action and verbs:
        action = verbs[0]
    actions = []
    for item in verbs:
        if item not in actions:
            actions.append(item)
    if action and action not in actions:
        actions.insert(0, action)
    return {
        "platform": platform or "other",
        "action": action or "unknown",
        "actions_list": actions,
        "is_compound": len(urls) > 1 or len(actions) > 1,
        "target_urls": urls,
    }


def _normalize_v5(self, result: dict, text_description: str = "") -> dict:
    out = _ORIG_NORMALIZE(self, result, text_description)
    urls = self._extract_urls_from_text(text_description)
    for url in out.get("target_urls") or []:
        if url not in urls:
            urls.append(url)
    evidence = _classify_evidence(self, text_description, urls)
    if evidence["platform"] not in {"", "other"}:
        out["platform"] = evidence["platform"]
    if evidence["action"] not in {"", "unknown"}:
        if out.get("action") in {"", "unknown", "start_bot"} or evidence["action"] in {"repost", "comment", "like"}:
            if not (out.get("is_telegram_bot") and out.get("action") == "start_bot"):
                out["action"] = evidence["action"]
    merged = []
    for item in (evidence["actions_list"] + (out.get("actions_list") or [])):
        if item and item not in merged and item != "unknown":
            merged.append(item)
    if out.get("action") and out["action"] not in merged and out["action"] != "unknown":
        merged.insert(0, out["action"])
    out["actions_list"] = merged
    out["is_compound"] = bool(len(urls) > 1 or len(merged) > 1)
    out["target_urls"] = urls or out.get("target_urls") or []
    out["evidence_v5"] = True
    return out


AIBrain._extract_urls_from_text = _extract_urls_v5
AIBrain._normalize_ai_result = _normalize_v5
logger.info("AI %s loaded", AI_CORE_V5)

brain = AIBrain()
