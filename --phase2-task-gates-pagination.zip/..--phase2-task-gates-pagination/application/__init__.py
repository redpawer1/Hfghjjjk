"""
Application Module - V3
"""
try:
    from .session_registry import session_registry, SessionRegistry
except ImportError:
    session_registry = None
    SessionRegistry = None

try:
    from .task_collector import TaskCollector
except ImportError:
    TaskCollector = None

try:
    from .lifecycle import lifecycle, LifecycleManager
except ImportError:
    lifecycle = None
    LifecycleManager = None

try:
    from .health import HealthMonitor
except ImportError:
    HealthMonitor = None

try:
    from .lock_manager import ExecutionLockManager
except ImportError:
    ExecutionLockManager = None

try:
    from .task_queue import TaskQueue, TaskStatus
except ImportError:
    TaskQueue = None
    TaskStatus = None

__all__ = [
    "session_registry", "SessionRegistry",
    "TaskCollector",
    "lifecycle", "LifecycleManager",
    "HealthMonitor",
    "ExecutionLockManager",
    "TaskQueue", "TaskStatus",
]
