"""
Session Registry - إدارة موحدة للجلسات
كل منصة لها تعريف واحد واضح
"""
import json
import logging
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime
from .session_paths import (
    DEFAULT_SESSION_ROOT,
    SUPPORTED_PLATFORMS,
    account_number,
    candidate_paths,
    canonical_platform,
    validate_session_file,
)

logger = logging.getLogger("SessionRegistry")

class SessionRegistry:
    """سجل موحد لكل جلسات المنصات"""
    
    DEFAULT_SESSIONS = {
        "unu": {
            "type": "playwright_storage",
            "paths": [str(path) for path in candidate_paths("unu")],
            "enabled": True,
            "status": "unknown",
            "last_checked": None,
        },
        "telegram": {
            "type": "telethon_string",
            "env_key": "TELEGRAM_STRING_SESSION",
            "paths": ["/root/sessions/telegram.json"],
            "enabled": True,
            "status": "unknown",
            "last_checked": None,
        },
        "vk": {
            "type": "playwright_cookies",
            "paths": ["/root/sessions/vk.json"],
            "enabled": True,
            "status": "unknown",
            "last_checked": None,
        },
        "youtube": {
            "type": "playwright_cookies",
            "paths": ["/root/sessions/youtube.json"],
            "enabled": True,
            "status": "unknown",
            "last_checked": None,
        },
        "instagram": {
            "type": "playwright_cookies",
            "paths": ["/root/sessions/instagram.json"],
            "enabled": True,
            "status": "unknown",
            "last_checked": None,
        },
        "tiktok": {
            "type": "playwright_cookies",
            "paths": ["/root/sessions/tiktok.json"],
            "enabled": True,
            "status": "unknown",
            "last_checked": None,
        },
        "twitter": {
            "type": "playwright_cookies",
            "paths": ["/root/sessions/x.json", "/root/sessions/twitter.json"],
            "enabled": True,
            "status": "unknown",
            "last_checked": None,
        },
        "rutube": {
            "type": "playwright_cookies",
            "paths": ["/root/sessions/rutube.json"],
            "enabled": True,
            "status": "unknown",
            "last_checked": None,
        },
        "max": {
            "type": "playwright_cookies",
            "paths": ["/root/sessions/max.json"],
            "enabled": True,
            "status": "unknown",
            "last_checked": None,
        },
        "ozon": {
            "type": "playwright_cookies",
            "paths": ["/root/sessions/ozon.json"],
            "enabled": True,
            "status": "unknown",
            "last_checked": None,
        },
        "wildberries": {
            "type": "playwright_cookies",
            "paths": ["/root/sessions/wildberries.json", "/root/sessions/wb.json"],
            "enabled": True,
            "status": "unknown",
            "last_checked": None,
        },
    }
    
    def __init__(self):
        self.sessions = {
            key: dict(value) for key, value in self.DEFAULT_SESSIONS.items()
        }
        self._cache = {}
    
    def get_session_path(self, platform: str, account_id: str = "account-1") -> Optional[str]:
        """جلب مسار الجلسة للمنصة"""
        platform = canonical_platform(platform)
        session = self.sessions.get(platform)
        if not session:
            return None
        number = account_number(account_id)
        for path in candidate_paths(platform, number):
            if path.exists():
                return str(path)
        for path in session.get("paths", []):
            if Path(path).exists():
                return str(path)
        return None
    
    def load_session(self, platform: str) -> Optional[Dict]:
        """تحميل بيانات الجلسة"""
        if platform in self._cache:
            return self._cache[platform]
        
        path = self.get_session_path(platform)
        if not path:
            self.sessions[platform]["status"] = "not_found"
            return None
        
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self._cache[platform] = data
            self.sessions[platform]["status"] = "loaded"
            self.sessions[platform]["last_checked"] = datetime.now().isoformat()
            logger.info("Session loaded: platform=%s path_exists=%s", platform, True)
            return data
        except Exception as e:
            self.sessions[platform]["status"] = "invalid"
            logger.warning("Session load failed for platform=%s: %s", platform, type(e).__name__)
            return None
    
    def get_cookies(self, platform: str) -> Dict[str, str]:
        """جلب الكوكيز من الجلسة"""
        data = self.load_session(platform)
        if not data:
            return {}
        
        cookies = {}
        # Playwright storage_state format
        if "cookies" in data:
            for c in data["cookies"]:
                cookies[c.get("name", "")] = c.get("value", "")
        # Simple dict format
        elif isinstance(data, dict):
            cookies = {k: v for k, v in data.items() if isinstance(v, str)}
        
        return cookies
    
    def get_status(self, account_id: str = "account-1") -> Dict[str, Any]:
        """حالة كل الجلسات"""
        result = {}
        for platform, session in self.sessions.items():
            path = self.get_session_path(platform, account_id=account_id)
            valid = False
            reason = "missing"
            if path:
                valid, reason = validate_session_file(path, platform)
            result[platform] = {
                "enabled": session["enabled"],
                "status": reason if path else "missing",
                "path_exists": path is not None,
                "exists": path is not None,
                "valid": valid,
            }
        return result
    
    def invalidate_cache(self, platform: str = None):
        """مسح الكاش"""
        if platform:
            self._cache.pop(platform, None)
        else:
            self._cache.clear()


    def get_available_platforms(self, account_id: str = "account-1") -> set:
        """المنصات اللي عندها ملف جلسة، بما فيها الحسابات الإضافية youtube_2.json."""
        available = set()
        roots = []
        try:
            from pathlib import Path as _Path
            roots = [_Path("/root/sessions"), _Path("/root/unu-bot/data/sessions"), _Path("data/sessions")]
        except Exception:
            roots = []
        names = set(SUPPORTED_PLATFORMS) - {"unu"}
        for platform in names:
            path = self.get_session_path(platform, account_id=account_id)
            if path:
                valid, _ = validate_session_file(path, platform)
                if valid:
                    available.add(platform)
                continue
            aliases = [platform]
            if platform == "twitter":
                aliases.append("x")
            if platform == "wildberries":
                aliases.append("wb")
            found = False
            for root in roots:
                if not root.exists():
                    continue
                for alias in aliases:
                    matches = list(root.glob(f"{alias}.json")) + list(root.glob(f"{alias}_*.json")) + list(root.glob(f"{alias}-*.json"))
                    if matches:
                        found = True
                        break
                if found:
                    break
            if found:
                available.add(platform)
        return available
    
    def can_execute(self, platform: str, account_id: str = "account-1") -> bool:
        """هل نقدر ننفذ مهام المنصة دي؟"""
        if platform in ("website", "other", "unknown"):
            return True
        return platform in self.get_available_platforms(account_id=account_id)

# Singleton
session_registry = SessionRegistry()
