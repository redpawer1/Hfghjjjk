#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Account fleet — تعدد حسابات UNU وحسابات المنصات.

data/accounts.json يتولد من الجلسات الموجودة ولا يُستبدل لو اتعدل.
الحالة بتتحفظ في data/fleet_state.json.
الحساب المتعطل يدخل كولدوان متزايد لحد يوم وبعدين يرجع يحاول.
"""
from __future__ import annotations

import json
import logging
import os
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from account_runtime import AccountRuntime
from application.session_paths import (
    DEFAULT_SESSION_ROOT,
    SUPPORTED_PLATFORMS,
    account_number,
    canonical_platform,
    session_filename,
    validate_session_file,
)

logger = logging.getLogger("AccountFleet")


def _unu_identity(path: Path) -> str:
    """نفس حساب UNU حتى لو متسجل في أكتر من ملف."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return f"file:{path}"
    marks = []
    for item in data.get("cookies") or []:
        if not isinstance(item, dict):
            continue
        if "unu.im" not in str(item.get("domain") or ""):
            continue
        if item.get("name") in {"id", "hash"} and item.get("value"):
            marks.append(f"{item['name']}={item['value']}")
    if marks:
        return "|".join(sorted(marks))
    return f"file:{path.resolve()}"


def _dedupe_unu(accounts: list) -> list:
    kept = []
    seen = set()
    has_primary = any(
        Path(str(item.get("storage_state") or "")).name == "unu.json"
        and Path(str(item.get("storage_state") or "")).exists()
        for item in accounts
    )
    for item in accounts:
        path = Path(str(item.get("storage_state") or ""))
        if has_primary and path.name == "storage_state.json":
            logger.info("UNU legacy alias dropped in favor of unu.json")
            continue
        key = _unu_identity(path) if path.exists() else f"missing:{item.get('id')}"
        if key in seen:
            logger.info("UNU duplicate dropped: %s", path)
            continue
        seen.add(key)
        kept.append(item)
    used_ids = set()
    for index, item in enumerate(kept):
        requested = str(item.get("id") or "").strip()
        if not requested or requested in used_ids:
            requested = f"unu-{index + 1}"
            while requested in used_ids:
                requested = f"unu-{index + len(used_ids) + 1}"
        item["id"] = requested
        used_ids.add(requested)
    return kept

PLATFORM_NAMES = tuple(SUPPORTED_PLATFORMS)

COOLDOWN_STEPS = (300, 900, 3600, 6 * 3600, 24 * 3600)

DEFAULT_PROOF = {
    "instagram": {"username": "virexohq1", "profile_url": "https://www.instagram.com/virexohq1"},
    "tiktok": {"username": "virexohq", "profile_url": "https://www.tiktok.com/@virexohq"},
    "max": {"username": "", "profile_url": "https://max.ru/u/f9LHodD0cOIeVY5jPgXZClogFIlVV5c_1_pbg6D9kyFdLQeUZwQvmtOj8m8"},
    "rutube": {"username": "56024403", "profile_url": "https://rutube.ru/channel/56024403/"},
    "youtube": {"username": "AjaebWalaken", "profile_url": "https://www.youtube.com/@AjaebWalaken"},
    "vk": {"username": "id1043297158", "profile_url": "https://m.vk.ru/id1043297158"},
    "twitter": {"username": "Yssyionbhhqxq", "profile_url": "https://x.com/Yssyionbhhqxq"},
    "x": {"username": "Yssyionbhhqxq", "profile_url": "https://x.com/Yssyionbhhqxq"},
}

HOURLY_CAP = {
    "instagram": 25, "tiktok": 30, "youtube": 20, "telegram": 60, "vk": 30,
    "rutube": 25, "max": 20, "twitter": 20, "x": 20, "ozon": 15, "wildberries": 15,
}

SESSION_ROOTS = (
    DEFAULT_SESSION_ROOT,
    Path("/root/unu-bot/data/sessions"),
    Path("data/sessions"),
)


def _now() -> float:
    return time.time()


def _today() -> str:
    return datetime.now().date().isoformat()


def _read_json(path: Path):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        logger.warning("json read failed %s: %s", path, error)
    return None


def _write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _canon_platform(name: str) -> str:
    name = (name or "").strip().lower()
    if name in {"x", "x.com"}:
        return "twitter"
    return name


class AccountFleet:
    def __init__(self, path: Optional[str] = None):
        self.path = Path(path or os.getenv("ACCOUNTS_FILE", "data/accounts.json"))
        self.state_path = Path(os.getenv("FLEET_STATE_FILE", "data/fleet_state.json"))
        self.accounts: Dict = {"version": 1, "unu": [], "platforms": {}}
        self.state: Dict = {"unu": {}, "platforms": {}}
        self._mtime = 0.0
        self._active_unu_id: Optional[str] = None
        self.active_lease: Optional[dict] = None
        self.hour_errors: List[dict] = []
        self._runtimes: Dict[str, AccountRuntime] = {}
        self.load()

    def load(self) -> None:
        raw = _read_json(self.path)
        has_accounts = isinstance(raw, dict) and (raw.get("unu") or raw.get("platforms"))
        if not has_accounts:
            raw = self._discover()
            try:
                if not self.path.exists():
                    _write_json(self.path, raw)
                    logger.info("Wrote discovered accounts to %s", self.path)
            except Exception as error:
                logger.warning("accounts.json write failed: %s", error)
        self.accounts = {
            "version": 1,
            "unu": list(raw.get("unu") or []),
            "platforms": dict(raw.get("platforms") or {}),
        }
        self._normalize()
        self._merge_discovered()
        state = _read_json(self.state_path)
        if isinstance(state, dict):
            self.state = {
                "unu": dict(state.get("unu") or {}),
                "platforms": dict(state.get("platforms") or {}),
            }
        try:
            self._mtime = self.path.stat().st_mtime if self.path.exists() else 0.0
        except Exception:
            self._mtime = 0.0
        logger.info(
            "Fleet loaded unu=%s platforms=%s",
            len(self.accounts["unu"]),
            {k: len(v) for k, v in self.accounts["platforms"].items()},
        )

    def reload_if_changed(self) -> None:
        try:
            if self.path.exists() and self.path.stat().st_mtime != self._mtime:
                logger.info("accounts.json changed — reloading")
                self.load()
                return
        except Exception as error:
            logger.debug("fleet reload: %s", error)
        # ملفات جلسة جديدة تتضاف حتى لو ما عدّلتش accounts.json
        if not getattr(self, "_last_scan", 0) or (time.time() - self._last_scan) > 60:
            self._last_scan = time.time()
            self._merge_discovered()

    def _discover(self) -> dict:
        unu = []
        platforms: Dict[str, list] = {}
        seen = set()

        def add_unu(path: Path):
            if not path.exists():
                return
            key = str(path.resolve())
            if key in seen:
                return
            seen.add(key)
            unu.append({
                "id": f"unu-{len(unu) + 1}",
                "label": path.stem,
                "enabled": True,
                "storage_state": str(path),
                "daily_cap": int(os.getenv("UNU_DAILY_CAP", "40")),
                "proxy": "",
            })

        def add_platform(platform: str, path: Path, primary: bool):
            platform = canonical_platform(platform)
            if platform not in PLATFORM_NAMES and platform not in {"twitter"}:
                return
            if not path.exists():
                return
            key = str(path.resolve())
            if key in seen:
                return
            seen.add(key)
            bucket = platforms.setdefault(platform, [])
            proof = DEFAULT_PROOF.get(platform, {}) if primary else {}
            bucket.append({
                "id": f"{platform}-{len(bucket) + 1}",
                "label": path.stem,
                "enabled": True,
                "session": str(path),
                "username": proof.get("username", ""),
                "profile_url": proof.get("profile_url", ""),
                "hourly_cap": HOURLY_CAP.get(platform, 20),
                "daily_cap": 150,
            })

        for root in SESSION_ROOTS:
            if not root.exists():
                continue
            # Canonical paths: unu.json, unu-2.json, unu-3.json, ...
            for path in sorted(root.glob("unu*.json")):
                if path.name == "unu.json" or re.match(r"^unu-\d+\.json$", path.name):
                    add_unu(path)
            # Compatibility with older deployments.
            for path in sorted(root.glob("storage_state*.json")):
                add_unu(path)
            for path in sorted(root.glob("*.json")):
                stem = path.stem.lower()
                if (
                    stem in {"storage_state", "unu"}
                    or stem.startswith(("unu-", "unu_", "storage_state"))
                ):
                    continue
                match = re.match(r"^([a-z][a-z0-9_]*?)(?:-(\d+))?$", stem)
                if not match:
                    continue
                platform = canonical_platform(match.group(1))
                if platform not in PLATFORM_NAMES:
                    continue
                add_platform(
                    platform,
                    path,
                    not match.group(2) and platform in PLATFORM_NAMES,
                )

        if not unu:
            unu.append({
                "id": "unu-1",
                "label": "primary",
                "enabled": True,
                "storage_state": str(DEFAULT_SESSION_ROOT / "unu.json"),
                "daily_cap": int(os.getenv("UNU_DAILY_CAP", "40")),
                "proxy": "",
            })
        return {"version": 1, "unu": _dedupe_unu(unu), "platforms": platforms}

    def _normalize(self) -> None:
        cleaned = []
        for index, item in enumerate(self.accounts["unu"]):
            if not isinstance(item, dict):
                continue
            item = dict(item)
            item["id"] = str(item.get("id") or f"unu-{index + 1}")
            item["enabled"] = bool(item.get("enabled", True))
            item["daily_cap"] = int(os.getenv("UNU_DAILY_CAP", "40"))
            item["storage_state"] = str(item.get("storage_state") or "")
            cleaned.append(item)
        self.accounts["unu"] = _dedupe_unu(cleaned)
        grouped = {}
        for platform, items in self.accounts["platforms"].items():
            platform = _canon_platform(str(platform))
            bucket = grouped.setdefault(platform, [])
            if not isinstance(items, list):
                continue
            for index, item in enumerate(items):
                if not isinstance(item, dict):
                    continue
                item = dict(item)
                item["id"] = str(item.get("id") or f"{platform}-{index + 1}")
                item["enabled"] = bool(item.get("enabled", True))
                item["platform"] = platform
                item["hourly_cap"] = int(item.get("hourly_cap") or HOURLY_CAP.get(platform, 20))
                item["daily_cap"] = int(item.get("daily_cap") or 150)
                item["session"] = str(item.get("session") or "")
                bucket.append(item)
        self.accounts["platforms"] = grouped

    def _merge_discovered(self) -> None:
        """أي ملف جلسة جديد يتضاف لوحده من غير ما يمسح تعديلاتك."""
        try:
            found = self._discover()
        except Exception as error:
            logger.debug("discover merge failed: %s", error)
            return
        changed = False
        known_unu = {a.get("storage_state") for a in self.accounts["unu"]}
        known_ids = set()
        for account in self.accounts["unu"]:
            path = Path(str(account.get("storage_state") or ""))
            if path.exists():
                known_ids.add(_unu_identity(path))
        for item in found.get("unu") or []:
            path = item.get("storage_state") or ""
            file_path = Path(path)
            if not path or path in known_unu or not file_path.exists():
                continue
            ident = _unu_identity(file_path)
            if ident in known_ids:
                logger.info("UNU session already known, skip %s", path)
                continue
            item["id"] = f"unu-{len(self.accounts['unu']) + 1}"
            self.accounts["unu"].append(item)
            known_unu.add(path)
            known_ids.add(ident)
            changed = True
            logger.info("Fleet added UNU account %s", path)
        for platform, items in (found.get("platforms") or {}).items():
            bucket = self.accounts["platforms"].setdefault(platform, [])
            known = {i.get("session") for i in bucket}
            for item in items:
                path = item.get("session") or ""
                if not path or path in known or not Path(path).exists():
                    continue
                item["id"] = f"{platform}-{len(bucket) + 1}"
                item["platform"] = platform
                bucket.append(item)
                known.add(path)
                changed = True
                logger.info("Fleet added %s account %s", platform, path)
        if changed and self.path.exists():
            try:
                _write_json(self.path, self.accounts)
            except Exception as error:
                logger.warning("accounts merge save failed: %s", error)

    def save_state(self) -> None:
        try:
            _write_json(self.state_path, self.state)
        except Exception as error:
            logger.warning("fleet state save failed: %s", error)

    def _slot(self, kind: str, account_id: str) -> dict:
        bucket = self.state.setdefault(kind, {})
        slot = bucket.get(account_id)
        if not isinstance(slot, dict):
            slot = {
                "ok": 0, "fail": 0, "streak": 0, "cooldown_until": 0,
                "day": _today(), "day_count": 0, "hour_window": [],
                "last_error": "", "last_ok": 0,
            }
            bucket[account_id] = slot
        if slot.get("day") != _today():
            slot["day"] = _today()
            slot["day_count"] = 0
        now = _now()
        slot["hour_window"] = [ts for ts in slot.get("hour_window") or [] if now - float(ts) < 3600]
        return slot

    def unu_accounts(self) -> List[dict]:
        self.reload_if_changed()
        return [a for a in self.accounts["unu"] if a.get("enabled")]

    def real_unu_accounts(self) -> List[dict]:
        return [a for a in self.unu_accounts() if a.get("storage_state") and Path(a["storage_state"]).exists()]

    def _unu_ready(self, account: dict) -> bool:
        if not account or not account.get("id"):
            return False
        slot = self._slot("unu", account["id"])
        if float(slot.get("cooldown_until") or 0) > _now():
            return False
        if int(slot.get("day_count") or 0) >= int(account.get("daily_cap") or 40):
            return False
        path = account.get("storage_state") or ""
        valid, reason = validate_session_file(path, "unu")
        if not valid:
            if reason not in {"missing"}:
                logger.warning(
                    "UNU account session unavailable: account=%s reason=%s",
                    account.get("id"),
                    reason,
                )
            return False
        return True

    def healthy_unu(self, account_id: Optional[str] = None) -> List[dict]:
        ready = [a for a in self.unu_accounts() if self._unu_ready(a)]
        if account_id is not None:
            return [a for a in ready if str(a.get("id")) == str(account_id)]
        return ready

    def current_unu(self) -> Optional[dict]:
        accounts = self.healthy_unu()
        if not accounts:
            return None
        if self._active_unu_id:
            for account in accounts:
                if account["id"] == self._active_unu_id and self._unu_ready(account):
                    return account
        return None

    def get_unu(self, account_id: str) -> Optional[dict]:
        if not account_id:
            return None
        for account in self.unu_accounts():
            if account["id"] == account_id:
                return account
        return None

    def resolve_runtime(self, account_id: str) -> Optional[AccountRuntime]:
        """Resolve exactly one ready account; never choose a substitute."""
        requested = str(account_id or "").strip()
        if not requested:
            return None
        account = self.get_unu(requested)
        if not account or not self._unu_ready(account):
            return None
        state = self.read_storage(account) or {}
        cookies = {}
        for item in state.get("cookies") or []:
            if isinstance(item, dict) and "unu.im" in str(item.get("domain") or ""):
                if item.get("name"):
                    cookies[str(item["name"])] = str(item.get("value") or "")
        if not cookies:
            return None
        runtime = self._runtimes.get(requested)
        if runtime is None or runtime.disconnected:
            runtime = AccountRuntime(
                requested,
                account=account,
                cookies=cookies,
                storage_state=str(account.get("storage_state") or ""),
            )
            self._runtimes[requested] = runtime
        else:
            runtime.account = dict(account)
            if runtime.cookies != cookies:
                old_client = runtime.api_client
                runtime.api_client = None
                if old_client is not None and hasattr(old_client, "close"):
                    old_client.close()
            runtime.cookies = dict(cookies)
            runtime.storage_state = str(account.get("storage_state") or "")
        return runtime

    def account_status(self, account_id: str) -> dict:
        account = self.get_unu(account_id)
        if not account:
            return {"account_id": str(account_id or ""), "available": False, "error": "unknown_account"}
        ready = self._unu_ready(account)
        slot = self._slot("unu", account["id"])
        return {
            "account_id": account["id"],
            "label": account.get("label") or account["id"],
            "enabled": bool(account.get("enabled")),
            "available": bool(ready),
            "connected": bool(self._runtimes.get(account["id"]) and not self._runtimes[account["id"]].disconnected),
            "last_error": str(slot.get("last_error") or ""),
            "cooldown_until": float(slot.get("cooldown_until") or 0),
        }

    def add_unu_account(self, account_id: str, storage_state: str, label: str = "") -> dict:
        account_id = str(account_id or "").strip()
        storage_state = str(storage_state or "").strip()
        if not account_id or not storage_state:
            raise ValueError("account_id and storage_state are required")
        if self.get_unu(account_id):
            raise ValueError(f"account_exists:{account_id}")
        account = {
            "id": account_id,
            "label": label or account_id,
            "enabled": True,
            "storage_state": storage_state,
            "daily_cap": int(os.getenv("UNU_DAILY_CAP", "40")),
            "proxy": "",
        }
        self.accounts["unu"].append(account)
        self._normalize()
        _write_json(self.path, self.accounts)
        return dict(account)

    def update_unu_account(self, account_id: str, **changes) -> dict:
        account = self.get_unu(account_id)
        if not account:
            raise ValueError(f"unknown_account:{account_id}")
        allowed = {"label", "storage_state", "enabled", "daily_cap", "proxy"}
        for key, value in changes.items():
            if key in allowed:
                account[key] = value
        _write_json(self.path, self.accounts)
        runtime = self._runtimes.get(account_id)
        if runtime and "storage_state" in changes:
            runtime.disconnected = True
        return dict(account)

    def disconnect_unu(self, account_id: str) -> bool:
        runtime = self._runtimes.pop(str(account_id), None)
        if runtime:
            runtime.disconnected = True
            client = runtime.api_client
            runtime.api_client = None
            if client is not None and hasattr(client, "close"):
                client.close()
        account = self.get_unu(account_id)
        if not account:
            return False
        account["enabled"] = False
        _write_json(self.path, self.accounts)
        return True

    def remove_unu(self, account_id: str) -> bool:
        account_id = str(account_id or "")
        runtime = self._runtimes.pop(account_id, None)
        if runtime:
            runtime.disconnected = True
            client = runtime.api_client
            runtime.api_client = None
            if client is not None and hasattr(client, "close"):
                client.close()
        before = len(self.accounts["unu"])
        self.accounts["unu"] = [a for a in self.accounts["unu"] if str(a.get("id")) != account_id]
        if len(self.accounts["unu"]) == before:
            return False
        self.state.get("unu", {}).pop(account_id, None)
        _write_json(self.path, self.accounts)
        self.save_state()
        return True

    def test_unu_account(self, account_id: str) -> dict:
        runtime = self.resolve_runtime(account_id)
        if runtime is None:
            return self.account_status(account_id) | {"ok": False}
        try:
            result = runtime.get_api().get_balance()
            return self.account_status(account_id) | {"ok": True, "balance": result}
        except Exception as error:
            runtime.last_error = str(error)[:180]
            return self.account_status(account_id) | {"ok": False, "error": runtime.last_error}

    def mark_unu(self, account_id: str, status: str, reason: str = "") -> None:
        account = self.get_unu(account_id)
        if not account:
            return
        slot = self._slot("unu", account_id)
        status = (status or "").lower()
        if status in {"ok", "success", "verified"}:
            slot["ok"] = int(slot.get("ok") or 0) + 1
            slot["streak"] = 0
            slot["cooldown_until"] = 0
            slot["day_count"] = int(slot.get("day_count") or 0) + 1
            slot["last_ok"] = _now()
            slot["last_error"] = ""
        else:
            slot["fail"] = int(slot.get("fail") or 0) + 1
            slot["streak"] = int(slot.get("streak") or 0) + 1
            slot["last_error"] = (reason or status)[:180]
            if status in {"session", "session_invalid", "banned", "rate_limit", "429"}:
                step = min(int(slot["streak"]) - 1, len(COOLDOWN_STEPS) - 1)
                slot["cooldown_until"] = _now() + COOLDOWN_STEPS[max(0, step)]
                if self._active_unu_id == account_id:
                    self._active_unu_id = None
        self._remember_error("unu", account_id, status, reason)
        self.save_state()

    def read_storage(self, account: Optional[dict]) -> Optional[dict]:
        if not account:
            return None
        data = _read_json(Path(account.get("storage_state") or ""))
        if isinstance(data, dict) and ("cookies" in data or "origins" in data):
            return data
        return None

    def unu_cookies(self, account: Optional[dict]) -> dict:
        state = self.read_storage(account) or {}
        cookies = {}
        for item in state.get("cookies") or []:
            if "unu.im" in str(item.get("domain") or "") and item.get("name"):
                cookies[item["name"]] = item["value"]
        return cookies

    def next_unu_after(self, account_id: str) -> Optional[dict]:
        self.mark_unu(account_id, "session", "rotate")
        return self.current_unu()

    def available_platforms(self, account_id: Optional[str] = None) -> set:
        found = set()
        for platform, items in self.accounts["platforms"].items():
            if account_id is not None:
                number = account_number(account_id)
            for item in items:
                item_id = str(item.get("id") or "")
                if account_id is not None and item_id.endswith(f"-{number}"):
                    pass
                elif account_id is not None and item_id and not item_id.endswith("-1"):
                    continue
                path = item.get("session") or ""
                valid, _ = validate_session_file(path, platform)
                if item.get("enabled") and path and valid:
                    found.add(platform)
                    if platform == "twitter":
                        found.add("x")
        return found

    def _platform_ready(self, account: dict) -> bool:
        if not account or not account.get("enabled"):
            return False
        path = account.get("session") or ""
        platform = str(account.get("platform") or "").strip().lower()
        valid, _ = validate_session_file(path, platform)
        if path and not valid:
            return False
        slot = self._slot("platforms", account["id"])
        if float(slot.get("cooldown_until") or 0) > _now():
            return False
        if int(slot.get("day_count") or 0) >= int(account.get("daily_cap") or 150):
            return False
        if len(slot.get("hour_window") or []) >= int(account.get("hourly_cap") or 20):
            return False
        return True

    def lease_platform(self, platform: str) -> Optional[dict]:
        platform = _canon_platform(platform)
        if platform in {"", "website", "unknown", "other"}:
            self.active_lease = None
            return None
        items = list(self.accounts["platforms"].get(platform) or [])
        ready = [item for item in items if self._platform_ready(item)]
        if not ready:
            ready = [
                item for item in items
                if item.get("enabled") and Path(item.get("session") or "missing").exists()
            ]
        if not ready:
            self.active_lease = None
            return None
        ready.sort(key=lambda item: len(self._slot("platforms", item["id"]).get("hour_window") or []))
        chosen = dict(ready[0])
        chosen["platform"] = platform
        self.active_lease = chosen
        self.apply_lease(chosen)
        return chosen

    def apply_lease(self, lease: dict) -> None:
        platform = _canon_platform(lease.get("platform") or "")
        path = lease.get("session") or ""
        if platform and path:
            os.environ[f"FLEET_COOKIE_{platform.upper()}"] = path
            env_names = {
                "youtube": "YOUTUBE_COOKIES_FILE",
                "tiktok": "TIKTOK_COOKIES_FILE",
                "instagram": "INSTAGRAM_COOKIES_FILE",
                "twitter": "TWITTER_COOKIES_FILE",
                "vk": "VK_COOKIES_FILE",
                "max": "MAX_COOKIES_FILE",
                "rutube": "RUTUBE_COOKIES_FILE",
                "ozon": "OZON_COOKIES_FILE",
                "wildberries": "WILDBERRIES_COOKIES_FILE",
                "telegram": "TELEGRAM_WEB_COOKIES_FILE",
            }
            if platform in env_names:
                os.environ[env_names[platform]] = path
            try:
                import skill_manager as skill_mod
                if hasattr(skill_mod, "SM_COOKIE_FILES"):
                    skill_mod.SM_COOKIE_FILES[platform] = path
                    if platform == "twitter":
                        skill_mod.SM_COOKIE_FILES["x"] = path
                if hasattr(skill_mod, "_SM_COOKIE_MTIME"):
                    skill_mod._SM_COOKIE_MTIME.pop(platform, None)
            except Exception as error:
                logger.debug("skill cookie path update: %s", error)
        if lease.get("session_string"):
            os.environ["TELEGRAM_STRING_SESSION"] = str(lease["session_string"])

    def release_platform(self, lease: Optional[dict], success: bool, reason: str = "") -> None:
        if not lease:
            return
        slot = self._slot("platforms", lease["id"])
        if success:
            slot["ok"] = int(slot.get("ok") or 0) + 1
            slot["streak"] = 0
            slot["cooldown_until"] = 0
            slot["day_count"] = int(slot.get("day_count") or 0) + 1
            slot["last_ok"] = _now()
            slot["last_error"] = ""
        else:
            slot["fail"] = int(slot.get("fail") or 0) + 1
            slot["streak"] = int(slot.get("streak") or 0) + 1
            slot["last_error"] = (reason or "fail")[:180]
            kind = (reason or "").lower()
            if any(token in kind for token in ("session", "login", "auth", "rate", "429", "banned", "captcha")):
                step = min(int(slot["streak"]) - 1, len(COOLDOWN_STEPS) - 1)
                slot["cooldown_until"] = _now() + COOLDOWN_STEPS[max(0, step)]
        if success or "rate" in (reason or "").lower() or "429" in (reason or ""):
            slot["hour_window"] = list(slot.get("hour_window") or []) + [_now()]
        self._remember_error(lease.get("platform") or "platform", lease["id"], "ok" if success else "fail", reason)
        self.save_state()

    def proof_identity(self, platform: str) -> dict:
        platform = _canon_platform(platform)
        lease = self.active_lease
        if not lease or _canon_platform(lease.get("platform") or "") != platform:
            items = [item for item in self.accounts["platforms"].get(platform, []) if item.get("enabled")]
            lease = items[0] if items else None
        if not lease:
            proof = DEFAULT_PROOF.get(platform) or {}
            return {
                "username": proof.get("username") or "",
                "profile_url": proof.get("profile_url") or "",
                "locked": False,
            }
        return {
            "username": str(lease.get("username") or "").lstrip("@"),
            "profile_url": str(lease.get("profile_url") or ""),
            "locked": True,
        }

    def _remember_error(self, platform: str, account_id: str, status: str, reason: str) -> None:
        if status in {"ok", "success", "verified"}:
            return
        now = _now()
        self.hour_errors.append({
            "ts": now,
            "platform": platform,
            "account": account_id,
            "status": status,
            "reason": (reason or "")[:160],
        })
        self.hour_errors = [item for item in self.hour_errors if now - item["ts"] < 3600][-200:]

    def digest(self, bot=None) -> str:
        unu_lines = []
        for account in self.unu_accounts():
            slot = self._slot("unu", account["id"])
            cool = float(slot.get("cooldown_until") or 0)
            flag = "كولدوان" if cool > _now() else "جاهز"
            exists = "ملف" if Path(account.get("storage_state") or "").exists() else "لا ملف"
            unu_lines.append(
                f"• {account['id']} ({account.get('label')}) {flag} اليوم {slot.get('day_count')}/{account.get('daily_cap')} [{exists}]"
            )
        plat_lines = []
        for platform, items in sorted(self.accounts["platforms"].items()):
            ready = sum(1 for item in items if self._platform_ready(item))
            done = sum(int(self._slot("platforms", item["id"]).get("day_count") or 0) for item in items)
            plat_lines.append(f"• {platform}: {ready}/{len(items)} حساب، منفّذ اليوم {done}")
        recent = self.hour_errors[-8:]
        err_txt = "\n".join(
            f"• {item['platform']}/{item['account']}: {item['status']} {item['reason'][:80]}"
            for item in recent
        ) or "• لا شيء"
        done = getattr(bot, "daily_tasks_done", 0) if bot else 0
        money = getattr(bot, "daily_earnings", 0.0) if bot else 0.0
        uptime = ""
        if bot is not None and getattr(bot, "start_time", None):
            seconds = int((datetime.now() - bot.start_time).total_seconds())
            days, rem = divmod(seconds, 86400)
            hours, _rem = divmod(rem, 3600)
            uptime = f"{days}ي {hours}س"
        return (
            "📋 تقرير الساعة\n"
            f"شغال من: {uptime or 'الآن'}\n"
            f"اليوم: {done} مهمة | {float(money):.2f}₽\n\n"
            "حسابات UNU:\n" + ("\n".join(unu_lines) or "• لا يوجد")
            + "\n\nالمنصات:\n" + ("\n".join(plat_lines) or "• لا يوجد")
            + "\n\nآخر الأخطاء:\n" + err_txt
        )

    def attach(self, bot) -> None:
        count = max(1, len(self.real_unu_accounts()) or len(self.unu_accounts()))
        current = int(getattr(bot, "max_tasks_per_day", 40) or 40)
        bot.max_tasks_per_day = min(40 * count, 200)
        bot.max_concurrent_checks = 1
        bot._active_unu_id = None
        logger.info(
            "Fleet attached unu=%s daily_cap=%s concurrency=1",
            count, bot.max_tasks_per_day,
        )
