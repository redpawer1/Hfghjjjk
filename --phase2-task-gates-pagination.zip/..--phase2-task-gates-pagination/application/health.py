"""
Health Monitor - مراقبة صحة البوت وإعادة التشغيل التلقائي
"""
import asyncio
import logging
try:
    import psutil
except ImportError:
    psutil = None
from datetime import datetime
from typing import Optional, Callable

logger = logging.getLogger("HealthMonitor")

class HealthMonitor:
    """مراقب صحة البوت"""
    
    def __init__(self, bot):
        self.bot = bot
        self.running = False
        self._task = None
        self.checks = {
            "browser": True,
            "session": True,
            "memory": True,
            "last_check": None,
            "errors": 0,
            "collector": True,
            "last_cycle": 0,
        }
        self.max_memory_mb = 1500
        self.max_errors = 10
        self.on_restart: Optional[Callable] = None
    
    async def start(self):
        """بدء المراقبة"""
        if self.running:
            return
        self.running = True
        self._task = asyncio.create_task(self._monitor_loop())
        logger.info("🏥 HealthMonitor started")
    
    async def stop(self):
        """إيقاف المراقبة"""
        self.running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
    
    async def _monitor_loop(self):
        """حلقة المراقبة"""
        while self.running:
            try:
                await self._check_health()
                await asyncio.sleep(60)  # كل دقيقة
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning("Health check error: %s", e)
                await asyncio.sleep(30)
    
    def _busy(self) -> bool:
        bot = self.bot
        page = getattr(bot, "_active_task_page", None)
        if page is not None:
            return True
        lock = getattr(bot, "_execution_lock", None)
        try:
            if lock is not None and lock.locked():
                return True
        except Exception:
            pass
        return False

    async def _check_health(self):
        """فحص الصحة. لا يلمس صفحة أو جلسة أثناء تنفيذ مهمة."""
        self.checks["last_check"] = datetime.now().isoformat()
        self.checks["last_cycle"] = float(
            getattr(self.bot, "last_cycle_finished", 0) or 0
        )
        if self._busy():
            self.checks["skipped"] = "execution"
            return
        self.checks["skipped"] = ""
        collector = getattr(self.bot, "task_collector", None)
        if collector is not None:
            self.checks["collector"] = bool(getattr(collector, "running", False))
            if not self.checks["collector"] and getattr(self.bot, "running", False):
                logger.warning("TaskCollector is stopped while bot is running")
                try:
                    await collector.start()
                    self.checks["collector"] = True
                except Exception as error:
                    self.checks["errors"] += 1
                    logger.warning("TaskCollector restart failed: %s", type(error).__name__)
        
        # Check memory
        try:
            if psutil is None:
                mem = 0
            else:
                mem = psutil.Process().memory_info().rss / 1024 / 1024
            self.checks["memory_mb"] = mem
            if mem > self.max_memory_mb:
                logger.warning("⚠️ High memory: %.0f MB", mem)
                await self._handle_high_memory()
        except Exception:
            pass
        
        # Check browser without navigating the execution page.
        page = getattr(self.bot, "page", None)
        if page is None:
            self.checks["browser"] = False
            return
        try:
            closed = page.is_closed() if hasattr(page, "is_closed") else False
        except Exception:
            closed = True
        if closed:
            logger.warning("Browser page closed")
            self.checks["browser"] = False
            self.checks["needs_restart"] = True
            await self._recover_browser("page_closed")
            return
        self.checks["browser"] = True
        try:
            await asyncio.wait_for(page.evaluate("1 + 1"), timeout=15)
        except Exception as error:
            self.checks["browser"] = False
            self.checks["needs_restart"] = True
            logger.warning("Browser responsiveness check failed: %s", type(error).__name__)
            await self._recover_browser("page_unresponsive")
            return
        try:
            url = str(getattr(page, "url", "") or "").lower()
        except Exception:
            url = ""
        if url:
            self.checks["session"] = "/login" not in url and "/signin" not in url and "/auth" not in url

    async def _recover_browser(self, reason: str) -> bool:
        restart = getattr(self.bot, "restart_browser", None)
        if not callable(restart):
            return False
        try:
            recovered = await restart(reason)
            self.checks["browser"] = bool(recovered)
            self.checks["needs_restart"] = not recovered
            if recovered:
                self.checks["collector"] = bool(
                    getattr(getattr(self.bot, "task_collector", None), "running", False)
                )
            return bool(recovered)
        except Exception as error:
            self.checks["errors"] += 1
            logger.warning("Browser recovery failed: %s", type(error).__name__)
            return False
    
    async def _handle_high_memory(self):
        """معالجة الذاكرة العالية"""
        # Clear caches
        if hasattr(self.bot, "tasks_details"):
            if len(self.bot.tasks_details) > 500:
                keys = list(self.bot.tasks_details.keys())[:200]
                for k in keys:
                    self.bot.tasks_details.pop(k, None)
                logger.info("🧹 Cleared old task details")
        
        # Clear history if too large
        if hasattr(self.bot, "history") and len(self.bot.history) > 5000:
            self.bot.history = set(list(self.bot.history)[-2000:])
            logger.info("🧹 Trimmed history")
        
        if hasattr(self.bot, "invalid") and len(self.bot.invalid) > 5000:
            self.bot.invalid = set(list(self.bot.invalid)[-2000:])
            logger.info("🧹 Trimmed invalid")
    
    async def _restart_browser(self):
        """إعادة تشغيل المتصفح بدون إغلاق الصفحة الرئيسية"""
        logger.info("🔄 Restarting browser...")
        try:
            # Don't close the main page - just mark as needing restart
            # The main loop will handle actual restart
            self.checks["browser"] = False
            self.checks["needs_restart"] = True
            logger.info("⚠️ Browser marked for restart")
        except Exception as e:
            logger.error("Browser restart mark failed: %s", e)
            self.checks["errors"] += 1
    
    def get_status(self) -> dict:
        """حالة الصحة"""
        return {
            **self.checks,
            "running": self.running,
        }
