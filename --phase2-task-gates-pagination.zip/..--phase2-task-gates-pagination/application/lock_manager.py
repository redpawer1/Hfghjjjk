"""
Execution Lock Manager - إدارة آمنة للقفل
"""
import asyncio
import logging
from typing import Optional
from datetime import datetime

logger = logging.getLogger("LockManager")

class LockTimeoutError(TimeoutError):
    """خطأ انتهاء مهلة القفل"""
    pass

class ExecutionLockManager:
    """مدير قفل التنفيذ مع ملكية موثوقة"""
    
    def __init__(self, timeout: float = 180.0):
        self._lock = asyncio.Lock()
        self._owner_task: Optional[asyncio.Task] = None
        self._acquired_at: Optional[datetime] = None
        self._timeout = timeout
    
    @property
    def locked(self) -> bool:
        return self._lock.locked()
    
    @property
    def owner(self) -> Optional[asyncio.Task]:
        return self._owner_task
    
    async def acquire(self, timeout: float = None) -> bool:
        """الحصول على القفل - يرفع LockTimeoutError عند الفشل"""
        timeout = timeout or self._timeout
        current = asyncio.current_task()
        
        try:
            await asyncio.wait_for(self._lock.acquire(), timeout=timeout)
            self._owner_task = current
            self._acquired_at = datetime.now()
            logger.debug("Lock acquired by %s", id(current) if current else "unknown")
            return True
        except asyncio.TimeoutError:
            logger.warning("Lock acquire timeout after %.0fs", timeout)
            raise LockTimeoutError(f"Failed to acquire lock within {timeout}s")
        except asyncio.CancelledError:
            logger.debug("Lock acquire cancelled")
            raise
    
    def release(self) -> bool:
        """تحرير القفل فقط إذا كنا المالك"""
        current = asyncio.current_task()
        
        if not self._lock.locked():
            return False
        
        if self._owner_task is not None and self._owner_task != current:
            logger.warning("Task %s attempted to release lock owned by %s", 
                          id(current), id(self._owner_task))
            return False
        
        try:
            self._lock.release()
            self._owner_task = None
            self._acquired_at = None
            logger.debug("Lock released by %s", id(current))
            return True
        except RuntimeError as e:
            logger.warning("Lock release error: %s", e)
            return False
    
    def force_release(self):
        """تحرير قسري - للإغلاق المنسق فقط"""
        if self._lock.locked():
            try:
                self._lock.release()
                logger.info("Lock force released")
            except RuntimeError:
                pass
        self._owner_task = None
        self._acquired_at = None
    
    async def __aenter__(self):
        """دخول - يرفع LockTimeoutError إذا فشل"""
        await self.acquire()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """خروج - يحرر القفل دائمًا"""
        self.release()
        return False
