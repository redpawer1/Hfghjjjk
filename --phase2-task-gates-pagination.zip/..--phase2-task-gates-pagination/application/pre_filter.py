"""
Pre-Filter - فحص سريع قبل الحجز
يتحقق من المنصة المتاحة قبل حجز المهمة
"""
import re
import logging
from typing import Optional, Set

logger = logging.getLogger("PreFilter")

# كلمات محظورة في العنوان
FORBIDDEN_TITLE_WORDS = [
    "регистрация", "регистр", "скачать", "установить",
    "бот", "mini app", "miniapp", "крипт", "usdt", "btc",
    "вывод", "вывести", "кошелек", "wallet",
    "телефон", "номер", "sms", "смс",
]

# أنماط المنصات في العنوان
# المنصات المسموحة فقط
ALLOWED_PLATFORMS = {"youtube", "tiktok", "instagram", "twitter", "rutube", "ozon", "telegram", "wildberries", "vk", "max"}

PLATFORM_PATTERNS = {
    "telegram": [r"telegram", r"телеграм", r"тг\b", r"t\.me"],
    "vk": [r"\bвк\b", r"вконтакте", r"vk\.com", r"vk\.ru"],
    "youtube": [r"youtube", r"ютуб", r"ютюб"],
    "tiktok": [r"tiktok", r"тикток", r"тик\s*ток"],
    "instagram": [r"instagram", r"инстаграм", r"инста"],
    "twitter": [r"twitter", r"твиттер", r"\bx\b"],
    "rutube": [r"rutube", r"рутуб"],
    "ozon": [r"ozon", r"озон"],
    "max": [r"\bmax\b", r"макс"],
    "wildberries": [r"wildberries", r"вайлдберриз", r"вб\b"],
    # منصات معروفة لكن غير مدعومة — تترفض فورًا
    "avito": [r"avito", r"авито"],
    "booking": [r"booking", r"букинг"],
    "chrome": [r"chrome", r"хром", r"расширени"],
    "google": [r"google\s*(play|chrome|maps)", r"гугл"],
    "facebook": [r"facebook", r"фейсбук"],
    "yandex": [r"yandex", r"яндекс"],
    "ok": [r"одноклассник", r"\bok\.ru\b", r"ok\.ru"],
}

def detect_platform_from_title(title: str) -> Optional[str]:
    """اكتشاف المنصة من العنوان"""
    if not title:
        return None
    title_lower = title.lower()
    for platform, patterns in PLATFORM_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, title_lower, re.I):
                return platform
    return None

def title_has_forbidden(title: str) -> bool:
    """هل العنوان فيه كلمة محظورة ككلمة كاملة؟
    «бот» جوه «работа» مش فخ — لازم حد كلمة.
    """
    if not title:
        return False
    title_lower = title.lower().replace("ё", "е")
    for word in FORBIDDEN_TITLE_WORDS:
        if word == "бот":
            if re.search(r"(?<![а-яёa-z0-9])бот", title_lower):
                return True
            continue
        if word in ("смс", "sms", "btc"):
            if re.search(rf"(?<![а-яёa-z0-9]){re.escape(word)}(?![а-яёa-z0-9])", title_lower):
                return True
            continue
        if word in title_lower:
            return True
    return False


# أنماط الفخاخ (المهام اللي عنوانها بسيط لكن المطلوب معقد)
TRAP_PATTERNS = [
    r"стать рефералом",
    r"change-ref",
    r"реферал",
    r"партнёр",
    r"партнер",
    r"приглас",
    r"friends\?act=invite",
    r"скачать приложение",
    r"установить приложение",
    r"play\.google\.com",
    r"apps\.apple\.com",
    r"startapp",
    r"mini\s*app",
    r"usdt",
    r"binance",
    r"bep20",
    r"trc20",
    r"кошелек",
    r"wallet",
    r"вывести деньги",
    r"подтвердить почту",
    r"дебетов",
    r"оформить карт",
    r"альфа-банк",
    r"альфа банк",
    r"идентификац",
    r"паспорт",
    r"банковск\w* карт",
    r"оформлен\w* заявк",
]

def is_trap_task(title: str, description: str = "") -> tuple:
    """
    كشف المهام الفخ
    Returns: (is_trap: bool, reason: str)
    """
    text = f"{title} {description}".lower()
    
    for pattern in TRAP_PATTERNS:
        if re.search(pattern, text, re.I):
            return True, f"trap:{pattern}"
    
    return False, ""



CLEAR_ACTIONS = {
    "like": [r"лайк", r"like", r"класс"],
    "subscribe": [r"подпис", r"вступ", r"subscribe", r"follow"],
    "view": [r"просмотр", r"посмотр", r"view"],
    "comment": [r"коммент", r"comment", r"отзыв"],
    "share": [r"репост", r"поделиться", r"share", r"repost"],
}

def detect_action_from_title(title: str) -> str:
    text = (title or "").lower()
    for action, patterns in CLEAR_ACTIONS.items():
        for pattern in patterns:
            if re.search(pattern, text, re.I):
                return action
    return ""

def classify_title(title: str) -> dict:
    """تصنيف العنوان: high مقبول جدا / suspicious مشكوك / rejected مرفوض."""
    text = (title or "").lower().replace("ё", "е")
    if not text.strip():
        return {"tier": "rejected", "reason": "empty_title", "platform": "", "action": ""}
    if title_has_forbidden(title):
        return {"tier": "rejected", "reason": "forbidden", "platform": "", "action": ""}
    trap, trap_reason = is_trap_task(title)
    if trap:
        return {"tier": "rejected", "reason": trap_reason, "platform": "", "action": ""}
    for phrase in ("только для граждан рф", "только для росси", "гражданам рф"):
        if phrase in text:
            return {"tier": "rejected", "reason": "russian_only", "platform": "", "action": ""}
    platform = detect_platform_from_title(title) or ""
    if platform and platform not in ALLOWED_PLATFORMS:
        return {"tier": "rejected", "reason": f"platform_not_allowed:{platform}", "platform": platform, "action": ""}
    action = detect_action_from_title(title)
    if platform in ALLOWED_PLATFORMS and action:
        return {"tier": "high", "reason": "clear_title", "platform": platform, "action": action}
    if platform in ALLOWED_PLATFORMS:
        return {"tier": "suspicious", "reason": "platform_no_action", "platform": platform, "action": ""}
    return {"tier": "suspicious", "reason": "unknown_title", "platform": "", "action": ""}

def should_accept_task(
    title: str,
    available_platforms: Set[str],
    min_price: float = 0,
    max_price: float = 999999,
    price: float = 0,
) -> tuple:
    """
    فحص سريع قبل الحجز
    
    Returns:
        (should_accept: bool, reason: str)
    """
    # 1. فحص السعر
    if price > 0:
        if price < min_price:
            return False, f"price_low:{price}"
        if price > max_price:
            return False, f"price_high:{price}"
    
    # 2. فحص الفخاخ
    is_trap, trap_reason = is_trap_task(title)
    if is_trap:
        return False, trap_reason
    
    # 3. فحص الكلمات المحظورة
    if title_has_forbidden(title):
        return False, "forbidden_word"
    
    # 3. فحص المنصة - المسموحة فقط
    platform = detect_platform_from_title(title)
    title_low = (title or "").lower()
    bad_title = (
        "авито", "avito", "букинг", "booking", "одноклассник",
        "chrome", "хром", "расширени", "яндекс", "yandex",
    )
    if any(w in title_low for w in bad_title):
        return False, "bad_title_platform"
    classified = classify_title(title)
    if classified["tier"] == "rejected":
        return False, classified["reason"]
    if classified["tier"] == "suspicious":
        return True, "suspicious"
    if not platform:
        return True, "suspicious"
    if platform not in ALLOWED_PLATFORMS:
        return False, f"platform_not_allowed:{platform}"
    if available_platforms and platform not in available_platforms:
        return False, f"no_session:{platform}"
    
    return True, "ok"
