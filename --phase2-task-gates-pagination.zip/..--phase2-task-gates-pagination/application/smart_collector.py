"""
Smart Collector - تجميع ذكي
1. يشوف الجلسات المتاحة
2. يفلتر من العنوان
3. يحجز بس المقبول
4. يبعت للـ main loop
"""
import asyncio
import inspect
import logging
from typing import Set, List, Dict

logger = logging.getLogger("SmartCollector")

try:
    from application.pre_filter import should_accept_task
    from application.pre_filter import classify_title
    from application.session_registry import session_registry
except ImportError:
    should_accept_task = None
    classify_title = None
    session_registry = None

class SmartCollector:
    def __init__(self, bot, account_id: str = "legacy"):
        self.bot = bot
        self.account_id = str(account_id or "legacy")
        self.running = False
        self._task = None
        self.pending: List[dict] = []
        self.processed: Set[str] = set()
        self.processed_task_ids: Set[str] = set()
        self.task_id_urls: Dict[str, str] = {}
        self.stats = {"collected": 0, "filtered": 0, "reserved": 0}
    
    async def start(self):
        if self.running:
            return
        self.running = True
        self._task = asyncio.create_task(self._loop())
        logger.info("🔄 SmartCollector started")
    
    async def stop(self):
        self.running = False
        if self._task:
            self._task.cancel()
    
    async def _loop(self):
        while self.running:
            try:
                await self._collect()
                await asyncio.sleep(15)  # كل 15 ثانية
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning("Error: %s", e)
                await asyncio.sleep(30)
    
    async def _collect(self):
        if not hasattr(self.bot, "get_tasks_api"):
            return
        if not getattr(self.bot, "_allow_new_task_collection", True):
            return
        
        # 1. جيب المهام
        try:
            get_tasks = self.bot.get_tasks_api
            parameters = inspect.signature(get_tasks).parameters
            if "account_id" not in parameters and self.account_id != "legacy":
                raise RuntimeError("collector_api_missing_account_context")
            if "account_id" in parameters:
                tasks = await get_tasks(max_pages=50, account_id=self.account_id)
            else:
                tasks = await get_tasks(max_pages=50)
        except Exception:
            return
        
        if not tasks:
            return
        
        # 2. شوف الجلسات المتاحة
        available = set()
        if session_registry:
            available = session_registry.get_available_platforms()
        logger.info("📋 Available platforms: %s", available)
        
        # 3. فلتر واحجز
        for t in tasks:
            url = t.get("accept_url", "")
            title = t.get("title", "")
            task_id = str(t.get("id") or "").strip()
            
            if not url or url in self.processed:
                continue
            if task_id:
                previous_url = self.task_id_urls.get(task_id)
                if task_id in self.processed_task_ids:
                    if previous_url and previous_url != url:
                        logger.warning(
                            "Duplicate task ID with conflicting URLs: id=%s old=%s new=%s",
                            task_id,
                            previous_url,
                            url,
                        )
                    continue
                self.processed_task_ids.add(task_id)
                self.task_id_urls[task_id] = url
            
            self.processed.add(url)
            self.stats["collected"] += 1
            invalidate = getattr(self.bot, "_invalidate_task_verification", None)
            if callable(invalidate):
                invalidate(url, self.account_id)
            
            # فحص سريع
            if should_accept_task:
                accept, reason = should_accept_task(
                    title, available, min_price=0, max_price=999999, price=0
                )
                if not accept:
                    logger.debug(
                        "preliminary title filter deferred to detailed analysis: %s | %s",
                        title[:30],
                        reason,
                    )
            if classify_title:
                classified = classify_title(title) or {}
                if classified.get("tier") == "rejected":
                    self.stats["filtered"] += 1
                    logger.info(
                        "Skip explicitly rejected title: %s | %s",
                        title[:30],
                        classified.get("reason") or "unknown",
                    )
                    continue
            
            # All collectors use the shared account-aware pipeline.  A
            # collector never performs a URL-only reservation.
            try:
                processor = getattr(self.bot, "_process_collected_task", None)
                if not callable(processor):
                    self.pending.append({
                        "url": url,
                        "title": title,
                        "price": float(t.get("price", 0) or 0),
                        "task_id": task_id,
                        "unu_account_id": self.account_id,
                        "decision_status": "needs_review",
                    })
                    continue
                reserved = await processor(t, account_id=self.account_id)
                if reserved:
                    self.stats["reserved"] += 1
                    self.pending.append({
                        "url": url,
                        "title": title,
                        "price": float(t.get("price", 0) or 0),
                        "task_id": task_id,
                        "unu_account_id": self.account_id,
                    })
            except Exception as error:
                logger.warning("Shared task pipeline failed: %s", error)
        
        logger.info("📊 Stats: collected=%d filtered=%d reserved=%d pending=%d",
                   self.stats["collected"], self.stats["filtered"], 
                   self.stats["reserved"], len(self.pending))
    
    def get_pending(self) -> List[str]:
        urls = [t["url"] for t in self.pending]
        self.pending.clear()
        return urls
    
    def get_stats(self) -> Dict:
        return {**self.stats, "pending": len(self.pending)}
