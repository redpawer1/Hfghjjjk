"""
Lifecycle Manager - إدارة دورة حياة البوت
يتحكم في التشغيل والإيقاف والإغلاق
"""
import asyncio
import logging
from typing import Optional, List, Callable
from datetime import datetime

logger = logging.getLogger("Lifecycle")

class LifecycleManager:
    """مدير دورة حياة البوت"""
    
    def __init__(self):
        self.running = False
        self.started_at: Optional[datetime] = None
        self.background_tasks: List[asyncio.Task] = []
        self.cleanup_handlers: List[Callable] = []
        self._shutdown_event = asyncio.Event()
    
    def register_cleanup(self, handler: Callable):
        """تسجيل دالة تنظيف"""
        self.cleanup_handlers.append(handler)
    
    def register_background_task(self, task: asyncio.Task):
        """تسجيل مهمة خلفية"""
        self.background_tasks.append(task)
    
    async def start(self):
        """بدء التشغيل"""
        if self.running:
            logger.warning("Already running")
            return
        self.running = True
        self.started_at = datetime.now()
        self._shutdown_event.clear()
        logger.info("🚀 Lifecycle started")
    
    async def stop(self):
        """إيقاف التشغيل"""
        if not self.running:
            return
        self.running = False
        self._shutdown_event.set()
        logger.info("🛑 Lifecycle stopping...")
        await self.shutdown()
    
    async def shutdown(self):
        """إغلاق كل الموارد"""
        logger.info("🧹 Starting shutdown...")
        
        # Cancel background tasks
        for task in self.background_tasks:
            if not task.done():
                task.cancel()
                try:
                    await asyncio.wait_for(task, timeout=5.0)
                except (asyncio.CancelledError, asyncio.TimeoutError):
                    pass
        self.background_tasks.clear()
        
        # Run cleanup handlers
        for handler in self.cleanup_handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler()
                else:
                    handler()
            except Exception as e:
                logger.warning("Cleanup handler failed: %s", e)
        
        logger.info("✅ Shutdown complete")
    
    def get_uptime(self) -> Optional[float]:
        """وقت التشغيل بالثواني"""
        if not self.started_at:
            return None
        return (datetime.now() - self.started_at).total_seconds()
    
    async def wait_for_shutdown(self):
        """انتظار الإغلاق"""
        await self._shutdown_event.wait()

# Singleton
lifecycle = LifecycleManager()
