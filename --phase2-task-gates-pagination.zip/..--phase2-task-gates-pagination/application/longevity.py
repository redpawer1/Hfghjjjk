#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
تشغيل طويل: لوجات بتلف، تنظيف سكرين، نبض، ومفكرة أخطاء.
مفيش إعادة تشغيل يدوية. لو العملية فضلت فاتحة سنة، القرص ما يمتلئش
من السكرين واللوج.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path

logger = logging.getLogger("Longevity")

LOG_PATH = Path(os.getenv("BOT_LOG_FILE", "data/logs/unu-bot.log"))
HEARTBEAT_PATH = Path(os.getenv("HEARTBEAT_FILE", "data/heartbeat.json"))
JOURNAL_PATH = Path(os.getenv("ERROR_JOURNAL", "data/logs/error_journal.jsonl"))

_installed = False
_running = False


def attach_logging() -> None:
    global _installed
    if _installed:
        return
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    handler = RotatingFileHandler(
        LOG_PATH,
        maxBytes=8_000_000,
        backupCount=8,
        encoding="utf-8",
    )
    handler.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    ))
    handler.setLevel(logging.INFO)
    root.addHandler(handler)
    root.setLevel(logging.INFO)
    _installed = True
    logger.info("Rotating log attached: %s", LOG_PATH)


def journal(kind: str, message: str, extra: dict | None = None) -> None:
    try:
        JOURNAL_PATH.parent.mkdir(parents=True, exist_ok=True)
        row = {
            "ts": time.time(),
            "kind": kind,
            "message": (message or "")[:500],
            "extra": extra or {},
        }
        with JOURNAL_PATH.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
        if JOURNAL_PATH.stat().st_size > 6_000_000:
            lines = JOURNAL_PATH.read_text(encoding="utf-8", errors="ignore").splitlines()[-1500:]
            JOURNAL_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except Exception as error:
        logger.debug("journal failed: %s", error)


def _trim_tree(root: Path, older_than_sec: int, keep_newest: int = 0) -> int:
    if not root.exists():
        return 0
    now = time.time()
    files = [p for p in root.rglob("*") if p.is_file()]
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    removed = 0
    for index, path in enumerate(files):
        if index < keep_newest:
            continue
        try:
            if now - path.stat().st_mtime > older_than_sec:
                path.unlink()
                removed += 1
        except Exception:
            continue
    return removed


def housekeeping(bot=None) -> None:
    shots = Path(os.getenv("SCREENSHOTS_DIR", "data/screenshots"))
    removed = _trim_tree(shots, older_than_sec=2 * 86400, keep_newest=150)
    removed += _trim_tree(Path("data/idempotency"), older_than_sec=21 * 86400, keep_newest=50)
    if removed:
        logger.info("Housekeeping removed %s old files", removed)
    if bot is None:
        return
    for name, limit in (("history", 20000), ("invalid", 20000), ("validated", 20000)):
        bucket = getattr(bot, name, None)
        if isinstance(bucket, set) and len(bucket) > limit:
            setattr(bot, name, set(list(bucket)[-limit:]))
            logger.info("Trimmed %s to %s", name, limit)
    details = getattr(bot, "tasks_details", None)
    if isinstance(details, dict) and len(details) > 800:
        for key in list(details.keys())[:400]:
            details.pop(key, None)
    reasons = getattr(bot, "invalid_reasons", None)
    if isinstance(reasons, dict) and len(reasons) > 3000:
        for key in list(reasons.keys())[:1500]:
            reasons.pop(key, None)


def write_heartbeat(bot=None) -> None:
    payload = {
        "ts": time.time(),
        "iso": time.strftime("%Y-%m-%d %H:%M:%S"),
        "running": bool(getattr(bot, "running", False)) if bot else False,
        "daily_tasks": int(getattr(bot, "daily_tasks_done", 0) or 0) if bot else 0,
        "daily_earnings": float(getattr(bot, "daily_earnings", 0.0) or 0) if bot else 0,
        "pid": os.getpid(),
    }
    fleet = getattr(bot, "fleet", None) if bot else None
    if fleet is not None:
        payload["unu_account"] = getattr(fleet, "_active_unu_id", None)
    try:
        HEARTBEAT_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = HEARTBEAT_PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        tmp.replace(HEARTBEAT_PATH)
    except Exception as error:
        logger.debug("heartbeat failed: %s", error)


async def loop(bot) -> None:
    global _running
    _running = True
    last_house = 0.0
    while _running and getattr(bot, "running", True):
        try:
            write_heartbeat(bot)
            now = time.time()
            if now - last_house > 1800:
                housekeeping(bot)
                last_house = now
        except Exception as error:
            logger.debug("longevity loop: %s", error)
        await asyncio.sleep(30)
    write_heartbeat(bot)


def stop() -> None:
    global _running
    _running = False
