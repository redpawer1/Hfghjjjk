"""Canonical account/platform session paths.

Session files are discovered by name only; their contents are never logged.
The first account uses ``platform.json`` and later accounts use
``platform-<number>.json``.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Iterable, Optional


DEFAULT_SESSION_ROOT = Path("/root/sessions")

PLATFORM_ALIASES = {
    "x": "twitter",
    "twitter": "twitter",
    "wb": "wildberries",
}

SUPPORTED_PLATFORMS = (
    "unu",
    "vk",
    "telegram",
    "youtube",
    "tiktok",
    "instagram",
    "twitter",
    "rutube",
    "max",
    "ozon",
    "wildberries",
)


def canonical_platform(platform: str) -> str:
    value = str(platform or "").strip().lower()
    return PLATFORM_ALIASES.get(value, value)


def account_number(account_id: str, default: int = 1) -> int:
    match = re.search(r"-(\d+)$", str(account_id or "").strip())
    return int(match.group(1)) if match else default


def session_filename(platform: str, number: int = 1) -> str:
    platform = canonical_platform(platform)
    if platform == "twitter":
        platform = "x"
    suffix = "" if int(number) == 1 else f"-{int(number)}"
    return f"{platform}{suffix}.json"


def session_path(
    platform: str,
    number: int = 1,
    root: Path | str = DEFAULT_SESSION_ROOT,
) -> Path:
    return Path(root).expanduser() / session_filename(platform, number)


def candidate_paths(
    platform: str,
    number: int = 1,
    roots: Iterable[Path | str] = (DEFAULT_SESSION_ROOT,),
) -> list[Path]:
    """Return canonical path first, followed by compatibility aliases."""
    platform = canonical_platform(platform)
    names = [session_filename(platform, number)]
    if platform == "unu" and int(number) == 1:
        names += ["storage_state.json"]
    if platform == "twitter":
        names += [f"twitter{'-' + str(number) if int(number) != 1 else ''}.json"]
    result: list[Path] = []
    for root in roots:
        root = Path(root).expanduser()
        for name in names:
            path = root / name
            if path not in result:
                result.append(path)
    return result


def validate_session_file(path: Path | str, platform: str) -> tuple[bool, str]:
    """Validate shape only; never returns session values."""
    candidate = Path(path).expanduser()
    if not candidate.is_file():
        return False, "missing"
    try:
        data = json.loads(candidate.read_text(encoding="utf-8"))
    except Exception:
        return False, "invalid_json"
    if canonical_platform(platform) == "telegram":
        return (bool(data), "valid" if data else "empty")
    if not isinstance(data, dict):
        return False, "invalid_shape"
    if "cookies" in data and not isinstance(data.get("cookies"), list):
        return False, "invalid_cookies"
    if canonical_platform(platform) == "unu":
        cookies = data.get("cookies") or []
        if not any(
            isinstance(cookie, dict)
            and "unu.im" in str(cookie.get("domain") or "")
            and cookie.get("name")
            for cookie in cookies
        ):
            return False, "missing_unu_cookie"
    return True, "valid"
