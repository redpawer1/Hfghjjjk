"""
Task Queue - طابور مهام موحد مع تخزين دائم
"""
import json
import logging
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, List
from enum import Enum

logger = logging.getLogger("TaskQueue")

class TaskStatus(Enum):
    DISCOVERED = "discovered"
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    WAITING_HUMAN = "waiting_human"
    AWAITING_APPROVAL = "awaiting_approval"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRYABLE = "retryable"
    REJECTED = "rejected"

class TaskQueue:
    """طابور مهام موحد مع تخزين في SQLite"""
    
    def __init__(self, db_path: str = "data/unu_bot.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()
    
    def _get_conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=30.0)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=30000")
        return conn
    
    def _init_db(self):
        with self._get_conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS task_queue (
                    id TEXT PRIMARY KEY,
                    url TEXT NOT NULL,
                    title TEXT,
                    price REAL DEFAULT 0,
                    status TEXT DEFAULT 'pending',
                    attempts INTEGER DEFAULT 0,
                    max_attempts INTEGER DEFAULT 3,
                    last_error TEXT,
                    created_at TEXT,
                    updated_at TEXT,
                    claimed_at TEXT,
                    completed_at TEXT,
                    retry_after TEXT,
                    data TEXT
                )
            """)
            columns = {
                row[1]
                for row in conn.execute("PRAGMA table_info(task_queue)").fetchall()
            }
            if "account_id" not in columns:
                conn.execute(
                    "ALTER TABLE task_queue ADD COLUMN account_id TEXT NOT NULL DEFAULT 'legacy'"
                )
            if "task_id" not in columns:
                conn.execute(
                    "ALTER TABLE task_queue ADD COLUMN task_id TEXT NOT NULL DEFAULT ''"
                )
                conn.execute("UPDATE task_queue SET task_id = id WHERE task_id = ''")
            conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS uq_task_queue_account_task "
                "ON task_queue(account_id, task_id)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_tq_account_status "
                "ON task_queue(account_id, status)"
            )
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tq_status ON task_queue(status)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tq_retry ON task_queue(retry_after)")
            conn.commit()
    
    def add(
        self,
        task_id: str,
        url: str,
        title: str = "",
        price: float = 0,
        data: Dict = None,
        account_id: str = "legacy",
    ) -> bool:
        now = datetime.now().isoformat()
        scoped_id = f"{account_id}:{task_id}" if account_id != "legacy" else task_id
        try:
            with self._get_conn() as conn:
                conflict = conn.execute(
                    "SELECT url FROM task_queue WHERE account_id=? AND task_id=?",
                    (str(account_id or "legacy"), str(task_id)),
                ).fetchone()
                if conflict and str(conflict[0]) != str(url):
                    logger.warning(
                        "task id/url conflict preserved once: account=%s task_id=%s",
                        account_id, task_id,
                    )
                    return False
                conn.execute("""
                    INSERT OR IGNORE INTO task_queue 
                    (id, account_id, task_id, url, title, price, status, created_at, updated_at, data)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    scoped_id,
                    account_id,
                    str(task_id),
                    url,
                    title,
                    price,
                    TaskStatus.PENDING.value,
                    now,
                    now,
                    json.dumps(data or {}),
                ))
                conn.commit()
                return conn.total_changes > 0
        except Exception as e:
            logger.warning("Add task failed: %s", e)
            return False
    
    def claim_next(self, worker_id: str = None, account_id: str = "legacy") -> Optional[Dict]:
        """حجز المهمة التالية ذريًا"""
        now = datetime.now().isoformat()
        try:
            with self._get_conn() as conn:
                conn.row_factory = sqlite3.Row
                # Get next available task
                row = conn.execute("""
                    SELECT * FROM task_queue 
                    WHERE account_id = ?
                    AND status IN ('discovered', 'pending', 'retryable')
                    AND (retry_after IS NULL OR retry_after <= ?)
                    AND attempts < max_attempts
                    ORDER BY created_at ASC
                    LIMIT 1
                """, (str(account_id or "legacy"), now)).fetchone()
                
                if not row:
                    return None
                
                # Claim it atomically
                result = conn.execute("""
                    UPDATE task_queue 
                    SET status = 'in_progress', claimed_at = ?, updated_at = ?
                    WHERE id = ? AND status IN ('discovered', 'pending', 'retryable')
                """, (now, now, row['id']))
                conn.commit()
                
                if result.rowcount > 0:
                    return dict(row)
                return None
        except Exception as e:
            logger.warning("Claim failed: %s", e)
            return None
    
    def claim_batch(self, limit: int = 10, account_id: str = "legacy") -> List[Dict]:
        """حجز مجموعة مهام"""
        claimed = []
        for _ in range(limit):
            task = self.claim_next(account_id=account_id)
            if task:
                claimed.append(task)
            else:
                break
        return claimed
    
    def update_status(self, task_id: str, status: TaskStatus, error: str = None,
                      increment_attempts: bool = False, account_id: str = "legacy"):
        now = datetime.now().isoformat()
        try:
            with self._get_conn() as conn:
                if status == TaskStatus.COMPLETED:
                    conn.execute("""
                        UPDATE task_queue SET status = ?, updated_at = ?, completed_at = ?
                        WHERE id = ? AND account_id = ?
                    """, (status.value, now, now, task_id, str(account_id or "legacy")))
                elif status == TaskStatus.RETRYABLE:
                    retry_after = (datetime.now() + timedelta(minutes=5)).isoformat()
                    conn.execute("""
                        UPDATE task_queue 
                        SET status = ?, updated_at = ?, last_error = ?, retry_after = ?,
                            attempts = attempts + 1
                        WHERE id = ? AND account_id = ?
                    """, (status.value, now, error, retry_after, task_id, str(account_id or "legacy")))
                else:
                    if increment_attempts:
                        conn.execute("""
                            UPDATE task_queue 
                            SET status = ?, updated_at = ?, last_error = ?, attempts = attempts + 1
                            WHERE id = ? AND account_id = ?
                        """, (status.value, now, error, task_id, str(account_id or "legacy")))
                    else:
                        conn.execute("""
                            UPDATE task_queue SET status = ?, updated_at = ?, last_error = ?
                            WHERE id = ? AND account_id = ?
                        """, (status.value, now, error, task_id, str(account_id or "legacy")))
                conn.commit()
        except Exception as e:
            logger.warning("Update status failed: %s", e)
    
    def recover_stale(self, timeout_minutes: int = 30) -> int:
        """استعادة المهام العالقة"""
        cutoff = (datetime.now() - timedelta(minutes=timeout_minutes)).isoformat()
        try:
            with self._get_conn() as conn:
                result = conn.execute("""
                    UPDATE task_queue 
                    SET status = 'retryable', updated_at = ?, last_error = 'stale_recovery'
                    WHERE status = 'in_progress' AND claimed_at < ?
                """, (datetime.now().isoformat(), cutoff))
                conn.commit()
                return result.rowcount
        except Exception as e:
            logger.warning("Recover stale failed: %s", e)
            return 0
    
    def get_pending(self, limit: int = 50, account_id: str = "legacy") -> List[Dict]:
        """المهام القابلة للتنفيذ الآن، من غير ما تعتبرها مكتملة."""
        now = datetime.now().isoformat()
        try:
            with self._get_conn() as conn:
                conn.row_factory = sqlite3.Row
                rows = conn.execute("""
                    SELECT * FROM task_queue
                    WHERE account_id = ?
                    AND status IN ('discovered', 'pending', 'retryable', 'awaiting_approval')
                    AND (retry_after IS NULL OR retry_after <= ?)
                    AND attempts < max_attempts
                    ORDER BY created_at ASC
                    LIMIT ?
                """, (account_id, now, int(limit))).fetchall()
                return [dict(row) for row in rows]
        except Exception as e:
            logger.warning("get_pending failed: %s", e)
            return []

    def get_pending_count(self, account_id: Optional[str] = None) -> int:
        try:
            with self._get_conn() as conn:
                if account_id is None:
                    row = conn.execute("""
                        SELECT COUNT(*) FROM task_queue
                        WHERE status IN ('discovered', 'pending', 'retryable', 'awaiting_approval')
                    """).fetchone()
                else:
                    row = conn.execute("""
                        SELECT COUNT(*) FROM task_queue
                        WHERE account_id = ?
                        AND status IN ('discovered', 'pending', 'retryable', 'awaiting_approval')
                    """, (str(account_id),)).fetchone()
                return row[0] if row else 0
        except Exception:
            return 0
    
    def get_stats(self) -> Dict:
        try:
            with self._get_conn() as conn:
                rows = conn.execute("""
                    SELECT status, COUNT(*) as count FROM task_queue GROUP BY status
                """).fetchall()
                return {r[0]: r[1] for r in rows}
        except Exception:
            return {}
    
    def exists(self, task_id: str, account_id: str = "legacy") -> bool:
        try:
            with self._get_conn() as conn:
                row = conn.execute(
                    "SELECT 1 FROM task_queue WHERE id = ? AND account_id = ?",
                    (task_id, str(account_id or "legacy")),
                ).fetchone()
                return row is not None
        except Exception:
            return False
