#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU BOT — SQLite Persistence (WAL)

يحفظ حالة التشغيل عبر restart/crash/deploy:
  tasks / attempts / settings / daily_stats / earnings / history

لا يستبدل الـ RAM state فورًا بالكامل؛ طبقة إضافية يقرأ/يكتب منها main.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import threading
import time
import shutil
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("Persistence")

# Task state machine values
TASK_STATES = (
    "DISCOVERED",
    "FILTERED",
    "ANALYZING",
    "VALIDATED",
    "ACCEPT_PENDING",
    "ACCEPTED",
    "EXECUTING",
    "EXECUTED",
    "PROOF_PENDING",
    "SUBMITTED",
    "VERIFIED",
    "COMPLETED",
    "FAILED_RETRYABLE",
    "FAILED_PERMANENT",
    "BLOCKED",
    "MANUAL_REVIEW",
    "ABORTED",
    "PARTIAL_FAILURE",
)


class BotPersistence:
    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None
        self._ensure()

    def _connect(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(
                str(self.db_path),
                check_same_thread=False,
                timeout=30.0,
            )
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL;")
            self._conn.execute("PRAGMA synchronous=NORMAL;")
            self._conn.execute("PRAGMA foreign_keys=ON;")
        return self._conn

    def _ensure(self) -> None:
        with self._lock:
            if self.db_path.exists():
                backup = self.db_path.with_suffix(self.db_path.suffix + ".migration.bak")
                if not backup.exists():
                    try:
                        shutil.copy2(self.db_path, backup)
                    except OSError as error:
                        logger.warning("database backup failed before migration: %s", error)
            conn = self._connect()
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS daily_stats (
                    day TEXT PRIMARY KEY,
                    tasks_done INTEGER NOT NULL DEFAULT 0,
                    earnings REAL NOT NULL DEFAULT 0,
                    updated_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS task_urls (
                    url_key TEXT PRIMARY KEY,
                    task_id TEXT,
                    url TEXT NOT NULL,
                    state TEXT NOT NULL,
                    platform TEXT,
                    action TEXT,
                    price REAL,
                    reason TEXT,
                    payload TEXT,
                    updated_at REAL NOT NULL,
                    created_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS task_attempts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    url_key TEXT NOT NULL,
                    attempt_no INTEGER NOT NULL,
                    success INTEGER NOT NULL,
                    status TEXT,
                    detail TEXT,
                    created_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS history_keys (
                    key TEXT PRIMARY KEY,
                    kind TEXT NOT NULL,
                    created_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS dict_calibration (
                    bucket TEXT PRIMARY KEY,
                    total INTEGER NOT NULL DEFAULT 0,
                    correct INTEGER NOT NULL DEFAULT 0,
                    updated_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS audit_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    level TEXT,
                    message TEXT,
                    created_at REAL NOT NULL
                );
                """
            )
            for table, column in (
                ("task_urls", "account_id"),
                ("task_urls", "task_id"),
                ("task_attempts", "account_id"),
                ("history_keys", "account_id"),
            ):
                columns = {
                    row["name"]
                    for row in conn.execute(f"PRAGMA table_info({table})").fetchall()
                }
                if column not in columns:
                    conn.execute(
                        f"ALTER TABLE {table} ADD COLUMN {column} TEXT NOT NULL DEFAULT 'legacy'"
                    )
            history_sql = conn.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name='history_keys'"
            ).fetchone()["sql"] or ""
            if "KEY TEXT PRIMARY KEY" in history_sql.upper():
                backup_name = f"history_keys_legacy_backup_{int(time.time())}"
                conn.execute("ALTER TABLE history_keys RENAME TO " + backup_name)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS history_keys (
                        key TEXT NOT NULL,
                        kind TEXT NOT NULL,
                        created_at REAL NOT NULL,
                        account_id TEXT NOT NULL DEFAULT 'legacy',
                        PRIMARY KEY (key, kind, account_id)
                    )
                """)
                conn.execute("""
                    INSERT OR IGNORE INTO history_keys
                    (key, kind, created_at, account_id)
                    SELECT key, kind, created_at, account_id FROM %s
                """ % backup_name)
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_task_urls_account "
                "ON task_urls(account_id, url_key)"
            )
            conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS uq_task_urls_account_url "
                "ON task_urls(account_id, url)"
            )
            conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS uq_task_urls_account_task "
                "ON task_urls(account_id, task_id) WHERE task_id IS NOT NULL AND task_id <> ''"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_history_account "
                "ON history_keys(account_id, kind)"
            )
            conn.commit()

    # ---------- settings ----------
    def set_setting(self, key: str, value: Any) -> None:
        with self._lock:
            conn = self._connect()
            conn.execute(
                "INSERT INTO settings(key, value, updated_at) VALUES(?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
                (str(key), json.dumps(value, ensure_ascii=False), time.time()),
            )
            conn.commit()

    def get_setting(self, key: str, default: Any = None) -> Any:
        with self._lock:
            conn = self._connect()
            row = conn.execute(
                "SELECT value FROM settings WHERE key=?", (str(key),)
            ).fetchone()
            if not row:
                return default
            try:
                return json.loads(row["value"])
            except Exception:
                return row["value"]

    # ---------- daily ----------
    def bump_daily(self, earnings: float = 0.0, tasks: int = 1) -> dict:
        day = time.strftime("%Y-%m-%d")
        with self._lock:
            conn = self._connect()
            row = conn.execute(
                "SELECT tasks_done, earnings FROM daily_stats WHERE day=?", (day,)
            ).fetchone()
            if row:
                td = int(row["tasks_done"]) + int(tasks)
                er = float(row["earnings"]) + float(earnings or 0)
                conn.execute(
                    "UPDATE daily_stats SET tasks_done=?, earnings=?, updated_at=? WHERE day=?",
                    (td, er, time.time(), day),
                )
            else:
                td = int(tasks)
                er = float(earnings or 0)
                conn.execute(
                    "INSERT INTO daily_stats(day, tasks_done, earnings, updated_at) VALUES(?,?,?,?)",
                    (day, td, er, time.time()),
                )
            conn.commit()
            return {"day": day, "tasks_done": td, "earnings": er}

    def get_daily(self) -> dict:
        day = time.strftime("%Y-%m-%d")
        with self._lock:
            conn = self._connect()
            row = conn.execute(
                "SELECT tasks_done, earnings FROM daily_stats WHERE day=?", (day,)
            ).fetchone()
            if not row:
                return {"day": day, "tasks_done": 0, "earnings": 0.0}
            return {
                "day": day,
                "tasks_done": int(row["tasks_done"]),
                "earnings": float(row["earnings"]),
            }

    # ---------- task state ----------
    def upsert_task(
        self,
        url: str,
        state: str,
        *,
        platform: str = "",
        action: str = "",
        price: float = 0.0,
        reason: str = "",
        payload: Optional[dict] = None,
        account_id: str = "legacy",
        task_id: str = "",
    ) -> None:
        raw_key = str(url or "").rstrip("/")
        account_id = str(account_id or "legacy")
        url_key = f"{account_id}:{raw_key}" if account_id != "legacy" else raw_key
        if not url_key:
            return
        now = time.time()
        with self._lock:
            conn = self._connect()
            existing = conn.execute(
                "SELECT created_at FROM task_urls WHERE url_key=?", (url_key,)
            ).fetchone()
            if task_id:
                task_conflict = conn.execute(
                    "SELECT url FROM task_urls WHERE account_id=? AND task_id=?",
                    (account_id, str(task_id)),
                ).fetchone()
                if task_conflict and str(task_conflict["url"]).rstrip("/") != str(url).rstrip("/"):
                    logger.warning(
                        "task id/url conflict preserved once: account=%s task_id=%s old=%s new=%s",
                        account_id, task_id, task_conflict["url"], url,
                    )
                    return
            created = float(existing["created_at"]) if existing else now
            conn.execute(
                "INSERT INTO task_urls(url_key, task_id, url, state, platform, action, price, reason, payload, updated_at, created_at, account_id) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(url_key) DO UPDATE SET "
                "state=excluded.state, platform=excluded.platform, action=excluded.action, "
                "price=excluded.price, reason=excluded.reason, payload=excluded.payload, updated_at=excluded.updated_at",
                (
                    url_key,
                    str(task_id or ""),
                    str(url),
                    str(state or "DISCOVERED"),
                    str(platform or ""),
                    str(action or ""),
                    float(price or 0),
                    str(reason or ""),
                    json.dumps(payload or {}, ensure_ascii=False),
                    now,
                    created,
                    account_id,
                ),
            )
            conn.commit()

    def log_attempt(
        self,
        url: str,
        success: bool,
        status: str = "",
        detail: Optional[dict] = None,
        account_id: str = "legacy",
    ) -> None:
        raw_key = str(url or "").rstrip("/")
        account_id = str(account_id or "legacy")
        url_key = f"{account_id}:{raw_key}" if account_id != "legacy" else raw_key
        if not url_key:
            return
        with self._lock:
            conn = self._connect()
            n = conn.execute(
                "SELECT COUNT(*) AS c FROM task_attempts WHERE url_key=?", (url_key,)
            ).fetchone()
            attempt_no = int(n["c"] if n else 0) + 1
            conn.execute(
                "INSERT INTO task_attempts(url_key, attempt_no, success, status, detail, created_at, account_id) "
                "VALUES(?,?,?,?,?,?,?)",
                (
                    url_key,
                    attempt_no,
                    1 if success else 0,
                    str(status or ""),
                    json.dumps(detail or {}, ensure_ascii=False),
                    time.time(),
                    account_id,
                ),
            )
            conn.commit()

    # ---------- history sets ----------
    def add_history(self, key: str, kind: str = "history", account_id: str = "legacy") -> None:
        with self._lock:
            conn = self._connect()
            conn.execute(
                "INSERT OR IGNORE INTO history_keys(key, kind, created_at, account_id) VALUES(?,?,?,?)",
                (str(key), str(kind), time.time(), str(account_id or "legacy")),
            )
            conn.commit()

    def load_history_set(self, kind: str = "history", account_id: str = "legacy") -> set:
        with self._lock:
            conn = self._connect()
            rows = conn.execute(
                "SELECT key FROM history_keys WHERE kind=? AND account_id=?",
                (str(kind), str(account_id or "legacy")),
            ).fetchall()
            return {str(r["key"]) for r in rows}

    # ---------- dictionary calibration ----------
    def record_dict_outcome(self, confidence: float, correct: bool) -> None:
        if confidence >= 0.90:
            bucket = "0.90-1.00"
        elif confidence >= 0.80:
            bucket = "0.80-0.89"
        elif confidence >= 0.70:
            bucket = "0.70-0.79"
        else:
            bucket = "0.00-0.69"
        with self._lock:
            conn = self._connect()
            row = conn.execute(
                "SELECT total, correct FROM dict_calibration WHERE bucket=?", (bucket,)
            ).fetchone()
            if row:
                total = int(row["total"]) + 1
                corr = int(row["correct"]) + (1 if correct else 0)
                conn.execute(
                    "UPDATE dict_calibration SET total=?, correct=?, updated_at=? WHERE bucket=?",
                    (total, corr, time.time(), bucket),
                )
            else:
                conn.execute(
                    "INSERT INTO dict_calibration(bucket, total, correct, updated_at) VALUES(?,?,?,?)",
                    (bucket, 1, 1 if correct else 0, time.time()),
                )
            conn.commit()

    def calibrated_rate(self, confidence: float) -> Optional[float]:
        if confidence >= 0.90:
            bucket = "0.90-1.00"
        elif confidence >= 0.80:
            bucket = "0.80-0.89"
        elif confidence >= 0.70:
            bucket = "0.70-0.79"
        else:
            bucket = "0.00-0.69"
        with self._lock:
            conn = self._connect()
            row = conn.execute(
                "SELECT total, correct FROM dict_calibration WHERE bucket=?", (bucket,)
            ).fetchone()
            if not row or int(row["total"]) < 5:
                return None
            return float(row["correct"]) / float(row["total"])

    def close(self) -> None:
        with self._lock:
            if self._conn is not None:
                try:
                    self._conn.close()
                except Exception:
                    pass
                self._conn = None


_persistence: Optional[BotPersistence] = None


def get_persistence(db_path: str | Path | None = None) -> BotPersistence:
    global _persistence
    if _persistence is None:
        if db_path is None:
            try:
                from config import APP
                db_path = APP.DATABASE_PATH
            except Exception:
                db_path = Path("data/unubot_database.sqlite")
        _persistence = BotPersistence(db_path)
    return _persistence
