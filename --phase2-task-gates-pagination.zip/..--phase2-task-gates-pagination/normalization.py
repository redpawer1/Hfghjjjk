#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UNU BOT — Unified Normalization Layer

مصدر واحد لتطبيع:
  platform / action / proof / domain / url

كل الطبقات (main, skill_manager, dictionary, ai) يُفضّل تستورد من هنا
بدل تكرار aliases مختلفة في كل ملف.
لا يحذف أي منطق قديم في الملفات الأخرى؛ طبقة إضافية موحّدة.
"""

from __future__ import annotations

import re
from typing import Any, Optional
from urllib.parse import urlparse, urlunparse


# ============================================================
# Platform
# ============================================================

PLATFORM_ALIASES: dict[str, str] = {
    # telegram
    "telegram": "telegram",
    "телеграм": "telegram",
    "телега": "telegram",
    "тг": "telegram",
    "tg": "telegram",
    "t.me": "telegram",
    "telegram web": "telegram",
    # vk
    "vk": "vk",
    "вк": "vk",
    "вконтакте": "vk",
    "vk.com": "vk",
    "vk.ru": "vk",
    "m.vk.ru": "vk",
    "vk reels": "vk",
    "вк рилс": "vk",
    "клипы": "vk",
    # tiktok
    "tiktok": "tiktok",
    "тикток": "tiktok",
    "тик ток": "tiktok",
    "tt": "tiktok",
    # youtube
    "youtube": "youtube",
    "ютуб": "youtube",
    "ютюб": "youtube",
    "yt": "youtube",
    # instagram
    "instagram": "instagram",
    "инстаграм": "instagram",
    "инста": "instagram",
    "ig": "instagram",
    # rutube
    "rutube": "rutube",
    "рутуб": "rutube",
    "рутьюб": "rutube",
    # twitter / x
    "twitter": "twitter",
    "x": "twitter",
    "x.com": "twitter",
    "twitter/x": "twitter",
    "твиттер": "twitter",
    # max
    "max": "max",
    "макс": "max",
    "мах": "max",
    "max messenger": "max",
    "мессенджер max": "max",
    # others
    "facebook": "facebook",
    "фейсбук": "facebook",
    "fb": "facebook",
    "discord": "discord",
    "дискорд": "discord",
    "reddit": "reddit",
    "реддит": "reddit",
    "avito": "avito",
    "авито": "avito",
    "yandex": "yandex",
    "яндекс": "yandex",
    "дзен": "yandex",
    "dzen": "yandex",
    "google_maps": "google_maps",
    "google maps": "google_maps",
    "гугл карты": "google_maps",
    "google_play": "google_play",
    "google play": "google_play",
    "app_store": "app_store",
    "app store": "app_store",
    "website": "website",
    "site": "website",
    "сайт": "website",
    "review": "review",
}


ACTION_ALIASES: dict[str, str] = {
    "subscribe": "subscribe",
    "follow": "subscribe",
    "join": "subscribe",
    "подписаться": "subscribe",
    "подписка": "subscribe",
    "вступить": "subscribe",
    "اشتراك": "subscribe",
    "متابعة": "subscribe",
    "like": "like",
    "лайк": "like",
    "поставить лайк": "like",
    "إعجاب": "like",
    "لايك": "like",
    "comment": "comment",
    "коммент": "comment",
    "комментарий": "comment",
    "تعليق": "comment",
    "view": "view",
    "watch": "view",
    "просмотр": "view",
    "смотреть": "view",
    "مشاهدة": "view",
    "share": "share",
    "поделиться": "share",
    "مشاركة": "share",
    "repost": "repost",
    "репост": "repost",
    "ретвит": "repost",
    "retweet": "repost",
    "register": "register",
    "регистрация": "register",
    "تسجيل": "register",
    "review": "review",
    "отзыв": "review",
    "تقييم": "review",
    "start_bot": "start_bot",
    "запустить бота": "start_bot",
    "vote": "vote",
    "install": "install",
}


PROOF_ALIASES: dict[str, str] = {
    "screenshot": "screenshot",
    "скриншот": "screenshot",
    "скрин": "screenshot",
    "سكرين": "screenshot",
    "username": "username",
    "ник": "username",
    "логин": "username",
    "text": "text",
    "текст": "text",
    "link": "link",
    "ссылка": "link",
    "email": "email",
}


def _norm_text(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip().lower().replace("ё", "е")
    text = re.sub(r"\s+", " ", text)
    return text


def normalize_platform(value: Any) -> str:
    raw = _norm_text(value)
    if not raw:
        return ""
    if raw in PLATFORM_ALIASES:
        return PLATFORM_ALIASES[raw]
    # partial contains
    for alias, canonical in PLATFORM_ALIASES.items():
        if alias and alias in raw:
            return canonical
    return raw


def normalize_action(value: Any, platform: str = "") -> str:
    raw = _norm_text(value)
    if not raw:
        return "unknown"
    if raw in ACTION_ALIASES:
        action = ACTION_ALIASES[raw]
    else:
        action = raw
        for alias, canonical in ACTION_ALIASES.items():
            if alias in raw:
                action = canonical
                break
    plat = normalize_platform(platform)
    # twitter/tiktok: share ≈ repost
    if plat in {"twitter", "x", "tiktok"} and action in {"share", "retweet"}:
        action = "repost"
    if plat == "instagram" and action == "follow":
        action = "subscribe"
    return action


def normalize_proof(value: Any) -> str:
    raw = _norm_text(value)
    if not raw:
        return "screenshot"
    if raw in PROOF_ALIASES:
        return PROOF_ALIASES[raw]
    for alias, canonical in PROOF_ALIASES.items():
        if alias in raw:
            return canonical
    return raw


def normalize_domain(url_or_host: Any) -> str:
    text = str(url_or_host or "").strip().lower()
    if not text:
        return ""
    if "://" not in text:
        host = text.split("/")[0]
    else:
        try:
            host = (urlparse(text).hostname or "").lower()
        except Exception:
            host = ""
    return host.removeprefix("www.")


def normalize_url(url: Any) -> str:
    text = str(url or "").strip().strip("`")
    if not text:
        return ""
    try:
        parsed = urlparse(text)
        if not parsed.scheme:
            return text
        parsed = parsed._replace(fragment="")
        return urlunparse(parsed).rstrip("/")
    except Exception:
        return text


def platform_from_url(url: Any) -> Optional[str]:
    host = normalize_domain(url)
    if not host:
        return None
    mapping = {
        "t.me": "telegram",
        "telegram.me": "telegram",
        "telegram.org": "telegram",
        "vk.com": "vk",
        "vk.ru": "vk",
        "m.vk.ru": "vk",
        "tiktok.com": "tiktok",
        "instagram.com": "instagram",
        "youtube.com": "youtube",
        "youtu.be": "youtube",
        "rutube.ru": "rutube",
        "x.com": "twitter",
        "twitter.com": "twitter",
        "max.ru": "max",
        "facebook.com": "facebook",
        "avito.ru": "avito",
        "reddit.com": "reddit",
        "discord.com": "discord",
        "discord.gg": "discord",
    }
    for domain, plat in mapping.items():
        if host == domain or host.endswith("." + domain):
            return plat
    return None


__all__ = [
    "PLATFORM_ALIASES",
    "ACTION_ALIASES",
    "PROOF_ALIASES",
    "normalize_platform",
    "normalize_action",
    "normalize_proof",
    "normalize_domain",
    "normalize_url",
    "platform_from_url",
]
